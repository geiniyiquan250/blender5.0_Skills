# Blender技能包API文档补充任务

## 任务目标

**继续为Blender技能包补充API文档**

### 核心路径
- **技能包路径**: `skills-blender5.0`
- **模板规范**: `skills-main`
- **API来源**: `blender_python_reference_5_0`

---

## 任务说明

### 执行原则
1. **只增不改** - 只能创建新的API模块文档，不能修改或删除已有文档
2. **遵循规范** - 必须严格按照 `skills-main` 的模板格式编写
3. **来源唯一** - 所有API内容必须来源于 `blender_python_reference_5_0`
4. **中文注释** - 代码注释使用中文口语，简单直白

### 文档结构要求
每个API模块文档必须包含：
```
# bpy.ops.xxx - 模块名称

## 概述
- 模块功能简介

## 核心功能
- 基础用法示例
- 常用参数设置

## 实用函数
- 封装的高级功能函数

## 常见问题排查
- 典型问题和解决方案
```

---

## 快速执行步骤

### 1. 定位缺失模块
```bash
# 检查已有模块
ls skills-blender5.0/references/

# 扫描bpy.ops操作符
grep -r "bpy.ops\." blender_python_reference_5_0/ | cut -d'.' -f1-3 | sort -u

# 对比找出缺失的模块
```

### 2. 复制模板格式
从 `skills-main` 中选择一个已有的API模块文档作为模板：
- 复制文档结构
- 复制代码格式
- 复制注释风格

### 3. 编写新模块
- 打开 `blender_python_reference_5_0` 查找对应API
- 按照模板格式编写文档
- 保持代码示例简洁实用

### 4. 验证完整性
- 检查文档结构完整性
- 验证代码示例语法正确
- 确认没有重复创建

---

## 任务模板

### 消息模板（直接复制使用）
```
继续为我的blender技能包补充api skills-blender5.0 ，以它的规范为模板 skills-main ，以blender5.0api为来源 blender_python_reference_5_0
```

### 执行检查清单
- [ ] 定位3-5个缺失的API模块
- [ ] 为每个模块创建完整的文档
- [ ] 文档包含：概述、核心功能、实用函数、问题排查
- [ ] 保持与现有文档风格一致
- [ ] 不修改或删除任何已有文档

---

## 常用命令速查

### 查找缺失模块
```bash
# 查找所有bpy.ops操作符
cd blender_python_reference_5_0
find . -name "*.rst" -o -name "*.html" | xargs grep "bpy.ops\." | cut -d'.' -f1-4 | sort -u

# 列出已有模块
ls ../skills-blender5.0/references/bpy_ops_*.md | basename -s .md | sort
```

### 批量创建
```bash
# 循环创建缺失模块
for module in module1 module2 module3; do
  cp template_module.md bpy_ops_${module}_module.md
done
```

---

## 历史记录

### 已完成模块
- bpy.ops基础操作（object, transform, mesh等）
- bpy.ops导入导出（gltf, fbx, obj, abc等）
- bpy.ops动画系统（anim, action, pose等）
- bpy.ops渲染输出（render, export系列）
- 核心模块（bpy, bmesh, gpu, mathutils）

### 待补充模块
- 持续扫描 blender_python_reference_5_0 中未文档化的API

---

## 注意事项

1. **文件命名**: `bpy_ops_模块名_module.md`
2. **语言一致**: 所有说明文字使用中文
3. **代码注释**: 中文口语化，简单直接
4. **不写总结**: 文档内不添加使用总结或方法说明
5. **保持简洁**: 避免过度解释技术细节
