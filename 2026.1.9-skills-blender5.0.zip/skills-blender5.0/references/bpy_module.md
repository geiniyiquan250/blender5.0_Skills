# bpy Module Reference

Complete reference for the main Blender Python API module.

## bpy.context

Context-aware access to Blender data.

### Properties

- `active_object` - Currently selected object
- `selected_objects` - All selected objects
- `scene` - Current scene
- `view_layer` - Current view layer
- `window` - Current window
- `screen` - Current screen
- `area` - Current area
- `region` - Current region
- `space_data` - Current space data
- `region_data` - Current region data
- `mode` - Current mode (OBJECT', EDIT', SCULPT', etc.)

### Methods

- `copy()` - Create a copy of context
- `temp_override()` - Create temporary override context

### Context Usage Examples

```python
import bpy

# 获取当前上下文
context = bpy.context

# 获取活动对象
active_obj = context.active_object

# 获取所有选中对象
selected_objs = context.selected_objects

# 获取当前场景
current_scene = context.scene

# 创建临时上下文覆盖
with context.temp_override(selected_objects=[obj1, obj2]):
    # 在此上下文中执行操作
    bpy.ops.object.select_all(action='SELECT')
```

## bpy.data

Access to all blend file data.

### Collections

- `bpy.data.objects` - All objects
- `bpy.data.meshes` - All meshes
- `bpy.data.materials` - All materials
- `bpy.data.textures` - All textures
- `bpy.data.images` - All images
- `bpy.data.lamps` - All lamps (deprecated, use lights)
- `bpy.data.lights` - All lights
- `bpy.data.cameras` - All cameras
- `bpy.data.scenes` - All scenes
- `bpy.data.worlds` - All worlds
- `bpy.data.curves` - All curves
- `bpy.data.surfaces` - All surfaces
- `bpy.data.metaballs` - All metaballs
- `bpy.data.lattices` - All lattices
- `bpy.data.armatures` - All armatures
- `bpy.data.actions` - All actions
- `bpy.data.speakers` - All speakers
- `bpy.data.sounds` - All sounds
- `bpy.data.particles` - All particle systems
- `bpy.data.node_groups` - All node groups
- `bpy.data.texts` - All text blocks
- `bpy.data.collections` - All collections
- `bpy.data.movieclips` - All movie clips
- `bpy.data.masks` - All masks
- `bpy.data.grease_pencils` - All grease pencils
- `bpy.data.palettes` - All color palettes
- `bpy.data.workspaces` - All workspaces
- `bpy.data.screens` - All screens
- `bpy.data.window_managers` - All window managers
- `bpy.data.libraries` - All linked libraries
- `bpy.data.fonts` - All fonts
- `bpy.data.cache_files` - All cache files
- `bpy.data.hair_curves` - All hair curves
- `bpy.data.pointclouds` - All point clouds
- `bpy.data.volumes` - All volumes
- `bpy.data.paint_curves` - All paint curves
- `bpy.data.line_styles` - All line styles
- `bpy.data.brushes` - All brushes
- `bpy.data.node_trees` - All node trees
- `bpy.data.probes` - All probes

### Methods

- `new()` - Create new data block
- `remove()` - Remove data block
- `user_map()` - Get user map of data blocks

### Data Usage Examples

```python
import bpy

# 创建新网格
mesh = bpy.data.meshes.new("MyMesh")

# 创建新对象
obj = bpy.data.objects.new("MyObject", mesh)

# 将对象添加到场景
bpy.context.scene.collection.objects.link(obj)

# 遍历所有对象
for obj in bpy.data.objects:
    print(f"Object: {obj.name}")

# 删除对象
bpy.data.objects.remove(obj)

# 获取用户映射
user_map = bpy.data.user_map()

# 批量操作数据块
for mesh in bpy.data.meshes:
    if mesh.users == 0:
        bpy.data.meshes.remove(mesh)
```

## bpy.ops

Operators for executing Blender commands.

### Usage Pattern

```python
bpy.ops.category.operator_name(
    parameter1=value1,
    parameter2=value2
)
```

### Return Values

- `{'FINISHED'}` - Operation completed successfully
- `{'CANCELLED'}` - Operation was cancelled
- `{'RUNNING_MODAL'}` - Modal operator is running

### Common Parameters

- `override_context` - Override context for operation
- `confirm` - Confirm destructive operations
- `skip_save` - Skip saving before operation

### Operator Categories

#### Object Operations
```python
# 创建立方体
bpy.ops.mesh.primitive_cube_add(location=(0, 0, 0))

# 选择对象
bpy.ops.object.select_all(action='SELECT')

# 删除对象
bpy.ops.object.delete(use_global=False, confirm=False)

# 复制对象
bpy.ops.object.duplicate_move()

# 变换对象
bpy.ops.transform.translate(value=(1, 0, 0))
```

#### Mesh Operations
```python
# 进入编辑模式
bpy.ops.object.mode_set(mode='EDIT')

# 挤出顶点
bpy.ops.mesh.extrude_region_move()

# 细分网格
bpy.ops.mesh.subdivide(number_cuts=2)

# 合并顶点
bpy.ops.mesh.merge(type='CENTER')

# 退出编辑模式
bpy.ops.object.mode_set(mode='OBJECT')
```

#### Scene Operations
```python
# 设置当前帧
bpy.context.scene.frame_set(10)

# 插入关键帧
bpy.ops.anim.keyframe_insert(type='Location')

# 渲染场景
bpy.ops.render.render(write_still=True)

# 保存文件
bpy.ops.wm.save_as_mainfile(filepath="/path/to/file.blend")
```

## bpy.types

Type definitions for all Blender data.

### Common Base Classes

- `bpy.types.ID` - Base class for all data blocks
- `bpy.types.Struct` - Base class for RNA structs
- `bpy.types.Property` - Base class for properties

### Key Properties

All ID types have these properties:
- `name` - Name of the data block
- `users` - Number of users
- `use_fake_user` - Fake user flag
- `tag` - Tag for selection
- `library` - Library reference
- `library_weak_reference` - Weak library reference

## bpy.props

Property definitions for creating custom properties.

### Property Types

#### BoolProperty

```python
bpy.props.BoolProperty(
    name="My Bool",
    description="Description",
    default=False,
    options={'HIDDEN', 'SKIP_SAVE'}
)
```

#### IntProperty

```python
bpy.props.IntProperty(
    name="My Int",
    description="Description",
    default=0,
    min=0,
    max=100,
    soft_min=0,
    soft_max=100,
    step=1,
    options={'ANIMATABLE', 'PROPORTIONAL'}
)
```

#### FloatProperty

```python
bpy.props.FloatProperty(
    name="My Float",
    description="Description",
    default=0.0,
    min=0.0,
    max=1.0,
    precision=3,
    subtype='PERCENTAGE',
    unit='NONE',
    options={'ANIMATABLE', 'PROPORTIONAL'}
)
```

#### StringProperty

```python
bpy.props.StringProperty(
    name="My String",
    description="Description",
    default="",
    maxlen=1024,
    subtype='FILE_PATH',
    options={'HIDDEN', 'TEXTEDIT_UPDATE'}
)
```

#### EnumProperty

```python
bpy.props.EnumProperty(
    name="My Enum",
    description="Description",
    items=[
        ('A', "Option A", "Description A"),
        ('B', "Option B", "Description B"),
        ('C', "Option C", "Description C"),
    ],
    default='A',
    options={'ENUM_FLAG'}
)
```

#### CollectionProperty

```python
bpy.props.CollectionProperty(
    type=MyCustomType,
    name="My Collection",
    description="Collection of items"
)
```

#### PointerProperty

```python
bpy.props.PointerProperty(
    type=bpy.types.Object,
    name="Target Object",
    description="Reference to another object"
)
```

### Property Options

- `'HIDDEN'` - Hide from UI
- `'SKIP_SAVE'` - Don't save to file
- `'ANIMATABLE'` - Can be animated
- `'LIBRARY_EDITABLE'` - Editable in linked libraries
- `'PROPORTIONAL'` - Proportional editing
- `'TEXTEDIT_UPDATE'` - Update on text edit
- `'ENUM_FLAG'` - Multiple selection for enums

### Property Subtypes

- `'PIXEL'` - Pixel values
- `'UNSIGNED'` - Unsigned integers
- `'PERCENTAGE'` - Percentage values
- `'FACTOR'` - Factor values (0.0-1.0)
- `'ANGLE'` - Angle values
- `'TIME'` - Time values
- `'DISTANCE'` - Distance values
- `'FILE_PATH'` - File paths
- `'DIR_PATH'` - Directory paths
- `'FILE_NAME'` - File names
- `'BYTE_STRING'` - Byte strings

### Property Units

- `'NONE'` - No unit
- `'LENGTH'` - Length unit
- `'AREA'` - Area unit
- `'VOLUME'` - Volume unit
- `'ROTATION'` - Rotation unit
- `'TIME'` - Time unit
- `'VELOCITY'` - Velocity unit
- `'ACCELERATION'` - Acceleration unit
- `'MASS'` - Mass unit
- `'CAMERA'` - Camera unit

### Property Usage Example

```python
import bpy

class MyProperties(bpy.types.PropertyGroup):
    my_bool: bpy.props.BoolProperty(
        name="Enable Feature",
        description="Enable this feature",
        default=True
    )
    
    my_int: bpy.props.IntProperty(
        name="Count",
        description="Number of items",
        default=5,
        min=1,
        max=100
    )
    
    my_enum: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ('A', "Mode A", "First mode"),
            ('B', "Mode B", "Second mode"),
            ('C', "Mode C", "Third mode")
        ],
        default='A'
    )

# 注册属性组
bpy.utils.register_class(MyProperties)

# 添加到场景
bpy.types.Scene.my_props = bpy.props.PointerProperty(type=MyProperties)

# 使用属性
scene = bpy.context.scene
scene.my_props.my_bool = True
scene.my_props.my_int = 10
scene.my_props.my_enum = 'B'
)
```

#### CollectionProperty

```python
bpy.props.CollectionProperty(
    name="My Collection",
    description="Description",
    type=bpy.types.PropertyGroup
)
```

#### PointerProperty

```python
bpy.props.PointerProperty(
    name="My Pointer",
    description="Description",
    type=bpy.types.Object,
    poll=lambda self, obj: obj and obj.type == 'MESH'
)
```

#### FloatVectorProperty

```python
bpy.props.FloatVectorProperty(
    name="My Vector",
    description="Description",
    default=(0.0, 0.0, 0.0),
    size=3,
    min=0.0,
    max=1.0,
    subtype='COLOR',
    options={'ANIMATABLE', 'PROPORTIONAL'}
)
```

#### FloatColorProperty

```python
bpy.props.FloatColorProperty(
    name="My Color",
    description="Description",
    default=(0.8, 0.8, 0.8, 1.0),
    min=0.0,
    max=1.0,
    subtype='COLOR_GAMMA',
    options={'ANIMATABLE', 'PROPORTIONAL'}
)
```

### Property Options

- `HIDDEN` - Property is hidden in UI
- `SKIP_SAVE` - Property is not saved
- `ANIMATABLE` - Property can be animated
- `LIBRARY_EDITABLE` - Property can be edited in library
- `PROPORTIONAL` - Property is proportional
- `TEXTEDIT_UPDATE` - Update on text edit
- `ENUM_FLAG` - Enum is a flag set

### Property Subtypes

#### String Subtypes

- `FILE_PATH` - File path
- `DIR_PATH` - Directory path
- `FILE_NAME` - File name only
- `BYTE_STRING` - Byte string
- `PASSWORD` - Password field
- `NONE` - No subtype

#### Float Subtypes

- `PIXEL` - Pixel value
- `UNSIGNED` - Unsigned value
- `PERCENTAGE` - Percentage value
- `FACTOR` - Factor value (0-1)
- `ANGLE` - Angle value
- `TIME` - Time value
- `DISTANCE` - Distance value
- `NONE` - No subtype

#### FloatVector Subtypes

- `XYZ` - XYZ vector
- `COLOR` - RGBA color
- `COLOR_GAMMA` - RGBA color with gamma
- `TRANSLATION` - Translation vector
- `DIRECTION` - Direction vector
- `VELOCITY` - Velocity vector
- `ACCELERATION` - Acceleration vector
- `EULER` - Euler rotation
- `QUATERNION` - Quaternion rotation
- `NONE` - No subtype

## bpy.path

File path utilities for Blender.

### Functions

#### abspath

```python
path = bpy.path.abspath(path)
```

Get absolute path from relative path.

#### basename

```python
name = bpy.path.basename(path)
```

Get basename from path.

#### dirname

```python
dir = bpy.path.dirname(path)
```

Get directory name from path.

#### display_name

```python
name = bpy.path.display_name(path)
```

Get display name from filepath.

#### display_name_to_filepath

```python
path = bpy.path.display_name_to_filepath(name)
```

Get filepath from display name.

#### ensure_ext

```python
path = bpy.path.ensure_ext(filepath, ext)
```

Ensure file has extension.

#### is_subdir

```python
is_sub = bpy.path.is_subdir(directory, path)
```

Check if path is subdirectory.

#### native_pathsep

```python
path = bpy.path.native_pathsep(path)
```

Get path with native path separator.

#### resolve_ncase

```python
path = bpy.path.resolve_ncase(path)
```

Resolve path case-insensitively.

## bpy.app

Application information and utilities.

### Properties

- `version` - Blender version tuple
- `version_string` - Blender version string
- `binary_path` - Blender binary path
- `background` - Background mode flag
- `tempdir` - Temporary directory
- `translations` - Translations module

### Methods

- `timers.register()` - Register timer
- `timers.unregister()` - Unregister timer

## bpy.msgbus

Message bus for inter-module communication.

### Functions

#### clear_by_owner

```python
bpy.msgbus.clear_by_owner(owner)
```

Clear all messages by owner.

#### publish_rna

```python
bpy.msgbus.publish_rna(key, value)
```

Publish RNA message.

#### subscribe_rna

```python
bpy.msgbus.subscribe_rna(
    key,
    owner,
    args,
    notify
)
```

Subscribe to RNA message.

## Registration

### Register Functions

```python
import bpy

def register():
    bpy.utils.register_class(MyClass)
    bpy.types.VIEW3D_MT_mesh_add.append(menu_func)

def unregister():
    bpy.types.VIEW3D_MT_mesh_add.remove(menu_func)
    bpy.utils.unregister_class(MyClass)

if __name__ == "__main__":
    register()
```

### Class Registration

```python
bpy.utils.register_class(MyClass)
```

Register a single class.

```python
bpy.utils.register_classes([Class1, Class2, Class3])
```

Register multiple classes.

### Unregistration

```python
bpy.utils.unregister_class(MyClass)
```

Unregister a single class.

```python
bpy.utils.unregister_classes([Class1, Class2, Class3])
```

Unregister multiple classes.

## Utilities

### bpy.utils

#### import_test

```python
if bpy.utils.import_test("numpy"):
    import numpy
```

Test if module can be imported.

#### register_class

```python
bpy.utils.register_class(MyClass)
```

Register a class.

#### unregister_class

```python
bpy.utils.unregister_class(MyClass)
```

Unregister a class.

#### register_manual_map

```python
bpy.utils.register_manual_map("my_operator_id", "path/to/manual.html")
```

Register manual map entry.

#### unregister_manual_map

```python
bpy.utils.unregister_manual_map("my_operator_id")
```

Unregister manual map entry.

#### smpte_from_frame

```python
timecode = bpy.utils.smpte_from_frame(frame, fps=None, fps_base=None)
```

Convert frame to SMPTE timecode.

#### smpte_to_frame

```python
frame = bpy.utils.smpte_to_frame(timecode_string, fps=None, fps_base=None)
```

Convert SMPTE timecode to frame.

### bpy_extras

#### node_utils

```python
from bpy_extras import node_utils

node_utils.find_node_input(node, identifier)
node_utils.find_node_output(node, identifier)
node_utils.socket_id_to_index(node, identifier, is_input)
node_utils.socket_index_to_id(node, index, is_input)
```

Node utility functions.

#### object_utils

```python
from bpy_extras import object_utils

object_utils.object_data_group(context)
object_utils.add_object_align_init(context, operator)
object_utils.world_to_camera_view(context, operator)
```

Object utility functions.

#### mesh_utils

```python
from bpy_extras import mesh_utils

mesh_utils.mesh_linked_uv_islands(mesh)
mesh_utils.mesh_linked_uv_islands_to_mesh(mesh)
```

Mesh utility functions.

#### image_utils

```python
from bpy_extras import image_utils

image_utils.load_image(image_path)
image_utils.new_image(name, width, height, alpha=False, float_buffer=False)
```

Image utility functions.

#### asset_utils

```python
from bpy_extras import asset_utils

asset_utils.SpaceAssetInfo
asset_utils.activate_asset_by_id(asset_identifier, library_id=None, deferred=False)
asset_utils.asset_mark(asset_identifier, library_id=None)
```

Asset utility functions.
