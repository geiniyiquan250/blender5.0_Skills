# BMesh Module Reference

BMesh 模块提供低级别的网格编辑功能，用于高级网格操作。

## BMesh 概述

BMesh 是 Blender 的内部网格表示结构，提供比 bpy.ops.mesh 更高效的网格操作方式。

### 何时使用 BMesh

- 需要高性能的网格编辑操作
- 批量修改网格顶点、边、面
- 创建自定义网格算法
- 复杂的网格拓扑操作

## BMesh 基础

### 创建 BMesh

```python
import bmesh

# 创建新的 BMesh
bm = bmesh.new()

# 从现有网格创建 BMesh
mesh = bpy.context.object.data
bm = bmesh.new()
bm.from_mesh(mesh)

# 从编辑模式获取 BMesh
bm = bmesh.from_edit_mesh(mesh)
```

### 释放 BMesh

```python
# 释放 BMesh 内存
bm.free()

# 如果是从编辑模式获取的，需要释放
bmesh.update_edit_mesh(mesh)
```

### 写回网格

```python
# 将 BMesh 写回网格
bm.to_mesh(mesh)

# 更新网格
mesh.update()
```

## BMesh 类型

### BMVert (顶点)

顶点是网格的基本构建块。

```python
# 创建顶点
vert = bm.verts.new((0.0, 0.0, 0.0))

# 访问顶点坐标
co = vert.co

# 访问顶点索引
index = vert.index

# 访问连接的边
for edge in vert.link_edges:
    print(edge)

# 访问连接的面
for face in vert.link_faces:
    print(face)
```

### BMEdge (边)

边连接两个顶点。

```python
# 创建边
edge = bm.edges.new((vert1, vert2))

# 访问边的顶点
v1, v2 = edge.verts

# 访问边的索引
index = edge.index

# 访问连接的面
for face in edge.link_faces:
    print(face)

# 检查边是否是流形
is_manifold = edge.is_manifold
```

### BMFace (面)

面由三个或更多顶点组成。

```python
# 创建面
face = bm.faces.new((vert1, vert2, vert3))

# 访问面的顶点
for vert in face.verts:
    print(vert.co)

# 访问面的边
for edge in face.edges:
    print(edge)

# 访问面的法线
normal = face.normal

# 访问面的中心
center = face.calc_center_median()

# 访问面的面积
area = face.calc_area()
```

### BMLoop (循环)

循环是面的一部分，表示顶点-边-面关系。

```python
# 访问面的循环
for loop in face.loops:
    print(loop.vert)
    print(loop.edge)
    print(loop.face)
```

## BMesh 操作

### bmesh.ops.transform

变换 BMesh 元素。

```python
import mathutils

# 缩放
bmesh.ops.transform(
    bm,
    matrix=mathutils.Matrix.Scale(2.0, 4),
    space=matrix_world,
    verts=bm.verts
)

# 旋转
bmesh.ops.transform(
    bm,
    matrix=mathutils.Matrix.Rotation(math.radians(45), 4, 'Z'),
    space=matrix_world,
    verts=bm.verts
)

# 平移
bmesh.ops.transform(
    bm,
    matrix=mathutils.Matrix.Translation((1.0, 0.0, 0.0)),
    space=matrix_world,
    verts=bm.verts
)
```

### bmesh.ops.create_grid

创建网格。

```python
# 创建 10x10 网格
bmesh.ops.create_grid(
    bm,
    x_segments=10,
    y_segments=10,
    size=2.0
)
```

### bmesh.ops.create_cube

创建立方体。

```python
# 创建立方体
bmesh.ops.create_cube(bm, size=2.0)
```

### bmesh.ops.create_circle

创建圆形。

```python
# 创建圆形
bmesh.ops.create_circle(
    bm,
    cap_ends=True,
    cap_tris=True,
    segments=32,
    diameter=2.0
)
```

### bmesh.ops.extrude_face_region

挤出面区域。

```python
# 挤出选中的面
result = bmesh.ops.extrude_face_region(
    bm,
    geom=bm.faces[:],
    use_keep_orig=True,
    use_normal_flip=False,
    use_normal_from_adjacent=False
)

# 获取挤出的几何体
extruded_verts = result['geom']
```

### bmesh.ops.subdivide_edges

细分边。

```python
# 细分边
result = bmesh.ops.subdivide_edges(
    bm,
    edges=bm.edges[:],
    cuts=2,
    use_grid_fill=True,
    use_single_edge=False
)
```

### bmesh.ops.bisect_plane

用平面切割网格。

```python
# 用平面切割
result = bmesh.ops.bisect_plane(
    bm,
    geom=bm.verts[:] + bm.edges[:] + bm.faces[:],
    dist=0.01,
    plane_co=(0.0, 0.0, 0.0),
    plane_no=(0.0, 0.0, 1.0),
    use_snap_center=False,
    clear_outer=True,
    clear_inner=False
)
```

## BMesh 几何工具

### bmesh.geometry.intersect_face_point

检查点是否在面内。

```python
# 检查点是否在面内
point = mathutils.Vector((0.5, 0.5, 0.0))
result = bmesh.geometry.intersect_face_point(face, point)
```

### bmesh.geometry.distance_point_to_face

计算点到面的距离。

```python
# 计算点到面的距离
point = mathutils.Vector((1.0, 1.0, 1.0))
distance = bmesh.geometry.distance_point_to_face(face, point)
```

### bmesh.geometry.face_split

分割面。

```python
# 分割面
bmesh.geometry.face_split(face, vert1, vert2)
```

## BMesh 实用工具

### bmesh.utils.face_split_edgenet

用边网分割面。

```python
# 用边网分割面
bmesh.utils.face_split_edgenet(face, verts)
```

### bmesh.utils.vert_collapse_edge

通过边折叠顶点。

```python
# 通过边折叠顶点
bmesh.utils.vert_collapse_edge(edge, vert)
```

### bmesh.utils.edge_split

分割边。

```python
# 分割边
bmesh.utils.edge_split(edge, vert, factor=0.5)
```

## BMesh 高级用法

### 网格清理

```python
# 移除重复顶点
bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.0001)

# 移除孤立顶点
bmesh.ops.delete(bm, geom=bm.verts, context='VERTS')

# 三角化面
bmesh.ops.triangulate(bm, faces=bm.faces)

# 重新计算法线
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
```

### 网格分析

```python
# 检查网格是否有效
is_valid = bm.is_valid

# 获取边界边
boundary_edges = [edge for edge in bm.edges if edge.is_boundary]

# 获取非流形边
non_manifold_edges = [edge for edge in bm.edges if not edge.is_manifold]

# 计算网格体积
volume = bm.calc_volume()

# 计算网格表面积
surface_area = sum(face.calc_area() for face in bm.faces)
```

### 网格遍历

```python
# 遍历所有顶点
for vert in bm.verts:
    print(f"Vertex {vert.index}: {vert.co}")

# 遍历所有边
for edge in bm.edges:
    print(f"Edge {edge.index}: {[v.index for v in edge.verts]}")

# 遍历所有面
for face in bm.faces:
    print(f"Face {face.index}: {[v.index for v in face.verts]}")

# 遍历顶点的连接边
for vert in bm.verts:
    for edge in vert.link_edges:
        print(f"Vertex {vert.index} connected to edge {edge.index}")

# 遍历边的连接面
for edge in bm.edges:
    for face in edge.link_faces:
        print(f"Edge {edge.index} connected to face {face.index}")
```

### 完整示例：创建复杂网格

```python
import bpy
import bmesh
import mathutils

# 创建新的网格对象
mesh = bpy.data.meshes.new("ComplexMesh")
obj = bpy.data.objects.new("ComplexObject", mesh)
bpy.context.scene.collection.objects.link(obj)

# 创建 BMesh
bm = bmesh.new()

# 创建基础网格
bmesh.ops.create_grid(bm, x_segments=5, y_segments=5, size=4.0)

# 挤出中心面
center_faces = [face for face in bm.faces if face.calc_center_median().length < 1.0]
if center_faces:
    result = bmesh.ops.extrude_face_region(bm, geom=center_faces)
    extruded_verts = [elem for elem in result['geom'] if isinstance(elem, bmesh.types.BMVert)]
    
    # 移动挤出的顶点
    for vert in extruded_verts:
        vert.co.z += 1.0

# 细分网格
bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=1)

# 添加随机变形
for vert in bm.verts:
    vert.co += mathutils.Vector((
        (vert.co.x * 0.1) if vert.co.x > 0 else 0,
        (vert.co.y * 0.1) if vert.co.y > 0 else 0,
        math.sin(vert.co.x) * 0.2
    ))

# 清理网格
bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.001)
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

# 写回网格
bm.to_mesh(mesh)
bm.free()

# 更新网格
mesh.update()

print("复杂网格创建完成")
```

## 性能优化建议

1. **批量操作**：尽量使用 bmesh.ops 进行批量操作，而不是逐个修改元素
2. **避免频繁转换**：减少 bmesh 和 mesh 之间的转换次数
3. **使用适当的数据结构**：使用 BMesh 的链接关系进行高效遍历
4. **及时释放资源**：使用完成后及时调用 bm.free()
5. **合理使用编辑模式**：对于复杂操作，使用编辑模式可以避免频繁的数据转换

```python
# 创建圆形
bmesh.ops.create_circle(
    bm,
    radius=1.0,
    segments=32,
    cap_tris=False,
    cap_fill=False
)
```

### bmesh.ops.create_cone

创建圆锥。

```python
# 创建圆锥
bmesh.ops.create_cone(
    bm,
    radius1=1.0,
    radius2=0.0,
    depth=2.0,
    segments=32
)
```

### bmesh.ops.create_uvsphere

创建 UV 球体。

```python
# 创建 UV 球体
bmesh.ops.create_uvsphere(
    bm,
    radius=1.0,
    segments=32,
    ring_count=16
)
```

### bmesh.ops.create_icosphere

创建二十面体球体。

```python
# 创建二十面体球体
bmesh.ops.create_icosphere(
    bm,
    radius=1.0,
    subdivisions=2
)
```

### bmesh.ops.extrude_edge_face_indiv

挤出边和面。

```python
# 挤出选中的边
geom = bm.edges[:]
result = bmesh.ops.extrude_edge_face_indiv(bm, geom=geom)

# 移动挤出的几何体
bmesh.ops.transform(
    bm,
    matrix=mathutils.Matrix.Translation((0.0, 0.0, 1.0)),
    verts=result['geom']
)
```

### bmesh.ops.extrude_vert_indiv

挤出顶点。

```python
# 挤出选中的顶点
geom = bm.verts[:]
result = bmesh.ops.extrude_vert_indiv(bm, geom=geom)

# 移动挤出的顶点
bmesh.ops.transform(
    bm,
    matrix=mathutils.Matrix.Translation((0.0, 0.0, 1.0)),
    verts=result['geom']
)
```

### bmesh.ops.bevel

倒角边。

```python
# 倒角选中的边
geom = bm.edges[:]
bmesh.ops.bevel(
    bm,
    geom=geom,
    offset=0.1,
    segments=2,
    profile=0.5,
    clamp_overlap=True
)
```

### bmesh.ops.bisect_plane

用平面切割网格。

```python
# 用平面切割网格
geom = bm.faces[:]
result = bmesh.ops.bisect_plane(
    bm,
    geom=geom,
    plane_co=(0.0, 0.0, 0.0),
    plane_no=(0.0, 0.0, 1.0),
    clear_inner=False,
    clear_outer=False
)
```

### bmesh.ops.bridge_loops

连接两个循环。

```python
# 连接两个循环
loops = [loop1, loop2]
bmesh.ops.bridge_loops(
    bm,
    loops=loops,
    use_cyclic=False,
    use_merge=False,
    use_bridge_loops=True
)
```

### bmesh.ops.duplicate

复制几何体。

```python
# 复制选中的几何体
geom = bm.faces[:]
result = bmesh.ops.duplicate(bm, geom=geom)

# 移动复制的几何体
bmesh.ops.transform(
    bm,
    matrix=mathutils.Matrix.Translation((1.0, 0.0, 0.0)),
    verts=result['geom']
)
```

### bmesh.ops.delete

删除几何体。

```python
# 删除选中的面
geom = bm.faces[:]
bmesh.ops.delete(bm, geom=geom, context='FACES')

# 删除选中的边
geom = bm.edges[:]
bmesh.ops.delete(bm, geom=geom, context='EDGES')

# 删除选中的顶点
geom = bm.verts[:]
bmesh.ops.delete(bm, geom=geom, context='VERTS')
```

### bmesh.ops.merge

合并元素。

```python
# 合并选中的顶点
geom = bm.verts[:]
bmesh.ops.merge(
    bm,
    geom=geom,
    dist=0.01,
    use_verts=False
)
```

### bmesh.ops.split

分割几何体。

```python
# 分割选中的边
geom = bm.edges[:]
bmesh.ops.split(bm, geom=geom)
```

### bmesh.ops.smooth

平滑网格。

```python
# 平滑选中的顶点
geom = bm.verts[:]
bmesh.ops.smooth(
    bm,
    verts=geom,
    factor=0.5,
    mirror_clip_x=False,
    mirror_clip_y=False,
    mirror_clip_z=False,
    clip_dist=0.0,
    use_axis_x=True,
    use_axis_y=True,
    use_axis_z=True
)
```

### bmesh.ops.inset

内插面。

```python
# 内插选中的面
geom = bm.faces[:]
bmesh.ops.inset(
    bm,
    geom=geom,
    thickness=0.1,
    depth=0.0,
    use_even_offset=False,
    use_boundary=True,
    use_interpolate=True
)
```

### bmesh.ops.subdivide_edges

细分边。

```python
# 细分选中的边
geom = bm.edges[:]
bmesh.ops.subdivide_edges(
    bm,
    edges=geom,
    cuts=1,
    use_grid_fill=False,
    use_smooth_even=False
)
```

### bmesh.ops.weld_vert

焊接顶点。

```python
# 焊接选中的顶点
verts = bm.verts[:]
bmesh.ops.weld_vert(bm, verts=verts)
```

### bmesh.ops.remove_doubles

移除重复顶点。

```python
# 移除重复顶点
bmesh.ops.remove_doubles(
    bm,
    verts=bm.verts,
    dist=0.0001
)
```

### bmesh.ops.connect_verts

连接顶点。

```python
# 连接选中的顶点
verts = bm.verts[:]
bmesh.ops.connect_verts(bm, verts=verts)
```

### bmesh.ops.edge_split

分割边。

```python
# 分割选中的边
edges = bm.edges[:]
bmesh.ops.edge_split(bm, edges=edges)
```

### bmesh.ops.face_split

分割面。

```python
# 分割选中的面
faces = bm.faces[:]
bmesh.ops.face_split(bm, faces=faces)
```

### bmesh.ops.reverse_faces

反转面法线。

```python
# 反转选中的面
faces = bm.faces[:]
bmesh.ops.reverse_faces(bm, faces=faces)
```

### bmesh.ops.recalc_face_normals

重新计算面法线。

```python
# 重新计算所有面的法线
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
```

### bmesh.ops.rotate

旋转几何体。

```python
# 旋转选中的顶点
import mathutils

geom = bm.verts[:]
bmesh.ops.rotate(
    bm,
    cent=(0.0, 0.0, 0.0),
    matrix=mathutils.Matrix.Rotation(math.radians(45), 4, 'Z'),
    verts=geom
)
```

### bmesh.ops.scale

缩放几何体。

```python
# 缩放选中的顶点
geom = bm.verts[:]
bmesh.ops.scale(
    bm,
    vec=(2.0, 2.0, 2.0),
    space=mathutils.Matrix(),
    verts=geom
)
```

### bmesh.ops.translate

平移几何体。

```python
# 平移选中的顶点
geom = bm.verts[:]
bmesh.ops.translate(
    bm,
    vec=(1.0, 0.0, 0.0),
    space=mathutils.Matrix(),
    verts=geom
)
```

## BMesh 选择

### 选择顶点

```python
# 选择所有顶点
for vert in bm.verts:
    vert.select = True

# 选择特定顶点
bm.verts[0].select = True

# 选择范围内的顶点
for vert in bm.verts:
    if vert.co.length < 1.0:
        vert.select = True
```

### 选择边

```python
# 选择所有边
for edge in bm.edges:
    edge.select = True

# 选择特定边
bm.edges[0].select = True

# 选择连接到选中顶点的边
for vert in bm.verts:
    if vert.select:
        for edge in vert.link_edges:
            edge.select = True
```

### 选择面

```python
# 选择所有面
for face in bm.faces:
    face.select = True

# 选择特定面
bm.faces[0].select = True

# 选择法线向上的面
for face in bm.faces:
    if face.normal.z > 0.5:
        face.select = True
```

### 隐藏元素

```python
# 隐藏选中的顶点
for vert in bm.verts:
    if vert.select:
        vert.hide = True

# 隐藏选中的边
for edge in bm.edges:
    if edge.select:
        edge.hide = True

# 隐藏选中的面
for face in bm.faces:
    if face.select:
        face.hide = True
```

## BMesh 查询

### 查找顶点

```python
# 查找特定坐标的顶点
target_co = (0.0, 0.0, 0.0)
for vert in bm.verts:
    if (vert.co - target_co).length < 0.001:
        print(f"Found vertex: {vert.index}")
        break
```

### 查找边

```python
# 查找连接两个顶点的边
v1 = bm.verts[0]
v2 = bm.verts[1]
for edge in v1.link_edges:
    if v2 in edge.verts:
        print(f"Found edge: {edge.index}")
        break
```

### 查找面

```python
# 查找包含特定顶点的面
vert = bm.verts[0]
for face in vert.link_faces:
    print(f"Found face: {face.index}")
```

### 获取边界边

```python
# 获取所有边界边
boundary_edges = [edge for edge in bm.edges if len(edge.link_faces) == 1]
```

### 获取孤立顶点

```python
# 获取所有孤立顶点
isolated_verts = [vert for vert in bm.verts if len(vert.link_edges) == 0]
```

## BMesh 遍历

### 遍历顶点

```python
# 遍历所有顶点
for vert in bm.verts:
    print(f"Vertex {vert.index}: {vert.co}")

# 遍历选中的顶点
for vert in bm.verts:
    if vert.select:
        print(f"Selected vertex {vert.index}: {vert.co}")
```

### 遍历边

```python
# 遍历所有边
for edge in bm.edges:
    print(f"Edge {edge.index}: {edge.verts[0].co} -> {edge.verts[1].co}")

# 遍历选中的边
for edge in bm.edges:
    if edge.select:
        print(f"Selected edge {edge.index}")
```

### 遍历面

```python
# 遍历所有面
for face in bm.faces:
    print(f"Face {face.index}: {len(face.verts)} vertices")

# 遍历选中的面
for face in bm.faces:
    if face.select:
        print(f"Selected face {face.index}")
```

## BMesh 实用函数

### bmesh.geometry

```python
import bmesh.geometry

# 获取面的中心
center = bmesh.geometry.face_center(face)

# 获取面的法线
normal = bmesh.geometry.face_normal(face)

# 获取面的面积
area = bmesh.geometry.face_area(face)

# 获取边的长度
length = bmesh.geometry.edge_length(edge)

# 获取顶点之间的距离
dist = bmesh.geometry.vert_distance(vert1, vert2)

# 获取顶点的法线
normal = bmesh.geometry.vert_normal(vert)

# 获取顶点的切线
tangent = bmesh.geometry.vert_tangent(vert)
```

### bmesh.utils

```python
import bmesh.utils

# 获取面的循环
loops = bmesh.utils.face_loops(face)

# 获取边的循环
loops = bmesh.utils.edge_loops(edge)

# 获取顶点的循环
loops = bmesh.utils.vert_loops(vert)

# 检查边是否是边界
is_boundary = bmesh.utils.edge_is_boundary(edge)

# 检查顶点是否是边界
is_boundary = bmesh.utils.vert_is_boundary(vert)

# 获取面的边界边
boundary_edges = bmesh.utils.face_boundary_edges(face)

# 获取面的边界顶点
boundary_verts = bmesh.utils.face_boundary_verts(face)
```

## BMesh 完整示例

```python
import bmesh
import bpy
import mathutils

# 创建立方体并修改
obj = bpy.context.object
if obj and obj.type == 'MESH':
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    
    # 选择所有面
    for face in bm.faces:
        face.select = True
    
    # 内插面
    bmesh.ops.inset(bm, geom=bm.faces[:], thickness=0.1)
    
    # 挤出选中的面
    result = bmesh.ops.extrude_edge_face_indiv(bm, geom=bm.faces[:])
    
    # 移动挤出的几何体
    bmesh.ops.transform(
        bm,
        matrix=mathutils.Matrix.Translation((0.0, 0.0, 0.5)),
        verts=result['geom']
    )
    
    # 写回网格
    bm.to_mesh(mesh)
    mesh.update()
    
    # 释放 BMesh
    bm.free()
```
