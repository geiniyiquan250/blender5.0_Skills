# bpy.ops.ed - 编辑器操作模块

Blender编辑器通用操作符，用于各种编辑器中的编辑操作。

## 概述

`bpy.ops.ed` 模块提供用于在Blender各种编辑器中进行通用编辑操作的功能，包括撤销、重做、复制、粘贴等。

## 核心功能

### 撤销重做

```python
import bpy

# 撤销
bpy.ops.ed.undo()

# 重做
bpy.ops.ed.redo()

# 撤销历史
bpy.ops.ed.undo_history(
    step=1
)

# 撤销消息
bpy.ops.ed.undo_push(
    message='自定义操作'
)

# 撤销重新引发
bpy.ops.ed.undo_redo()
```

### 撤销重做设置

```python
# 启用撤销
bpy.context.preferences.edit.use_global_undo = True

# 禁用撤销
bpy.context.preferences.edit.use_global_undo = False

# 设置撤销步数
bpy.context.preferences.edit.undo_steps = 256

# 设置撤销内存
bpy.context.preferences.edit.undo_memory_limit = 64
```

### 复制粘贴

```python
# 复制
bpy.ops.ed.copy(
    buffer_name='BUFFER'
)

# 粘贴
bpy.ops.ed.paste(
    buffer_name='BUFFER'
)

# 粘贴历史
bpy.ops.ed.paste_buffer(
    flip=True,
    offset=(0, 0, 0)
)

# 复制选择
bpy.ops.ed.copy_selected()
```

### 选择操作

```python
# 全选
bpy.ops.ed.select_all(
    action='SELECT'
)

# 取消全选
bpy.ops.ed.select_all(
    action='DESELECT'
)

# 反选
bpy.ops.ed.select_all(
    action='INVERT'
)

# 选择相似
bpy.ops.ed.select_all(
    action='SIMILAR'
)
```

### 删除操作

```python
# 删除
bpy.ops.ed.delete()

# 删除行
bpy.ops.ed.delete_line()

# 删除字符
bpy.ops.ed.delete_char(
    direction='FORWARD'
)

# 删除单词
bpy.ops.ed.delete_word(
    direction='FORWARD'
)
```

### 插入操作

```python
# 插入换行
bpy.ops.ed.insert()

# 插入字符
bpy.ops.ed.insert_text(
    text='a'
)

# 插入换行符
bpy.ops.ed.insert_line_break()
```

### 移动操作

```python
# 移动行
bpy.ops.ed.move_lines(
    direction='DOWN'
)

# 移动字符
bpy.ops.ed.move_char(
    direction='FORWARD'
)

# 移动单词
bpy.ops.ed.move_word(
    direction='FORWARD'
)

# 移动到行首
bpy.ops.ed.move_line_start()

# 移动到行尾
bpy.ops.ed.move_line_end()
```

### 查找替换

```python
# 查找
bpy.ops.ed.find()

# 查找下一个
bpy.ops.ed.find_next()

# 查找上一个
bpy.ops.ed.find_previous()

# 替换
bpy.ops.ed.replace()

# 替换全部
bpy.ops.ed.replace_all()
```

### 缩进操作

```python
# 增加缩进
bpy.ops.ed.indent(
    insert=True
)

# 减少缩进
bpy.ops.ed.indent(
    insert=False
)

# 自动缩进
bpy.ops.ed.auto_indent()

# 转换缩进
bpy.ops.ed.indentation_convert()
```

### 注释操作

```python
# 切换注释
bpy.ops.ed.comment_toggle()

# 添加注释
bpy.ops.ed.comment_add()

# 删除注释
bpy.ops.ed.comment_remove()
```

## 实用函数

```python
def select_all_in_editor():
    """全选"""
    bpy.ops.ed.select_all(action='SELECT')

def deselect_all_in_editor():
    """取消全选"""
    bpy.ops.ed.select_all(action='DESELECT')

def invert_selection():
    """反选"""
    bpy.ops.ed.select_all(action='INVERT')

def undo_operation():
    """撤销"""
    bpy.ops.ed.undo()

def redo_operation():
    """重做"""
    bpy.ops.ed.redo()

def copy_selection():
    """复制选择内容"""
    bpy.ops.ed.copy()

def paste_buffer():
    """粘贴"""
    bpy.ops.ed.paste()

def find_text(text):
    """查找文本"""
    bpy.ops.ed.find()
    # 在查找框中输入文本
    for char in text:
        bpy.ops.ed.insert_text(text=char)

def replace_text(old_text, new_text):
    """替换文本"""
    bpy.ops.ed.find()
    bpy.ops.ed.replace()
    # 在替换框中输入文本
    for char in old_text:
        bpy.ops.ed.delete_char(direction='FORWARD')
    for char in new_text:
        bpy.ops.ed.insert_text(text=char)

def move_line_down():
    """下移行"""
    bpy.ops.ed.move_lines(direction='DOWN')

def move_line_up():
    """上移行"""
    bpy.ops.ed.move_lines(direction='UP')

def indent_selected():
    """增加选中缩进"""
    bpy.ops.ed.indent(insert=True)

def dedent_selected():
    """减少选中缩进"""
    bpy.ops.ed.indent(insert=False)
```

## 常见问题排查

### 撤销不工作
```python
# 检查撤销设置
print(f"全局撤销: {bpy.context.preferences.edit.use_global_undo}")
print(f"撤销步数: {bpy.context.preferences.edit.undo_steps}")

# 启用撤销
bpy.context.preferences.edit.use_global_undo = True

# 检查撤销历史
print(f"撤销历史: {bpy.context.scene.undo_stack}")

# 手动触发撤销
bpy.ops.ed.undo()
```

### 选择不工作
```python
# 检查编辑器类型
print(f"区域类型: {bpy.context.area.type}")

# 确保在可编辑区域
if bpy.context.area.type in ['TEXT_EDITOR', 'CONSOLE', 'NODE_EDITOR']:
    print("支持选择操作")
else:
    print("不支持选择操作")

# 重置选择
bpy.ops.ed.select_all(action='DESELECT')
```

### 复制粘贴问题
```python
# 检查剪贴板
import os
print(f"剪贴板内容: {os.popen('powershell Get-Clipboard').read()}")

# 检查缓冲区
print(f"缓冲区: {bpy.context.scene.tool_settings.buffer}")

# 清除缓冲区
bpy.ops.ed.copy(buffer_name='BUFFER')

# 重新复制
bpy.ops.ed.copy()
```
