# bpy.ops.script - Python Script Operations Module

Blender Python 脚本操作符，用于执行和管理 Python 脚本。

## Overview

`bpy.ops.script` 模块包含脚本执行和管理的操作命令，支持 Python 脚本的运行、文本操作和脚本加载。这个模块主要用于脚本自动化和扩展 Blender 功能。

## 核心功能

```python
import bpy

# 执行 Python 脚本
bpy.ops.script.python_file_run(filepath="C:/scripts/myscript.py")

# 新建脚本
bpy.ops.script.new()

# 重新加载模块
bpy.ops.script.reload()
```

## 实际应用示例

### 脚本管理器

```python
import bpy
import sys
import os

class ScriptManager:
    """脚本管理器"""
    
    def __init__(self):
        self.script_dir = os.path.join(bpy.app.tempdir, "scripts")
        os.makedirs(self.script_dir, exist_ok=True)
    
    def execute_file(self, filepath):
        """执行脚本文件"""
        if os.path.exists(filepath):
            bpy.ops.script.python_file_run(filepath=filepath)
            return True
        return False
    
    def execute_code(self, code):
        """执行代码"""
        try:
            exec(code, globals())
            return True
        except Exception as e:
            print(f"执行错误: {e}")
            return False
    
    def create_script(self, name, code):
        """创建脚本"""
        filepath = os.path.join(self.script_dir, f"{name}.py")
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(code)
        
        return filepath
    
    def load_script(self, filepath):
        """加载脚本"""
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    
    def save_script(self, name, code):
        """保存脚本"""
        filepath = os.path.join(self.script_dir, f"{name}.py")
        return self.create_script(name, code)
    
    def list_scripts(self):
        """列出脚本"""
        if os.path.exists(self.script_dir):
            return [f[:-3] for f in os.listdir(self.script_dir) 
                   if f.endswith('.py')]
        return []
    
    def delete_script(self, name):
        """删除脚本"""
        filepath = os.path.join(self.script_dir, f"{name}.py")
        if os.path.exists(filepath):
            os.remove(filepath)
            return True
        return False
    
    def duplicate_script(self, name, new_name):
        """复制脚本"""
        code = self.load_script(os.path.join(self.script_dir, f"{name}.py"))
        return self.create_script(new_name, code)
    
    def rename_script(self, name, new_name):
        """重命名脚本"""
        code = self.load_script(os.path.join(self.script_dir, f"{name}.py"))
        self.delete_script(name)
        return self.create_script(new_name, code)
    
    def export_script(self, name, output_path):
        """导出脚本"""
        code = self.load_script(os.path.join(self.script_dir, f"{name}.py"))
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(code)
        
        return output_path
    
    def import_script(self, filepath):
        """导入脚本"""
        code = self.load_script(filepath)
        name = os.path.splitext(os.path.basename(filepath))[0]
        return self.create_script(name, code)
    
    def reload_all_scripts(self):
        """重新加载所有脚本"""
        bpy.ops.script.reload()
        
        # 重新导入用户模块
        for module_name in list(sys.modules.keys()):
            if module_name.startswith('user_'):
                del sys.modules[module_name]


def setup_script_manager():
    """设置脚本管理器"""
    manager = ScriptManager()
    
    print("脚本管理器已设置")
    print(f"脚本目录: {manager.script_dir}")
    print(f"脚本列表: {manager.list_scripts()}")
    
    return manager
```

### 自动化脚本库

```python
import bpy
import os

class AutomationScriptLibrary:
    """自动化脚本库"""
    
    def __init__(self):
        self.scripts = {}
        self.categories = {}
    
    def register_script(self, name, category, code):
        """注册脚本"""
        self.scripts[name] = code
        if category not in self.categories:
            self.categories[category] = []
        self.categories[category].append(name)
    
    def get_script(self, name):
        """获取脚本"""
        return self.scripts.get(name)
    
    def get_scripts_by_category(self, category):
        """按类别获取脚本"""
        return self.categories.get(category, [])
    
    def get_all_categories(self):
        """获取所有类别"""
        return list(self.categories.keys())
    
    def execute_script(self, name):
        """执行脚本"""
        code = self.get_script(name)
        if code:
            return bpy.ops.script.execute_python(code=code)
    
    def execute_script_with_args(self, name, **kwargs):
        """带参数执行脚本"""
        code = self.get_script(name)
        if code:
            # 格式化代码
            formatted_code = code.format(**kwargs)
            return bpy.ops.script.execute_python(code=formatted_code)
    
    def create_category_script(self, category):
        """创建类别脚本"""
        scripts = self.get_scripts_by_category(category)
        combined_code = "\n\n".join(
            f"# {name}\n{self.scripts[name]}" 
            for name in scripts
        )
        
        self.scripts[f"{category}_all"] = combined_code
        return combined_code
    
    def export_category(self, category, output_dir):
        """导出类别"""
        scripts = self.get_scripts_by_category(category)
        os.makedirs(output_dir, exist_ok=True)
        
        for name in scripts:
            code = self.get_script(name)
            filepath = os.path.join(output_dir, f"{name}.py")
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(code)
        
        return len(scripts)
    
    def import_directory(self, directory):
        """导入目录"""
        count = 0
        
        for filename in os.listdir(directory):
            if filename.endswith('.py'):
                filepath = os.path.join(directory, filename)
                name = os.path.splitext(filename)[0]
                
                with open(filepath, 'r', encoding='utf-8') as f:
                    code = f.read()
                
                self.register_script(name, "Imported", code)
                count += 1
        
        return count
    
    def create_script_documentation(self, name):
        """创建脚本文档"""
        code = self.get_script(name)
        if not code:
            return None
        
        # 解析文档字符串
        lines = code.split('\n')
        doc = []
        in_doc = False
        
        for line in lines:
            if line.startswith('"""') or line.startswith("'''"):
                in_doc = not in_doc
            elif in_doc:
                doc.append(line)
        
        return '\n'.join(doc)
    
    def list_scripts_with_docs(self):
        """列出带文档的脚本"""
        result = []
        for name in self.scripts:
            doc = self.create_script_documentation(name)
            result.append({
                'name': name,
                'documentation': doc or "无文档"
            })
        return result


def setup_automation_library():
    """设置自动化脚本库"""
    library = AutomationScriptLibrary()
    
    # 注册常用脚本
    library.register_script(
        "setup_scene",
        "Scene",
        '''
import bpy

def setup_basic_scene():
    bpy.ops.object.light_add(type='SUN', location=(5, 5, 10))
    bpy.ops.object.camera_add(location=(0, -10, 5))
    return True
'''
    )
    
    library.register_script(
        "cleanup_scene",
        "Scene",
        '''
import bpy

def remove_unused_materials():
    for mat in list(bpy.data.materials):
        if mat.users == 0:
            bpy.data.materials.remove(mat)
    return True
'''
    )
    
    library.register_script(
        "export_glb",
        "Export",
        '''
import bpy

def export_selected(filepath):
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        use_selection=True
    )
    return filepath
'''
    )
    
    print("自动化脚本库已设置")
    print(f"类别: {library.get_all_categories()}")
    
    return library
```

### 批量处理工具

```python
import bpy
import os

class BatchProcessingTool:
    """批量处理工具"""
    
    def __init__(self):
        self.queue = []
        self.results = []
    
    def add_task(self, task_type, **kwargs):
        """添加任务"""
        self.queue.append({
            'type': task_type,
            'params': kwargs
        })
    
    def clear_queue(self):
        """清空队列"""
        self.queue = []
    
    def process_queue(self, progress_callback=None):
        """处理队列"""
        self.results = []
        
        for i, task in enumerate(self.queue):
            result = self._execute_task(task)
            self.results.append(result)
            
            if progress_callback:
                progress_callback(i + 1, len(self.queue))
        
        return self.results
    
    def _execute_task(self, task):
        """执行任务"""
        task_type = task['type']
        params = task['params']
        
        if task_type == 'export':
            return self._export_task(params)
        elif task_type == 'import':
            return self._import_task(params)
        elif task_type == 'render':
            return self._render_task(params)
        elif task_type == 'apply_modifiers':
            return self._apply_modifiers_task(params)
        
        return {'success': False, 'error': '未知任务类型'}
    
    def _export_task(self, params):
        """导出任务"""
        obj_name = params.get('object')
        filepath = params.get('filepath')
        format = params.get('format', 'GLTF')
        
        if format == 'GLTF':
            bpy.ops.wm.gltf_export(
                filepath=filepath,
                selected_objects=[bpy.data.objects.get(obj_name)] if obj_name else None
            )
        
        return {'success': True, 'file': filepath}
    
    def _import_task(self, params):
        """导入任务"""
        filepath = params.get('filepath')
        
        if filepath.endswith('.glb') or filepath.endswith('.gltf'):
            bpy.ops.wm.gltf_import(filepath=filepath)
        elif filepath.endswith('.fbx'):
            bpy.ops.import_scene.fbx(filepath=filepath)
        elif filepath.endswith('.obj'):
            bpy.ops.import_scene.obj(filepath=filepath)
        
        return {'success': True, 'imported': filepath}
    
    def _render_task(self, params):
        """渲染任务"""
        filepath = params.get('filepath')
        engine = params.get('engine', 'CYCLES')
        
        scene = bpy.context.scene
        old_engine = scene.render.engine
        scene.render.engine = engine
        scene.render.filepath = filepath
        
        bpy.ops.render.render(write_still=True)
        
        scene.render.engine = old_engine
        
        return {'success': True, 'rendered': filepath}
    
    def _apply_modifiers_task(self, params):
        """应用修改器任务"""
        obj_name = params.get('object')
        obj = bpy.data.objects.get(obj_name)
        
        if obj:
            for modifier in obj.modifiers[:]:
                bpy.ops.object.modifier_apply(modifier=modifier.name)
            return {'success': True, 'object': obj_name}
        
        return {'success': False, 'error': '对象不存在'}
    
    def add_export_tasks(self, objects, output_dir, format='GLB'):
        """添加导出任务"""
        for obj in objects:
            if obj.type in ['MESH', 'CURVE', 'ARMATURE']:
                filepath = os.path.join(output_dir, f"{obj.name}.{format.lower()}")
                self.add_task('export', object=obj.name, filepath=filepath, format=format)
    
    def add_import_task(self, filepath):
        """添加导入任务"""
        self.add_task('import', filepath=filepath)
    
    def add_render_tasks(self, output_dir, format='PNG'):
        """添加渲染任务"""
        for frame in range(
            bpy.context.scene.frame_start,
            bpy.context.scene.frame_end + 1
        ):
            filepath = os.path.join(
                output_dir, 
                f"frame_{frame:04d}.{format.lower()}"
            )
            self.add_task('render', filepath=filepath)
    
    def get_task_summary(self):
        """获取任务摘要"""
        summary = {}
        for task in self.queue:
            task_type = task['type']
            summary[task_type] = summary.get(task_type, 0) + 1
        return summary
    
    def export_queue(self, filepath):
        """导出队列"""
        import json
        
        with open(filepath, 'w') as f:
            json.dump(self.queue, f, indent=2)
        
        return filepath
    
    def import_queue(self, filepath):
        """导入队列"""
        import json
        
        with open(filepath, 'r') as f:
            self.queue = json.load(f)
        
        return len(self.queue)


def setup_batch_processor():
    """设置批量处理器"""
    processor = BatchProcessingTool()
    
    print("批量处理工具已设置")
    print(f"当前队列: {processor.get_task_summary()}")
    
    return processor
```

### Python 环境工具

```python
import bpy
import sys
import subprocess

class PythonEnvironmentTool:
    """Python 环境工具"""
    
    def __init__(self):
        self.packages = {}
    
    def get_python_version(self):
        """获取 Python 版本"""
        return sys.version
    
    def get_python_path(self):
        """获取 Python 路径"""
        return sys.executable
    
    def get_installed_packages(self):
        """获取已安装包"""
        return list(sys.modules.keys())
    
    def check_package(self, package_name):
        """检查包"""
        return package_name in sys.modules
    
    def import_package(self, package_name):
        """导入包"""
        try:
            module = __import__(package_name)
            return module
        except ImportError:
            return None
    
    def run_pip_command(self, command):
        """运行 pip 命令"""
        python_path = sys.executable
        
        try:
            result = subprocess.run(
                [python_path, '-m', 'pip'] + command.split(),
                capture_output=True,
                text=True
            )
            return result.stdout + result.stderr
        except Exception as e:
            return str(e)
    
    def install_package(self, package_name):
        """安装包"""
        return self.run_pip_command(f"install {package_name}")
    
    def uninstall_package(self, package_name):
        """卸载包"""
        return self.run_pip_command(f"uninstall -y {package_name}")
    
    def list_updatable_packages(self):
        """列出可更新包"""
        return self.run_pip_command("list --outdated")
    
    def upgrade_package(self, package_name):
        """更新包"""
        return self.run_pip_command(f"install --upgrade {package_name}")
    
    def create_virtual_environment(self, path):
        """创建虚拟环境"""
        return self.run_pip_command(f"-m venv {path}")
    
    def execute_in_venv(self, venv_path, command):
        """在虚拟环境中执行"""
        if sys.platform == 'win32':
            python_path = os.path.join(venv_path, 'Scripts', 'python.exe')
        else:
            python_path = os.path.join(venv_path, 'bin', 'python')
        
        try:
            result = subprocess.run(
                [python_path] + command.split(),
                capture_output=True,
                text=True
            )
            return result.stdout + result.stderr
        except Exception as e:
            return str(e)
    
    def get_blender_modules(self):
        """获取 Blender 模块"""
        modules = []
        for name in dir(bpy):
            if not name.startswith('_'):
                modules.append(name)
        return modules
    
    def get_bpy_modules(self):
        """获取 bpy 子模块"""
        modules = []
        for attr in dir(bpy):
            if isinstance(getattr(bpy, attr), type(bpy)):
                modules.append(attr)
        return modules
    
    def export_environment_info(self, filepath):
        """导出环境信息"""
        info = {
            'python_version': self.get_python_version(),
            'python_path': self.get_python_path(),
            'blender_version': bpy.app.version_string,
            'installed_packages': self.get_installed_packages()[:50]
        }
        
        import json
        
        with open(filepath, 'w') as f:
            json.dump(info, f, indent=2)
        
        return filepath


def setup_python_environment():
    """设置 Python 环境"""
    tool = PythonEnvironmentTool()
    
    print("Python 环境工具已设置")
    print(f"Python 版本: {tool.get_python_version()[:50]}")
    print(f"Blender 版本: {bpy.app.version_string}")
    
    return tool
```
