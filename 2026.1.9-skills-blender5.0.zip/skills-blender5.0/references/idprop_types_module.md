# idprop.types 模块

idprop.types 模块定义了 Blender ID 属性系统的核心类型，用于在数据块中存储自定义属性。

## ID 属性类型概述

ID 属性是 Blender 中用于在各种数据块（对象、材质、场景等）中存储自定义数据的关键机制。该模块定义了属性类型和工具函数。

### 何时使用 ID 属性

- 存储自定义对象数据
- 保存插件配置
- 实现属性动画
- 在数据块之间传递数据

## 属性类型

### IDPropertyGroup

属性组容器，用于组织多个相关属性。

```python
import bpy
from idprop.types import IDPropertyGroup

# 访问对象的属性组
obj = bpy.context.active_object

# 检查是否有属性组
if "custom_props" not in obj:
    # 创建新的属性组
    obj["custom_props"] = {}

# 访问属性组
props = obj["custom_props"]

# 设置属性
props["my_int"] = 42
props["my_float"] = 3.14
props["my_string"] = "Hello"
props["my_vector"] = [1.0, 2.0, 3.0]

# 读取属性
print(props.get("my_int"))
print(props.get("my_float"))
```

### IDPropertyArray

属性数组，用于存储数组类型的属性。

```python
import bpy

# 创建数组属性
obj = bpy.context.active_object

# 整数数组
obj["int_array"] = [1, 2, 3, 4, 5]

# 浮点数数组
obj["float_array"] = [1.1, 2.2, 3.3, 4.4]

# 向量（3元素数组）
obj["position"] = [0.0, 0.0, 0.0]

# 矩阵（16元素数组，用于 4x4 矩阵）
obj["transform"] = [1.0] * 16

# 访问数组
array = obj["int_array"]
print(f"数组长度: {len(array)}")
print(f"第一个元素: {array[0]}")
print(f"数组类型: {type(array)}")
```

## 属性类型函数

### to_idprop

将 Python 对象转换为 ID 属性。

```python
from idprop.types import to_idprop

# 转换各种类型
int_prop = to_idprop(42)
float_prop = to_idprop(3.14)
string_prop = to_idprop("hello")
list_prop = to_idprop([1, 2, 3])
dict_prop = to_idprop({"key": "value"})
```

### idprop_to_py

将 ID 属性转换回 Python 对象。

```python
from idprop.types import idprop_to_py

# 假设从属性中获取的值
value = bpy.context.active_object.get("my_property")

# 转换为 Python 对象
py_value = idprop_to_py(value)
```

## 实际应用示例

### 自定义属性管理器

```python
import bpy
from idprop.types import IDPropertyGroup
from typing import Any, Dict, List, Optional

class CustomPropertyManager:
    """自定义属性管理器"""
    
    def __init__(self, data_block):
        self.data_block = data_block
        self.group_name = "_custom_props"
        self._ensure_group()
    
    def _ensure_group(self):
        """确保属性组存在"""
        if self.group_name not in self.data_block:
            self.data_block[self.group_name] = {}
    
    @property
    def group(self):
        """获取属性组"""
        return self.data_block[self.group_name]
    
    def set_int(self, key: str, value: int) -> None:
        """设置整数属性"""
        self.group[key] = int(value)
    
    def get_int(self, key: str, default: int = 0) -> int:
        """获取整数属性"""
        return int(self.group.get(key, default))
    
    def set_float(self, key: str, value: float) -> None:
        """设置浮点数属性"""
        self.group[key] = float(value)
    
    def get_float(self, key: str, default: float = 0.0) -> float:
        """获取浮点数属性"""
        return float(self.group.get(key, default))
    
    def set_string(self, key: str, value: str) -> None:
        """设置字符串属性"""
        self.group[key] = str(value)
    
    def get_string(self, key: str, default: str = "") -> str:
        """获取字符串属性"""
        return str(self.group.get(key, default))
    
    def set_vector(self, key: str, value: List[float], size: int = 3) -> None:
        """设置向量属性"""
        vector = list(value)
        while len(vector) < size:
            vector.append(0.0)
        self.group[key] = vector[:size]
    
    def get_vector(self, key: str, default: List[float] = None) -> List[float]:
        """获取向量属性"""
        if default is None:
            default = [0.0, 0.0, 0.0]
        return list(self.group.get(key, default))
    
    def set_bool(self, key: str, value: bool) -> None:
        """设置布尔属性"""
        self.group[key] = bool(value)
    
    def get_bool(self, key: str, default: bool = False) -> bool:
        """获取布尔属性"""
        return bool(self.group.get(key, default))
    
    def set_color(self, key: str, r: float, g: float, b: float, a: float = 1.0) -> None:
        """设置颜色属性"""
        self.group[key] = [float(r), float(g), float(b), float(a)]
    
    def get_color(self, key: str, default: List[float] = None) -> List[float]:
        """获取颜色属性"""
        if default is None:
            default = [0.0, 0.0, 0.0, 1.0]
        return list(self.group.get(key, default))
    
    def set_matrix(self, key: str, matrix, size: int = 16) -> None:
        """设置矩阵属性"""
        flat = []
        for row in matrix:
            flat.extend(list(row))
        self.group[key] = flat[:size]
    
    def get_matrix(self, key: str) -> List[float]:
        """获取矩阵属性"""
        return list(self.group.get(key, [1.0] * 16))
    
    def remove(self, key: str) -> bool:
        """删除属性"""
        if key in self.group:
            del self.group[key]
            return True
        return False
    
    def clear(self) -> None:
        """清除所有属性"""
        self.group.clear()
    
    def has(self, key: str) -> bool:
        """检查属性是否存在"""
        return key in self.group
    
    def keys(self) -> List[str]:
        """获取所有属性键"""
        return list(self.group.keys())
    
    def values(self) -> List[Any]:
        """获取所有属性值"""
        return list(self.group.values())
    
    def items(self) -> Dict[str, Any]:
        """获取所有属性项"""
        return dict(self.group.items())
    
    def get_all(self) -> Dict[str, Any]:
        """获取所有属性"""
        return self.items()


class ObjectPropertyManager(CustomPropertyManager):
    """对象属性管理器"""
    
    def __init__(self, obj):
        super().__init__(obj)
        self.obj = obj
    
    def set_work_mode(self, mode: str) -> None:
        """设置工作模式"""
        valid_modes = ['EDIT', 'POSE', 'SCULPT', 'PAINT']
        if mode not in valid_modes:
            mode = valid_modes[0]
        self.set_string("work_mode", mode)
    
    def get_work_mode(self) -> str:
        """获取工作模式"""
        return self.get_string("work_mode", "EDIT")
    
    def set_selection_priority(self, priority: int) -> None:
        """设置选择优先级"""
        self.set_int("selection_priority", max(0, min(10, priority)))
    
    def get_selection_priority(self) -> int:
        """获取选择优先级"""
        return self.get_int("selection_priority", 0)
    
    def set_custom_color(self, r: float, g: float, b: float) -> None:
        """设置自定义颜色"""
        self.set_color("custom_color", r, g, b, 1.0)
    
    def get_custom_color(self) -> List[float]:
        """获取自定义颜色"""
        return self.get_color("custom_color", [0.0, 0.0, 0.0, 1.0])
    
    def mark_as_important(self, important: bool = True) -> None:
        """标记为重要"""
        self.set_bool("is_important", important)
    
    def is_important(self) -> bool:
        """检查是否重要"""
        return self.get_bool("is_important", False)
    
    def save_transform_data(self) -> None:
        """保存变换数据"""
        self.set_vector("saved_location", self.obj.location)
        self.set_vector("saved_rotation", self.obj.rotation_euler)
        self.set_vector("saved_scale", self.obj.scale)
    
    def restore_transform_data(self) -> None:
        """恢复变换数据"""
        if self.has("saved_location"):
            self.obj.location = self.get_vector("saved_location")
        if self.has("saved_rotation"):
            self.obj.rotation_euler = self.get_vector("saved_rotation")
        if self.has("saved_scale"):
            self.obj.scale = self.get_vector("saved_scale")


class MaterialPropertyManager(CustomPropertyManager):
    """材质属性管理器"""
    
    def __init__(self, mat):
        super().__init__(mat)
        self.mat = mat
    
    def set_shader_type(self, shader_type: str) -> None:
        """设置着色器类型"""
        valid_types = ['PRINCIPLED', 'EMISSION', 'TOON', 'GLOSSY']
        if shader_type not in valid_types:
            shader_type = valid_types[0]
        self.set_string("shader_type", shader_type)
    
    def get_shader_type(self) -> str:
        """获取着色器类型"""
        return self.get_string("shader_type", "PRINCIPLED")
    
    def set_render_weight(self, weight: float) -> None:
        """设置渲染权重"""
        self.set_float("render_weight", max(0.0, min(1.0, weight)))
    
    def get_render_weight(self) -> float:
        """获取渲染权重"""
        return self.get_float("render_weight", 1.0)
    
    def set_subsurface_color(self, r: float, g: float, b: float) -> None:
        """设置次表面颜色"""
        self.set_color("subsurface_color", r, g, b, 1.0)
    
    def get_subsurface_color(self) -> List[float]:
        """获取次表面颜色"""
        return self.get_color("subsurface_color", [0.8, 0.2, 0.2, 1.0])


def create_property_managers():
    """创建属性管理器"""
    obj = bpy.context.active_object
    
    if obj:
        obj_manager = ObjectPropertyManager(obj)
        print(f"对象属性管理器已创建: {obj.name}")
        return obj_manager
    
    mat = bpy.context.active_object.active_material if bpy.context.active_object else None
    
    if mat:
        mat_manager = MaterialPropertyManager(mat)
        print(f"材质属性管理器已创建: {mat.name}")
        return mat_manager
    
    print("未选中对象或材质")
    return None
```

### 插件配置系统

```python
import bpy
from idprop.types import IDPropertyGroup
import json
import os

class PluginConfigManager:
    """插件配置管理器"""
    
    def __init__(self, plugin_name: str):
        self.plugin_name = plugin_name
        self.config_group = "_plugin_config"
        self._ensure_config()
    
    def _ensure_config(self):
        """确保配置组存在"""
        if self.config_group not in bpy.context.scene:
            bpy.context.scene[self.config_group] = {}
    
    @property
    def config(self):
        """获取配置"""
        return bpy.context.scene[self.config_group].get(self.plugin_name, {})
    
    def _get_or_create_config(self):
        """获取或创建配置"""
        if self.plugin_name not in bpy.context.scene[self.config_group]:
            bpy.context.scene[self.config_group][self.plugin_name] = {}
        return bpy.context.scene[self.config_group][self.plugin_name]
    
    def set(self, key: str, value) -> None:
        """设置配置值"""
        config = self._get_or_create_config()
        
        # 类型检查和转换
        if isinstance(value, bool):
            config[key] = bool(value)
        elif isinstance(value, int):
            config[key] = int(value)
        elif isinstance(value, float):
            config[key] = float(value)
        elif isinstance(value, str):
            config[key] = str(value)
        elif isinstance(value, (list, tuple)):
            config[key] = list(value)
        elif isinstance(value, dict):
            config[key] = dict(value)
        else:
            config[key] = value
    
    def get(self, key: str, default=None):
        """获取配置值"""
        config = self._get_or_create_config()
        return config.get(key, default)
    
    def remove(self, key: str) -> bool:
        """删除配置项"""
        config = self._get_or_create_config()
        if key in config:
            del config[key]
            return True
        return False
    
    def clear(self) -> None:
        """清除所有配置"""
        config = self._get_or_create_config()
        config.clear()
    
    def export_config(self, filepath: str) -> bool:
        """导出配置到文件"""
        config = self._get_or_create_config()
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(dict(config), f, indent=2, ensure_ascii=False)
            print(f"配置已导出到: {filepath}")
            return True
        except Exception as e:
            print(f"导出配置失败: {e}")
            return False
    
    def import_config(self, filepath: str) -> bool:
        """从文件导入配置"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                imported_config = json.load(f)
            
            config = self._get_or_create_config()
            config.clear()
            config.update(imported_config)
            
            print(f"配置已从 {filepath} 导入")
            return True
        except Exception as e:
            print(f"导入配置失败: {e}")
            return False
    
    def reset_to_defaults(self) -> None:
        """重置为默认配置"""
        defaults = {
            'auto_save': True,
            'save_interval': 300,
            'debug_mode': False,
            'language': 'en',
            'theme': 'DARK',
            'recent_files': []
        }
        
        config = self._get_or_create_config()
        config.clear()
        config.update(defaults)
        print("配置已重置为默认值")


class AddonPreferencesManager:
    """插件偏好设置管理器"""
    
    def __init__(self, addon_name: str):
        self.addon_name = addon_name
        self.prefs_name = "_addon_preferences"
    
    def get_preferences(self):
        """获取偏好设置"""
        if self.prefs_name not in bpy.context.scene:
            bpy.context.scene[self.prefs_name] = {}
        
        return bpy.context.scene[self.prefs_name].get(self.addon_name, {})
    
    def set_hotkey(self, hotkey_name: str, key: str, ctrl: bool = False, 
                   shift: bool = False, alt: bool = False) -> None:
        """设置快捷键"""
        prefs = self.get_preferences()
        
        if 'hotkeys' not in prefs:
            prefs['hotkeys'] = {}
        
        prefs['hotkeys'][hotkey_name] = {
            'key': key,
            'ctrl': ctrl,
            'shift': shift,
            'alt': alt
        }
    
    def get_hotkey(self, hotkey_name: str) -> dict:
        """获取快捷键"""
        prefs = self.get_preferences()
        hotkeys = prefs.get('hotkeys', {})
        return hotkeys.get(hotkey_name, {})
    
    def set_ui_scale(self, scale: float) -> None:
        """设置界面缩放"""
        prefs = self.get_preferences()
        prefs['ui_scale'] = max(0.5, min(2.0, scale))
    
    def get_ui_scale(self) -> float:
        """获取界面缩放"""
        return self.get_preferences().get('ui_scale', 1.0)
    
    def set_cache_size(self, size_mb: int) -> None:
        """设置缓存大小"""
        prefs = self.get_preferences()
        prefs['cache_size_mb'] = max(100, min(10000, size_mb))
    
    def get_cache_size(self) -> int:
        """获取缓存大小"""
        return self.get_preferences().get('cache_size_mb', 500)
    
    def enable_feature(self, feature_name: str) -> None:
        """启用功能"""
        prefs = self.get_preferences()
        
        if 'features' not in prefs:
            prefs['features'] = {}
        
        prefs['features'][feature_name] = True
    
    def disable_feature(self, feature_name: str) -> None:
        """禁用功能"""
        prefs = self.get_preferences()
        
        if 'features' in prefs:
            prefs['features'][feature_name] = False
    
    def is_feature_enabled(self, feature_name: str) -> bool:
        """检查功能是否启用"""
        prefs = self.get_preferences()
        features = prefs.get('features', {})
        return features.get(feature_name, False)


def setup_plugin_configuration():
    """设置插件配置"""
    config_manager = PluginConfigManager("MyBlenderPlugin")
    
    # 设置默认配置
    config_manager.set('version', '1.0.0')
    config_manager.set('auto_save', True)
    config_manager.set('save_interval', 300)
    config_manager.set('debug_mode', False)
    config_manager.set('max_history', 20)
    
    prefs_manager = AddonPreferencesManager("MyBlenderPlugin")
    prefs_manager.set_hotkey("open_panel", 'P', ctrl=True)
    prefs_manager.set_ui_scale(1.0)
    prefs_manager.set_cache_size(500)
    
    print("插件配置已设置")
    
    return config_manager, prefs_manager
```

### 场景状态保存系统

```python
import bpy
from idprop.types import IDPropertyGroup
from typing import Dict, List, Any
import json

class SceneStateManager:
    """场景状态管理器"""
    
    def __init__(self):
        self.state_group = "_scene_states"
        self._ensure_state_group()
    
    def _ensure_state_group(self):
        """确保状态组存在"""
        if self.state_group not in bpy.context.scene:
            bpy.context.scene[self.state_group] = {}
    
    @property
    def states(self):
        """获取所有状态"""
        return bpy.context.scene[self.state_group]
    
    def save_current_state(self, name: str) -> bool:
        """保存当前场景状态"""
        scene = bpy.context.scene
        
        state = {
            'frame': scene.frame_current,
            'frame_start': scene.frame_start,
            'frame_end': scene.frame_end,
            'render_resolution': (scene.render.resolution_x, scene.render.resolution_y),
            'object_states': self._save_object_states(),
            'collection_states': self._save_collection_states()
        }
        
        self.states[name] = state
        print(f"已保存状态: {name}")
        return True
    
    def _save_object_states(self) -> Dict[str, Dict]:
        """保存对象状态"""
        object_states = {}
        
        for obj in bpy.data.objects:
            object_states[obj.name] = {
                'location': list(obj.location),
                'rotation_euler': list(obj.rotation_euler),
                'scale': list(obj.scale),
                'visible': obj.visible_get(),
                'select': obj.select_get()
            }
        
        return object_states
    
    def _save_collection_states(self) -> Dict[str, Dict]:
        """保存集合状态"""
        collection_states = {}
        
        for coll in bpy.data.collections:
            collection_states[coll.name] = {
                'hide_viewport': coll.hide_viewport,
                'hide_render': coll.hide_render,
                'objects': [obj.name for obj in coll.objects]
            }
        
        return collection_states
    
    def restore_state(self, name: str) -> bool:
        """恢复场景状态"""
        if name not in self.states:
            print(f"未找到状态: {name}")
            return False
        
        state = self.states[name]
        scene = bpy.context.scene
        
        # 恢复帧设置
        scene.frame_current = state.get('frame', 1)
        scene.frame_start = state.get('frame_start', 1)
        scene.frame_end = state.get('frame_end', 250)
        
        # 恢复渲染分辨率
        res = state.get('render_resolution', (1920, 1080))
        scene.render.resolution_x = res[0]
        scene.render.resolution_y = res[1]
        
        # 恢复对象状态
        if 'object_states' in state:
            self._restore_object_states(state['object_states'])
        
        # 恢复集合状态
        if 'collection_states' in state:
            self._restore_collection_states(state['collection_states'])
        
        print(f"已恢复状态: {name}")
        return True
    
    def _restore_object_states(self, object_states: Dict[str, Dict]) -> None:
        """恢复对象状态"""
        for obj_name, obj_state in object_states.items():
            obj = bpy.data.objects.get(obj_name)
            if obj:
                obj.location = obj_state.get('location', obj.location)
                obj.rotation_euler = obj_state.get('rotation_euler', obj.rotation_euler)
                obj.scale = obj_state.get('scale', obj.scale)
    
    def _restore_collection_states(self, collection_states: Dict[str, Dict]) -> None:
        """恢复集合状态"""
        for coll_name, coll_state in collection_states.items():
            coll = bpy.data.collections.get(coll_name)
            if coll:
                coll.hide_viewport = coll_state.get('hide_viewport', False)
                coll.hide_render = coll_state.get('hide_render', False)
    
    def delete_state(self, name: str) -> bool:
        """删除状态"""
        if name in self.states:
            del self.states[name]
            print(f"已删除状态: {name}")
            return True
        return False
    
    def list_states(self) -> List[str]:
        """列出所有保存的状态"""
        return list(self.states.keys())
    
    def export_states(self, filepath: str) -> bool:
        """导出所有状态到文件"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(dict(self.states), f, indent=2, ensure_ascii=False)
            print(f"状态已导出到: {filepath}")
            return True
        except Exception as e:
            print(f"导出失败: {e}")
            return False
    
    def import_states(self, filepath: str) -> bool:
        """从文件导入状态"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                imported_states = json.load(f)
            
            self.states.clear()
            self.states.update(imported_states)
            
            print(f"状态已从 {filepath} 导入")
            return True
        except Exception as e:
            print(f"导入失败: {e}")
            return False


def manage_scene_states():
    """管理场景状态"""
    manager = SceneStateManager()
    
    # 保存当前状态
    manager.save_current_state("initial")
    
    # 执行一些操作...
    
    # 恢复初始状态
    manager.restore_state("initial")
    
    # 列出所有状态
    print(f"已保存的状态: {manager.list_states()}")
    
    return manager
```

## 最佳实践

1. **命名规范**：使用前缀或特定命名空间组织自定义属性，避免冲突
2. **类型安全**：始终进行类型检查和转换，确保属性类型正确
3. **版本控制**：在属性组中包含版本信息，便于未来迁移和升级
4. **数据验证**：设置属性时进行范围和有效性验证
5. **备份恢复**：实现状态的保存和恢复机制，保护用户数据
