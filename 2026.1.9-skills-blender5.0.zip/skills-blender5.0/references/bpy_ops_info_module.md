# bpy.ops.info - Info Area Operations Module

Blender 信息区域操作符，用于获取系统信息和日志记录。

## Overview

`bpy.ops.info` 模块包含信息区域的操作命令，支持报告选择、复制和系统信息获取。这个模块主要用于调试和信息查询。

## 核心功能

```python
import bpy

# 全选报告
bpy.ops.info.select_all(action='SELECT')

# 复制报告
bpy.ops.info.copy()

# 报告类型过滤
bpy.ops.info.report_type_update()
bpy.ops.info.report_copy()

# 重启 Blender
bpy.ops.info.restart_blender()
```

## 实际应用示例

### 信息报告管理器

```python
import bpy

class InfoReportManager:
    """信息报告管理器"""
    
    def __init__(self):
        self.reports = []
    
    def select_all_reports(self):
        """全选报告"""
        bpy.ops.info.select_all(action='SELECT')
    
    def deselect_all_reports(self):
        """取消选择"""
        bpy.ops.info.select_all(action='DESELECT')
    
    def select_by_type(self, report_type):
        """按类型选择"""
        self.select_all_reports()
        # 过滤类型
        for area in bpy.context.screen.areas:
            if area.type == 'INFO':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        for ui_item in region.ui_items:
                            if hasattr(ui_item, 'report_type'):
                                if ui_item.report_type != report_type:
                                    ui_item.select = False
    
    def copy_all_reports(self):
        """复制所有报告"""
        self.select_all_reports()
        bpy.ops.info.copy()
        return bpy.context.window_manager.clipboard
    
    def copy_error_reports(self):
        """复制错误报告"""
        self.select_by_type('ERROR')
        return self.copy_all_reports()
    
    def copy_warning_reports(self):
        """复制警告报告"""
        self.select_by_type('WARNING')
        return self.copy_all_reports()
    
    def get_report_summary(self):
        """获取报告摘要"""
        summary = {
            'errors': 0,
            'warnings': 0,
            'info': 0,
            'debug': 0
        }
        
        for area in bpy.context.screen.areas:
            if area.type == 'INFO':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        for ui_item in region.ui_items:
                            if hasattr(ui_item, 'report_type'):
                                summary[ui_item.report_type] = summary.get(ui_item.report_type, 0) + 1
        
        return summary
    
    def clear_all_reports(self):
        """清除所有报告"""
        bpy.ops.info.select_all(action='SELECT')
        bpy.ops.info.delete(type='SELECTED')
    
    def export_reports(self, filepath):
        """导出报告"""
        content = self.copy_all_reports()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return filepath
    
    def restart_blender_safe(self):
        """安全重启 Blender"""
        # 保存当前状态
        bpy.ops.wm.save_homefile()
        
        # 重启
        bpy.ops.info.restart_blender()


def setup_info_manager():
    """设置信息管理器"""
    manager = InfoReportManager()
    
    # 获取当前报告摘要
    summary = manager.get_report_summary()
    print(f"报告摘要: {summary}")
    
    return manager
```

### 系统诊断工具

```python
import bpy
import sys
import platform

class SystemDiagnostics:
    """系统诊断工具"""
    
    def __init__(self):
        self.diagnostics = {}
    
    def get_blender_info(self):
        """获取 Blender 信息"""
        return {
            'version': bpy.app.version_string,
            'version_major': bpy.app.version_major,
            'version_minor': bpy.app.version_minor,
            'build_hash': bpy.app.build_hash,
            'build_branch': bpy.app.build_branch,
            'platform': platform.system(),
            'architecture': platform.architecture(),
            'python_version': sys.version
        }
    
    def get_memory_usage(self):
        """获取内存使用"""
        return {
            'total_memory_mb': bpy.app.driver_mem_cache / (1024 * 1024),
            'texture_memory_mb': bpy.app.tex_mem_cache / (1024 * 1024)
        }
    
    def get_render_info(self):
        """获取渲染信息"""
        scene = bpy.context.scene
        return {
            'engine': scene.render.engine,
            'resolution': f"{scene.render.resolution_x}x{scene.render.resolution_y}",
            'fps': scene.render.fps,
            'frame_start': scene.frame_start,
            'frame_end': scene.frame_end
        }
    
    def get_object_stats(self):
        """获取对象统计"""
        stats = {
            'total_objects': len(bpy.data.objects),
            'meshes': 0,
            'cameras': 0,
            'lights': 0,
            'armatures': 0,
            'curves': 0
        }
        
        for obj in bpy.data.objects:
            stats[f'{obj.type}s'] = stats.get(f'{obj.type}s', 0) + 1
        
        return stats
    
    def run_full_diagnostics(self):
        """运行完整诊断"""
        self.diagnostics = {
            'blender': self.get_blender_info(),
            'memory': self.get_memory_usage(),
            'render': self.get_render_info(),
            'objects': self.get_object_stats()
        }
        
        return self.diagnostics
    
    def export_diagnostics(self, filepath):
        """导出诊断结果"""
        import json
        
        if not self.diagnostics:
            self.run_full_diagnostics()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.diagnostics, f, indent=2, ensure_ascii=False)
        
        return filepath
    
    def print_diagnostics(self):
        """打印诊断结果"""
        if not self.diagnostics:
            self.run_full_diagnostics()
        
        print("=== Blender 诊断信息 ===")
        print(f"版本: {self.diagnostics['blender']['version']}")
        print(f"平台: {self.diagnostics['blender']['platform']}")
        print(f"内存: {self.diagnostics['memory']['total_memory_mb']:.2f} MB")
        print(f"对象数: {self.diagnostics['objects']['total_objects']}")


def run_system_check():
    """运行系统检查"""
    diagnostics = SystemDiagnostics()
    diagnostics.run_full_diagnostics()
    diagnostics.print_diagnostics()
    return diagnostics
```
