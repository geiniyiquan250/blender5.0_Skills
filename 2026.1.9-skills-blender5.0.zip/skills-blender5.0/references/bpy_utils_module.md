# bpy.utils 模块

bpy.utils 模块提供了 Blender Python API 中各种工具函数，用于对象操作、注册、序列化等任务。

## 工具函数概述

工具函数模块包含了许多实用的辅助函数，涵盖对象管理、模块注册、数据序列化等功能。

### 何时使用工具函数

- 注册和注销自定义类
- 序列化 Blender 数据
- 对象和集合操作
- 路径和文件操作
- 单元系统和本地化

## 模块注册

### register_class

注册 Blender 类（运算符、面板、属性组等）。

```python
import bpy

# 注册自定义运算符
class MyOperator(bpy.types.Operator):
    bl_idname = "object.my_operator"
    bl_label = "我的运算符"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        self.report({'INFO'}, "运算符执行成功")
        return {'FINISHED'}

# 注册类
bpy.utils.register_class(MyOperator)

# 注销类
bpy.utils.unregister_class(MyOperator)
```

### register_submodule_factory

注册模块工厂，用于批量注册模块中的类。

```python
import bpy
from importlib import import_module

# 定义要注册的模块列表
submodule_names = (
    "operators",
    "panels",
    "properties",
)

# 批量注册模块
register_factory, unregister_factory = bpy.utils.register_submodule_factory(
    __package__, submodule_names
)

# 在注册函数中调用
def register():
    register_factory()

# 在注销函数中调用
def unregister():
    unregister_factory()
```

### unregister_manual_map

注销手动映射。

```python
# 注册手动映射
manual_map = bpy.utils.manual_map()
manual_map.add((MyOperator, "doc/manual/mymodule.html"))

# 注销时清理
bpy.utils.unregister_manual_map(manual_map)
```

## 对象工具函数

### object_pack_all

打包所有未打包的图像。

```python
# 打包所有未打包的图像
bpy.utils.object_pack_all()

# 仅打包指定类型的对象
bpy.utils.object_pack_all(force_pack=True)

# 仅打包选定对象中的未打包图像
for obj in bpy.context.selected_objects:
    if obj.type == 'MESH':
        bpy.utils.object_pack_all()
```

### object_udpate_all

更新所有对象。

```python
# 强制更新所有对象
bpy.utils.object_update_all()

# 重新计算所有对象的变换
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
bpy.utils.object_update_all()
```

### scene_update_all

更新所有场景。

```python
# 刷新所有场景数据
bpy.utils.scene_update_all()
```

## 数据块工具

### idmaker_py

生成 Python 代码来表示数据块。

```python
# 生成对象的 Python 表示
obj = bpy.context.active_object
code = bpy.utils.idmaker_py(obj)

print(code)
```

### user_resource

获取用户资源目录路径。

```python
# 获取用户脚本目录
scripts_path = bpy.utils.user_resource('SCRIPTS')
print(f"脚本目录: {scripts_path}")

# 获取用户配置目录
config_path = bpy.utils.user_resource('CONFIG')
print(f"配置目录: {config_path}")

# 获取用户数据目录
data_path = bpy.utils.user_resource('DATAFILES')
print(f"数据目录: {data_path}")
```

## 单元系统

### units.convert

单位转换函数。

```python
from bpy.utils import units

# 将 Blender 单位转换为其他单位
blender_units = 1.0  # 1 米
meters = units.to_value('METERS', blender_units)
print(f"{blender_units} Blender 单位 = {meters} 米")

# 将厘米转换为 Blender 单位
centimeters = 100
blender_units = units.from_value('METERS', centimeters)
print(f"{centimeters} 厘米 = {blender_units} Blender 单位")

# 使用不同的单位系统
# 单位类型：'METERS', 'CENTIMETERS', 'MILLIMETERS', 'FEET', 'INCHES'
value = units.to_value('FEET', 1.0, unit_system='IMPERIAL')
print(f"1 米 = {value} 英尺")
```

### units.user_system

获取当前用户使用的单位系统。

```python
from bpy.utils import units

# 获取当前单位系统
user_system = units.user_system()
print(f"当前单位系统: {user_system}")
# 返回: 'METRIC' 或 'IMPERIAL'
```

## 序列化和反序列化

### data_create_tuple

创建数据的元组表示。

```python
import bpy

# 获取对象的 Python 数据元组
obj = bpy.context.active_object
if obj and obj.type == 'MESH':
    data_tuple = bpy.utils.data_create_tuple(obj.data)
    print(f"顶点数量: {len(data_tuple[0])}")
    print(f"边数量: {len(data_tuple[1])}")
    print(f"面数量: {len(data_tuple[2])}")
```

## 实际应用示例

### 插件注册系统

```python
import bpy
from importlib import import_module
import sys

class AddonManager:
    def __init__(self, module_name):
        self.module_name = module_name
        self.classes = []
        self.handlers = []
        self.keymaps = []
    
    def register_class(self, cls):
        """注册单个类"""
        if issubclass(cls, bpy.types.Operator):
            bpy.utils.register_class(cls)
            self.classes.append(cls)
        elif issubclass(cls, bpy.types.Panel):
            bpy.utils.register_class(cls)
            self.classes.append(cls)
        elif issubclass(cls, bpy.types.PropertyGroup):
            bpy.utils.register_class(cls)
            self.classes.append(cls)
        elif issubclass(cls, bpy.types.Menu):
            bpy.utils.register_class(cls)
            self.classes.append(cls)
    
    def register_module(self, module_name):
        """注册模块中的所有类"""
        try:
            module = import_module(f"{self.module_name}.{module_name}")
            
            # 查找所有注册的类
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (isinstance(attr, type) and 
                    issubclass(attr, bpy.types.bpy_struct) and 
                    attr.bl_rna is not None):
                    self.register_class(attr)
            
            print(f"模块 {module_name} 注册完成")
            return True
        except Exception as e:
            print(f"注册模块 {module_name} 失败: {e}")
            return False
    
    def register_handler(self, handler_func, event_type):
        """注册事件处理器"""
        if event_type == 'frame':
            bpy.app.handlers.frame_change_pre.append(handler_func)
        elif event_type == 'save':
            bpy.app.handlers.save_post.append(handler_func)
        elif event_type == 'load':
            bpy.app.handlers.load_post.append(handler_func)
        
        self.handlers.append((handler_func, event_type))
    
    def register_keymap(self, km_name, kmi_name, key, ctrl=False, shift=False, alt=False):
        """注册快捷键"""
        wm = bpy.context.window_manager
        km = wm.keyconfigs.default.keymaps.get(km_name)
        
        if km:
            kmi = km.keymap_items.new(kmi_name, key, 'PRESS',
                                     ctrl=ctrl, shift=shift, alt=alt)
            self.keymaps.append((km, kmi))
    
    def unregister(self):
        """注销所有注册的内容"""
        # 注销快捷键
        for km, kmi in self.keymaps:
            km.keymap_items.remove(kmi)
        self.keymaps.clear()
        
        # 注销事件处理器
        for handler_func, event_type in self.handlers:
            if event_type == 'frame':
                if handler_func in bpy.app.handlers.frame_change_pre:
                    bpy.app.handlers.frame_change_pre.remove(handler_func)
            elif event_type == 'save':
                if handler_func in bpy.app.handlers.save_post:
                    bpy.app.handlers.save_post.remove(handler_func)
            elif event_type == 'load':
                if handler_func in bpy.app.handlers.load_post:
                    bpy.app.handlers.load_post.remove(handler_func)
        self.handlers.clear()
        
        # 注销类
        for cls in reversed(self.classes):
            try:
                bpy.utils.unregister_class(cls)
            except Exception as e:
                print(f"注销类 {cls} 失败: {e}")
        self.classes.clear()
    
    def register(self):
        """执行注册"""
        # 注册模块
        module_names = ['operators', 'panels', 'properties', 'menus']
        for module_name in module_names:
            self.register_module(module_name)
        
        # 注册快捷键
        self.register_keymap('Object Mode', 'object.my_operator', 'F', ctrl=True)


class MyAddon:
    def __init__(self):
        self.manager = AddonManager(__name__)
    
    def register(self):
        self.manager.register()
    
    def unregister(self):
        self.manager.unregister()
```

### 场景数据导出工具

```python
import bpy
import json
from bpy.utils import units

class SceneExporter:
    def __init__(self):
        self.export_data = {
            'scene': {},
            'objects': [],
            'materials': [],
            'collections': []
        }
    
    def export_scene_info(self):
        """导出场景基本信息"""
        scene = bpy.context.scene
        
        self.export_data['scene'] = {
            'name': scene.name,
            'frame_current': scene.frame_current,
            'frame_start': scene.frame_start,
            'frame_end': scene.frame_end,
            'fps': scene.render.fps,
            'resolution_x': scene.render.resolution_x,
            'resolution_y': scene.render.resolution_y,
            'unit_system': units.user_system()
        }
        
        # 导出单位信息
        if scene.unit_settings.system == 'METRIC':
            self.export_data['scene']['unit_scale'] = scene.unit_settings.scale_length
            self.export_data['scene']['unit'] = 'METERS'
        else:
            self.export_data['scene']['unit_scale'] = 1.0
            self.export_data['scene']['unit'] = 'FEET'
        
        return self.export_data['scene']
    
    def export_objects(self, selected_only=False):
        """导出对象数据"""
        objects = bpy.context.selected_objects if selected_only else bpy.context.scene.objects
        
        for obj in objects:
            obj_data = {
                'name': obj.name,
                'type': obj.type,
                'location': list(obj.location),
                'rotation_euler': list(obj.rotation_euler),
                'rotation_quaternion': list(obj.rotation_quaternion),
                'scale': list(obj.scale),
                'matrix_world': [list(row) for row in obj.matrix_world],
                'parent': obj.parent.name if obj.parent else None,
                'data_name': obj.data.name if obj.data else None,
                'collections': [coll.name for coll in obj.users_collection]
            }
            
            if obj.type == 'MESH':
                obj_data['mesh'] = {
                    'vertex_count': len(obj.data.vertices),
                    'edge_count': len(obj.data.edges),
                    'polygon_count': len(obj.data.polygons),
                    'material_slots': [ms.name for ms in obj.material_slots]
                }
            
            elif obj.type == 'CAMERA':
                obj_data['camera'] = {
                    'lens': obj.data.lens,
                    'sensor_size': obj.data.sensor_size,
                    'clip_start': obj.data.clip_start,
                    'clip_end': obj.data.clip_end
                }
            
            elif obj.type == 'LIGHT':
                obj_data['light'] = {
                    'type': obj.data.type,
                    'energy': obj.data.energy,
                    'color': list(obj.data.color),
                    'radius': obj.data.radius
                }
            
            self.export_data['objects'].append(obj_data)
        
        return self.export_data['objects']
    
    def export_materials(self):
        """导出材质数据"""
        for mat in bpy.data.materials:
            mat_data = {
                'name': mat.name,
                'use_nodes': mat.use_nodes,
                'blend_method': mat.blend_method,
                'shadow_method': mat.shadow_method,
                'nodes': []
            }
            
            if mat.use_nodes:
                for node in mat.node_tree.nodes:
                    node_data = {
                        'name': node.name,
                        'type': node.type,
                        'location': list(node.location),
                        'inputs': {},
                        'outputs': {}
                    }
                    
                    for input in node.inputs:
                        if input.is_linked:
                            node_data['inputs'][input.name] = {
                                'linked': True,
                                'from_node': input.links[0].from_node.name
                            }
                        else:
                            node_data['inputs'][input.name] = {
                                'linked': False,
                                'value': list(input.default_value) if hasattr(input, 'default_value') else None
                            }
                    
                    for output in node.outputs:
                        node_data['outputs'][output.name] = {
                            'linked': len(output.links) > 0
                        }
                    
                    mat_data['nodes'].append(node_data)
            
            self.export_data['materials'].append(mat_data)
        
        return self.export_data['materials']
    
    def export_collections(self):
        """导出集合数据"""
        for coll in bpy.data.collections:
            coll_data = {
                'name': coll.name,
                'objects': [obj.name for obj in coll.objects],
                'children': [child.name for child in coll.children],
                'parent': coll.parent.name if coll.parent else None
            }
            self.export_data['collections'].append(coll_data)
        
        return self.export_data['collections']
    
    def export_to_dict(self, selected_only=False):
        """导出所有数据到字典"""
        self.export_scene_info()
        self.export_objects(selected_only)
        self.export_materials()
        self.export_collections()
        return self.export_data
    
    def export_to_json(self, filepath, selected_only=False):
        """导出到 JSON 文件"""
        self.export_to_dict(selected_only)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.export_data, f, ensure_ascii=False, indent=2)
        
        print(f"场景数据已导出到: {filepath}")
        return self.export_data
```

### 单位转换工具

```python
from bpy.utils import units

class UnitConverter:
    def __init__(self):
        self.unit_systems = ['METRIC', 'IMPERIAL']
        self.units = {
            'METRIC': ['METERS', 'CENTIMETERS', 'MILLIMETERS', 'KILOMETERS'],
            'IMPERIAL': ['FEET', 'INCHES', 'YARDS', 'MILES']
        }
    
    def convert(self, value, from_unit, to_unit, from_system='METRIC', to_system='METRIC'):
        """转换单位"""
        # 先转换为 Blender 单位（米）
        blender_value = self.to_blender(value, from_unit, from_system)
        
        # 从 Blender 单位转换到目标单位
        result = self.from_blender(blender_value, to_unit, to_system)
        
        return result
    
    def to_blender(self, value, unit, system='METRIC'):
        """转换为 Blender 单位（米）"""
        if unit == 'METERS':
            return value
        elif unit == 'CENTIMETERS':
            return value / 100
        elif unit == 'MILLIMETERS':
            return value / 1000
        elif unit == 'KILOMETERS':
            return value * 1000
        elif unit == 'FEET':
            return value * 0.3048
        elif unit == 'INCHES':
            return value * 0.0254
        elif unit == 'YARDS':
            return value * 0.9144
        elif unit == 'MILES':
            return value * 1609.344
        else:
            return value
    
    def from_blender(self, blender_value, unit, system='METRIC'):
        """从 Blender 单位转换"""
        if unit == 'METERS':
            return blender_value
        elif unit == 'CENTIMETERS':
            return blender_value * 100
        elif unit == 'MILLIMETERS':
            return blender_value * 1000
        elif unit == 'KILOMETERS':
            return blender_value / 1000
        elif unit == 'FEET':
            return blender_value / 0.3048
        elif unit == 'INCHES':
            return blender_value / 0.0254
        elif unit == 'YARDS':
            return blender_value / 0.9144
        elif unit == 'MILES':
            return blender_value / 1609.344
        else:
            return blender_value
    
    def format_distance(self, blender_value, system='METRIC', decimals=2):
        """格式化距离值"""
        if system == 'METRIC':
            if blender_value >= 1000:
                return f"{blender_value / 1000:.2f} km"
            elif blender_value >= 1:
                return f"{blender_value:.2f} m"
            elif blender_value >= 0.01:
                return f"{blender_value * 100:.1f} cm"
            else:
                return f"{blender_value * 1000:.1f} mm"
        else:
            if blender_value >= 1609.344:
                return f"{blender_value / 1609.344:.2f} mi"
            elif blender_value >= 0.3048:
                feet = blender_value / 0.3048
                inches = (feet % 1) * 12
                return f"{int(feet)}'{int(inches)}\""
            else:
                return f"{blender_value / 0.0254:.1f} in"
    
    def get_user_settings(self):
        """获取用户的单位设置"""
        scene = bpy.context.scene
        
        settings = {
            'system': units.user_system(),
            'scale_length': scene.unit_settings.scale_length if hasattr(scene, 'unit_settings') else 1.0
        }
        
        return settings
```

## 最佳实践

1. **模块组织**：使用 register_submodule_factory 批量注册模块，保持代码整洁
2. **资源清理**：在注销时清理所有注册的类和处理器
3. **单位处理**：使用 units 模块进行单位转换，避免硬编码数值
4. **错误处理**：在注册过程中添加异常处理，提高插件稳定性
5. **数据导出**：使用用户资源目录存储插件数据，遵循 Blender 规范
