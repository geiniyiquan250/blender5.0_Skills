# bpy_extras.object_utils - 对象工具模块

bpy_extras.object_utils模块提供了对象创建、对象变换和对象数据管理的实用工具函数。

## 概述

对象工具模块封装了Blender中常见的对象操作，包括对象的创建、数据添加、坐标转换等功能。适用于开发自动化建模工具和对象管理插件。

## 核心功能

### 对象创建

```python
import bpy
import mathutils
from mathutils import Vector, Matrix
from bpy_extras.object_utils import (
    object_data_add,
    object_data_link,
    add_object_align_init
)

def create_mesh_object(name, vertices, edges=None, faces=None, location=(0, 0, 0)):
    """创建网格对象"""
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(vertices, edges if edges else [], faces if faces else [])
    mesh.update()
    
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    
    return obj

def create_curve_object(name, points, location=(0, 0, 0)):
    """创建曲线对象"""
    curve_data = bpy.data.curves.new(name, type='CURVE')
    curve_data.dimensions = '3D'
    
    spline = curve_data.splines.new('BEZIER')
    spline.bezier_points.add(len(points) - 1)
    for i, point in enumerate(points):
        spline.bezier_points[i].co = point
    
    obj = bpy.data.objects.new(name, curve_data)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    
    return obj

def add_primitive_cube(location=(0, 0, 0), size=2):
    """添加立方体"""
    bpy.ops.mesh.primitive_cube_add(size=size, location=location)
    return bpy.context.active_object

def add_primitive_sphere(location=(0, 0, 0), radius=1, segments=32, ring_count=16):
    """添加球体"""
    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=radius, 
        segments=segments, 
        ring_count=ring_count,
        location=location
    )
    return bpy.context.active_object

def add_primitive_cylinder(location=(0, 0, 0), radius=1, depth=2, vertices=32):
    """添加圆柱体"""
    bpy.ops.mesh.primitive_cylinder_add(
        radius=radius, 
        depth=depth, 
        vertices=vertices,
        location=location
    )
    return bpy.context.active_object
```

### 对象数据添加

```python
def add_mesh_data(context, mesh):
    """添加网格数据到新对象"""
    return object_data_add(context, mesh)

def add_curve_data(context, curve):
    """添加曲线数据到新对象"""
    return object_data_add(context, curve)

def link_object_data(data, scene=None, collection=None, object_name=None):
    """链接数据到对象"""
    return object_data_link(data, scene, collection, object_name)

def add_object_with_alignment(context, operator, align_type='WORLD'):
    """添加带对齐的对齐"""
    matrix = add_object_align_init(context, operator, align_type=align_type)
    return matrix
```

### 坐标转换

```python
def world_to_local(obj, world_co):
    """世界坐标转局部坐标"""
    return obj.matrix_world.inverted() @ world_co

def local_to_world(obj, local_co):
    """局部坐标转世界坐标"""
    return obj.matrix_world @ local_co

def world_to_object(obj, point):
    """将点转换到对象空间"""
    return obj.matrix_world.inverted() @ point

def object_to_world(point):
    """将点转换到世界空间"""
    return bpy.context.active_object.matrix_world @ point

def transform_point_by_matrix(point, matrix):
    """通过矩阵变换点"""
    return matrix @ point

def transform_vector_by_matrix(vector, matrix):
    """通过矩阵变换向量"""
    return (matrix.to_3x3() @ vector)

def get_object_bounds(obj, apply_modifiers=True):
    """获取对象边界框"""
    depsgraph = bpy.context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    try:
        coords = [v.co for v in mesh.vertices]
        if not coords:
            return None, None
        min_co = Vector(min(c[i] for c in coords) for i in range(3))
        max_co = Vector(max(c[i] for c in coords) for i in range(3))
        return min_co, max_co
    finally:
        eval_obj.to_mesh_clear()
```

## 实用函数

### 对象变换

```python
def set_location(obj, location):
    """设置位置"""
    obj.location = location

def set_rotation(obj, rotation_euler=None, rotation_axis_angle=None):
    """设置旋转"""
    if rotation_euler:
        obj.rotation_euler = rotation_euler
    elif rotation_axis_angle:
        obj.rotation_axis_angle = rotation_axis_angle

def set_scale(obj, scale):
    """设置缩放"""
    obj.scale = scale

def reset_transform(obj):
    """重置变换"""
    obj.location = (0, 0, 0)
    obj.rotation_euler = (0, 0, 0)
    obj.scale = (1, 1, 1)

def apply_transform(obj, location=True, rotation=True, scale=True):
    """应用变换"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(
        location=location, 
        rotation=rotation, 
        scale=scale
    )

def duplicate_object(obj, linked=False):
    """复制对象"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.duplicate(linked=linked)
    return bpy.context.active_object
```

### 对象选择

```python
def select_object(obj, deselect_others=True):
    """选择对象"""
    if deselect_others:
        bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj

def deselect_all():
    """取消所有选择"""
    bpy.ops.object.select_all(action='DESELECT')

def select_by_type(obj_type):
    """按类型选择"""
    bpy.ops.object.select_all(action='DESELECT')
    for obj in bpy.context.scene.objects:
        if obj.type == obj_type:
            obj.select_set(True)

def select_by_name_pattern(pattern):
    """按名称模式选择"""
    bpy.ops.object.select_all(action='DESELECT')
    for obj in bpy.context.scene.objects:
        if pattern in obj.name:
            obj.select_set(True)

def get_selected_objects():
    """获取选中的对象"""
    return bpy.context.selected_objects

def get_active_object():
    """获取活动对象"""
    return bpy.context.active_object
```

### 对象层级

```python
def get_all_children(obj):
    """获取所有子对象"""
    children = []
    for child in obj.children:
        children.append(child)
        children.extend(get_all_children(child))
    return children

def get_parent_chain(obj):
    """获取父对象链"""
    chain = []
    current = obj
    while current:
        chain.append(current)
        current = current.parent
    return chain

def set_parent(obj, parent, keep_transform=True):
    """设置父对象"""
    if keep_transform:
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        parent.select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
    else:
        obj.parent = parent

def clear_parent(obj, keep_transform=True):
    """清除父对象"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM' if keep_transform else 'CLEAR')
```

## 常见问题排查

### 变换不生效

对象未激活：
- 确保对象被选中
- 设置活动对象
- 检查对象是否在视图中

### 坐标转换错误

矩阵不可逆：
- 检查对象是否有零缩放
- 确认矩阵变换有效
- 使用try-except处理异常

### 对象未找到

名称冲突：
- 使用完整的对象名称
- 检查对象是否存在
- 考虑不同集合中的同名对象
