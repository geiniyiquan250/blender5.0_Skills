# bpy.ops.import_scene - COLLADA导入操作模块

Blender COLLADA（DAE）文件导入操作符，用于将COLLADA格式文件导入Blender。

## 概述

`bpy.ops.import_scene.dae` 模块提供用于将COLLADA（DAE）格式文件导入Blender的功能，支持几何体、材质、纹理、骨骼和动画的导入。

## 核心功能

### 基础导入

```python
import bpy

# 导入DAE文件
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    directory='//',
    files=[{'name': 'model.dae'}],
    ui_tab='MAIN',
    import_units=False,
    import_animation=True,
    import_cameras=True,
    import_lights=True,
    import_meshes=True,
    import_curves=True,
    import_surfaces=True,
    import_nurbs=True,
    fix_orientation=True,
    axis_forward='Z',
    axis_up='Y',
    import_uv=True,
    import_normals=True,
    import_materials=True,
    import_textures=True,
    import_blendShapes=True,
    import_animations=True,
    animation_mode='REPLACE',
    import_force_end_frame=False,
    custom_normals=True
)
```

### 单位设置

```python
# 导入单位
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    import_units=True
)

# 不导入单位
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    import_units=False
)
```

### 动画导入

```python
# 导入动画
bpy.ops.import_scene.dae(
    filepath='//anim.dae',
    import_animation=True
)

# 不导入动画
bpy.ops.import_scene.dae(
    filepath='//static.dae',
    import_animation=False
)

# 导入动画类型
bpy.ops.import_scene.dae(
    filepath='//anim.dae',
    import_animations=True,
    animation_mode='REPLACE'
)

# 附加动画
bpy.ops.import_scene.dae(
    filepath='//anim.dae',
    import_animations=True,
    animation_mode='APPEND'
)

# 强制结束帧
bpy.ops.import_scene.dae(
    filepath='//anim.dae',
    import_animation=True,
    import_force_end_frame=True
)
```

### 几何体导入

```python
# 导入网格
bpy.ops.import_scene.dae(
    filepath='//meshes.dae',
    import_meshes=True
)

# 不导入网格
bpy.ops.import_scene.dae(
    filepath='//no_meshes.dae',
    import_meshes=False
)

# 导入曲线
bpy.ops.import_scene.dae(
    filepath='//curves.dae',
    import_curves=True
)

# 不导入曲线
bpy.ops.import_scene.dae(
    filepath='//no_curves.dae',
    import_curves=False
)

# 导入曲面
bpy.ops.import_scene.dae(
    filepath='//surfaces.dae',
    import_surfaces=True
)

# 不导入曲面
bpy.ops.import_scene.dae(
    filepath='//no_surfaces.dae',
    import_surfaces=False
)

# 导入NURBS
bpy.ops.import_scene.dae(
    filepath='//nurbs.dae',
    import_nurbs=True
)

# 不导入NURBS
bpy.ops.import_scene.dae(
    filepath='//no_nurbs.dae',
    import_nurbs=False
)
```

### 相机导入

```python
# 导入相机
bpy.ops.import_scene.dae(
    filepath='//cameras.dae',
    import_cameras=True
)

# 不导入相机
bpy.ops.import_scene.dae(
    filepath='//no_cameras.dae',
    import_cameras=False
)
```

### 灯光导入

```python
# 导入灯光
bpy.ops.import_scene.dae(
    filepath='//lights.dae',
    import_lights=True
)

# 不导入灯光
bpy.ops.import_scene.dae(
    filepath='//no_lights.dae',
    import_lights=False
)
```

### 方向修正

```python
# 修正方向
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    fix_orientation=True
)

# 不修正方向
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    fix_orientation=False
)
```

### 坐标轴设置

```python
# 设置前向轴
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    axis_forward='Z'
)

# 设置上向轴
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    axis_up='Y'
)

# 其他轴向组合
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    axis_forward='-Z',
    axis_up='Y'
)
```

### UV导入

```python
# 导入UV
bpy.ops.import_scene.dae(
    filepath='//uv.dae',
    import_uv=True
)

# 不导入UV
bpy.ops.import_scene.dae(
    filepath='//no_uv.dae',
    import_uv=False
)
```

### 法线导入

```python
# 导入法线
bpy.ops.import_scene.dae(
    filepath='//normals.dae',
    import_normals=True
)

# 不导入法线
bpy.ops.import_scene.dae(
    filepath='//no_normals.dae',
    import_normals=False
)

# 自定义法线
bpy.ops.import_scene.dae(
    filepath='//custom_normals.dae',
    custom_normals=True
)
```

### 材质导入

```python
# 导入材质
bpy.ops.import_scene.dae(
    filepath='//materials.dae',
    import_materials=True
)

# 不导入材质
bpy.ops.import_scene.dae(
    filepath='//no_materials.dae',
    import_materials=False
)

# 导入纹理
bpy.ops.import_scene.dae(
    filepath='//textures.dae',
    import_textures=True
)

# 不导入纹理
bpy.ops.import_scene.dae(
    filepath='//no_textures.dae',
    import_textures=False
)
```

### 混合形状导入

```python
# 导入混合形状
bpy.ops.import_scene.dae(
    filepath='//blendshapes.dae',
    import_blendShapes=True
)

# 不导入混合形状
bpy.ops.import_scene.dae(
    filepath='//no_blendshapes.dae',
    import_blendShapes=False
)
```

## 实用函数

```python
def import_dae_model(filepath):
    """导入DAE模型"""
    bpy.ops.import_scene.dae(
        filepath=filepath,
        import_animation=False,
        import_cameras=True,
        import_lights=True,
        import_meshes=True,
        import_uv=True,
        import_normals=True,
        import_materials=True,
        import_textures=True
    )
    return list(bpy.context.selected_objects)

def import_dae_with_animations(filepath):
    """导入DAE带动画"""
    bpy.ops.import_scene.dae(
        filepath=filepath,
        import_animation=True,
        import_animations=True,
        animation_mode='REPLACE',
        import_cameras=True,
        import_lights=True,
        import_meshes=True,
        import_uv=True,
        import_normals=True,
        import_materials=True,
        import_textures=True,
        import_blendShapes=True
    )
    return list(bpy.context.selected_objects)

def import_dae_for_editing(filepath):
    """导入DAE用于编辑"""
    bpy.ops.import_scene.dae(
        filepath=filepath,
        import_animation=False,
        import_cameras=False,
        import_lights=False,
        import_meshes=True,
        import_uv=True,
        import_normals=True,
        import_materials=False,
        import_textures=False
    )
    return list(bpy.context.selected_objects)

def import_dae_character(filepath):
    """导入DAE角色"""
    bpy.ops.import_scene.dae(
        filepath=filepath,
        import_animation=True,
        import_animations=True,
        animation_mode='REPLACE',
        import_cameras=True,
        import_lights=True,
        import_meshes=True,
        import_uv=True,
        import_normals=True,
        import_materials=True,
        import_textures=True,
        import_blendShapes=True
    )
    return list(bpy.context.selected_objects)

def import_dae_and_merge(filepath):
    """导入DAE并合并"""
    bpy.ops.import_scene.dae(
        filepath=filepath,
        import_animation=False,
        import_cameras=False,
        import_lights=False,
        import_meshes=True
    )
    
    objects = list(bpy.context.selected_objects)
    if len(objects) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = objects[0]
        bpy.ops.object.join()
        return [bpy.context.active_object]
    
    return objects

def batch_import_dae_files(dae_files):
    """批量导入DAE文件"""
    all_objects = []
    for filepath in dae_files:
        bpy.ops.import_scene.dae(filepath=filepath)
        imported = list(bpy.context.selected_objects)
        all_objects.extend(imported)
    return all_objects
```

## 常见问题排查

### 导入后模型不可见
```python
# 检查选中对象
selected = bpy.context.selected_objects
print(f"导入对象数: {len(selected)}")

# 检查对象类型
for obj in selected:
    print(f"{obj.name}: 类型={obj.type}")

# 检查隐藏状态
for obj in selected:
    print(f"{obj.name}: 隐藏={obj.hide_viewport}")
    obj.hide_viewport = False

# 检查显示类型
for obj in selected:
    obj.display_type = 'SOLID'
```

### 材质丢失
```python
# 检查材质
print(f"材质数: {len(bpy.data.materials)}")

# 检查纹理
print(f"纹理数: {len(bpy.data.textures)}")

# 检查图像
print(f"图像数: {len(bpy.data.images)}")

# 重新导入带材质
bpy.ops.import_scene.dae(
    filepath='//mat.dae',
    import_materials=True,
    import_textures=True
)
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 检查骨骼动画
if obj.type == 'ARMATURE':
    print(f"骨骼数: {len(obj.data.bones)}")

# 重新导入带动画
bpy.ops.import_scene.dae(
    filepath='//anim.dae',
    import_animation=True,
    import_animations=True,
    animation_mode='REPLACE'
)
```

### 骨骼问题
```python
# 检查骨骼
armature = None
for obj in bpy.context.selected_objects:
    if obj.type == 'ARMATURE':
        armature = obj
        break

if armature:
    print(f"骨骼数: {len(armature.data.bones)}")
    
    # 检查权重
    for child in armature.children:
        if child.type == 'MESH':
            print(f"子对象: {child.name}")
            for mod in child.modifiers:
                if mod.type == 'ARMATURE':
                    print(f"绑定到: {mod.object}")

# 重新导入带骨骼
bpy.ops.import_scene.dae(
    filepath='//armature.dae',
    import_animation=True,
    import_meshes=True
)
```

### 混合形状丢失
```python
# 检查混合形状
obj = bpy.context.active_object
if hasattr(obj.data, 'shape_keys'):
    print(f"混合形状: {obj.data.shape_keys}")

# 确保导入混合形状
bpy.ops.import_scene.dae(
    filepath='//blendshapes.dae',
    import_meshes=True,
    import_blendShapes=True
)
```

### 方向问题
```python
# 检查导入的变换
obj = bpy.context.active_object
print(f"位置: {obj.location}")
print(f"旋转: {obj.rotation_euler}")
print(f"缩放: {obj.scale}")

# 尝试不同轴向
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    axis_forward='Z',
    axis_up='Y',
    fix_orientation=True
)

bpy.ops.import_scene.dae(
    filepath='//model.dae',
    axis_forward='-Z',
    axis_up='Y',
    fix_orientation=False
)
```

### 性能问题
```python
# 检查对象数
print(f"对象数: {len(bpy.context.selected_objects)}")

# 减少导入内容
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    import_cameras=False,
    import_lights=False,
    import_curves=False,
    import_surfaces=False,
    import_nurbs=False,
    import_animation=False
)

# 导入后优化
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.join()
```

### 单位问题
```python
# 检查单位
print(f"场景单位: {bpy.context.scene.unit_settings.system}")
print(f"比例: {bpy.context.scene.unit_settings.scale_length}")

# 导入单位
bpy.ops.import_scene.dae(
    filepath='//model.dae',
    import_units=True
)

# 手动调整
obj = bpy.context.active_object
obj.scale = (0.01, 0.01, 0.01)
bpy.ops.object.transform_apply(scale=True)
```
