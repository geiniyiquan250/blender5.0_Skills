# bpy.ops.action 模块

动作编辑器操作模块，提供时间轴和动作数据编辑功能。

## 概述

bpy.ops.action 模块包含用于操作动作编辑器（Action Editor）和时间轴（Timeline）的运算符。这些运算符主要用于编辑动画关键帧、动作数据块和时间轴范围。

## 常用操作

### 关键帧操作

```python
import bpy

# 选择关键帧
bpy.ops.action.select_all(action='SELECT')
bpy.ops.action.select_all(action='DESELECT')
bpy.ops.action.select_all(action='INVERT')

# 选择关键帧范围
bpy.ops.action.select_lefthand()
bpy.ops.action.select_righthand()

# 选择关键帧列（同一帧上的所有关键帧）
bpy.ops.action.select_column(mode='KEYS')
bpy.ops.action.select_column(mode='CFRA')

# 选择同类型关键帧
bpy.ops.action.select_same_type()

# 关键帧外推类型切换
bpy.ops.action.extrapolation_type(type='MAKE_CYCLIC')
```

### 关键帧编辑

```python
# 复制关键帧到剪贴板
bpy.ops.action.copy()

# 粘贴关键帧
bpy.ops.action.paste(offset='START')
bpy.ops.action.paste(offset='CURRENT')

# 删除关键帧
bpy.ops.action.delete()

# 移动关键帧
bpy.ops.action.move(type='KEYS')
bpy.ops.action.move(type='FRAME')

# 滑动关键帧
bpy.ops.action.slide(value=5.0)

# 插入关键帧
bpy.ops.action.keyframe_insert(type='ALL')
bpy.ops.action.keyframe_insert(type='SELECTED')

# 转换为关键帧
bpy.ops.action.keyframe(type='REPLACE')
bpy.ops.action.keyframe(type='INSERT')

# 清除关键帧
bpy.ops.action.keyframe_clear(type='ALL')
bpy.ops.action.keyframe_clear(type='SELECTED')
```

### 通道操作

```python
# 选择通道
bpy.ops.action.select_all(action='SELECT')

# 通道类型选择
bpy.ops.action.select_type(type='FCOURSE')
bpy.ops.action.select_type(type='OBJECT')
bpy.ops.action.select_type(type='GROUP')
bpy.ops.action.select_type(type='MATERIAL')
bpy.ops.action.select_type(type='CONSTRAINT')

# 切换通道激活状态
bpy.ops.action.toggle_active()

# 移动通道
bpy.ops.action.move_down()
bpy.ops.action.move_up()

# 通道独奏
bpy.ops.action.solo_selected()
```

### 范围和帧操作

```python
# 设置预览范围
bpy.ops.action.view_previewrange()

# 设置场景范围
bpy.ops.action.view_framename(name='name')

# 跳转帧
bpy.ops.action.frame_jump()

# 推送帧到范围
bpy.ops.action.push_down()

# 替换动作
bpy.ops.action.replacement_add()

# 快照
bpy.ops.action.snapshot()
bpy.ops.action.snapshot_clear()
```

## 实际应用示例

### 批量调整动画时间

```python
import bpy

def retime_animation(obj, start_frame, speed_factor):
    """调整动画时间和速度"""
    # 切换到物体模式
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 选择物体
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    # 进入物体动画编辑
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 调整时间
    if speed_factor != 1.0:
        bpy.ops.action.scale_length(value=speed_factor)
    
    # 移动到新起始帧
    bpy.ops.action.offset_set(offset=start_frame - obj.animation_data.action.frame_range[0])

# 使用示例
cube = bpy.data.objects['Cube']
retime_animation(cube, frame=1, speed_factor=0.5)
```

### 复制动画数据

```python
def copy_animation(source_obj, target_obj):
    """复制动画从源物体到目标物体"""
    if not source_obj.animation_data or not source_obj.animation_data.action:
        return
    
    action = source_obj.animation_data.action
    
    # 创建新动作
    new_action = action.copy()
    new_action.name = f"{target_obj.name}_Action"
    new_action.use_fake_user = True
    
    # 分配到目标
    if not target_obj.animation_data:
        target_obj.animation_data_create()
    target_obj.animation_data.action = new_action
    
    return new_action
```

## 使用场景

- **动画时间轴编辑**：调整关键帧位置、范围
- **动作库管理**：复制、粘贴、推送动作数据
- **动画重定时**：调整动画速度和时序
- **通道编辑**：调整动画通道顺序和激活状态
- **关键帧批量操作**：选择、删除、移动多个关键帧

## 注意事项

- 操作前确保选中正确的动作编辑器区域
- 某些操作需要在物体模式和姿态模式间切换
- 关键帧操作会影响所有选中的通道
