# gpu.texture - GPU纹理模块

gpu.texture模块提供了GPU纹理对象的创建、加载和管理功能，用于在着色器中使用图像数据。

## 概述

GPU纹理模块封装了纹理操作的各种功能，包括纹理创建、绑定、更新和采样设置。纹理是GPU渲染中用于存储图像数据的重要资源。

## 核心功能

### 纹理创建

```python
import gpu
from gpu.texture import (
    Texture,
    Texture1D,
    Texture2D,
    Texture3D,
    TextureCube,
    is_compatible,
    image_from_blender
)

def create_2d_texture(width, height, data=None, format='RGBA8', samples=0):
    """创建2D纹理"""
    if samples > 0:
        tex = gpu.texture.Texture2DMultisample(width, height, samples, format)
    else:
        tex = gpu.texture.Texture2D(width, height, format)
    if data:
        tex.update(data)
    return tex

def create_3d_texture(width, height, depth, data=None, format='RGBA8'):
    """创建3D纹理"""
    tex = gpu.texture.Texture3D(width, height, depth, format)
    if data:
        tex.update(data)
    return tex

def create_cubemap_texture(size, data=None, format='RGBA8'):
    """创建立方体贴图"""
    tex = gpu.texture.TextureCube(size, format)
    if data:
        tex.update(data)
    return tex

def create_1d_texture(width, data=None, format='RGBA8'):
    """创建1D纹理"""
    tex = gpu.texture.Texture1D(width, format)
    if data:
        tex.update(data)
    return tex
```

### 纹理加载

```python
def load_texture_from_image(image):
    """从Blender图像加载纹理"""
    tex = image_to_texture(image)
    return tex

def load_texture_from_file(filepath):
    """从文件加载纹理"""
    img = bpy.data.images.load(filepath)
    return load_texture_from_image(img)

def load_texture_array(filepaths, width, height, format='RGBA8'):
    """加载纹理数组"""
    tex = gpu.texture.Texture2DArray(width, height, len(filepaths), format)
    for i, filepath in enumerate(filepaths):
        img = bpy.data.images.load(filepath)
        tex.update(img.pixels, layer=i)
    return tex

def load_cubemap_from_files(filepaths, size, format='RGBA8'):
    """从文件加载立方体贴图"""
    tex = gpu.texture.TextureCube(size, format)
    for i, filepath in enumerate(filepaths):
        img = bpy.data.images.load(filepath)
        tex.update(img.pixels, face=i)
    return tex
```

### 纹理更新

```python
def update_texture(tex, data, level=0):
    """更新纹理数据"""
    tex.update(data, level)

def update_texture_region(tex, data, x, y, width, height, level=0):
    """更新纹理区域"""
    tex.update_region(data, x, y, width, height, level)

def replace_texture_data(tex, data):
    """替换纹理数据"""
    tex.replace(data)

def clear_texture(tex, color=(0, 0, 0, 0)):
    """清除纹理"""
    tex.clear(color)
```

## 实用函数

### 纹理采样

```python
from gpu.texture import (
    sampler_wrap_repeat,
    sampler_wrap_clamp,
    sampler_filter_linear,
    sampler_filter_nearest
)

def create_default_sampler():
    """创建默认采样器"""
    return gpu.texture.Sampler()

def create_linear_sampler():
    """创建线性采样器"""
    sampler = gpu.texture.Sampler()
    sampler.filter = sampler_filter_linear()
    return sampler

def create_nearest_sampler():
    """创建最近邻采样器"""
    sampler = gpu.texture.Sampler()
    sampler.filter = sampler_filter_nearest()
    return sampler

def create_repeat_sampler():
    """创建重复寻址采样器"""
    sampler = gpu.texture.Sampler()
    sampler.wrap = sampler_wrap_repeat()
    return sampler

def create_clamped_sampler():
    """创建钳制寻址采样器"""
    sampler = gpu.texture.Sampler()
    sampler.wrap = sampler_wrap_clamp()
    return sampler
```

### 纹理绑定

```python
def bind_texture(tex, unit=0):
    """绑定纹理到单元"""
    tex.bind(unit)

def unbind_texture(unit=0):
    """解绑纹理"""
    gpu.texture.unbind(unit)

def active_texture(unit):
    """激活纹理单元"""
    gpu.texture.active(unit)

def get_bound_texture(unit):
    """获取绑定的纹理"""
    return gpu.texture.unit_get_binding(unit)
```

### 纹理查询

```python
def get_texture_size(tex):
    """获取纹理尺寸"""
    return tex.size

def get_texture_format(tex):
    """获取纹理格式"""
    return tex.format

def get_texture_levels(tex):
    """获取纹理级别数"""
    return tex.levels

def is_texture_ready(tex):
    """检查纹理是否就绪"""
    return tex.is_created()

def get_texture_memory_size(tex):
    """获取纹理内存大小"""
    return tex.memory_size()
```

## 高级功能

### 纹理压缩

```python
def create_compressed_texture(filepath, format='DXT1'):
    """创建压缩纹理"""
    return gpu.texture.create_compressed(filepath, format)

def compress_texture(tex, format='DXT1'):
    """压缩纹理"""
    return tex.compress(format)
```

### 纹理生成

```python
def create_noise_texture(width, height, noise_type='PERLIN'):
    """创建噪声纹理"""
    tex = gpu.texture.Texture2D(width, height, 'RGBA8')
    noise_data = generate_noise_data(width, height, noise_type)
    tex.update(noise_data)
    return tex

def create_gradient_texture(width, height, gradient_type='LINEAR'):
    """创建渐变纹理"""
    tex = gpu.texture.Texture2D(width, height, 'RGBA8')
    gradient_data = generate_gradient_data(width, height, gradient_type)
    tex.update(gradient_data)
    return tex

def create_checker_texture(size, num_checks=8, color1=(1,1,1,1), color2=(0,0,0,1)):
    """创建棋盘纹理"""
    tex = gpu.texture.Texture2D(size, size, 'RGBA8')
    checker_data = generate_checker_data(size, num_checks, color1, color2)
    tex.update(checker_data)
    return tex
```

### 纹理管理

```python
class TextureManager:
    """纹理管理器"""
    def __init__(self):
        self.textures = {}
        self.max_size = 1024
    
    def load(self, name, filepath):
        """加载纹理"""
        if name in self.textures:
            return self.textures[name]
        tex = load_texture_from_file(filepath)
        self.textures[name] = tex
        return tex
    
    def get(self, name):
        """获取纹理"""
        return self.textures.get(name)
    
    def release(self, name):
        """释放纹理"""
        tex = self.textures.pop(name)
        tex.release()
    
    def clear(self):
        """清除所有纹理"""
        for tex in self.textures.values():
            tex.release()
        self.textures.clear()
```

## 常见问题排查

### 纹理加载失败

格式不支持：
- 确认图像格式被支持
- 检查文件路径正确性
- 验证文件完整性

### 纹理采样问题

采样参数错误：
- 检查采样器配置
- 确认纹理坐标范围
- 验证mipmap生成

### 内存不足

纹理过大：
- 使用更小的纹理尺寸
- 考虑纹理压缩
- 及时释放未使用的纹理
