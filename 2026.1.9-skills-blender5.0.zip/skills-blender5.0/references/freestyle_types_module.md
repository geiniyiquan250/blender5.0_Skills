# freestyle.types - 类型定义模块

freestyle.types模块定义了Freestyle线条渲染框架中使用的核心数据类型，包括边、线条、点等基础数据结构。

## 概述

类型模块定义了Freestyle系统的数据结构，这些类型是构建线条渲染管线的基础。理解这些类型对于开发自定义样式和工具至关重要。

## 核心类型

### 边类型

```python
from freestyle.types import (
    Edge,
    OrientedEdge,
    ViewEdge,
    FEdge,
    FEdgeSilhouette,
    FEdgeCrease,
    FEdgeBorder,
    FEdgeRidge,
    FEdgeValence1,
    FEdgeValence2
)

class Edge:
    """基础边类型"""
    def __init__(self, vertices=None, id=None):
        self.vertices = vertices or []
        self.id = id
        self.length = 0.0
    
    def compute_length(self):
        """计算边长度"""
        if len(self.vertices) >= 2:
            self.length = (self.vertices[0] - self.vertices[1]).length
        return self.length

class ViewEdge(Edge):
    """视图边类型"""
    def __init__(self, edge=None, viewpoint=None):
        super().__init__()
        self.edge = edge
        self.viewpoint = viewpoint
        self.view2d = None
        self.is_silhouette = False
        self.is_border = False
    
    def compute_projection(self, viewpoint):
        """计算投影"""
        self.view2d = self.edge.project(viewpoint)

class OrientedEdge:
    """有向边类型"""
    def __init__(self, view_edge, orientation):
        self.view_edge = view_edge
        self.orientation = orientation
        self.tvertices = []
    
    def get_opposite(self):
        """获取相反方向的有向边"""
        return OrientedEdge(self.view_edge, not self.orientation)
```

### 线条类型

```python
from freestyle.types import (
    Stroke,
    StrokeVertex,
    StrokeAttribute
)

class StrokeVertex:
    """线条顶点类型"""
    def __init__(
        self, 
        point=None, 
        normal=None, 
        curvature=0.0,
        attributes=None
    ):
        self.point = point or Vector((0, 0, 0))
        self.normal = normal or Vector((0, 0, 1))
        self.curvature = curvature
        self.attributes = attributes or StrokeAttribute()
    
    def compute_curvature(self):
        """计算曲率"""
        pass

class Stroke:
    """线条类型"""
    def __init__(self, vertices=None):
        self.vertices = vertices or []
        self.attributes = StrokeAttribute()
        self.length = 0.0
        self.id = None
    
    def __len__(self):
        return len(self.vertices)
    
    def __iter__(self):
        return iter(self.vertices)
    
    def compute_length(self):
        """计算线条长度"""
        self.length = sum(
            (self.vertices[i].point - self.vertices[i-1].point).length
            for i in range(1, len(self.vertices))
        )
        return self.length
    
    def get_point_at(self, distance):
        """获取指定距离的点"""
        pass

class StrokeAttribute:
    """线条属性类型"""
    def __init__(
        self, 
        color=None, 
        thickness=None, 
        alpha=None,
        visibility=True
    ):
        self.color = color or (0, 0, 0, 1)
        self.thickness = thickness or 1.0
        self.alpha = alpha or 1.0
        self.visibility = visibility
        self.texture_id = None
    
    def __eq__(self, other):
        if not isinstance(other, StrokeAttribute):
            return False
        return (self.color == other.color and
                self.thickness == other.thickness and
                self.alpha == other.alpha)
```

## 扩展类型

### 谓词结果

```python
from freestyle.types import (
    PredType,
    STROKE,
    EDGE,
    VERTEX1D,
    VERTEX2D
)

class PredType:
    """谓词结果类型"""
    def __init__(self, value=True):
        self.value = value
    
    def __bool__(self):
        return self.value
    
    def __and__(self, other):
        return PredType(self.value and other.value)
    
    def __or__(self, other):
        return PredType(self.value or other.value)
    
    def __invert__(self):
        return PredType(not self.value)
```

### 视图映射

```python
from freestyle.types import ViewMap

class ViewMap:
    """视图映射类型"""
    def __init__(self):
        self.edges = []
        self.fedges = []
        self.stroke_list = None
    
    def __len__(self):
        return len(self.edges)
    
    def __iter__(self):
        return iter(self.edges)
    
    def add_edge(self, edge):
        """添加边"""
        self.edges.append(edge)
    
    def add_fedge(self, fedge):
        """添加特征边"""
        self.fedges.append(fedge)
    
    def build(self):
        """构建视图映射"""
        pass
    
    def clear(self):
        """清空视图映射"""
        self.edges.clear()
        self.fedges.clear()
```

### 样式模块

```python
from freestyle.types import (
    StrokeShader,
    ChainPredicateIterator,
    StrokeIterator
)

class StrokeShader:
    """线条着色器类型"""
    def __init__(self):
        self.name = None
    
    def shade(self, stroke):
        """着色方法"""
        pass

class ChainPredicateIterator:
    """链化谓词迭代器类型"""
    def __init__(self, predicate=None, it=None):
        self.predicate = predicate
        self.iterator = it
    
    def iterate(self, stroke):
        """迭代方法"""
        pass
    
    def reset(self):
        """重置迭代器"""
        pass

class StrokeIterator:
    """线条迭代器类型"""
    def __init__(self, chain_predicate_iterator=None, stroke_shader=None):
        self.chain_predicate_iterator = chain_predicate_iterator
        self.stroke_shader = stroke_shader
    
    def __iter__(self):
        return self
    
    def __next__(self):
        """获取下一条线条"""
        pass
```

## 实用函数

### 类型转换

```python
def edge_to_viewedge(edge, viewpoint):
    """将边转换为视图边"""
    return ViewEdge(edge, viewpoint)

def points_to_stroke(points):
    """将点转换为线条"""
    vertices = [StrokeVertex(p) for p in points]
    stroke = Stroke(vertices)
    stroke.compute_length()
    return stroke

def stroke_to_polylines(stroke):
    """将线条转换为多段线"""
    return [v.point for v in stroke.vertices]
```

### 类型检查

```python
def is_fedge_silhouette(fedge):
    """检查是否为轮廓特征边"""
    return isinstance(fedge, FEdgeSilhouette)

def is_fedge_crease(fedge):
    """检查是否为折痕特征边"""
    return isinstance(fedge, FEdgeCrease)

def is_fedge_ridge(fedge):
    """检查是否为脊特征边"""
    return isinstance(fedge, FEdgeRidge)

def is_fedge_border(fedge):
    """检查是否为边界特征边"""
    return isinstance(fedge, FEdgeBorder)
```

## 常见问题排查

### 类型不匹配

类型使用错误：
- 确认使用正确的类型导入
- 检查对象实例类型
- 使用isinstance验证

### 属性访问错误

属性不存在：
- 使用hasattr检查属性
- 确认对象已正确初始化
- 检查属性名称拼写

### 内存问题

对象数量过多：
- 及时清理不需要的对象
- 使用弱引用管理对象
- 分批处理大量数据
