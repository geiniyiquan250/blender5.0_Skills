# bpy.ops.paint_vertex - 顶点绘制操作模块

Blender顶点绘制操作符，用于在顶点级别进行颜色和权重绘制。

## 概述

`bpy.ops.paint_vertex` 模块提供用于顶点颜色绘制和顶点权重编辑的功能。这是在顶点级别操作网格颜色和权重的核心工具。

## 核心功能

### 顶点颜色绘制

```python
import bpy

# 切换到顶点颜色模式
bpy.ops.paint.vertex_paint_toggle()

# 切换到权重绘制模式
bpy.ops.paint.weight_paint_toggle()

# 设置绘制颜色
bpy.context.tool_settings.vertex_paint.brush.color = (1.0, 0.0, 0.0)

# 设置绘制强度
bpy.context.tool_settings.vertex_paint.brush.strength = 0.8

# 设置绘制混合模式
bpy.context.tool_settings.vertex_paint.brush.blend = 'MIX'

# 设置画笔大小
bpy.context.tool_settings.vertex_paint.brush.size = 30

# 设置画笔硬度
bpy.context.tool_settings.vertex_paint.brush.hardness = 0.5
```

### 顶点颜色操作

```python
# 填充颜色
bpy.ops.paint.vertex_color_set(
    color=(0.0, 1.0, 0.0, 1.0)
)

# 混合颜色
bpy.ops.paint.vertex_color_brightness_contrast(
    brightness=0.0,
    contrast=0.0
)

# 调整色相
bpy.ops.paint.vertex_color_hsv(
    h=0.5,
    s=1.0,
    v=1.0
)

# 反转颜色
bpy.ops.paint.vertex_color_invert()

# 平滑颜色
bpy.ops.paint.vertex_color_smooth()

# 混合到目标
bpy.ops.paint.vertex_color_from_weight()
```

### 顶点权重操作

```python
# 设置权重
bpy.context.tool_settings.weight_paint.brush.weight = 0.5

# 添加权重
bpy.ops.paint.weight_grow_blur(
    factor=0.1
)

# 减少权重
bpy.ops.paint.weight_decrease(
    factor=0.1
)

# 镜像权重
bpy.ops.paint.weight_mirror(
    flip_names=True
)

# 标准化权重
bpy.ops.paint.weight_normalize_all()

# 清除未使用的权重
bpy.ops.paint.weight_clean()

# 从顶点组填充
bpy.ops.paint.weight_set()

# 混合权重
bpy.ops.paint.weight_blend(
    blend_type='MIX'
)
```

### 选择操作

```python
# 全选
bpy.ops.paint.select_all(action='SELECT')

# 取消全选
bpy.ops.paint.select_all(action='DESELECT')

# 反选
bpy.ops.paint.select_all(action='INVERT')

# 选择相似
bpy.ops.paint.select_similar(
    threshold=0.1,
    type='WEIGHT'
)

# 扩展选择
bpy.ops.paint.select_lasso(
    path=[(x, y) for x, y in [(100, 100), (200, 100), (200, 200), (100, 200)]]
)

# 选择连通的
bpy.ops.paint.select_linked()

# 取消选择连通的
bpy.ops.paint.select_linked_pick(toggle=True)
```

### 顶点组操作

```python
# 新建顶点组
bpy.ops.object.vertex_group_add()

# 重命名顶点组
bpy.ops.object.vertex_group_rename(
    name='NewName'
)

# 删除顶点组
bpy.ops.object.vertex_group_remove()

# 复制顶点组
bpy.ops.object.vertex_group_copy()

# 设置活动顶点组
bpy.context.active_object.vertex_groups.active_index = 0

# 分配到顶点组
bpy.ops.object.vertex_group_assign()

# 从顶点组移除
bpy.ops.object.vertex_group_remove_from()

# 选择顶点组
bpy.ops.object.vertex_group_select()

# 反选顶点组
bpy.ops.object.vertex_group_deselect()
```

### 权重工具

```python
# 绘制权重
bpy.ops.paint.weight_paint()

# 绘制渐变权重
bpy.ops.paint.weight_gradient(
    type='LINEAR'
)

# 绘制径向权重
bpy.ops.paint.weight_gradient(
    type='RADIAL'
)

# 刷权重
bpy.ops.paint.weight_brush()

# 克隆权重
bpy.ops.paint.weight_clone()

# 采样权重
bpy.ops.paint.weight_sample()

# 对称权重
bpy.ops.paint.weight_symmetrize()
```

## 实用函数

```python
def get_vertex_colors(mesh):
    """获取网格的所有顶点颜色层"""
    return [layer.name for layer in mesh.vertex_colors]

def get_active_vertex_color(mesh):
    """获取活动顶点颜色层"""
    if mesh.vertex_colors.active:
        return mesh.vertex_colors.active.name
    return None

def create_vertex_color_layer(mesh, layer_name):
    """创建顶点颜色层"""
    return mesh.vertex_colors.new(name=layer_name)

def set_vertex_color(mesh, color_layer, vertex_indices, color):
    """设置顶点颜色"""
    layer = mesh.vertex_colors.get(color_layer)
    if layer:
        for i in vertex_indices:
            layer.data[i].color = color

def get_vertex_weights(obj, vertex_group_name):
    """获取顶点的权重"""
    group = obj.vertex_groups.get(vertex_group_name)
    if group:
        weights = []
        for i, v in enumerate(obj.data.vertices):
            try:
                weight = group.weight(i)
                weights.append(weight)
            except:
                weights.append(0.0)
        return weights
    return []

def set_vertex_weights(obj, vertex_group_name, weights):
    """设置顶点权重"""
    group = obj.vertex_groups.get(vertex_group_name)
    if group:
        for i, weight in enumerate(weights):
            if weight > 0:
                group.add([i], weight, 'REPLACE')
            else:
                group.remove([i])

def normalize_vertex_weights(obj, vertex_group_name):
    """标准化顶点权重"""
    group = obj.vertex_groups.get(vertex_group_name)
    if group:
        weights = get_vertex_weights(obj, group.name)
        max_weight = max(weights) if weights else 1.0
        if max_weight > 0:
            normalized = [w / max_weight for w in weights]
            set_vertex_weights(obj, group.name, normalized)

def smooth_vertex_weights(obj, vertex_group_name, iterations=3):
    """平滑顶点权重"""
    for _ in range(iterations):
        weights = get_vertex_weights(obj, vertex_group_name)
        smoothed = []
        for i in range(len(weights)):
            neighbors = []
            for edge in obj.data.edges:
                if i in edge.vertices:
                    neighbor = edge.vertices[0] if edge.vertices[1] == i else edge.vertices[1]
                    if neighbor < len(weights):
                        neighbors.append(weights[neighbor])
            if neighbors:
                smoothed.append(sum(neighbors) / len(neighbors))
            else:
                smoothed.append(weights[i])
        set_vertex_weights(obj, vertex_group_name, smoothed)

def copy_vertex_colors(src_obj, dst_obj, src_layer, dst_layer):
    """复制顶点颜色"""
    src_mesh = src_obj.data
    dst_mesh = dst_obj.data
    
    src_color = src_mesh.vertex_colors.get(src_layer)
    dst_color = dst_mesh.vertex_colors.get(dst_layer)
    
    if src_color and dst_color:
        for src_loop, dst_loop in zip(src_color.data, dst_color.data):
            dst_loop.color = src_loop.color
```

## 常见问题排查

### 顶点颜色不显示
```python
# 检查顶点颜色层
mesh = bpy.context.active_object.data
print(f"顶点颜色层: {[l.name for l in mesh.vertex_colors]}")

# 检查活动层
print(f"活动层: {mesh.vertex_colors.active}")

# 启用顶点颜色显示
for poly in mesh.polygons:
    poly.use_smooth = True

# 检查材质
mat = bpy.context.active_object.active_material
if mat:
    print(f"使用顶点颜色: {mat.use_vertex_color_paint}")
    mat.use_vertex_color_paint = True
```

### 权重绘制无效果
```python
# 检查活动顶点组
obj = bpy.context.active_object
print(f"活动顶点组: {obj.vertex_groups.active}")

# 检查权重
group = obj.vertex_groups.get(obj.vertex_groups.active.name)
if group:
    weights = get_vertex_weights(obj, group.name)
    print(f"权重范围: {min(weights)} - {max(weights)}")

# 检查绘制模式
print(f"绘制模式: {bpy.context.mode}")

# 切换到权重绘制模式
bpy.ops.paint.weight_paint_toggle()
```

### 选择问题
```python
# 检查选择模式
print(f"选择模式: {bpy.context.tool_settings.select_mode}")

# 检查是否可以编辑
obj = bpy.context.active_object
print(f"可编辑: {not obj.library}")

# 重置选择
bpy.ops.paint.select_all(action='DESELECT')

# 手动选择顶点
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='DESELECT')
bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
```
