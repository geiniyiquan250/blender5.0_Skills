# bpy.ops.export_scene - FBX导出操作模块

Blender FBX文件导出操作符，用于将场景导出为FBX格式。

## 概述

`bpy.ops.export_scene.fbx` 模块提供用于将Blender场景导出为Autodesk FBX格式的功能，支持几何体、材质、纹理、骨骼和动画的导出。

## 核心功能

### 基础导出

```python
import bpy

# 导出选中对象
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    export_selected=True,
    use_selection=False,
    mesh_smooth_type='OFF',
    use_mesh_smooth=False,
    use_mesh_modifiers=True,
    use_triangles=False,
    use_nurbs=False,
    use_armature_deform=False,
    bake_space_transform=False,
    use_anim=True,
    use_anim_action_all=True,
    use_anim_only=False,
    use_shape_keys=False,
    use_custom_props=False,
    apply_scale_options='FBX_SCALE_NONE',
    axis_forward='-Z',
    axis_up='Y',
    bake_anim_scenes=True,
    bake_anim_use_all_bones=True,
    bake_anim_use_nla_strips=True,
    bake_anim_use_all_actions=True,
    bake_anim_force_startend_keying=True,
    bake_anim_step=1.0,
    bake_anim_simplify_factor=1.0,
    path_mode='ABSOLUTE',
    embed_textures=False,
    batch_mode='OFF',
    use_batch_own_dir=False,
    use_metadata=True
)
```

### 导出范围

```python
# 只导出选中对象
bpy.ops.export_scene.fbx(
    filepath='//selected.fbx',
    export_selected=True
)

# 导出所有对象
bpy.ops.export_scene.fbx(
    filepath='//all.fbx',
    export_selected=False
)
```

### 网格设置

```python
# 平滑类型
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    mesh_smooth_type='OFF'
)

# 边平滑
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    mesh_smooth_type='EDGE'
)

# 面平滑
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    mesh_smooth_type='FACE'
)

# 使用网格平滑
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    use_mesh_smooth=True
)

# 应用网格修改器
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    use_mesh_modifiers=True
)

# 三角化
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    use_triangles=True
)
```

### 骨骼设置

```python
# 导出骨骼变形
bpy.ops.export_scene.fbx(
    filepath='//armature.fbx',
    use_armature_deform=True
)

# 不导出骨骼
bpy.ops.export_scene.fbx(
    filepath='//mesh.fbx',
    use_armature_deform=False
)
```

### 动画设置

```python
# 导出动画
bpy.ops.export_scene.fbx(
    filepath='//animation.fbx',
    use_anim=True
)

# 不导出动画
bpy.ops.export_scene.fbx(
    filepath='//static.fbx',
    use_anim=False
)

# 导出所有动作
bpy.ops.export_scene.fbx(
    filepath='//animations.fbx',
    use_anim=True,
    use_anim_action_all=True
)

# 只导出动画
bpy.ops.export_scene.fbx(
    filepath='//anim_only.fbx',
    use_anim=True,
    use_anim_only=True
)
```

### 变形目标

```python
# 导出变形目标
bpy.ops.export_scene.fbx(
    filepath='//shapekeys.fbx',
    use_shape_keys=True
)

# 不导出变形目标
bpy.ops.export_scene.fbx(
    filepath='//no_shapekeys.fbx',
    use_shape_keys=False
)
```

### 自定义属性

```python
# 导出自定义属性
bpy.ops.export_scene.fbx(
    filepath='//custom.fbx',
    use_custom_props=True
)

# 不导出自定义属性
bpy.ops.export_scene.fbx(
    filepath='//no_custom.fbx',
    use_custom_props=False
)
```

### 缩放应用

```python
# 不应用缩放
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    apply_scale_options='FBX_SCALE_NONE'
)

# 应用FBX缩放
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    apply_scale_options='FBX_SCALE_UNITS'
)

# 应用所有缩放
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    apply_scale_options='FBX_SCALE_ALL'
)
```

### 坐标轴设置

```python
# Blender默认轴向
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    axis_forward='-Z',
    axis_up='Y'
)

# 其他轴向组合
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    axis_forward='Y',
    axis_up='Z'
)
```

### 烘焙动画

```python
# 烘焙动画场景
bpy.ops.export_scene.fbx(
    filepath='//baked.fbx',
    bake_anim_scenes=True
)

# 烘焙所有骨骼
bpy.ops.export_scene.fbx(
    filepath='//baked.fbx',
    bake_anim_use_all_bones=True
)

# 烘焙NLA轨道
bpy.ops.export_scene.fbx(
    filepath='//baked.fbx',
    bake_anim_use_nla_strips=True
)

# 烘焙所有动作
bpy.ops.export_scene.fbx(
    filepath='//baked.fbx',
    bake_anim_use_all_actions=True
)

# 强制开始结束关键帧
bpy.ops.export_scene.fbx(
    filepath='//baked.fbx',
    bake_anim_force_startend_keying=True
)

# 设置烘焙步长
bpy.ops.export_scene.fbx(
    filepath='//baked.fbx',
    bake_anim_step=0.1
)

# 简化因子
bpy.ops.export_scene.fbx(
    filepath='//baked.fbx',
    bake_anim_simplify_factor=1.0
)
```

### 批处理

```python
# 禁用批处理
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    batch_mode='OFF'
)

# 启用批处理
bpy.ops.export_scene.fbx(
    filepath='//export/',
    batch_mode='COLLECTION'
)

# 按对象批处理
bpy.ops.export_scene.fbx(
    filepath='//export/',
    batch_mode='OBJECT'
)
```

## 实用函数

```python
def export_fbx_model(filepath, apply_modifiers=True):
    """导出FBX模型"""
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        export_selected=True,
        use_mesh_modifiers=apply_modifiers,
        mesh_smooth_type='OFF',
        use_armature_deform=False
    )

def export_fbx_with_animations(filepath):
    """导出FBX带动画"""
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        export_selected=True,
        use_mesh_modifiers=True,
        use_armature_deform=True,
        use_anim=True,
        use_anim_action_all=True,
        bake_anim_use_nla_strips=True,
        bake_anim_use_all_actions=True
    )

def export_fbx_character(filepath):
    """导出FBX角色"""
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        export_selected=True,
        use_mesh_modifiers=True,
        use_armature_deform=True,
        use_anim=True,
        use_anim_action_all=True,
        use_shape_keys=True,
        bake_anim_scenes=True,
        bake_anim_use_all_bones=True,
        bake_anim_use_nla_strips=True,
        bake_anim_use_all_actions=True
    )

def export_fbx_for_unreal(filepath):
    """导出FBX用于Unreal"""
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        export_selected=True,
        use_mesh_modifiers=True,
        use_triangles=True,
        use_armature_deform=True,
        use_anim=True,
        use_anim_action_all=True,
        bake_anim_scenes=True,
        bake_anim_use_all_bones=True,
        bake_anim_use_nla_strips=True,
        bake_anim_use_all_actions=True,
        bake_anim_force_startend_keying=True,
        apply_scale_options='FBX_SCALE_UNITS'
    )

def export_fbx_for_maya(filepath):
    """导出FBX用于Maya"""
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        export_selected=True,
        use_mesh_modifiers=True,
        use_armature_deform=True,
        use_anim=True,
        use_anim_action_all=True,
        bake_anim_scenes=True,
        apply_scale_options='FBX_SCALE_NONE'
    )

def batch_export_fbx_by_collection(output_dir):
    """按集合批量导出FBX"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for collection in bpy.data.collections:
        bpy.ops.object.select_all(action='DESELECT')
        
        for obj in collection.objects:
            obj.select_set(True)
        
        if bpy.context.selected_objects:
            bpy.context.view_layer.active_layer_collection = bpy.context.layer_collection.children[collection.name]
            filepath = os.path.join(output_dir, f'{collection.name}.fbx')
            bpy.ops.export_scene.fbx(
                filepath=filepath,
                export_selected=True,
                use_mesh_modifiers=True
            )
```

## 常见问题排查

### 导出后模型丢失
```python
# 检查选中对象
selected = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
print(f"选中网格: {len(selected)}")

# 确保对象可见
for obj in selected:
    obj.hide_viewport = False
    obj.hide_render = False

# 检查导出路径
print(f"导出路径: {bpy.path.abspath('//model.fbx')}")

# 确保文件扩展名正确
filepath = '//model.fbx'
if not filepath.endswith('.fbx'):
    filepath += '.fbx'
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")
    if obj.animation_data.action:
        print(f"帧范围: {obj.animation_data.action.frame_range}")

# 检查骨骼动画
if obj.type == 'ARMATURE':
    print(f"骨骼数: {len(obj.data.bones)}")

# 确保导出动画选项
bpy.ops.export_scene.fbx(
    filepath='//anim.fbx',
    export_selected=True,
    use_anim=True,
    use_anim_action_all=True,
    bake_anim_use_all_actions=True
)
```

### 材质丢失
```python
# 检查材质
obj = bpy.context.active_object
print(f"材质数: {len(obj.data.materials) if obj.data else 0}")

# 检查材质类型
for mat in obj.data.materials:
    print(f"材质: {mat.name}")
    print(f"使用节点: {mat.use_nodes}")

# 确保导出材质
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    export_selected=True,
    mesh_smooth_type='OFF'
)

# 检查导出设置
print("FBX导出设置:")
print("  - 导出选中: True")
print("  - 使用网格修改器: True")
print("  - 导出动画: True")
```

### 骨骼问题
```python
# 检查骨骼
armature = None
for obj in bpy.context.selected_objects:
    if obj.type == 'ARMATURE':
        armature = obj
        break

if armature:
    print(f"骨骼数: {len(armature.data.bones)}")
    
    # 检查绑定
    for child in armature.children:
        if child.type == 'MESH':
            print(f"子对象: {child.name}")
            for mod in child.modifiers:
                if mod.type == 'ARMATURE':
                    print(f"绑定到: {mod.object}")

# 确保导出骨骼
bpy.ops.export_scene.fbx(
    filepath='//armature.fbx',
    export_selected=True,
    use_armature_deform=True
)
```

### 缩放问题
```python
# 检查缩放
obj = bpy.context.active_object
print(f"缩放: {obj.scale}")

# 应用缩放
bpy.ops.object.transform_apply(scale=True)

# 设置正确的缩放选项
bpy.ops.export_scene.fbx(
    filepath='//model.fbx',
    export_selected=True,
    apply_scale_options='FBX_SCALE_UNITS'
)

# 检查单位设置
print(f"场景单位: {bpy.context.scene.unit_settings.system}")
print(f"比例: {bpy.context.scene.unit_settings.scale_length}")
```
