# imbuf 图像缓冲模块

imbuf 模块提供了对 Blender 图像处理 API 的访问，允许在 Blender 的 `bpy.types.Image` 数据块上下文之外直接操作图像缓冲区。

```python
import imbuf
```

## 主要函数

### load(filepath)

从文件加载图像。

参数：
- `filepath` (str | bytes)：图像的文件路径

返回：
- `ImBuf`：新加载的图像缓冲区

```python
# 从文件加载图像
import imbuf

image_buffer = imbuf.load("//textures/my_image.png")
print(f"图像尺寸: {image_buffer.size}")
```

### load_from_buffer(buffer)

从缓冲区加载图像。

参数：
- `buffer` (collections.abc.Buffer)：包含图像数据的缓冲区

返回：
- `ImBuf`：新加载的图像缓冲区

```python
# 从内存缓冲区加载图像
import imbuf

with open("//texture.raw", "rb") as f:
    raw_data = f.read()

image_buffer = imbuf.load_from_buffer(raw_data)
```

### new(size)

创建新图像。

参数：
- `size` (tuple[int, int])：图像的像素尺寸

返回：
- `ImBuf`：新创建的图像缓冲区

```python
# 创建空白图像
import imbuf

new_image = imbuf.new((1024, 1024))
print(f"新图像尺寸: {new_image.size}")
```

### write(image, filepath=None)

将图像写入文件。

参数：
- `image` (ImBuf)：要写入的图像缓冲区
- `filepath` (str | bytes | None)：可选的文件路径，默认为图像的原始路径

```python
# 保存图像到文件
import imbuf

image_buffer = imbuf.load("//textures/original.png")
# 修改图像...
imbuf.write(image_buffer, "//textures/modified.png")
```

## imbuf.types.ImBuf 类

ImBuf 类是图像缓冲区的核心类型，包含以下属性和方法。

### 属性

#### channels

图像的位平面数量。

类型：`int`

```python
import imbuf

img = imbuf.load("//texture.png")
print(f"通道数: {img.channels}")  # 通常为 3 (RGB) 或 4 (RGBA)
```

#### filepath

与图像关联的文件路径。

类型：`str`

```python
import imbuf

img = imbuf.load("//textures/texture.png")
print(f"文件路径: {img.filepath}")
```

#### planes

与图像关联的位数。

类型：`int`

```python
import imbuf

img = imbuf.load("//textures/texture.png")
print(f"位数: {img.planes}")  # 通常为 24 (RGB) 或 32 (RGBA)
```

#### ppm

每米的像素数。

类型：`tuple[float, float]`

```python
import imbuf

img = imbuf.load("//textures/texture.png")
print(f"PPM: {img.ppm}")  # (x_ppm, y_ppm)
```

#### size

图像的像素尺寸。

类型：`tuple[int, int]`

```python
import imbuf

img = imbuf.load("//textures/texture.png")
width, height = img.size
print(f"宽度: {width}, 高度: {height}")
```

### 方法

#### copy()

创建图像的副本。

返回：
- `ImBuf`：图像的副本

```python
import imbuf

original = imbuf.load("//texture.png")
duplicate = original.copy()
```

#### crop(min, max)

裁剪图像。

参数：
- `min` (tuple[int, int])：X, Y 最小坐标
- `max` (tuple[int, int])：X, Y 最大坐标

```python
import imbuf

img = imbuf.load("//texture.png")
img.crop((100, 100), (400, 400))
```

#### free()

立即清除图像数据，再次使用会导致错误。

```python
import imbuf

img = imbuf.load("//texture.png")
# 使用图像...
img.free()  # 释放内存
```

#### resize(size, method='FAST')

调整图像大小。

参数：
- `size` (tuple[int, int])：新的尺寸
- `method` (str)：调整方法，可选 `'FAST'` 或 `'BILINEAR'`

```python
import imbuf

img = imbuf.load("//texture.png")
img.resize((512, 512), method='BILINEAR')
```

## 实际应用示例

### 批量处理纹理

```python
import os
import imbuf
import bpy

def batch_resize_textures(directory, new_size):
    """批量调整目录下所有纹理的大小"""
    for filename in os.listdir(directory):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.tga')):
            filepath = os.path.join(directory, filename)
            
            img = imbuf.load(filepath)
            img.resize(new_size, method='BILINEAR')
            
            output_path = os.path.join(directory, "resized", filename)
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            imbuf.write(img, output_path)
            
            print(f"已处理: {filename}")

# 使用示例
batch_resize_textures("//textures", (1024, 1024))
```

### 创建程序化纹理

```python
import imbuf

def create_checkerboard(size, tile_size, color1, color2):
    """创建棋盘格纹理"""
    img = imbuf.new(size)
    
    width, height = size
    for y in range(height):
        for x in range(width):
            tile_x = x // tile_size
            tile_y = y // tile_size
            
            if (tile_x + tile_y) % 2 == 0:
                pixel = color1
            else:
                pixel = color2
            
            idx = (y * width + x) * 4
            img.rect[idx:idx+4] = pixel
    
    return img

# 创建 512x512 的棋盘格
checker = create_checkerboard((512, 512), 64, (255, 0, 0, 255), (0, 0, 255, 255))
imbuf.write(checker, "//checkerboard.png")
```

### 图像批量裁剪

```python
import os
import imbuf

def batch_crop_images(input_dir, output_dir, crop_region):
    """批量裁剪图像"""
    os.makedirs(output_dir, exist_ok=True)
    
    for filename in os.listdir(input_dir):
        if filename.lower().endswith(('.png', '.jpg', '.tga')):
            filepath = os.path.join(input_dir, filename)
            
            img = imbuf.load(filepath)
            img.crop(crop_region[0], crop_region[1])
            
            output_path = os.path.join(output_dir, filename)
            imbuf.write(img, output_path)
            print(f"已裁剪: {filename}")

# 使用示例
batch_crop_images(
    "//raw_images",
    "//cropped_images",
    ((100, 100), (500, 500))
)
```
