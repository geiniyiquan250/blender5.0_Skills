# bpy.ops.export_mesh - PLY导出操作模块

Blender PLY文件导出操作符，用于将网格导出为PLY格式。

## 概述

`bpy.ops.export_mesh.ply` 模块提供用于将Blender网格导出为PLY（Polygon File Format）格式的功能，支持顶点和面数据的保存。

## 核心功能

### 基础导出

```python
import bpy

# 导出选中对象
bpy.ops.export_mesh.ply(
    filepath='//model.ply',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    export_selected=True,
    apply_modifiers=True,
    export_normals=True,
    export_uv=True,
    export_colors=True
)

# 导出所有对象
bpy.ops.export_mesh.ply(
    filepath='//all_models.ply',
    export_selected=False
)
```

### 法线导出

```python
# 导出法线
bpy.ops.export_mesh.ply(
    filepath='//with_normals.ply',
    export_normals=True
)

# 不导出法线
bpy.ops.export_mesh.ply(
    filepath='//no_normals.ply',
    export_normals=False
)
```

### UV导出

```python
# 导出UV
bpy.ops.export_mesh.ply(
    filepath='//with_uv.ply',
    export_uv=True
)

# 不导出UV
bpy.ops.export_mesh.ply(
    filepath='//no_uv.ply',
    export_uv=False
)
```

### 颜色导出

```python
# 导出顶点颜色
bpy.ops.export_mesh.ply(
    filepath='//with_colors.ply',
    export_colors=True
)

# 不导出顶点颜色
bpy.ops.export_mesh.ply(
    filepath='//no_colors.ply',
    export_colors=False
)

# 导出面颜色
bpy.ops.export_mesh.ply(
    filepath='//face_colors.ply',
    export_face_colors=True
)
```

### 导出选项

```python
# 应用修改器
bpy.ops.export_mesh.ply(
    filepath='//applied.ply',
    apply_modifiers=True
)

# 只导出选中对象
bpy.ops.export_mesh.ply(
    filepath='//selected.ply',
    export_selected=True
)

# 导出所有网格
bpy.ops.export_mesh.ply(
    filepath='//all.ply',
    export_selected=False
)

# 三角化
bpy.ops.export_mesh.ply(
    filepath='//triangulated.ply',
    export_triangulated_mesh=True
)
```

### 坐标轴设置

```python
# Blender默认轴向
bpy.ops.export_mesh.ply(
    filepath='//model.ply',
    axis_forward='Z',
    axis_up='Y'
)

# 其他轴向
bpy.ops.export_mesh.ply(
    filepath='//model.ply',
    axis_forward='-Z',
    axis_up='Y'
)
```

## 实用函数

```python
def export_ply_model(filepath, obj=None, apply_modifiers=True):
    """导出PLY模型"""
    if obj:
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
    
    bpy.ops.export_mesh.ply(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=apply_modifiers,
        export_normals=True,
        export_uv=True,
        export_colors=True
    )

def export_ply_with_colors(filepath):
    """导出PLY带颜色"""
    bpy.ops.export_mesh.ply(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=True,
        export_normals=True,
        export_uv=True,
        export_colors=True
    )

def export_ply_simple(filepath):
    """导出简单PLY（仅几何体）"""
    bpy.ops.export_mesh.ply(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=True,
        export_normals=False,
        export_uv=False,
        export_colors=False
    )

def export_ply_for_scanning(filepath):
    """导出PLY用于扫描"""
    bpy.ops.export_mesh.ply(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=True,
        export_normals=True,
        export_uv=True,
        export_colors=True,
        export_triangulated_mesh=True
    )

def batch_export_ply(output_dir):
    """批量导出PLY文件"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            filepath = os.path.join(output_dir, f'{obj.name}.ply')
            bpy.ops.export_mesh.ply(
                filepath=filepath,
                export_selected=True,
                apply_modifiers=True
            )

def export_ply_selection(objects, filepath):
    """导出选中的对象列表"""
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        if obj.type == 'MESH':
            obj.select_set(True)
    
    if bpy.context.selected_objects:
        bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]
        bpy.ops.export_mesh.ply(
            filepath=filepath,
            export_selected=True,
            apply_modifiers=True
        )
```

## 常见问题排查

### 导出文件不完整
```python
# 检查选中对象
selected = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
print(f"选中网格: {len(selected)}")

# 检查网格数据
for obj in selected:
    print(f"{obj.name}: 顶点数={len(obj.data.vertices)}, 面数={len(obj.data.polygons)}")

# 确保网格可见
for obj in selected:
    obj.hide_viewport = False
    obj.hide_render = False
```

### 颜色丢失
```python
# 检查顶点颜色层
mesh = bpy.context.active_object.data
print(f"顶点颜色层: {[l.name for l in mesh.vertex_colors]}")

# 检查材质
obj = bpy.context.active_object
print(f"材质: {obj.data.materials}")

# 检查是否启用了顶点颜色
mat = obj.active_material
if mat:
    print(f"使用顶点颜色: {mat.use_vertex_color_paint}")

# 确保导出颜色选项
bpy.ops.export_mesh.ply(
    filepath='//colors.ply',
    export_selected=True,
    export_colors=True
)
```

### UV丢失
```python
# 检查UV层
mesh = bpy.context.active_object.data
print(f"UV层: {[l.name for l in mesh.uv_layers]}")

# 检查UV数据
for uv in mesh.uv_layers:
    print(f"UV层: {uv.name}, 数据长度: {len(uv.data)}")

# 确保导出UV选项
bpy.ops.export_mesh.ply(
    filepath='//uv.ply',
    export_selected=True,
    export_uv=True
)
```

### 法线问题
```python
# 检查法线
mesh = bpy.context.active_object.data
print(f"自定义法线: {mesh.has_custom_normals}")

# 重新计算法线
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.mesh.normals_make_consistent(inside=False)
bpy.ops.object.mode_set(mode='OBJECT')

# 确保导出法线选项
bpy.ops.export_mesh.ply(
    filepath='//normals.ply',
    export_selected=True,
    export_normals=True
)
```

### 轴向问题
```python
# 检查导出后的方向
# 在第三方软件中打开PLY文件检查

# 尝试不同轴向
bpy.ops.export_mesh.ply(
    filepath='//zy.ply',
    axis_forward='Z',
    axis_up='Y'
)

bpy.ops.export_mesh.ply(
    filepath='//-zy.ply',
    axis_forward='-Z',
    axis_up='Y'
)
```
