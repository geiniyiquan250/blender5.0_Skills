# bpy_extras.asset_utils - 资源工具模块

bpy_extras.asset_utils模块提供了Blender资源库和资源管理的实用工具函数。

## 概述

资源工具模块支持资源库的浏览、资源的查找和过滤、以及资源数据的访问等操作。适用于开发资源浏览器插件和资源批量处理工具。

## 核心功能

### 资源库操作

```python
import bpy
from bpy_extras.asset_utils import (
    SpaceFileReferences,
    AssetLibrary,
    iterate_asset_files
)

def get_all_asset_libraries():
    """获取所有资源库"""
    return bpy.context.preferences.filepaths.asset_libraries

def get_active_asset_library():
    """获取当前活动资源库"""
    return bpy.context.window_manager.active_asset_library

def refresh_asset_library(library_path):
    """刷新资源库"""
    for library in bpy.context.preferences.filepaths.asset_libraries:
        if library.path == library_path:
            library.reload()
            break

def add_asset_library(name, path):
    """添加资源库"""
    prefs = bpy.context.preferences.filepaths
    new_lib = prefs.asset_libraries.add()
    new_lib.name = name
    new_lib.path = path
    return new_lib

def remove_asset_library(library_path):
    """移除资源库"""
    prefs = bpy.context.preferences.filepaths
    for i, lib in enumerate(prefs.asset_libraries):
        if lib.path == library_path:
            prefs.asset_libraries.remove(i)
            break
```

### 资源浏览

```python
def iterate_local_assets(directory):
    """遍历本地资源文件"""
    for item in iterate_asset_files(bpy.context, directory):
        yield item

def get_blend_assets(filepath):
    """获取blend文件中的资源"""
    with bpy.data.libraries.load(filepath) as (data_from, data_to):
        for collection in data_from.collections:
            yield {
                'name': collection,
                'type': 'collection',
                'filepath': filepath
            }
        for obj in data_from.objects:
            yield {
                'name': obj,
                'type': 'object',
                'filepath': filepath
            }
        for mat in data_from.materials:
            yield {
                'name': mat,
                'type': 'material',
                'filepath': filepath
            }

def find_assets_by_type(asset_library, asset_type):
    """按类型查找资源"""
    results = []
    for asset in iterate_asset_files(bpy.context, asset_library):
        if hasattr(asset, 'asset_type'):
            if asset.asset_type == asset_type:
                results.append(asset)
    return results
```

### 资源属性

```python
def get_asset_identifier(obj):
    """获取资源标识符"""
    if not obj.asset_data:
        return None
    return obj.asset_data.name

def set_asset_name(obj, name):
    """设置资源名称"""
    if obj.asset_data:
        obj.asset_data.name = name

def get_asset_tags(obj):
    """获取资源标签"""
    if not obj.asset_data:
        return []
    return [tag.name for tag in obj.asset_data.tags]

def add_asset_tag(obj, tag_name):
    """添加资源标签"""
    if obj.asset_data:
        obj.asset_data.tags.new(name=tag_name)

def remove_asset_tag(obj, tag_name):
    """移除资源标签"""
    if obj.asset_data:
        for tag in obj.asset_data.tags:
            if tag.name == tag_name:
                obj.asset_data.tags.remove(tag)
                break

def get_asset_author(obj):
    """获取资源作者"""
    if obj.asset_data:
        return obj.asset_data.author
    return None

def set_asset_author(obj, author):
    """设置资源作者"""
    if obj.asset_data:
        obj.asset_data.author = author
```

## 实用函数

### 资源导入

```python
def import_asset(filepath, asset_type='auto', link=False):
    """导入资源"""
    if asset_type == 'auto':
        if filepath.endswith('.blend'):
            asset_type = 'blend'
        elif filepath.endswith('.fbx'):
            asset_type = 'fbx'
        elif filepath.endswith('.gltf'):
            asset_type = 'gltf'
    
    if asset_type == 'blend':
        with bpy.data.libraries.load(filepath, link=link) as (src, dst):
            for item in src.objects:
                dst.objects.append(item)
        return dst.objects[-1] if dst.objects else None
    
    return None

def append_asset(filepath, asset_name, asset_type='collection'):
    """追加资源"""
    directory = filepath
    if asset_type == 'collection':
        directory = filepath + '/Collection/'
    elif asset_type == 'object':
        directory = filepath + '/Object/'
    elif asset_type == 'material':
        directory = filepath + '/Material/'
    
    bpy.ops.wm.append(
        filepath=filepath,
        directory=directory,
        files=[{'name': asset_name}],
        link=False
    )
```

### 资源导出

```python
def export_as_asset(obj, filepath, include_data=True):
    """导出为资源"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        use_selection=True,
        export_include=[] if include_data else ['DATA']
    )

def batch_export_assets(objects, output_dir, format='GLTF'):
    """批量导出资源"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for obj in objects:
        filepath = os.path.join(output_dir, f"{obj.name}.gltf")
        export_as_asset(obj, filepath)
```

### 资源管理

```python
class AssetManager:
    """资源管理器"""
    def __init__(self):
        self.assets = []
    
    def add_asset(self, obj):
        """添加资源"""
        if obj.asset_data:
            self.assets.append(obj)
    
    def remove_asset(self, obj):
        """移除资源"""
        if obj in self.assets:
            self.assets.remove(obj)
    
    def clear(self):
        """清空管理器"""
        self.assets.clear()
    
    def filter_by_tag(self, tag_name):
        """按标签过滤"""
        return [a for a in self.assets if tag_name in get_asset_tags(a)]
    
    def filter_by_type(self, obj_type):
        """按类型过滤"""
        return [a for a in self.assets if a.type == obj_type]
    
    def export_all(self, output_dir, format='GLTF'):
        """导出所有资源"""
        for obj in self.assets:
            export_as_asset(obj, os.path.join(output_dir, f"{obj.name}.{format.lower()}"))
```

## 常见问题排查

### 资源无法标记

数据块类型不支持：
- 只有ID数据块可以标记为资源
- 确保对象类型是可标记的
- 检查asset_data属性是否存在

### 资源库不显示

路径问题：
- 确认资源库路径存在
- 检查路径权限
- 尝试刷新资源库

### 导入资源失败

文件格式问题：
- 确认文件格式被支持
- 检查blend文件版本
- 验证资源名称正确性
