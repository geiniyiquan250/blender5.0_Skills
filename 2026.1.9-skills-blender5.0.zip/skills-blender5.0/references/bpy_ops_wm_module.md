# bpy.ops.wm - 窗口管理操作模块

Blender窗口管理操作符，用于管理窗口、上下文和系统级操作。

## 概述

`bpy.ops.wm` 模块提供用于管理Blender窗口、上下文、系统和用户界面操作的功能。这是Blender中最通用的操作符模块之一。

## 核心功能

### 文件操作

```python
import bpy

# 新建文件
bpy.ops.wm.read_homefile(
    use_empty=True
)

# 打开文件
bpy.ops.wm.open_mainfile(
    filepath='//project.blend',
    load_ui=True
)

# 保存文件
bpy.ops.wm.save_mainfile(
    filepath='//project.blend',
    write_python=True
)

# 另存为
bpy.ops.wm.save_as_mainfile(
    filepath='//new_project.blend',
    copy=True
)

# 保存副本
bpy.ops.wm.save_homefile()

# 恢复上次保存
bpy.ops.wm.revert_mainfile()

# 追加文件
bpy.ops.wm.append(
    filepath='//library.blend',
    directory='//library.blend/Object/',
    files=[{'name': 'Cube'}],
    link=False,
    relative_path=True
)

# 链接文件
bpy.ops.wm.link(
    filepath='//library.blend',
    directory='//library.blend/Object/',
    files=[{'name': 'Cube'}],
    relative_path=True
)
```

### 导入操作

```python
# 导入主菜单
bpy.ops.wm.read_homefile(
    use_factory_settings=True
)

# 导入用户设置
bpy.ops.wm.read_user_interface()

# 导入键位设置
bpy.ops.wm.keyconfig_import(
    filepath='//keymap.py'
)

# 导入主题
bpy.ops.wm.theme_import(
    filepath='//theme.xml'
)

# 导入配
```python
# 导出配
bpy.ops.wm.properties_add(data_path='scene.render.resolution_percentage')
```

### 上下文操作

```python
# 复制数据路径
bpy.ops.wm.context_path_copy(
    data_path='active_object.location'
)

# 粘贴数据路径
bpy.ops.wm.context_path_paste()

# 枚举数值
bpy.ops.wm.context_enum_parse(
    data_path='object.type',
    items='["MESH", "CURVE", "SURFACE", "META", "FONT", "ARMATURE", "LATTICE", "EMPTY", "CAMERA", "LIGHT"]'
)

# 设置布尔值
bpy.ops.wm.context_boolean_set(
    data_path='object.select_get()',
    value=True
)

# 设置浮点值
bpy.ops.wm.context_set_float(
    data_path='object.location.x',
    value=1.0
)

# 设置整数值
bpy.ops.wm.context_set_int(
    data_path='object.pass_index',
    value=1
)

# 设置字符串
bpy.ops.wm.context_set_string(
    data_path='object.name',
    value='NewName'
)
```

### 工具操作

```python
# 运行Python脚本
bpy.ops.wm.python_file_run(
    filepath='//script.py'
)

# 运行Python控制台命令
bpy.ops.wm.console_toggle()

# 切换脚本区域
bpy.ops.wm.script_reload(
    doctors=True
)

# 重新加载脚本
bpy.ops.wm.script_reload(
    module='my_module'
)
```

### 批处理操作

```python
# 批量打开文件
bpy.ops.wm.open_mainfile(
    filepath='file1.blend'
)

# 批量保存
bpy.ops.wm.save_mainfile(
    filepath='project.blend'
)

# 导出所有打开的文件
bpy.ops.wm.save_all_mainfile(
    path='//backup'
)
```

### 撤销重做

```python
# 撤销
bpy.ops.wm.undo()

# 重做
bpy.ops.wm.redo()

# 撤销历史步数
bpy.ops.wm.undo_push(
    message='自定义操作'
)

# 清除撤销历史
bpy.ops.wm.undo_history_clear()
```

### 窗口管理

```python
# 新建窗口
bpy.ops.wm.window_new()

# 最大化窗口
bpy.ops.wm.window_fullscreen_toggle()

# 关闭窗口
bpy.ops.wm.window_close()

# 切换控制台
bpy.ops.wm.console_toggle()

# 设置窗口标题
bpy.ops.wm.window_title_set(
    title='Blender - Project'
)
```

### 进度条

```python
# 显示进度条
bpy.ops.wm.progress_start(
    title='Processing',
    message='正在处理...'
)

# 更新进度
bpy.ops.wm.progress_update(
    value=0.5
)

# 结束进度条
bpy.ops.wm.progress_end()

# 取消进度
bpy.ops.wm.progress_cancel()
```

### 系统操作

```python
# 调用菜单
bpy.ops.wm.call_menu(
    name='VIEW3D_MT_object_context_menu'
)

# 调用面板
bpy.ops.wm.call_panel(
    name='DATA_PT_context_material',
    keep_open=True
)

# 调用操作符
bpy.ops.wm.call_operator(
    name='object.simple_operator',
    properties={'prop': value}
)

# 设置键位
bpy.ops.wm.keyconfig_assign(
    filepath='//keymap.py'
)

# 重置键位
bpy.ops.wm.keyconfig_reset()
```

## 实用函数

```python
def save_backup():
    """保存备份"""
    import time
    timestamp = time.strftime('%Y%m%d_%H%M%S')
    bpy.ops.wm.save_as_mainfile(
        filepath=f'//backup_{timestamp}.blend',
        copy=True
    )

def export_all_objects(filepath):
    """导出所有对象"""
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.export_scene.fbx(filepath=filepath)
    bpy.ops.object.select_all(action='DESELECT')

def batch_process_files(file_list, output_dir):
    """批量处理文件"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for filepath in file_list:
        bpy.ops.wm.open_mainfile(filepath=filepath)
        # 处理当前文件
        process_current_file()
        # 保存到输出目录
        output_path = os.path.join(output_dir, os.path.basename(filepath))
        bpy.ops.wm.save_mainfile(filepath=output_path)

def create_project_backup(project_path, backup_dir):
    """创建项目备份"""
    import os
    import shutil
    import datetime
    
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = os.path.join(backup_dir, f'backup_{timestamp}')
    
    shutil.copy2(project_path, backup_path)
    print(f'备份创建成功: {backup_path}')

def import_objects_from_library(library_path, object_names):
    """从库中导入对象"""
    bpy.ops.wm.append(
        filepath=library_path,
        directory=f'{library_path}/Object/',
        files=[{'name': name} for name in object_names],
        link=False,
        relative_path=True
    )

def link_objects_from_library(library_path, object_names):
    """从库中链接对象"""
    bpy.ops.wm.link(
        filepath=library_path,
        directory=f'{library_path}/Object/',
        files=[{'name': name} for name in object_names],
        relative_path=True
    )
```

## 常见问题排查

### 文件保存失败
```python
# 检查文件路径
filepath = '//project.blend'
print(f"绝对路径: {bpy.path.abspath(filepath)}")

# 检查目录是否存在
import os
dir_path = os.path.dirname(bpy.path.abspath(filepath))
print(f"目录存在: {os.path.exists(dir_path)}")

# 检查文件权限
try:
    with open(bpy.path.abspath(filepath), 'w') as f:
        f.write('test')
    print("可写")
except PermissionError:
    print("权限不足")

# 检查场景是否有效
print(f"场景有效: {bpy.context.scene is not None}")

# 尝试保存副本
bpy.ops.wm.save_as_mainfile(filepath='//copy.blend', copy=True)
```

### 导入失败
```python
# 检查文件是否存在
filepath = '//library.blend'
print(f"文件存在: {os.path.exists(bpy.path.abspath(filepath))}")

# 检查Blend文件版本
try:
    bpy.ops.wm.open_mainfile(filepath=filepath, load_ui=False)
    print("文件可打开")
except:
    print("文件损坏或版本不兼容")

# 检查数据路径
directory = '//library.blend/Object/'
print(f"目录存在: {os.path.exists(bpy.path.abspath(directory))}")

# 列出可用数据块
print("可用对象:")
for obj in bpy.data.objects:
    print(f"  {obj.name}")
```

### 撤销历史耗尽
```python
# 检查撤销步数
print(f"撤销次数: {bpy.context.scene.undo_steps}")

# 增加撤销步数
bpy.context.scene.undo_steps = 256

# 清除历史
bpy.ops.wm.undo_history_clear()

# 手动推送操作
bpy.ops.wm.undo_push(message='我的操作')

# 检查内存使用
print(f"内存: {bpy.context.preferences.filepaths.file_preview_type}")
```

### 窗口问题
```python
# 检查窗口数
print(f"窗口数: {len(bpy.data.window_managers[0].windows)}")

# 检查活动窗口
print(f"活动窗口: {bpy.context.window}")

# 切换到下一个窗口
for win in bpy.data.window_managers[0].windows:
    bpy.context.window_manager.windows.active = win

# 重新打开窗口
bpy.ops.wm.window_new()

# 重置界面
bpy.ops.wm.read_homefile(use_factory_settings=True)
```
