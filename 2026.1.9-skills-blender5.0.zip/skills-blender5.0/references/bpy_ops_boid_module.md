# bpy.ops.boid - Boid Operations Module

Blender Boid（群集）操作符，用于粒子系统的群集行为模拟。

## Overview

`bpy.ops.boid` 模块包含 Boid 粒子系统的操作命令，支持群集行为的配置和控制。这个模块主要用于模拟鸟类、鱼类等群体行为。

## 核心功能

```python
import bpy

# Boid 状态操作
bpy.ops.boid.rule_external_logic()

# Boid 行为规则
bpy.ops.boid.rule_separation()
bpy.ops.boid.rule_alignment()
bpy.ops.boid.rule_cohesion()
```

## 实际应用示例

### Boid 行为管理器

```python
import bpy
import math

class BoidManager:
    """Boid 管理器"""
    
    def __init__(self):
        self.boids = []
    
    def add_boid_rule(self, particle_system, rule_type):
        """添加 Boid 规则"""
        rule = particle_system.settings.boids.active_boid_state.active_rule
        
        if rule_type == 'separation':
            rule.separation_distance = 1.0
            rule.separation_weight = 1.0
        elif rule_type == 'alignment':
            rule.alignment_distance = 2.0
            rule.alignment_weight = 1.0
        elif rule_type == 'cohesion':
            rule.cohesion_distance = 3.0
            rule.cohesion_weight = 1.0
        elif rule_type == 'target':
            rule.target = bpy.context.active_object
    
    def create_flocking_simulation(self, particle_system, 
                                   count=100, radius=10):
        """创建群集模拟"""
        settings = particle_system.settings
        
        # 设置 Boid 模式
        settings.physics_type = 'BOIDS'
        settings.boids.mode = 'FLOCK'
        
        # 添加规则
        self.add_boid_rule(particle_system, 'separation')
        self.add_boid_rule(particle_system, 'alignment')
        self.add_boid_rule(particle_system, 'cohesion')
        
        # 设置粒子数
        settings.count = count
        settings.frame_start = 1
        settings.frame_end = 200
    
    def create_fish_school(self, particle_system, count=50,
                          school_radius=5):
        """创建鱼群"""
        settings = particle_system.settings
        
        settings.physics_type = 'BOIDS'
        settings.boids.mode = 'FLOCK'
        settings.boids.fish = True
        
        # 设置鱼的行为
        self.add_boid_rule(particle_system, 'separation')
        self.add_boid_rule(particle_system, 'cohesion')
        
        # 添加目标吸引
        rule = settings.boids.active_boid_state.active_rule
        rule.average_distance = school_radius
    
    def create_bird_flock(self, particle_system, count=30,
                         flight_area=20):
        """创建鸟群"""
        settings = particle_system.settings
        
        settings.physics_type = 'BOIDS'
        settings.boids.bird = True
        
        # 设置飞行行为
        self.add_boid_rule(particle_system, 'alignment')
        self.add_boid_rule(particle_system, 'cohesion')
        
        # 设置高度范围
        settings.zmin = 0
        settings.zmax = flight_area
    
    def set_boid_physics(self, particle_system, 
                         mass=1.0, max_speed=5.0, max_force=0.5):
        """设置 Boid 物理属性"""
        settings = particle_system.settings
        
        settings.mass = mass
        settings.boid_max_speed = max_speed
        settings.boid_max_force = max_force
    
    def add_target_attractor(self, particle_system, target_object):
        """添加目标吸引"""
        settings = particle_system.settings
        
        rule = settings.boids.active_boid_state.active_rule
        rule.type = 'TARGET'
        rule.target = target_object
        rule.weight = 1.0
    
    def add_avoid_attractor(self, particle_system, avoid_object,
                           distance=5.0, weight=2.0):
        """添加回避吸引"""
        settings = particle_system.settings
        
        rule = settings.boids.active_boid_state.active_rule
        rule.type = 'AVOID'
        rule.collision_collection = avoid_object
        rule.distance = distance
        rule.weight = weight
    
    def set_boid_states(self, particle_system, states):
        """设置 Boid 状态"""
        settings = particle_system.settings
        
        # 清除现有状态
        settings.boids.boid_states.clear()
        
        # 添加新状态
        for state_data in states:
            state = settings.boids.boid_states.add()
            state.name = state_data.get('name', 'State')
            
            for rule_name in state_data.get('rules', []):
                rule = state.active_rule
                if rule_name == 'separation':
                    rule.separation = True
                elif rule_name == 'alignment':
                    rule.alignment = True
                elif rule_name == 'cohesion':
                    rule.cohesion = True
    
    def create_state_machine(self, particle_system):
        """创建状态机"""
        states = [
            {
                'name': 'Wander',
                'rules': ['separation', 'alignment', 'cohesion']
            },
            {
                'name': 'Seek',
                'rules': ['target']
            },
            {
                'name': 'Flee',
                'rules': ['avoid']
            }
        ]
        
        self.set_boid_states(particle_system, states)
    
    def export_boid_settings(self, particle_system, filepath):
        """导出 Boid 设置"""
        settings = particle_system.settings
        
        data = {
            'mode': settings.boids.mode,
            'max_speed': settings.boid_max_speed,
            'max_force': settings.boid_max_force,
            'states': []
        }
        
        for state in settings.boids.boid_states:
            state_data = {
                'name': state.name,
                'rules': []
            }
            
            rule = state.active_rule
            if rule.separation:
                state_data['rules'].append('separation')
            if rule.alignment:
                state_data['rules'].append('alignment')
            if rule.cohesion:
                state_data['rules'].append('cohesion')
            
            data['states'].append(state_data)
        
        import json
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        
        return filepath


def setup_boid_simulation():
    """设置 Boid 模拟"""
    manager = BoidManager()
    
    print("Boid 管理器已设置")
    print("可用功能:")
    print("- create_flocking_simulation: 创建群集")
    print("- create_fish_school: 创建鱼群")
    print("- create_state_machine: 创建状态机")
    
    return manager
```

### 群集动画系统

```python
import bpy
import math

class FlockAnimationSystem:
    """群集动画系统"""
    
    def __init__(self):
        self.flock_objects = {}
    
    def create_flock_from_mesh(self, mesh_name, count=50,
                              offset=0.1):
        """从网格创建群集"""
        mesh = bpy.data.objects.get(mesh_name)
        if not mesh:
            return None
        
        # 创建粒子系统
        bpy.context.view_layer.objects.active = mesh
        bpy.ops.object.particle_system_add()
        
        particle_system = mesh.particle_systems[-1]
        
        # 配置 Boid
        manager = BoidManager()
        manager.create_flocking_simulation(particle_system, count)
        
        # 设置发射器
        particle_system.settings.distribution = 'RAND'
        particle_system.settings.emitter = mesh
        particle_system.settings.grid_resolution = 10
        
        return particle_system
    
    def animate_flock_movement(self, particle_system, 
                              duration=100, speed=1.0):
        """动画群集移动"""
        settings = particle_system.settings
        
        # 设置时间范围
        settings.frame_start = 1
        settings.frame_end = duration
        
        # 设置速度
        settings.normal_factor = speed
    
    def create_flock_formation(self, particle_system, 
                               formation='V_SHAPE'):
        """创建群集阵型"""
        settings = particle_system.settings
        
        if formation == 'V_SHAPE':
            settings.boids.flock_shape = 'V'
        elif formation == 'LINE':
            settings.boids.flock_shape = 'LINE'
        elif formation == 'SPHERE':
            settings.boids.flock_shape = 'SPHERE'
    
    def add_predator(self, particle_system, predator_object,
                    fear_distance=5.0):
        """添加捕食者"""
        manager = BoidManager()
        manager.add_avoid_attractor(
            particle_system,
            predator_object,
            distance=fear_distance,
            weight=3.0
        )
    
    def create_trail_effect(self, particle_system, target_object):
        """创建拖尾效果"""
        # 创建轨迹曲线
        bpy.ops.curve.primitive_nurbs_path_add()
        trail = bpy.context.active_object
        trail.name = f"{target_object.name}_Trail"
        
        return trail
    
    def sync_flock_to_audio(self, particle_system, audio_file,
                           beat_frames=None):
        """同步群集到音频"""
        sound = bpy.data.sounds.get(audio_file)
        if not sound:
            return
        
        # 基于节拍调整群集行为
        fps = bpy.context.scene.render.fps
        duration = sound.length
        
        # 创建节拍帧
        if beat_frames is None:
            beat_frames = list(range(0, int(duration * fps), int(fps / 2)))
        
        return beat_frames
    
    def create_migration_pattern(self, particle_system, 
                                start_point, end_point,
                                duration=200):
        """创建迁徙模式"""
        settings = particle_system.settings
        
        # 设置目标
        bpy.ops.object.empty_add(location=end_point)
        target = bpy.context.active_object
        target.name = "MigrationTarget"
        
        manager = BoidManager()
        manager.add_target_attractor(particle_system, target)
        
        # 设置动画
        for frame in range(1, duration + 1):
            bpy.context.scene.frame_set(frame)
            
            t = frame / duration
            
            # 移动目标
            current_pos = (
                start_point[0] + (end_point[0] - start_point[0]) * t,
                start_point[1] + (end_point[1] - start_point[1]) * t,
                start_point[2] + (end_point[2] - start_point[2]) * t
            )
            
            target.location = current_pos
            target.keyframe_insert(data_path='location', frame=frame)
    
    def create_boid_collision_avoidance(self, particle_system,
                                       obstacle_objects):
        """创建 Boid 避障"""
        settings = particle_system.settings
        
        # 创建避障集合
        collection = bpy.data.collections.new("BoidObstacles")
        bpy.context.scene.collection.children.link(collection)
        
        for obj in obstacle_objects:
            for col in obj.users_collection:
                col.objects.unlink(obj)
            collection.objects.link(obj)
        
        # 设置碰撞集合
        rule = settings.boids.active_boid_state.active_rule
        rule.collision_collection = collection
        rule.distance = 2.0
        rule.weight = 2.0
    
    def export_flock_animation(self, particle_system, filepath):
        """导出群集动画"""
        settings = particle_system.settings
        
        animation_data = {
            'frame_start': settings.frame_start,
            'frame_end': settings.frame_end,
            'count': settings.count,
            'boid_settings': {
                'max_speed': settings.boid_max_speed,
                'max_force': settings.boid_max_force
            }
        }
        
        import json
        
        with open(filepath, 'w') as f:
            json.dump(animation_data, f, indent=2)
        
        return filepath


def setup_flock_animation():
    """设置群集动画"""
    system = FlockAnimationSystem()
    
    print("群集动画系统已设置")
    print("可用功能:")
    print("- create_flock_from_mesh: 从网格创建")
    print("- create_migration_pattern: 迁徙模式")
    print("- sync_flock_to_audio: 音频同步")
    
    return system
```

### 群集优化工具

```python
import bpy

class FlockOptimizationTool:
    """群集优化工具"""
    
    def __init__(self):
        self.performance_settings = {}
    
    def set_render_quality(self, particle_system, quality='LOW'):
        """设置渲染质量"""
        settings = particle_system.settings
        
        if quality == 'LOW':
            settings.render_step = 4
            settings.triangle_seed_step = 4
        elif quality == 'MEDIUM':
            settings.render_step = 2
            settings.triangle_seed_step = 2
        elif quality == 'HIGH':
            settings.render_step = 1
            settings.triangle_seed_step = 1
    
    def optimize_flock_for_realtime(self, particle_system):
        """优化群集实时性能"""
        self.set_render_quality(particle_system, 'LOW')
        
        settings = particle_system.settings
        settings.count = min(settings.count, 100)
        settings.frame_start = 1
        settings.frame_end = 100
    
    def optimize_flock_for_rendering(self, particle_system):
        """优化群集渲染"""
        self.set_render_quality(particle_system, 'HIGH')
        
        settings = particle_system.settings
        settings.count = min(settings.count, 1000)
    
    def balance_quality_performance(self, particle_system, 
                                    target_fps=30):
        """平衡质量和性能"""
        settings = particle_system.settings
        
        # 计算最大粒子数
        current_fps = bpy.context.scene.render.fps
        render_time = 1.0 / target_fps
        
        # 调整粒子数
        max_count = int(render_time * settings.count / 0.01)
        settings.count = min(settings.count, max_count)
    
    def set_lod_levels(self, particle_system, levels):
        """设置 LOD 级别"""
        settings = particle_system.settings
        
        for i, (distance, percent) in enumerate(levels):
            if i == 0:
                settings.lod_distance = distance
                settings.lod_percent = percent
            elif i == 1:
                settings.lod_max_hysteresis = distance
                settings.lod_max_percent = percent
    
    def create_render_baker(self, particle_system):
        """创建渲染烘焙器"""
        # 烘焙粒子到关键帧
        bpy.context.view_layer.objects.active = particle_system.point_cache[0].object
        bpy.ops.ptcache.bake_from_cache()
    
    def export_particle_cache(self, particle_system, filepath):
        """导出粒子缓存"""
        bpy.ops.ptcache.external_export(filepath=filepath)
    
    def import_particle_cache(self, particle_system, filepath):
        """导入粒子缓存"""
        bpy.ops.ptcache.external_import(filepath=filepath)
    
    def check_flock_health(self, particle_system):
        """检查群集健康"""
        settings = particle_system.settings
        
        health = {
            'particle_count': settings.count,
            'frame_range': f"{settings.frame_start}-{settings.frame_end}",
            'physics_type': settings.physics_type,
            'render_step': settings.render_step,
            'memory_usage': settings.count * settings.render_step
        }
        
        return health
    
    def create_flock_report(self, particle_system):
        """创建群集报告"""
        health = self.check_flock_health(particle_system)
        
        report = f"""
=== 群集健康报告 ===

粒子数量: {health['particle_count']}
帧范围: {health['frame_range']}
物理类型: {health['physics_type']}
渲染步长: {health['render_step']}
预估内存: {health['memory_usage']} MB
"""
        
        return report
    
    def reset_flock_simulation(self, particle_system):
        """重置群集模拟"""
        # 清除缓存
        bpy.ops.ptcache.free()
        
        # 重置帧
        bpy.context.scene.frame_set(1)
        
        # 重新开始
        particle_system.seed = int(bpy.context.scene.frame_current)


def setup_flock_optimization():
    """设置群集优化"""
    tool = FlockOptimizationTool()
    
    print("群集优化工具已设置")
    print("可用功能:")
    print("- optimize_flock_for_realtime: 实时优化")
    print("- create_render_baker: 烘焙渲染")
    print("- check_flock_health: 健康检查")
    
    return tool
```
