# bpy.ops.constraint 模块

约束操作模块，用于创建和管理物体间的约束关系。

## 概述

bpy.ops.constraint 模块包含用于在物体上添加、编辑和删除约束的运算符。这些约束控制物体之间的运动关系，如跟随目标、复制变换、父子关系等。

## 常用操作

### 约束添加

```python
import bpy

# 添加约束到选中物体
bpy.ops.constraint.add(type='COPY_LOCATION')

# 添加目标物体类型的约束
bpy.ops.constraint.add(type='TRACK_TO')

# 添加影响特定轴的约束
bpy.ops.constraint.add(type='COPY_LOCATION', influence=0.5)
```

### 约束类型

```python
# 复制位置
bpy.ops.constraint.add(type='COPY_LOCATION')
bpy.ops.constraint.add(type='COPY_LOCATION', use_x=True, use_y=True, use_z=True)

# 复制旋转
bpy.ops.constraint.add(type='COPY_ROTATION')
bpy.ops.constraint.add(type='COPY_ROTATION', use_x=True, use_y=True, use_z=True)

# 复制缩放
bpy.ops.constraint.add(type='COPY_SCALE')
bpy.ops.constraint.add(type='COPY_SCALE', use_x=True, use_y=True, use_z=True)

# 复制变换
bpy.ops.constraint.add(type='COPY_TRANSFORMS')

# 跟随路径
bpy.ops.constraint.add(type='FOLLOW_PATH')
bpy.ops.constraint.add(type='FOLLOW_PATH', follow_curve=True, use_curve_follow=True)

# 变换到变换
bpy.ops.constraint.add(type='TRANSFORM_TO')

# 变换来自
bpy.ops.constraint.add(type='TRANSFORM_FROM')

# 变换偏移
bpy.ops.constraint.add(type='TRANSFORM_OFFSET')

# 限制位置
bpy.ops.constraint.add(type='LIMIT_LOCATION')
bpy.ops.constraint.add(type='LIMIT_LOCATION', use_min_x=True, use_max_x=True)

# 限制旋转
bpy.ops.constraint.add(type='LIMIT_ROTATION')
bpy.ops.constraint.add(type='LIMIT_ROTATION', use_min_x=True, use_max_x=True)

# 限制缩放
bpy.ops.constraint.add(type='LIMIT_SCALE')
bpy.ops.constraint.add(type='LIMIT_SCALE', use_min_x=True, use_max_x=True)

# 维护体积
bpy.ops.constraint.add(type='MAINTAIN_VOLUME')

# 变换混合
bpy.ops.constraint.add(type='TRANSFORM_MIX')
bpy.ops.constraint.add(type='TRANSFORM_MIX', use_location=True, use_rotation=True)
```

### 约束操作

```python
# 选中约束
bpy.ops.constraint.select(action='SELECT')
bpy.ops.constraint.select(action='DESELECT')
bpy.ops.constraint.select(action='INVERT')

# 移动约束
bpy.ops.constraint.move(type='UP')
bpy.ops.constraint.move(type='DOWN')

# 删除约束
bpy.ops.constraint.delete()

# 应用约束
bpy.ops.constraint.apply(constraint='Constraint')

# 禁用约束
bpy.ops.constraint.disable(constraint='Constraint')
bpy.ops.constraint.enable(constraint='Constraint')

# 设置目标
bpy.ops.constraint.set_target(target='TargetObject')

# 设置子物体
bpy.ops.constraint.set_subtarget(subtarget='BoneName')

# 复制约束
bpy.ops.constraint.copy')

# 粘贴约束
bpy.ops.constraint.paste')
```

### 约束目标操作

```python
# 从目标创建空物体
bpy.ops.constraint.object_bake_offsets(type='OFFSET')

# 清除偏移
bpy.ops.constraint.object_bake_offsets(type='CLEAR')

# 设置目标偏移
bpy.ops.constraint.object_bake_offsets(type='OFFSET')

# 重置目标
bpy.ops.constraint.reset_target()

# 更新目标
bpy.ops.constraint.update_target()
```

## 实际应用示例

### 创建相机跟随系统

```python
def setup_camera_follow(target_obj, camera_obj):
    """设置相机跟随目标物体"""
    # 确保相机被选中
    bpy.ops.object.select_all(action='DESELECT')
    camera_obj.select_set(True)
    bpy.context.view_layer.objects.active = camera_obj
    
    # 添加跟踪约束
    constraint = camera_obj.constraints.new(type='TRACK_TO')
    constraint.target = target_obj
    constraint.track_axis = 'TRACK_NEGATIVE_Z'
    constraint.up_axis = 'UP_Y'
    
    # 添加位置约束（带偏移）
    pos_constraint = camera_obj.constraints.new(type='COPY_LOCATION')
    pos_constraint.target = target_obj
    pos_constraint.influence = 0.0
    
    return [constraint, pos_constraint]
```

### 创建父子关系链

```python
def create_rig_chain(objects):
    """创建物体链条的父子关系"""
    for i, obj in enumerate(objects):
        if i == 0:
            continue
        
        # 清除现有约束
        for constraint in obj.constraints:
            obj.constraints.remove(constraint)
        
        # 添加跟随约束
        follow = obj.constraints.new(type='COPY_TRANSFORMS')
        follow.target = objects[i-1]
        follow.influence = 1.0
        
        # 使用子物体模式
        follow.subtarget = ''
    
    return objects
```

### 创建行走循环动画

```python
def setup_walk_cycle(character_root, foot_r, foot_l):
    """设置角色行走循环"""
    # 右脚位置约束
    foot_r_constraint = foot_r.constraints.new(type='COPY_LOCATION')
    foot_r_constraint.target = character_root
    
    # 右脚旋转约束
    foot_r_rot = foot_r.constraints.new(type='COPY_ROTATION')
    foot_r_rot.target = character_root
    foot_r_rot.influence = 0.0
    
    # 左脚位置约束
    foot_l_constraint = foot_l.constraints.new(type='COPY_LOCATION')
    foot_l_constraint.target = character_root
    
    # 左脚旋转约束
    foot_l_rot = foot_l.constraints.new(type='COPY_ROTATION')
    foot_l_rot.target = character_root
    foot_l_rot.influence = 0.0
    
    return [foot_r_constraint, foot_r_rot, foot_l_constraint, foot_l_rot]
```

### 创建眼睛注视系统

```python
def setup_eye_tracking(eye_l, eye_r, target):
    """设置双眼注视目标"""
    for eye in [eye_l, eye_r]:
        # 清除现有约束
        eye.constraints.clear()
        
        # 添加轨道约束
        track = eye.constraints.new(type='TRACK_TO')
        track.target = target
        track.track_axis = 'TRACK_NEGATIVE_Z'
        track.up_axis = 'UP_Y'
        
        # 添加限制旋转约束
        limit = eye.constraints.new(type='LIMIT_ROTATION')
        limit.use_min_x = True
        limit.min_x = -0.5
        limit.use_max_x = True
        limit.max_x = 0.5
        limit.use_min_y = True
        limit.min_y = -0.5
        limit.use_max_y = True
        limit.max_y = 0.5
```

## 使用场景

- **角色绑定**：创建骨骼和物体间的运动关系
- **相机控制**：设置相机跟随和注视目标
- **动画系统**：建立复杂的运动链和约束网络
- **机械动画**：创建齿轮、连杆等机械运动
- **特效控制**：控制粒子发射器和力场的行为

## 注意事项

- 约束按顺序执行，后添加的约束覆盖前面的效果
- 目标物体必须在场景中存在
- 子物体（subtarget）只对骨骼约束有效
- 父子关系约束和变换约束会冲突
- 循环约束会导致无限递归
