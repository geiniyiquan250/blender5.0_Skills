# bpy.ops.export_anim 模块

动画导出操作模块，用于将Blender动画导出为各种格式。

## 概述

bpy.ops.export_anim 模块包含用于将动画数据导出为外部格式的运算符。这些运算符支持导出骨骼动画、形状键动画和约束动画。

## 常用操作

### 基础导出

```python
import bpy

# 导出动画
bpy.ops.export_anim.animation_export(
    filepath='//animation.fbx',
    export_format='FBX'
)

# 导出选定动画
bpy.ops.export_anim.animation_export(
    filepath='//animation.fbx',
    use_selection=True
)

# 导出所有动画
bpy.ops.export_anim.animation_export(
    filepath='//animation.fbx',
    use_selection=False
)
```

### FBX导出

```python
# FBX格式导出
bpy.ops.export_anim.fbx_export(
    filepath='//animation.fbx',
    export_format='FBX',
    use_selection=False,
    export_animations=True,
    export_frame_range=True,
    export_nla_strips=True
)

# FBX骨骼导出
bpy.ops.export_anim.fbx_export(
    filepath='//character.fbx',
    export_format='FBX',
    export_armature=True,
    export_bone_animations=True
)

# FBX形状键导出
bpy.ops.export_anim.fbx_export(
    filepath='//morph.fbx',
    export_format='FBX',
    export_morph=True,
    export_morph_normal=True
)
```

### glTF导出

```python
# glTF格式导出
bpy.ops.export_anim.gltf_export(
    filepath='//animation.glb',
    export_format='GLB',
    use_selection=False,
    export_animations=True,
    export_lights=True,
    export_cameras=True
)

# glTF骨骼动画
bpy.ops.export_anim.gltf_export(
    filepath='//character.glb',
    export_format='GLB',
    export_animations=True,
    export_skins=True,
    export_morph=True
)

# glTF NLA导出
bpy.ops.export_anim.gltf_export(
    filepath='//nla.glb',
    export_format='GLB',
    export_animations=True,
    export_nla_strips=True
)
```

### ABC导出

```python
# Alembic格式导出
bpy.ops.export_anim.alembic_export(
    filepath='//simulation.abc',
    start=1,
    end=250,
    export_animations=True,
    export_frame_range=True
)

# ABC几何导出
bpy.ops.export_anim.alembic_export(
    filepath='//geometry.abc',
    start=1,
    end=100,
    export_animations=True,
    export_uv=True,
    export_normals=True
)
```

### OBJ导出

```python
# OBJ格式导出（带动画）
bpy.ops.export_anim.obj_export(
    filepath='//model.obj',
    export_animated=True,
    export_frame_start=1,
    export_frame_end=100
)
```

### 设置导出

```python
# 导出范围
bpy.ops.export_anim.animation_export(
    filepath='//animation.fbx',
    frame_start=1,
    frame_end=250
)

# 导出采样
bpy.ops.export_anim.animation_export(
    filepath='//animation.fbx',
    export_frame_step=1
)

# 导出烘焙
bpy.ops.export_anim.animation_export(
    filepath='//animation.fbx',
    export_bake_all_animations=True,
    export_bake_use_nla_strips=True
)
```

## 实际应用示例

### 导出角色动画到FBX

```python
def export_character_animation(character, output_path, start_frame=1, end_frame=250):
    """导出角色动画到FBX"""
    # 选中角色
    bpy.ops.object.select_all(action='DESELECT')
    character.select_set(True)
    bpy.context.view_layer.objects.active = character
    
    # 导出动画
    bpy.ops.export_anim.fbx_export(
        filepath=output_path,
        export_format='FBX',
        use_selection=True,
        export_animations=True,
        export_frame_range=True,
        export_bake_all_animations=True,
        export_armature=True,
        export_bone_animations=True,
        export_nla_strips=True,
        export_current_frame=start_frame
    )
    
    return output_path
```

### 导出glTF动画

```python
def export_gltf_animation(output_path, start_frame=1, end_frame=250):
    """导出glTF动画"""
    bpy.ops.export_anim.gltf_export(
        filepath=output_path,
        export_format='GLB',
        use_selection=False,
        export_animations=True,
        export_frame_range=True,
        export_nla_strips=True,
        export_current_frame=start_frame
    )
    
    return output_path
```

### 导出NLA动画

```python
def export_nla_animation(nla_track, output_path):
    """导出NLA轨道动画"""
    # 设置当前帧为动画开始
    bpy.context.scene.frame_set(nla_track.strips[0].frame_start)
    
    # 导出
    bpy.ops.export_anim.animation_export(
        filepath=output_path,
        export_format='FBX',
        use_selection=True,
        export_nla_strips=True
    )
    
    return output_path
```

### 批量导出动画

```python
def batch_export_animations(export_config):
    """批量导出多个动画"""
    import os
    
    results = []
    
    for config in export_config:
        character = config['character']
        output_dir = config['output_dir']
        animations = config['animations']
        
        for anim_name, anim_config in animations.items():
            output_path = os.path.join(output_dir, f'{anim_name}.fbx')
            
            # 设置帧范围
            bpy.context.scene.frame_start = anim_config['start']
            bpy.context.scene.frame_end = anim_config['end']
            
            # 选中角色
            bpy.ops.object.select_all(action='DESELECT')
            character.select_set(True)
            bpy.context.view_layer.objects.active = character
            
            # 导出
            bpy.ops.export_anim.fbx_export(
                filepath=output_path,
                export_format='FBX',
                use_selection=True,
                export_animations=True,
                export_frame_range=True
            )
            
            results.append({
                'animation': anim_name,
                'path': output_path,
                'frames': f"{anim_config['start']}-{anim_config['end']}"
            })
    
    return results
```

### 导出形状键动画

```python
def export_shape_key_animation(mesh, output_path, start_frame=1, end_frame=100):
    """导出形状键动画"""
    # 选中网格
    bpy.ops.object.select_all(action='DESELECT')
    mesh.select_set(True)
    bpy.context.view_layer.objects.active = mesh
    
    # 设置帧范围
    bpy.context.scene.frame_start = start_frame
    bpy.context.scene.frame_end = end_frame
    
    # 导出
    bpy.ops.export_anim.fbx_export(
        filepath=output_path,
        export_format='FBX',
        use_selection=True,
        export_morph=True,
        export_morph_normal=True
    )
    
    return output_path
```

### 导出Alembic模拟

```python
def export_alembic_simulation(domain_obj, output_path, start_frame=1, end_frame=250):
    """导出Alembic模拟"""
    # 选中域对象
    bpy.ops.object.select_all(action='DESELECT')
    domain_obj.select_set(True)
    bpy.context.view_layer.objects.active = domain_obj
    
    # 导出
    bpy.ops.export_anim.alembic_export(
        filepath=output_path,
        start=start_frame,
        end=end_frame,
        export_animations=True,
        export_frame_range=True
    )
    
    return output_path
```

### 导出程序化动画

```python
def export_procedural_animation(obj, output_path, frames=250):
    """导出程序化动画"""
    # 确保对象已选中
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    # 设置帧范围
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = frames
    
    # 烘焙动画
    bpy.ops.nla.bake(
        frame_start=1,
        frame_end=frames,
        visual_keying=True,
        clear_constraints=True
    )
    
    # 导出
    bpy.ops.export_anim.animation_export(
        filepath=output_path,
        export_format='GLB',
        use_selection=True,
        export_bake_all_animations=True
    )
    
    return output_path
```

## 使用场景

- **游戏开发**：导出角色和动画到游戏引擎
- **Web3D**：导出模型和动画到Web平台
- **后期合成**：导出分层渲染和模拟
- **跨平台共享**：在不同软件间传递动画
- **存档备份**：保存动画项目
- **渲染农场**：在外部渲染

## 注意事项

- 不同格式支持不同功能
- FBX适合大多数游戏引擎
- glTF适合Web和实时应用
- Alembic适合特效和模拟
- 烘焙动画确保兼容性
- 帧范围影响导出大小
