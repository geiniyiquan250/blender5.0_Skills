# bmesh.types - BMesh 数据类型参考

BMesh 是 Blender 的底层网格建模系统，提供比传统网格数据访问更强大和灵活的网格几何操作。

## Overview

`bmesh.types` 模块定义了 BMesh 中所有的数据类型，包括 BMesh 本身、顶点、边、面等核心元素。这些类型提供了对网格几何的低级别访问。

## 核心数据类型

### BMesh - 网格对象

```python
import bpy
import bmesh

# 创建 BMesh 对象
bm = bmesh.new()

# 从现有网格创建 BMesh
mesh = bpy.context.active_object.data
bm = bmesh.new()
bm.from_mesh(mesh)

# 从对象创建（包含变换）
bm = bmesh.new()
bm.from_object(bpy.context.active_object, bpy.context.evaluated_depsgraph_get())

# 操作完成后写回网格
bm.to_mesh(mesh)
bm.free()

# 使用 with 语句
with bmesh.new() as bm:
    # 在这里操作 bm
    bmesh.ops.create_cube(bm, size=1.0)
    mesh = bpy.context.active_object.data
    bm.to_mesh(mesh)
```

### BMesh 基础属性

```python
# 顶点
print(f"顶点数: {len(bm.vertices)}")

# 边
print(f"边数: {len(bm.edges)}")

# 面
print(f"面数: {len(bm.faces)}")

# 循环（边角点）
print(f"循环数: {len(bm.loops)}")

# 层数据
print(f"顶点层: {list(bm.verts.layers.deform.keys())}")
print(f"颜色层: {list(bm.verts.layers.color.keys())}")
```

## 顶点 (BMVert)

```python
import bmesh

# 创建顶点
v1 = bm.verts.new((0.0, 0.0, 0.0))
v2 = bm.verts.new((1.0, 0.0, 0.0))
v3 = bm.verts.new((1.0, 1.0, 0.0))
v4 = bm.verts.new((0.0, 1.0, 0.0))

# 创建后需要更新
bm.verts.ensure_lookup_table()

# 顶点属性
print(f"顶点索引: {v1.index}")
print(f"顶点坐标: {v1.co}")           # Vector
print(f"顶点法线: {v1.normal}")       # Vector
print(f"所属边: {v1.link_edges}")     # 边列表
print(f"所属面: {v1.link_faces}")     # 面列表

# 修改坐标
v1.co.x = 2.0
v1.co.y = 3.0
v1.co.z = 4.0

# 顶点选择状态
v1.select = True
print(f"是否选中: {v1.select}")

# 隐藏顶点
v1.hide = True
print(f"是否隐藏: {v1.hide}")

# 顶点排序
bm.verts.sort()

# 批量创建
verts = [bm.verts.new((x, 0, 0)) for x in range(5)]
bm.verts.ensure_lookup_table()

# 查找顶点
vertex = bm.verts.get((1.0, 0.0, 0.0))
if vertex:
    print(f"找到顶点: {vertex.index}")

# 遍历所有顶点
for v in bm.verts:
    print(f"顶点 {v.index}: {v.co}")
```

## 边 (BMEdge)

```python
import bmesh

# 创建边（需要两个顶点）
e1 = bm.edges.new((v1, v2))
e2 = bm.edges.new((v2, v3))
e3 = bm.edges.new((v3, v4))
e4 = bm.edges.new((v4, v1))
e5 = bm.edges.new((v1, v3))  # 对角线

# 使用现有顶点创建边
e6 = bm.edges.get((v1, v2))

# 边属性
print(f"边索引: {e1.index}")
print(f"起点: {e1.verts[0]}")  # BMVert
print(f"终点: {e1.verts[1]}")  # BMVert
print(f"长度: {e1.calc_length()}")  # float
print(f"所属面: {e1.link_faces}")  # 面列表

# 边选择状态
e1.select = True
print(f"是否选中: {e1.select}")

# 边折缝（用于权重/几何折缝）
e1.seam = True
print(f"是否接缝: {e1.seam}")

# 边粗糙（用于法线计算）
e1.crease = 0.5
print(f"粗糙度: {e1.crease}")

# 边类型检查
print(f"是否为边界边: {e1.is_boundary}")
print(f"是否为 Wire 边: {e1.is_wire}")
print(f"是否为 manifold 边: {e1.is_manifold}")

# 遍历边
for e in bm.edges:
    print(f"边 {e.index}: 长度 = {e.calc_length():.3f}")
```

## 面 (BMFace)

```python
import bmesh

# 创建面（需要3-4个顶点）
f1 = bm.faces.new((v1, v2, v3, v4))

# 面属性
print(f"面索引: {f1.index}")
print(f"顶点数: {len(f1.verts)}")
print(f"边数: {len(f1.edges)}")
print(f"法线: {f1.normal}")           # Vector
print(f"面积: {f1.calc_area()}")       # float
print(f"周长: {f1.calc_perimeter()}")  # float
print(f"中心: {f1.calc_center_median()}")  # Vector
print(f"几何中心: {f1.calc_center_bounds()}")  # Vector

# 获取顶点和边
for v in f1.verts:
    print(f"  顶点: {v.co}")

for e in f1.edges:
    print(f"  边: {e.index}")

# 循环（顶点-边对）
for loop in f1.loops:
    print(f"循环: vert={loop.vert.index}, edge={loop.edge.index}")
    print(f"  UV: {loop[bm.verts.layers.uv.active]}")
    print(f"  颜色: {loop[bm.verts.layers.color.active]}")

# 面选择状态
f1.select = True
print(f"是否选中: {f1.select}")

# 面隐藏
f1.hide = True
print(f"是否隐藏: {f1.hide}")

# 面填充
f1.material_index = 0

# 面法线方向
f1.flip()
print(f"翻转后面法线: {f1.normal}")

# 检查面类型
print(f"是否为三角面: {len(f1.verts) == 3}")
print(f"是否为四边面: {len(f1.verts) == 4}")
print(f"是否为多边面: {len(f1.verts) > 4}")

# 遍历所有面
for f in bm.faces:
    print(f"面 {f.index}: 面积 = {f.calc_area():.3f}")
```

## 循环 (BMLoop)

```python
import bmesh

# 循环是连接顶点、边和面的特殊对象
# 每个面有 N 个循环，每个循环包含一个顶点和一条边

for f in bm.faces:
    for loop in f.loops:
        # 循环属性
        print(f"顶点: {loop.vert}")
        print(f"边: {loop.edge}")
        print(f"邻接面: {loop.link_loop_next}")
        print(f"邻接面: {loop.link_loop_prev}")
        
        # 访问层数据
        if bm.verts.layers.uv.active:
            uv_layer = bm.verts.layers.uv.active
            print(f"UV: {loop[uv_layer].uv}")
        
        if bm.verts.layers.color.active:
            color_layer = bm.verts.layers.color.active
            print(f"颜色: {loop[color_layer].color}")
```

## 层数据 (BMLayer)

### 顶点组层（变形层）

```python
import bmesh

# 创建变形层
deform_layer = bm.verts.layers.deform.new("Weights")

# 访问变形数据
v = bm.verts[0]
v_deform = v[deform_layer]

# 设置权重
v_deform[0] = 1.0  # 顶点组索引 0 的权重
v_deform[1] = 0.5  # 顶点组索引 1 的权重

# 读取权重
weight_0 = v_deform.get(0, 0.0)

# 遍历所有变形组
for group_index, weight in v_deform.items():
    print(f"组 {group_index}: 权重 {weight}")
```

### UV 层

```python
import bmesh

# 创建 UV 层
uv_layer = bm.verts.layers.uv.new("UVMap")

# 访问 UV 数据
for f in bm.faces:
    for loop in f.loops:
        uv = loop[uv_layer]
        print(f"UV: {uv.uv}")
        
        # 设置 UV
        uv.uv = (loop.vert.co.x, loop.vert.co.y)
```

### 顶点颜色层

```python
import bmesh

# 创建顶点颜色层
color_layer = bm.verts.layers.color.new("Col")

# 访问颜色数据
for f in bm.faces:
    for loop in f.loops:
        color = loop[color_layer]
        print(f"颜色: {color}")
        
        # 设置颜色
        color.color = (1.0, 0.5, 0.2, 1.0)
```

## 顶点索引层

```python
import bmesh

# 创建自定义整数层
custom_int_layer = bm.verts.layers.int.new("CustomInt")

# 设置和获取
v = bm.verts[0]
v[custom_int_layer] = 42

value = v[custom_int_layer]
print(f"自定义整数: {value}")

# 浮点层
float_layer = bm.verts.layers.float.new("CustomFloat")
v[float_layer] = 3.14

# 字符串层
string_layer = bm.verts.layers.string.new("CustomString")
v[string_layer] = "vertex_data"
```

## 常用操作模式

### 遍历和过滤

```python
# 遍历所有顶点
for v in bm.verts:
    print(f"顶点 {v.index}: {v.co}")

# 遍历选中的顶点
selected_verts = [v for v in bm.verts if v.select]
print(f"选中顶点数: {len(selected_verts)}")

# 遍历边界顶点
boundary_verts = [v for v in bm.verts if any(e.is_boundary for e in v.link_edges)]
print(f"边界顶点数: {len(boundary_verts)}")

# 遍历孤立顶点
isolated_verts = [v for v in bm.verts if len(v.link_edges) == 0]
print(f"孤立顶点数: {len(isolated_verts)}")
```

### 创建标准几何体

```python
import bmesh
import math

def create_icosphere(bm, subdivisions=2, radius=1.0):
    """创建二十面体球体"""
    t = (1.0 + math.sqrt(5.0)) / 2.0
    
    verts = [
        bm.verts.new((-1, t, 0)),
        bm.verts.new((1, t, 0)),
        bm.verts.new((-1, -t, 0)),
        bm.verts.new((1, -t, 0)),
        bm.verts.new((0, -1, t)),
        bm.verts.new((0, 1, t)),
        bm.verts.new((0, -1, -t)),
        bm.verts.new((0, 1, -t)),
        bm.verts.new((t, 0, -1)),
        bm.verts.new((t, 0, 1)),
        bm.verts.new((-t, 0, -1)),
        bm.verts.new((-t, 0, 1)),
    ]
    
    bm.verts.ensure_lookup_table()
    
    faces = [
        (0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11),
        (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6), (7, 1, 8),
        (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9),
        (4, 9, 5), (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1),
    ]
    
    for f in faces:
        bm.faces.new(tuple(verts[i] for i in f))
    
    # 缩放到半径
    for v in bm.verts:
        v.co = v.co.normalized() * radius
    
    return bm

# 使用
with bmesh.new() as bm:
    create_icosphere(bm, subdivisions=2, radius=1.0)
```

### 数据转换

```python
import bmesh
import numpy as np

def get_vertex_data(bm):
    """提取顶点数据为 numpy 数组"""
    coords = np.array([v.co.to_tuple() for v in bm.verts])
    normals = np.array([v.normal.to_tuple() for v in bm.verts])
    return coords, normals

def set_vertex_colors_from_height(bm, min_height=0, max_height=2):
    """根据高度设置顶点颜色"""
    color_layer = bm.verts.layers.color.new("HeightColor")
    
    heights = [v.co.z for v in bm.verts]
    min_h = min(heights)
    max_h = max(heights)
    
    for f in bm.faces:
        for loop in f.loops:
            h = loop.vert.co.z
            t = (h - min_h) / (max_h - min_h) if max_h > min_h else 0.5
            
            # 渐变颜色：蓝 -> 绿 -> 红
            if t < 0.5:
                r = t * 2
                g = 1 - r
                b = 0
            else:
                r = 1
                g = 1 - (t - 0.5) * 2
                b = 0
            
            loop[color_layer].color = (r, g, b, 1.0)
```

## 性能优化

### 1. 批量操作

```python
# 不推荐：逐个操作
for v in bm.verts:
    v.co.x *= 2

# 推荐：使用 bmesh.ops
bmesh.ops.scale(bm, vec=(2, 1, 1), verts=bm.verts)
```

### 2. 避免频繁的索引查找

```python
# 不推荐
for i in range(len(bm.verts)):
    v = bm.verts[i]
    
# 推荐
bm.verts.ensure_lookup_table()
for v in bm.verts:
    pass
```

### 3. 及时清理

```python
# 删除孤立顶点
bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.0)

# 删除非流形几何
bmesh.ops.dissolve_degenerate(bm, edges=bm.edges, dist=0.001)
```

## 与传统网格的互操作

```python
import bmesh

# 从网格创建 BMesh
mesh = bpy.context.active_object.data
bm = bmesh.new()
bm.from_mesh(mesh)

# 操作 BMesh
bmesh.ops.subdivide_edges(bm, edges=bm.edges[:10], cuts=2)

# 写回网格
bm.to_mesh(mesh)
bm.free()

# 更新对象
mesh.update()

# 从 BMesh 创建新网格
new_mesh = bpy.data.meshes.new("NewMesh")
bm = bmesh.new()
bmesh.ops.create_cube(bm, size=1.0)
bm.to_mesh(new_mesh)
bm.free()

# 创建新对象
new_obj = bpy.data.objects.new("NewObject", new_mesh)
bpy.context.collection.objects.link(new_obj)
```

## 常见问题

### Q: 顶点坐标不更新
A: 确保操作后调用 `bm.verts.ensure_lookup_table()` 更新索引表。

### Q: 修改不生效
A: 检查是否调用 `bm.to_mesh(mesh)` 将更改写回网格。

### Q: 内存泄漏
A: 总是使用 `bm.free()` 或 `with bmesh.new() as bm:` 确保释放 BMesh 对象。

## 相关模块

- [bmesh.ops](bmesh_ops_module.md) - BMesh 操作
- [bmesh.utils](bmesh_utils_module.md) - BMesh 工具函数
- [bmesh.geometry](bmesh_geometry_module.md) - BMesh 几何计算
- [mathutils](mathutils_module.md) - 数学工具
