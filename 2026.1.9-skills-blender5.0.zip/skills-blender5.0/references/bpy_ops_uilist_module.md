# bpy.ops.uilist - UI List Operations Module

Blender UI 列表操作符，用于管理用户界面列表的选择和操作。

## Overview

`bpy.ops.uilist` 模块包含 UI 列表的操作命令，支持列表项的选择、移动、删除等操作。这个模块主要用于自定义界面和列表控件的交互。

## 核心功能

```python
import bpy

# 选择列表项
bpy.ops.uilist.select_item(index=0, extend=False)

# 选择范围
bpy.ops.uilist.select_item_range(start=0, end=10)

# 激活列表项
bpy.ops.uilist.active_item(index=0)

# 删除列表项
bpy.ops.uilist.delete_item(index=0)

# 移动列表项
bpy.ops.uilist.move_item(direction='UP')

# 复制列表项
bpy.ops.uilist.duplicate_item(index=0)
```

## 实际应用示例

### UI 列表管理器

```python
import bpy

class UIListManager:
    """UI 列表管理器"""
    
    def __init__(self):
        self.lists = {}
    
    def select_item(self, list_id, index, extend=False):
        """选择列表项"""
        bpy.ops.uilist.select_item(
            list_id=list_id,
            index=index,
            extend=extend
        )
    
    def select_range(self, list_id, start, end):
        """选择范围"""
        bpy.ops.uilist.select_item_range(
            list_id=list_id,
            start=start,
            end=end
        )
    
    def select_all(self, list_id):
        """全选"""
        bpy.ops.uilist.select_item(
            list_id=list_id,
            index=-1
        )
    
    def deselect_all(self, list_id):
        """取消选择"""
        bpy.ops.uilist.select_item(
            list_id=list_id,
            index=-2
        )
    
    def invert_selection(self, list_id):
        """反选"""
        bpy.ops.uilist.select_item(
            list_id=list_id,
            index=-3
        )
    
    def activate_item(self, list_id, index):
        """激活列表项"""
        bpy.ops.uilist.active_item(
            list_id=list_id,
            index=index
        )
    
    def delete_item(self, list_id, index):
        """删除列表项"""
        bpy.ops.uilist.delete_item(
            list_id=list_id,
            index=index
        )
    
    def delete_selected(self, list_id):
        """删除选中项"""
        bpy.ops.uilist.delete_item(
            list_id=list_id,
            index=-1
        )
    
    def move_item_up(self, list_id, index):
        """上移"""
        bpy.ops.uilist.move_item(
            list_id=list_id,
            direction='UP',
            index=index
        )
    
    def move_item_down(self, list_id, index):
        """下移"""
        bpy.ops.uilist.move_item(
            list_id=list_id,
            direction='DOWN',
            index=index
        )
    
    def duplicate_item(self, list_id, index):
        """复制"""
        bpy.ops.uilist.duplicate_item(
            list_id=list_id,
            index=index
        )
    
    def move_to_top(self, list_id, index):
        """移到顶部"""
        if index > 0:
            for i in range(index):
                self.move_item_up(list_id, 0)
    
    def move_to_bottom(self, list_id, index):
        """移到底部"""
        # 需要先获取列表长度
        pass
    
    def refresh_list(self, list_id):
        """刷新列表"""
        bpy.ops.uilist.select_item(
            list_id=list_id,
            index=-4
        )
    
    def filter_list(self, list_id, filter_text):
        """过滤列表"""
        bpy.ops.uilist.filter(
            list_id=list_id,
            filter_text=filter_text
        )
    
    def clear_filter(self, list_id):
        """清除过滤"""
        bpy.ops.uilist.filter(
            list_id=list_id,
            filter_text=""
        )
    
    def expand_all(self, list_id):
        """展开所有"""
        bpy.ops.uilist.expand_or_collapse(
            list_id=list_id,
            action='EXPAND'
        )
    
    def collapse_all(self, list_id):
        """折叠所有"""
        bpy.ops.uilist.expand_or_collapse(
            list_id=list_id,
            action='COLLAPSE'
        )


def setup_uilist_manager():
    """设置 UI 列表管理器"""
    manager = UIListManager()
    
    print("UI 列表管理器已设置")
    print("可用功能:")
    print("- select_item: 选择项")
    print("- delete_item: 删除项")
    print("- move_item: 移动项")
    print("- filter_list: 过滤列表")
    
    return manager
```

### 集合列表管理器

```python
import bpy

class CollectionListManager:
    """集合列表管理器"""
    
    def __init__(self):
        self.collections = []
    
    def get_collections(self):
        """获取所有集合"""
        self.collections = [col.name for col in bpy.data.collections]
        return self.collections
    
    def select_collection(self, collection_name):
        """选择集合"""
        collection = bpy.data.collections.get(collection_name)
        if collection:
            bpy.context.view_layer.active_collection = collection
    
    def create_collection(self, name, parent=None):
        """创建集合"""
        if parent:
            parent_col = bpy.data.collections.get(parent)
            if parent_col:
                collection = bpy.data.collections.new(name)
                parent_col.children.link(collection)
                return collection
        
        return bpy.data.collections.new(name)
    
    def delete_collection(self, collection_name):
        """删除集合"""
        collection = bpy.data.collections.get(collection_name)
        if collection:
            # 移除所有对象
            for obj in collection.objects:
                for col in obj.users_collection:
                    col.objects.unlink(obj)
            
            bpy.data.collections.remove(collection)
    
    def duplicate_collection(self, collection_name, new_name):
        """复制集合"""
        collection = bpy.data.collections.get(collection_name)
        if not collection:
            return None
        
        new_collection = bpy.data.collections.new(new_name)
        
        # 复制对象
        for obj in collection.objects:
            new_obj = obj.copy()
            new_obj.data = obj.data.copy() if obj.data else None
            new_collection.objects.link(new_obj)
        
        return new_collection
    
    def move_to_collection(self, object_name, collection_name):
        """移动对象到集合"""
        obj = bpy.data.objects.get(object_name)
        collection = bpy.data.collections.get(collection_name)
        
        if obj and collection:
            # 从旧集合移除
            for col in obj.users_collection:
                col.objects.unlink(obj)
            
            # 添加到新集合
            collection.objects.link(obj)
    
    def add_to_collection(self, object_names, collection_name):
        """添加对象到集合"""
        collection = bpy.data.collections.get(collection_name)
        if not collection:
            return
        
        for obj_name in object_names:
            obj = bpy.data.objects.get(obj_name)
            if obj and obj not in collection.objects:
                collection.objects.link(obj)
    
    def remove_from_collection(self, object_name, collection_name):
        """从集合移除对象"""
        obj = bpy.data.objects.get(object_name)
        collection = bpy.data.collections.get(collection_name)
        
        if obj and collection and obj in collection.objects:
            collection.objects.unlink(obj)
    
    def list_objects_in_collection(self, collection_name):
        """列出集合中的对象"""
        collection = bpy.data.collections.get(collection_name)
        if collection:
            return [obj.name for obj in collection.objects]
        return []
    
    def find_object_collections(self, object_name):
        """查找对象所在的集合"""
        obj = bpy.data.objects.get(object_name)
        if obj:
            return [col.name for col in obj.users_collection]
        return []
    
    def export_collection(self, collection_name, filepath):
        """导出集合"""
        collection = bpy.data.collections.get(collection_name)
        if not collection:
            return None
        
        # 导出到 GLTF
        bpy.ops.wm.gltf_export(
            filepath=filepath,
            export_format='GLTF_SEPARATE',
            selected=True,
            use_selection=True
        )
        
        return filepath
    
    def import_collection(self, filepath, collection_name="Imported"):
        """导入集合"""
        # 导入 GLTF
        bpy.ops.wm.gltf_import(filepath=filepath)
        
        # 获取导入的集合
        if bpy.context.selected_objects:
            collection = bpy.data.collections.get(collection_name)
            if not collection:
                collection = bpy.data.collections.new(collection_name)
            
            for obj in bpy.context.selected_objects:
                if obj not in collection.objects:
                    collection.objects.link(obj)
        
        return bpy.data.collections.get(collection_name)


def setup_collection_manager():
    """设置集合管理器"""
    manager = CollectionListManager()
    
    manager.get_collections()
    print("集合列表管理器已设置")
    print(f"当前集合: {manager.collections}")
    
    return manager
```

### 材质列表管理器

```python
import bpy

class MaterialListManager:
    """材质列表管理器"""
    
    def __init__(self):
        self.materials = []
    
    def get_materials(self):
        """获取所有材质"""
        self.materials = [mat.name for mat in bpy.data.materials]
        return self.materials
    
    def select_material(self, material_name):
        """选择材质"""
        material = bpy.data.materials.get(material_name)
        if material:
            bpy.context.active_object.active_material = material
    
    def create_material(self, name, base_color=(0.5, 0.5, 0.5, 1)):
        """创建材质"""
        material = bpy.data.materials.new(name=name)
        material.use_nodes = True
        
        # 设置基础颜色
        nodes = material.node_tree.nodes
        principled = nodes.get('Principled BSDF')
        if principled:
            principled.inputs['Base Color'].default_value = base_color
        
        return material
    
    def duplicate_material(self, material_name, new_name):
        """复制材质"""
        material = bpy.data.materials.get(material_name)
        if not material:
            return None
        
        new_material = material.copy()
        new_material.name = new_name
        return new_material
    
    def delete_material(self, material_name):
        """删除材质"""
        material = bpy.data.materials.get(material_name)
        if material:
            bpy.data.materials.remove(material)
    
    def assign_material(self, object_name, material_name, material_index=0):
        """分配材质"""
        obj = bpy.data.objects.get(object_name)
        material = bpy.data.materials.get(material_name)
        
        if obj and material:
            # 确保材质槽存在
            while len(obj.material_slots) <= material_index:
                obj.data.materials.append(None)
            
            obj.material_slots[material_index].material = material
    
    def get_object_material(self, object_name, slot_index=0):
        """获取对象材质"""
        obj = bpy.data.objects.get(object_name)
        if obj and slot_index < len(obj.material_slots):
            return obj.material_slots[slot_index].material
        return None
    
    def create_material_override(self, material_name, object_name):
        """创建材质覆盖"""
        material = bpy.data.materials.get(material_name)
        obj = bpy.data.objects.get(object_name)
        
        if material and obj:
            override_mat = material.copy()
            override_mat.name = f"{material_name}_Override"
            return self.assign_material(object_name, override_mat.name)
    
    def link_material_to_all_objects(self, material_name):
        """链接材质到所有对象"""
        material = bpy.data.materials.get(material_name)
        if not material:
            return
        
        for obj in bpy.data.objects:
            if obj.type in ['MESH', 'CURVE', 'SURFACE', 'FONT']:
                if material not in obj.data.materials:
                    obj.data.materials.append(material)
    
    def export_materials(self, filepath, format='MTL'):
        """导出材质"""
        if format == 'MTL':
            # 导出为 MTL 格式
            content = ""
            for mat in bpy.data.materials:
                content += f"newmtl {mat.name}\n"
                nodes = mat.node_tree.nodes if mat.use_nodes else []
                principled = nodes.get('Principled BSDF')
                if principled:
                    color = principled.inputs['Base Color'].default_value
                    content += f"Kd {color[0]} {color[1]} {color[2]}\n"
                content += "\n"
            
            with open(filepath, 'w') as f:
                f.write(content)
        
        return filepath
    
    def import_materials(self, filepath):
        """导入材质"""
        # 导入 MTL 格式
        pass
    
    def list_unused_materials(self):
        """列出未使用的材质"""
        unused = []
        for mat in bpy.data.materials:
            used = False
            for obj in bpy.data.objects:
                if obj.data and hasattr(obj.data, 'materials'):
                    if mat in obj.data.materials:
                        used = True
                        break
            if not used:
                unused.append(mat.name)
        return unused
    
    def remove_unused_materials(self):
        """移除未使用的材质"""
        unused = self.list_unused_materials()
        for name in unused:
            self.delete_material(name)
        return len(unused)


def setup_material_manager():
    """设置材质管理器"""
    manager = MaterialListManager()
    
    manager.get_materials()
    print("材质列表管理器已设置")
    print(f"当前材质: {manager.materials}")
    
    return manager
```

### 数据块列表工具

```python
import bpy

class DataBlockListTool:
    """数据块列表工具"""
    
    data_types = [
        'ACTIONS', 'ARMATURES', 'BRUSHES', 'CAMERAS', 'CURVES',
        'FONTS', 'GREASEPENCIL', 'IMAGES', 'LIGHT_PROBES',
        'LIGHTS', 'LINESTYLES', 'MASKS', 'MATERIALS', 'MESHES',
        'METABALLS', 'NODETREES', 'OBJECTS', 'PAINT_CURVES',
        'PALETTES', 'PARTICLES', 'SCENES', 'SOUNDS', 'SPEAKERS',
        'TEXTURES', 'WORKSPACES', 'WORLDS'
    ]
    
    def get_data_blocks(self, data_type):
        """获取数据块"""
        data_type = data_type.upper()
        
        if data_type == 'ACTIONS':
            return bpy.data.actions
        elif data_type == 'ARMATURES':
            return bpy.data.armatures
        elif data_type == 'BRUSHES':
            return bpy.data.brushes
        elif data_type == 'CAMERAS':
            return bpy.data.cameras
        elif data_type == 'CURVES':
            return bpy.data.curves
        elif data_type == 'IMAGES':
            return bpy.data.images
        elif data_type == 'LIGHTS':
            return bpy.data.lights
        elif data_type == 'MATERIALS':
            return bpy.data.materials
        elif data_type == 'MESHES':
            return bpy.data.meshes
        elif data_type == 'OBJECTS':
            return bpy.data.objects
        elif data_type == 'SCENES':
            return bpy.data.scenes
        elif data_type == 'SOUNDS':
            return bpy.data.sounds
        elif data_type == 'TEXTURES':
            return bpy.data.textures
        elif data_type == 'WORLDS':
            return bpy.data.worlds
        
        return None
    
    def list_data_blocks(self, data_type):
        """列出数据块"""
        blocks = self.get_data_blocks(data_type)
        if blocks:
            return [block.name for block in blocks]
        return []
    
    def get_data_block_count(self, data_type):
        """获取数据块数量"""
        blocks = self.get_data_blocks(data_type)
        return len(blocks) if blocks else 0
    
    def delete_data_block(self, data_type, name):
        """删除数据块"""
        blocks = self.get_data_blocks(data_type)
        if blocks:
            block = blocks.get(name)
            if block:
                blocks.remove(block)
                return True
        return False
    
    def rename_data_block(self, data_type, old_name, new_name):
        """重命名数据块"""
        blocks = self.get_data_blocks(data_type)
        if blocks:
            block = blocks.get(old_name)
            if block:
                block.name = new_name
                return True
        return False
    
    def duplicate_data_block(self, data_type, name, new_name):
        """复制数据块"""
        blocks = self.get_data_blocks(data_type)
        if blocks:
            block = blocks.get(name)
            if block:
                new_block = block.copy()
                new_block.name = new_name
                return new_block
        return None
    
    def find_data_block_usage(self, data_type, name):
        """查找数据块使用情况"""
        blocks = self.get_data_blocks(data_type)
        if blocks:
            block = blocks.get(name)
            if block:
                users = []
                for obj in bpy.data.objects:
                    if data_type == 'MATERIALS':
                        if block in obj.data.materials:
                            users.append(obj.name)
                    elif data_type == 'MESHES':
                        if obj.data == block:
                            users.append(obj.name)
                return users
        return []
    
    def clear_unused_data_blocks(self, data_type):
        """清理未使用的数据块"""
        blocks = self.get_data_blocks(data_type)
        if not blocks:
            return 0
        
        count = 0
        for block in list(blocks):
            if block.users == 0:
                blocks.remove(block)
                count += 1
        
        return count
    
    def export_data_blocks(self, data_type, filepath):
        """导出数据块"""
        blocks = self.get_data_blocks(data_type)
        if not blocks:
            return None
        
        import json
        
        data = []
        for block in blocks:
            data.append({
                'name': block.name,
                'users': block.users
            })
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        
        return filepath
    
    def get_all_data_stats(self):
        """获取所有数据统计"""
        stats = {}
        for data_type in self.data_types:
            count = self.get_data_block_count(data_type)
            if count > 0:
                stats[data_type] = count
        return stats


def setup_datablock_tool():
    """设置数据块工具"""
    tool = DataBlockListTool()
    
    stats = tool.get_all_data_stats()
    print("数据块列表工具已设置")
    print(f"统计数据: {stats}")
    
    return tool
```
