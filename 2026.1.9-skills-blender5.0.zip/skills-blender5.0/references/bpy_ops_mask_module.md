# bpy.ops.mask 模块

遮罩操作模块，用于创建和管理图像合成遮罩。

## 概述

bpy.ops.mask 模块包含用于在遮罩编辑器中创建和编辑遮罩的运算符。遮罩用于在合成阶段隔离图像的特定区域，支持形状绘制、动画和羽化效果。

## 常用操作

### 遮罩创建

```python
import bpy

# 创建新遮罩
bpy.ops.mask.new(name='MyMask')

# 从选中图像创建遮罩
bpy.ops.mask.new(name='NewMask')

# 复制遮罩
bpy.ops.mask.duplicate(mask='MyMask')
```

### 遮罩选择

```python
# 选择遮罩
bpy.ops.mask.select(mask='MyMask', extend=False)

# 扩展选择
bpy.ops.mask.select(mask='MyMask', extend=True)

# 选择所有
bpy.ops.mask.select_all(action='SELECT')

# 取消选择
bpy.ops.mask.select_all(action='DESELECT')

# 反选
bpy.ops.mask.select_all(action='INVERT')
```

### 图层操作

```python
# 添加图层
bpy.ops.mask.layer_new(name='NewLayer')

# 删除图层
bpy.ops.mask.layer_remove()

# 重命名图层
bpy.ops.mask.layer_rename(name='RenamedLayer')

# 设置活动图层
bpy.ops.mask.layer_set_active(name='LayerName')
```

### 样条操作

```python
# 添加新样条
bpy.ops.mask.primitive_add()

# 添加椭圆
bpy.ops.mask.primitive_add(type='ELLIPSE')

# 添加矩形
bpy.ops.mask.primitive_add(type='BOX')

# 添加直线
bpy.ops.mask.primitive_add(type='LINE')

# 关闭样条
bpy.ops.mask.cyclic_toggle(direction='CYCLIC_U')

# 切换方向
bpy.ops.mask.cyclic_toggle(direction='CYCLIC_V')

# 细分样条
bpy.ops.mask.subdivide(number_cuts=1)

# 合并样条
bpy.ops.mask.merge(type='LAST')

# 分割样条
bpy.ops.mask.split()
```

### 点操作

```python
# 选择点
bpy.ops.mask.select_border(extension=False)

# 选择更多点
bpy.ops.mask.select_more()

# 选择更少点
bpy.ops.mask.select_less()

# 添加点
bpy.ops.mask.cyclic_toggle(direction='CYCLIC_U')

# 删除点
bpy.ops.mask.delete(type='POINTS')

# 滑动点
bpy.ops.mask.slide(point='EVEN')

# 滑动长度
bpy.ops.mask.slide(length='EVEN')
```

### 形状操作

```python
# 插值形状
bpy.ops.mask.shape_key_insert()

# 清除形状键
bpy.ops.mask.shape_key_clear()

# 插入形状关键帧
bpy.ops.mask.shape_key_feather_insert()

# 羽化插值
bpy.ops.mask.feather_weight_clear()

# 对称
bpy.ops.mask.symmetrize(direction='NEGATIVE_X')

# 最小化距离
bpy.ops.mask.minimum_distance()

# 转换到线条
bpy.ops.mask.convert(type='OUTLINE')

# 转换到羽化
bpy.ops.mask.convert(type='RADIUS_ADVANCED')
```

### 动画操作

```python
# 插入关键帧
bpy.ops.mask.keyframe_insert(type='ALL')

# 删除关键帧
bpy.ops.mask.keyframe_delete(type='ALL')

# 清除关键帧
bpy.ops.mask.keyframe_clear(type='ALL')

# 跳转到关键帧
bpy.ops.mask.frame_jump()

# 插入形状关键帧
bpy.ops.mask.shape_key_insert()
```

### 视口操作

```python
# 放大
bpy.ops.mask.zoom_in()

# 缩小
bpy.ops.mask.zoom_out()

# 平移
bpy.ops.mask.view_pan()

# 居中
bpy.ops.mask.view_all()

# 翻转
bpy.ops.mask.flip()

# 旋转
bpy.ops.mask.rotate(value=0.785398)
```

## 实际应用示例

### 创建程序化遮罩系统

```python
def create_procedural_mask(name='ProceduralMask'):
    """创建程序化遮罩"""
    # 创建新遮罩
    bpy.ops.mask.new(name=name)
    mask = bpy.data.masks[name]
    
    # 创建基础图层
    layer = mask.layers.new(name='BaseLayer')
    mask.layers.active = layer
    
    # 创建遮罩形状
    for i in range(8):
        angle = i * (2 * 3.14159 / 8)
        x = 0.5 + 0.3 * (i % 2)
        y = 0.5 + 0.3 * ((i + 1) % 2)
        
        bpy.ops.mask.primitive_add(type='ELLIPSE')
        active_spline = layer.splines.active
        active_spline.points[0].co = (x, y, 0)
    
    return mask
```

### 创建动画遮罩

```python
def animate_mask_expansion(mask_name, start_frame=1, end_frame=60):
    """创建遮罩扩展动画"""
    mask = bpy.data.masks[mask_name]
    layer = mask.layers.active
    
    # 设置起始帧
    bpy.context.scene.frame_set(start_frame)
    
    # 初始大小
    for spline in layer.splines:
        for point in spline.points:
            point.radius = 0.1
        spline.keyframe_insert(data_path='points')
    
    # 设置结束帧
    bpy.context.scene.frame_set(end_frame)
    
    # 最终大小
    for spline in layer.splines:
        for point in spline.points:
            point.radius = 1.0
        spline.keyframe_insert(data_path='points')
```

### 创建复杂遮罩形状

```python
def create_complex_mask_shape():
    """创建复杂遮罩形状"""
    # 创建遮罩
    bpy.ops.mask.new(name='ComplexShape')
    mask = bpy.data.masks['ComplexShape']
    layer = mask.layers.new(name='MainLayer')
    mask.layers.active = layer
    
    # 创建星形遮罩
    points = 8
    outer_radius = 0.4
    inner_radius = 0.2
    
    for i in range(points):
        angle = i * (2 * 3.14159 / points)
        
        # 外点
        x_outer = 0.5 + outer_radius * math.cos(angle)
        y_outer = 0.5 + outer_radius * math.sin(angle)
        
        # 内点
        angle_inner = angle + 3.14159 / points
        x_inner = 0.5 + inner_radius * math.cos(angle_inner)
        y_inner = 0.5 + inner_radius * math.sin(angle_inner)
        
        # 添加点
        bpy.ops.mask.primitive_add(type='FREEHAND')
        active_spline = layer.splines.active
        
        # 设置点位置
        for j, point in enumerate(active_spline.points):
            if j % 2 == 0:
                point.co = (x_outer, y_outer, 0)
            else:
                point.co = (x_inner, y_inner, 0)
```

### 创建羽化遮罩

```python
def create_feathered_mask():
    """创建羽化遮罩"""
    # 创建遮罩
    bpy.ops.mask.new(name='FeatheredMask')
    mask = bpy.data.masks['FeatheredMask']
    layer = mask.layers.new(name='FeatherLayer')
    mask.layers.active = layer
    
    # 创建圆形遮罩
    bpy.ops.mask.primitive_add(type='ELLIPSE')
    spline = layer.splines.active
    
    # 设置羽化
    for point in spline.points:
        point.radius = 0.5
        point.feather_weight = 0.5
    
    # 插入羽化关键帧
    bpy.ops.mask.shape_key_feather_insert()
```

### 创建对称遮罩

```python
def create_symmetric_mask():
    """创建对称遮罩"""
    # 创建遮罩
    bpy.ops.mask.new(name='SymmetricMask')
    mask = bpy.data.masks['SymmetricMask']
    layer = mask.layers.new(name='SymLayer')
    mask.layers.active = layer
    
    # 创建一半遮罩
    bpy.ops.mask.primitive_add(type='FREEHAND')
    spline = layer.splines.active
    
    # 添加点
    points = [(0.3, 0.2), (0.6, 0.5), (0.3, 0.8)]
    for i, (x, y) in enumerate(points):
        spline.points[i].co = (x, y, 0)
    
    # 对称遮罩
    bpy.ops.mask.symmetrize(direction='POSITIVE_X')
```

## 使用场景

- **合成工作流**：在合成阶段隔离图像区域
- **动态遮罩**：创建动画遮罩用于跟踪
- **形状编辑**：创建复杂的遮罩形状
- **羽化效果**：创建柔和边缘的遮罩
- **批处理**：自动化遮罩创建流程
- **特效制作**：用于运动模糊、景深等效果

## 注意事项

- 遮罩需要在合成节点中使用
- 动画遮罩需要关键帧支持
- 羽化效果影响合成质量
- 点数量影响性能
- 对称操作需要正确设置方向
- 遮罩坐标系是归一化的（0-1范围）
