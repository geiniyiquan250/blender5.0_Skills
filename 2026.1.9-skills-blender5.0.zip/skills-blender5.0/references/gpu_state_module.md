# gpu.state - GPU状态管理模块

gpu.state模块提供了GPU渲染状态的设置和管理功能，包括混合模式、深度测试、面剔除等渲染状态控制。

## 概述

GPU状态管理模块允许开发者控制GPU渲染管线中的各种状态设置。正确设置渲染状态对于实现正确的视觉效果和优化渲染性能至关重要。

## 核心功能

### 混合状态

```python
import gpu
from gpu.state import (
    blend_set,
    blend_get,
    BLEND_ADD,
    BLEND_ALPHA,
    BLEND_MULTIPLY,
    BLEND_SUBTRACT,
    BLEND_DISABLED
)

def enable_alpha_blending():
    """启用Alpha混合"""
    blend_set(BLEND_ALPHA)

def enable_additive_blending():
    """启用加法混合"""
    blend_set(BLEND_ADD)

def enable_multiply_blending():
    """启用乘法混合"""
    blend_set(BLEND_MULTIPLY)

def disable_blending():
    """禁用混合"""
    blend_set(BLEND_DISABLED)

def set_custom_blend(src_rgb, dst_rgb, src_alpha, dst_alpha):
    """设置自定义混合"""
    gpu.state.blend_set_func(
        src_rgb, dst_rgb, src_alpha, dst_alpha
    )

def get_current_blend_mode():
    """获取当前混合模式"""
    return blend_get()
```

### 深度状态

```python
from gpu.state import (
    depth_test_set,
    depth_mask_set,
    depth_range_set,
    depth_test_less,
    depth_test_lequal,
    depth_test_equal,
    depth_test_always
)

def enable_depth_test():
    """启用深度测试"""
    depth_test_set(True)

def disable_depth_test():
    """禁用深度测试"""
    depth_test_set(False)

def set_depth_test_func(func='LESS'):
    """设置深度测试函数"""
    if func == 'LESS':
        depth_test_less()
    elif func == 'LEQUAL':
        depth_test_lequal()
    elif func == 'EQUAL':
        depth_test_equal()
    elif func == 'ALWAYS':
        depth_test_always()

def enable_depth_write():
    """启用深度写入"""
    depth_mask_set(True)

def disable_depth_write():
    """禁用深度写入"""
    depth_mask_set(False)

def set_depth_range(near, far):
    """设置深度范围"""
    depth_range_set(near, far)
```

### 模板状态

```python
from gpu.state import (
    stencil_test_set,
    stencil_mask_set,
    stencil_func_set,
    stencil_op_set
)

def enable_stencil_test():
    """启用模板测试"""
    stencil_test_set(True)

def disable_stencil_test():
    """禁用模板测试"""
    stencil_test_set(False)

def set_stencil_mask(mask):
    """设置模板掩码"""
    stencil_mask_set(mask)

def set_stencil_func(func, ref, mask):
    """设置模板函数"""
    stencil_func_set(func, ref, mask)

def set_stencil_op(sfail, dpfail, dppass):
    """设置模板操作"""
    stencil_op_set(sfail, dpfail, dppass)
```

## 实用函数

### 面剔除

```python
from gpu.state import (
    cull_face_set,
    cull_face_front,
    cull_face_back,
    cull_face_front_and_back
)

def enable_culling():
    """启用面剔除"""
    cull_face_set(True)

def disable_culling():
    """禁用面剔除"""
    cull_face_set(False)

def set_cull_face(mode='BACK'):
    """设置剔除面"""
    if mode == 'FRONT':
        cull_face_front()
    elif mode == 'BACK':
        cull_face_back()
    elif mode == 'BOTH':
        cull_face_front_and_back()
```

### 视口设置

```python
from gpu.state import viewport_set, viewport_get

def set_viewport(x, y, width, height):
    """设置视口"""
    viewport_set(x, y, width, height)

def get_viewport():
    """获取当前视口"""
    return viewport_get()

def set_scissor(x, y, width, height):
    """设置裁剪区域"""
    gpu.state.scissor_set(x, y, width, height)

def get_scissor():
    """获取当前裁剪区域"""
    return gpu.state.scissor_get()

def enable_scissor_test():
    """启用裁剪测试"""
    gpu.state.scissor_test_set(True)
```

### 着色器状态

```python
from gpu.state import (
    polygon_mode_set,
    POLYGON_MODE_FILL,
    POLYGON_MODE_LINE,
    POLYGON_MODE_POINT
)

def set_polygon_mode(mode='FILL'):
    """设置多边形模式"""
    if mode == 'FILL':
        polygon_mode_set(POLYGON_MODE_FILL)
    elif mode == 'LINE':
        polygon_mode_set(POLYGON_MODE_LINE)
    elif mode == 'POINT':
        polygon_mode_set(POLYGON_MODE_POINT)

def enable_program_point_size():
    """启用程序点大小"""
    gpu.state.program_point_size_set(True)
```

### 缓冲状态

```python
from gpu.state import (
    color_mask_set,
    clear_color_set,
    clear_depth_stencil_set
)

def set_color_mask(r, g, b, a):
    """设置颜色掩码"""
    color_mask_set(r, g, b, a)

def set_clear_color(r, g, b, a):
    """设置清除颜色"""
    clear_color_set(r, g, b, a)

def set_clear_depth(depth):
    """设置清除深度"""
    clear_depth_stencil_set(depth=depth)

def set_clear_stencil(stencil):
    """设置清除模板"""
    clear_depth_stencil_set(stencil=stencil)
```

## 状态保存恢复

```python
def save_state():
    """保存当前状态"""
    state = {
        'blend': blend_get(),
        'viewport': viewport_get(),
        'depth_test': gpu.state.depth_test_get(),
        'cull_face': gpu.state.cull_face_get()
    }
    return state

def restore_state(state):
    """恢复保存的状态"""
    blend_set(state['blend'])
    viewport_set(*state['viewport'])
    if state['depth_test']:
        enable_depth_test()
    else:
        disable_depth_test()

class StateGuard:
    """状态守卫"""
    def __init__(self):
        self.saved_state = None
    
    def __enter__(self):
        self.saved_state = save_state()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        restore_state(self.saved_state)
```

## 常见问题排查

### 渲染结果异常

状态冲突：
- 检查混合模式是否正确
- 确认深度测试启用状态
- 验证面剔除设置

### 性能问题

状态切换过多：
- 减少状态切换频率
- 批处理相似状态的操作
- 使用状态排序

### 状态未生效

状态应用时机：
- 确保在绘制前设置状态
- 检查是否被其他代码覆盖
- 确认上下文正确
