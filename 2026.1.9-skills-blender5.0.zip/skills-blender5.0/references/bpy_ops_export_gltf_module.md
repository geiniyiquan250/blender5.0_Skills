# bpy.ops.export_gltf - GLTF导出操作模块

Blender GLTF格式导出操作符，用于将场景导出为glTF/glb格式。

## 概述

`bpy.ops.export_gltf` 模块提供用于将Blender场景导出为glTF 2.0标准格式的功能，支持glb、gltf和glb嵌入式格式。

## 核心功能

### 基础导出

```python
import bpy

# 导出为GLB
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_format='GLB',
    export_selected=True,
    use_selection=True
)

# 导出为glTF
bpy.ops.export_gltf(
    filepath='//model.gltf',
    export_format='GLTF_SEPARATE',
    export_selected=False
)

# 导出嵌入式glTF
bpy.ops.export_gltf(
    filepath='//model.gltf',
    export_format='GLTF_EMBEDDED',
    export_selected=True
)
```

### 导出选项

```python
# 导出所有内容
bpy.ops.export_gltf(
    filepath='//scene.glb',
    export_format='GLB',
    export_selected=False
)

# 只导出选中对象
bpy.ops.export_gltf(
    filepath='//selected.glb',
    export_format='GLB',
    export_selected=True,
    use_selection=True
)

# 导出活动集合
bpy.ops.export_gltf(
    filepath='//collection.glb',
    export_format='GLB',
    export_active_collection=True
)

# 应用修改器
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_apply=True
)

# 应用变换
bpy.ops.export_gltf(
    filepath='//model.glb',
    apply_transforms=True
)
```

### 几何体导出选项

```python
# 导出UV
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_uv=True
)

# 导出法线
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_normals=True
)

# 导出变形目标
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_morph=True
)

# 导出网格数据
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_mesh=True
)

# 导出点云
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_pointcloud=True
)

# 导出顶点颜色
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_colors=True
)

# 三角化
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_triangulated_mesh=True
)
```

### 动画导出选项

```python
# 导出动画
bpy.ops.export_gltf(
    filepath='//animation.glb',
    export_animations=True
)

# 导出NLA轨道
bpy.ops.export_gltf(
    filepath='//animation.glb',
    export_nla_strips=True
)

# 导出所有动作
bpy.ops.export_gltf(
    filepath='//animations.glb',
    export_anim_action_all=True
)

# 导出活动动作
bpy.ops.export_gltf(
    filepath='//animation.glb',
    export_anim_action='ACTIVE'
)

# 导出骨骼
bpy.ops.export_gltf(
    filepath='//armature.glb',
    export_skins=True
)

# 导出所有影响
bpy.ops.export_gltf(
    filepath='//armature.glb',
    export_all_influences=True
)

# 骨骼仅变形
bpy.ops.export_gltf(
    filepath='//armature.glb',
    deform_bones_only=True
)

# 导出相机
bpy.ops.export_gltf(
    filepath='//scene.glb',
    export_cameras=True
)

# 导出灯光
bpy.ops.export_gltf(
    filepath='//scene.glb',
    export_lights=True
)
```

### PBR材质导出

```python
# 导出PBR材质
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_pbr_material=True
)

# 导出材质名称
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_material_names=True
)

# 导出纹理
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_textures=True
)
```

### 自定义属性导出

```python
# 导出自定义属性
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_custom_properties=True
)

# 导出Y轴向上
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_yup=True
)
```

## 实用函数

```python
def export_selected_for_web(filepath='//model.glb'):
    """导出选中对象用于Web"""
    bpy.ops.export_gltf(
        filepath=filepath,
        export_format='GLB',
        export_selected=True,
        use_selection=True,
        export_apply=True,
        export_uv=True,
        export_normals=True,
        export_morph=True,
        export_animations=True,
        export_skins=True,
        export_cameras=True,
        export_lights=True,
        export_pbr_material=True,
        export_textures=True
    )

def export_for_AR(filepath='//ar_model.glb'):
    """导出AR模型"""
    bpy.ops.export_gltf(
        filepath=filepath,
        export_format='GLB',
        export_selected=True,
        use_selection=True,
        export_apply=True,
        export_triangulated_mesh=True,
        export_animations=True,
        export_skins=True,
        export_morph=True
    )

def export_baked_textures(filepath='//baked.glb'):
    """导出烘焙纹理"""
    bpy.ops.export_gltf(
        filepath=filepath,
        export_format='GLB',
        export_selected=True,
        use_selection=True,
        export_apply=True,
        export_pbr_material=True,
        export_textures=True,
        export_uv=True
    )

def export_gltf_with_custom_props(filepath='//custom.glb'):
    """导出带自定义属性"""
    bpy.ops.export_gltf(
        filepath=filepath,
        export_format='GLB',
        export_selected=True,
        use_selection=True,
        export_custom_properties=True
    )

def batch_export_objects(objects, output_dir):
    """批量导出对象"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for obj in objects:
        if obj.type == 'MESH':
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            filepath = os.path.join(output_dir, f'{obj.name}.glb')
            bpy.ops.export_gltf(
                filepath=filepath,
                export_format='GLB',
                export_selected=True,
                use_selection=True
            )
```

## 常见问题排查

### 导出后模型丢失
```python
# 检查选中对象
selected = [obj for obj in bpy.context.selected_objects]
print(f"选中: {len(selected)}")

# 检查对象类型
print(f"对象类型: {[obj.type for obj in selected]}")

# 确保对象可见
for obj in selected:
    print(f"{obj.name}: 隐藏={obj.hide_viewport}")

# 检查原点位置
obj = bpy.context.active_object
print(f"原点: {obj.location}")
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 检查NLA轨道
for track in obj.animation_data.nla_tracks:
    print(f"轨道: {track.name}")

# 确保导出动画选项
bpy.ops.export_gltf(
    filepath='//anim.glb',
    export_animations=True,
    export_anim_action_all=True
)
```

### 材质问题
```python
# 检查材质
obj = bpy.context.active_object
print(f"材质: {obj.data.materials if obj.data else 'N/A'}")

# 检查节点材质
if obj.data.materials:
    mat = obj.data.materials[0]
    print(f"使用节点: {mat.use_nodes}")

# 烘焙材质
bpy.ops.export_gltf(
    filepath='//model.glb',
    export_pbr_material=True,
    export_textures=True
)
```
