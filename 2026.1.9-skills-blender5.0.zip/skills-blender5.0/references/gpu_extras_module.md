# gpu_extras GPU扩展模块

提供 GPU 编程的实用工具函数，包括批次创建和常用绘图预设。

## 子模块

### gpu_extras.batch 批次模块

用于创建与着色器兼容的 GPU 批次对象。

#### batch_for_shader

```python
import gpu
from gpu_extras import batch

shader = gpu.shader.from_builtin('UNIFORM_COLOR')
batch = batch.batch_for_shader(
    shader,
    'TRIS',
    {"pos": [(0, 0), (1, 0), (1, 1), (0, 1)], "uv": [(0, 0), (1, 0), (1, 1), (0, 1)]},
    indices=[(0, 1, 2), (0, 2, 3)]
)
batch.draw(shader)
```

创建与指定着色器兼容的批次对象。

**参数：**

- `shader` (GPUShader): 要创建兼容批次的着色器。
- `type` (str): 图元类型，'POINTS'、'LINES'、'TRIS' 或 'LINES_ADJ'。
- `content` (dict): 将着色器属性名映射到顶点缓冲区数据的字典。
- `indices` (Buffer | Sequence[int]): 可选的索引缓冲区数据。

**返回：**

- GPUBatch: 配置好的兼容批次对象。

---

### gpu_extras.presets 预设模块

提供常用的 2D 绘图预设函数。

#### draw_circle_2d

```python
from gpu_extras import presets

presets.draw_circle_2d(
    position=(100, 100),
    color=(1.0, 0.0, 0.0, 1.0),
    radius=50.0,
    segments=32
)
```

绘制二维圆形。

**参数：**

- `position` (Sequence[float]): 圆形的 2D 绘制位置。
- `color` (Sequence[float]): 圆形的颜色 (RGBA)。
  要使用透明度，混合模式需设置为 ALPHA。
- `radius` (float): 圆形的半径。
- `segments` (int | None): 绘制圆形使用的线段数。
  更高的值效果更好但绘制时间更长。
  如果为 None 或未指定，将自动计算值。

#### draw_texture_2d

```python
import gpu
from gpu_extras import presets

texture = gpu.texture.from_image(bpy.data.images[0])
presets.draw_texture_2d(
    texture=texture,
    position=(0, 0),
    width=256,
    height=256,
    is_scene_linear_with_rec709_srgb_target=True
)
```

绘制二维纹理。

**参数：**

- `texture` (GPUTexture): 要绘制的 GPUTexture。
  例如使用 gpu.texture.from_image(image) 从 bpy.types.Image 获取纹理。
- `position` (2D Vector): 左下角的位置。
- `width` (float): 绘制时的宽度（不一定是纹理的原始宽度）。
- `height` (float): 绘制时的高度。
- `is_scene_linear_with_rec709_srgb_target` (bool):
  如果 texture 存储在线性颜色空间且目标帧缓冲区使用 Rec.709 sRGB 颜色空间则为 True。
  这在 'PRE_VIEW'、'POST_VIEW' 或 'POST_PIXEL' 绘制处理程序中绘制从 bpy.types.Image 获取的纹理时成立。
  否则假设颜色空间与帧缓冲区的颜色空间匹配。

---

## 使用示例

### 基本批次绘制

```python
import gpu
from gpu_extras import batch

# 创建顶点数据
vertices = [
    (0.0, 0.0, 0.0),  # 顶点 0
    (1.0, 0.0, 0.0),  # 顶点 1
    (1.0, 1.0, 0.0),  # 顶点 2
    (0.0, 1.0, 0.0),  # 顶点 3
]

colors = [
    (1.0, 0.0, 0.0, 1.0),  # 红色
    (0.0, 1.0, 0.0, 1.0),  # 绿色
    (0.0, 0.0, 1.0, 1.0),  # 蓝色
    (1.0, 1.0, 0.0, 1.0),  # 黄色
]

indices = [
    (0, 1, 2),  # 第一个三角形
    (0, 2, 3),  # 第二个三角形
]

# 创建着色器
shader = gpu.shader.from_builtin('UNIFORM_COLOR')

# 创建批次
batch_obj = batch.batch_for_shader(
    shader,
    'TRIS',
    {"pos": vertices, "color": colors},
    indices=indices
)

# 绘制批次
batch_obj.draw(shader)
```

### 绘制圆形

```python
from gpu_extras import presets
import gpu

# 设置混合模式以支持透明度
gpu.state.blend_set('ALPHA')

# 绘制带透明度的圆形
presets.draw_circle_2d(
    position=(200, 200),
    color=(0.0, 0.5, 1.0, 0.8),  # 半透明蓝色
    radius=75.0,
    segments=64
)
```

### 绘制纹理

```python
import bpy
import gpu
from gpu_extras import presets

# 获取图像
image = bpy.data.images.get("Texture")
if image:
    # 创建纹理
    texture = gpu.texture.from_image(image)
    
    # 设置纹理.draw_texture_2绘制
    presetsd(
        texture=texture,
        position=(50, 50),
        width=200,
        height=200,
        is_scene_linear_with_rec709_srgb_target=True
    )
```

### 完整自定义绘制处理程序

```python
import bpy
import gpu
from gpu_extras import batch, presets

draw_handler = None

def draw_callback():
    global draw_handler
    
    # 绘制背景矩形
    presets.draw_texture_2d(
        texture=gpu.texture.from_blank(100, 100),
        position=(10, 10),
        width=100,
        height=100,
        is_scene_linear_with_rec709_srgb_target=True
    )
    
    # 绘制装饰圆
    gpu.state.blend_set('ALPHA')
    presets.draw_circle_2d(
        position=(60, 60),
        color=(1.0, 1.0, 1.0, 0.5),
        radius=30.0
    )

# 注册绘制处理程序
draw_handler = bpy.types.SpaceView3D.draw_handler_add(
    draw_callback,
    (),
    'WINDOW',
    'POST_PIXEL'
)
```

---

## 注意事项

1. **着色器兼容性**: batch_for_shader 函数自动计算与着色器兼容的格式，确保顶点缓冲区属性与着色器输入匹配。

2. **颜色空间**: draw_texture_2d 的 is_scene_linear_with_rec709_srgb_target 参数对于正确显示从 Blender 图像读取的纹理非常重要。

3. **混合模式**: 使用 draw_circle_2d 绘制半透明圆形时，需要先设置 gpu.state.blend_set('ALPHA')。

4. **性能考虑**: draw_circle_2d 的 segments 参数影响性能，较高的值会产生更平滑的圆形但需要更多计算。

5. **绘制顺序**: 在 3D 视图中使用这些函数时，注意绘制顺序和深度测试设置。