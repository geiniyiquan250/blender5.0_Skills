# bpy.ops.ptcache 模块

物理缓存操作模块，用于管理物理模拟的缓存数据。

## 概述

bpy.ops.ptcache 模块包含用于操作物理模拟缓存的运算符。物理缓存存储物理模拟的计算结果，用于提高回放性能和避免重复计算。

## 常用操作

### 缓存管理

```python
import bpy

# 添加缓存
bpy.ops.ptcache.add()

# 删除缓存
bpy.ops.ptcache.remove()

# 清除缓存
bpy.ops.ptcache.free()

# 刷新缓存
bpy.ops.ptcache.refresh()
```

### 缓存操作

```python
# 重载缓存
bpy.ops.ptcache.reload()

# 读取缓存
bpy.ops.ptcache.read_cache(frame_start=1, frame_end=250)

# 写入缓存
bpy.ops.ptcache.write_cache(frame_start=1, frame_end=250)

# 更新缓存
bpy.ops.ptcache.update_cache()
```

### 烘焙操作

```python
# 烘焙所有
bpy.ops.ptcache.bake_all()

# 烘焙选定
bpy.ops.ptcache.bake()

# 烘焙选择
bpy.ops.ptcache.bake_selected()

# 撤销烘焙
bpy.ops.ptcache.undo_bake()

# 重做烘焙
bpy.ops.ptcache.redo_bake()
```

### 物理类型

```python
# 烘焙粒子
bpy.ops.ptcache.bake(type='PARTICLES')

# 烘焙布料
bpy.ops.ptcache.bake(type='CLOTH')

# 烘焙流体
bpy.ops.ptcache.bake(type='FLUID')

# 烘焙刚体
bpy.ops.ptcache.bake(type='RIGID_BODY')

# 烘焙软体
bpy.ops.ptcache.bake(type='SOFT_BODY')

# 烘焙烟雾
bpy.ops.ptcache.bake(type='SMOKE')
```

## 实际应用示例

### 批量烘焙所有物理

```python
def bake_all_physics(frame_start=1, frame_end=250):
    """烘焙所有物理效果"""
    # 遍历所有有物理效果的物体
    for obj in bpy.context.scene.objects:
        if has_physics(obj):
            # 选中物体
            bpy.context.view_layer.objects.active = obj
            obj.select_set(True)
            
            # 烘焙
            bpy.ops.ptcache.bake(
                frame_start=frame_start,
                frame_end=frame_end,
                bake_type='PHYSICS'
            )
            
            # 取消选择
            obj.select_set(False)
    
    print("所有物理烘焙完成")

def has_physics(obj):
    """检查物体是否有物理效果"""
    # 检查各种物理修改器
    for mod in obj.modifiers:
        if mod.type in ['CLOTH', 'SOFT_BODY', 'FLUID', 'SMOKE', 'RIGID_BODY']:
            return True
    return obj.rigid_body is not None
```

### 烘焙粒子系统

```python
def bake_particle_systems(frame_start=1, frame_end=250):
    """烘焙所有粒子系统"""
    # 获取当前帧
    current_frame = bpy.context.scene.frame_current
    
    # 遍历所有粒子系统
    for obj in bpy.context.scene.objects:
        for ptcache in obj.particle_systems:
            # 确保粒子系统有缓存
            if ptcache.point_cache:
                # 设置帧范围
                ptcache.point_cache.frame_start = frame_start
                ptcache.point_cache.frame_end = frame_end
                
                # 选中物体
                bpy.context.view_layer.objects.active = obj
                
                # 烘焙
                bpy.ops.ptcache.bake(type='PARTICLES')
    
    # 恢复帧位置
    bpy.context.scene.frame_set(current_frame)
```

### 烘焙布料模拟

```python
def bake_cloth_simulation(obj, frame_start=1, frame_end=250):
    """烘焙布料模拟"""
    # 确保选中物体
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    
    # 设置时间范围
    bpy.context.scene.frame_start = frame_start
    bpy.context.scene.frame_end = frame_end
    
    # 清除旧缓存
    bpy.ops.ptcache.free()
    
    # 重新计算并烘焙
    bpy.ops.ptcache.bake(type='CLOTH')
    
    print(f"布料模拟烘焙完成: {obj.name}")
    
    # 取消选择
    obj.select_set(False)
```

### 烘焙流体模拟

```python
def bake_fluid_simulation(obj, frame_start=1, frame_end=250):
    """烘焙流体模拟"""
    # 确保选中物体
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    
    # 设置帧范围
    bpy.context.scene.frame_start = frame_start
    bpy.context.scene.frame_end = frame_end
    
    # 清除旧缓存
    bpy.ops.ptcache.free()
    
    # 烘焙流体
    bpy.ops.ptcache.bake(type='FLUID')
    
    print(f"流体模拟烘焙完成: {obj.name}")
    
    # 取消选择
    obj.select_set(False)
```

### 烘焙刚体模拟

```python
def bake_rigidbody_simulation(objects, frame_start=1, frame_end=250):
    """烘焙刚体模拟"""
    # 确保所有物体被选中
    for obj in objects:
        obj.select_set(True)
    
    bpy.context.view_layer.objects.active = objects[0]
    
    # 设置帧范围
    bpy.context.scene.frame_start = frame_start
    bpy.context.scene.frame_end = frame_end
    
    # 清除旧缓存
    bpy.ops.ptcache.free()
    
    # 烘焙刚体
    bpy.ops.ptcache.bake(type='RIGID_BODY')
    
    print(f"刚体模拟烘焙完成: {len(objects)} 个物体")
    
    # 取消选择
    for obj in objects:
        obj.select_set(False)
```

### 创建渐进式烘焙

```python
def progressive_bake(obj, chunk_size=50):
    """分块渐进式烘焙"""
    frame_start = bpy.context.scene.frame_start
    frame_end = bpy.context.scene.frame_end
    
    current_frame = frame_start
    
    while current_frame <= frame_end:
        chunk_end = min(current_frame + chunk_size - 1, frame_end)
        
        # 烘焙当前块
        bpy.ops.ptcache.bake(
            frame_start=current_frame,
            frame_end=chunk_end
        )
        
        print(f"烘焙帧范围: {current_frame} - {chunk_end}")
        
        current_frame = chunk_end + 1
```

### 验证缓存完整性

```python
def verify_cache_integrity(ptcache):
    """验证缓存完整性"""
    if not ptcache:
        return False
    
    # 检查帧范围
    expected_frames = ptcache.frame_end - ptcache.frame_start + 1
    
    # 检查缓存文件
    cache_path = bpy.path.abspath(ptcache.filepath)
    
    if not os.path.exists(cache_path):
        print(f"缓存文件不存在: {cache_path}")
        return False
    
    # 验证文件大小
    file_size = os.path.getsize(cache_path)
    
    if file_size == 0:
        print("缓存文件为空")
        return False
    
    print(f"缓存验证通过: {file_size} 字节, 帧范围: {ptcache.frame_start} - {ptcache.frame_end}")
    return True
```

### 清理无效缓存

```python
def cleanup_invalid_caches():
    """清理无效缓存"""
    # 获取所有可能的缓存位置
    cache_dirs = []
    
    for obj in bpy.context.scene.objects:
        if obj.point_caches:
            for ptcache in obj.point_caches:
                if ptcache.filepath:
                    cache_dir = bpy.path.abspath(os.path.dirname(ptcache.filepath))
                    if cache_dir not in cache_dirs:
                        cache_dirs.append(cache_dir)
    
    # 检查并清理空目录
    for cache_dir in cache_dirs:
        if os.path.exists(cache_dir):
            # 检查目录是否为空
            if not os.listdir(cache_dir):
                os.rmdir(cache_dir)
                print(f"删除空缓存目录: {cache_dir}")
```

### 导出缓存信息

```python
def export_cache_info(filepath):
    """导出缓存信息"""
    info = []
    info.append("=== 物理缓存信息 ===")
    
    for obj in bpy.context.scene.objects:
        for ptcache in obj.point_caches:
            info.append(f"\n物体: {obj.name}")
            info.append(f"  缓存名称: {ptcache.name}")
            info.append(f"  帧范围: {ptcache.frame_start} - {ptcache.frame_end}")
            info.append(f"  缓存路径: {ptcache.filepath}")
            info.append(f"  缓存类型: {ptcache.type}")
            info.append(f"  用户数: {ptcache.users}")
            
            # 检查缓存文件
            cache_path = bpy.path.abspath(ptcache.filepath)
            if os.path.exists(cache_path):
                info.append(f"  文件大小: {os.path.getsize(cache_path)} 字节")
            else:
                info.append("  状态: 文件不存在")
    
    # 写入文件
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('\n'.join(info))
    
    print(f"缓存信息已导出到: {filepath}")
```

### 重新计算关键帧缓存

```python
def recompute_keyframe_cache(obj, keyframes):
    """重新计算关键帧缓存"""
    # 获取当前帧
    current_frame = bpy.context.scene.frame_current
    
    # 删除旧的关键帧
    for frame in keyframes:
        bpy.context.scene.frame_set(frame)
        for ptcache in obj.point_caches:
            ptcache.clear_keyed(frame)
    
    # 重新计算
    for frame in keyframes:
        bpy.context.scene.frame_set(frame)
        
        # 设置物体状态
        set_object_state(obj, frame)
        
        # 插入关键帧
        obj.keyframe_insert(data_path='location', frame=frame)
        obj.keyframe_insert(data_path='rotation_euler', frame=frame)
    
    # 恢复帧位置
    bpy.context.scene.frame_set(current_frame)
```

### 创建缓存备份

```python
def backup_cache(ptcache, backup_dir):
    """备份缓存"""
    if not ptcache.filepath:
        print("没有缓存文件可备份")
        return
    
    source_path = bpy.path.abspath(ptcache.filepath)
    
    if not os.path.exists(source_path):
        print(f"源缓存文件不存在: {source_path}")
        return
    
    # 创建备份目录
    os.makedirs(backup_dir, exist_ok=True)
    
    # 生成备份文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(backup_dir, f"backup_{timestamp}.bphys")
    
    # 复制文件
    shutil.copy2(source_path, backup_path)
    
    print(f"缓存已备份到: {backup_path}")
```

## 使用场景

- **物理模拟优化**：缓存物理模拟结果
- **动画回放**：加速物理动画的预览
- **渲染准备**：为最终渲染准备缓存
- **数据管理**：管理物理模拟数据
- **性能优化**：减少实时计算开销
- **批量处理**：批量烘焙多个物理效果
- **数据验证**：验证缓存完整性
- **缓存备份**：备份重要模拟数据
- **跨平台共享**：共享模拟结果
- **版本控制**：管理不同版本的模拟

## 注意事项

- 大缓存文件可能占用大量磁盘空间
- 烘焙过程中不要修改场景
- 缓存与文件路径相关，移动文件后需要重新烘焙
- 不同物理类型需要不同的烘焙方法
- 定期清理无效缓存节省空间
- 关键帧缓存需要正确设置关键帧
- 渐进式烘焙适合大型模拟
- 验证缓存完整性防止渲染问题
- 备份重要缓存防止数据丢失
- 共享文件时注意相对路径设置
