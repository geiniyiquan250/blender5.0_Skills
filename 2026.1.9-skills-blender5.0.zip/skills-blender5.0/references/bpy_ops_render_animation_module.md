# bpy.ops.render - 动画渲染操作模块

Blender动画渲染操作符，用于渲染动画序列和视频输出。

## 概述

`bpy.ops.render.render` 模块提供用于在Blender中渲染动画的功能，支持序列帧渲染、视频编码输出和批量渲染操作。

## 核心功能

### 基础渲染

```python
import bpy

# 渲染动画
bpy.ops.render.render(
    animation=True,
    write_still=False,
    use_viewport=False,
    endframe=None,
    frame=None,
    filepath=None
)

# 渲染当前帧
bpy.ops.render.render(
    animation=False,
    write_still=True,
    use_viewport=False
)

# 渲染到视图
bpy.ops.render.render(
    animation=False,
    write_still=False,
    use_viewport=True
)
```

### 渲染设置

```python
# 渲染动画
bpy.ops.render.render(
    animation=True
)

# 渲染静帧
bpy.ops.render.render(
    animation=False,
    write_still=True
)

# 使用视口渲染
bpy.ops.render.render(
    animation=False,
    write_still=False,
    use_viewport=True
)
```

### 帧控制

```python
# 渲染指定帧
bpy.ops.render.render(
    animation=False,
    frame=50
)

# 渲染结束帧
bpy.ops.render.render(
    animation=True,
    endframe=100
)
```

### 输出路径

```python
# 设置输出路径渲染
bpy.ops.render.render(
    animation=True,
    filepath='//render/animation_'
)
```

### 视口渲染选项

```python
# 视口渲染设置
bpy.context.scene.render.use_lock_interface = False
bpy.context.scene.render.use_placeholder = False

# 渲染所有区域
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        space = area.spaces.active
        space.shading.type = 'RENDERED'
```

## 实用函数

```python
def render_animation(output_path='//render/'):
    """渲染动画"""
    bpy.context.scene.render.filepath = output_path
    bpy.ops.render.render(animation=True)

def render_current_frame():
    """渲染当前帧"""
    bpy.ops.render.render(animation=False, write_still=True)

def render_to_view():
    """渲染到视图"""
    bpy.ops.render.render(animation=False, write_still=False, use_viewport=True)

def render_frame_range(start, end, output_path='//render/'):
    """渲染帧范围"""
    bpy.context.scene.frame_start = start
    bpy.context.scene.frame_end = end
    bpy.context.scene.render.filepath = output_path
    bpy.ops.render.render(animation=True)

def render_with_settings(
    output_path='//render/',
    engine='CYCLES',
    samples=128,
    resolution=(1920, 1080),
    start_frame=1,
    end_frame=250
):
    """使用指定设置渲染"""
    scene = bpy.context.scene
    scene.render.engine = engine
    scene.render.resolution_x = resolution[0]
    scene.render.resolution_y = resolution[1]
    scene.render.filepath = output_path
    scene.frame_start = start_frame
    scene.frame_end = end_frame
    
    if engine == 'CYCLES':
        scene.cycles.samples = samples
    
    bpy.ops.render.render(animation=True)

def batch_render_scenes(scenes, output_dir='//render/'):
    """批量渲染场景"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    original_scene = bpy.context.scene.name
    
    for scene_name in scenes:
        bpy.context.window.scene = bpy.data.scenes[scene_name]
        scene = bpy.context.scene
        
        output_path = os.path.join(output_dir, f'{scene_name}_')
        scene.render.filepath = output_path
        
        bpy.ops.render.render(animation=True)
    
    # 恢复原始场景
    bpy.context.window.scene = bpy.data.scenes[original_scene]

def render_eevee_quick(output_path='//render/'):
    """快速EEVEE渲染"""
    scene = bpy.context.scene
    scene.render.engine = 'BLENDER_EEVEE'
    scene.render.filepath = output_path
    scene.eevee.taa_render_samples = 32
    bpy.ops.render.render(animation=True)

def render_cycles_high_quality(output_path='//render/', samples=256):
    """高质量Cycles渲染"""
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.render.filepath = output_path
    scene.cycles.samples = samples
    scene.cycles.adaptive_threshold = 0.01
    scene.cycles.time_limit = 300  # 5分钟限制
    bpy.ops.render.render(animation=True)
```

## 常见问题排查

### 渲染不工作
```python
# 检查渲染设置
print(f"渲染引擎: {bpy.context.scene.render.engine}")
print(f"分辨率: {bpy.context.scene.render.resolution_x} x {bpy.context.scene.render.resolution_y}")

# 检查输出路径
print(f"输出路径: {bpy.context.scene.render.filepath}")

# 检查帧范围
print(f"帧范围: {bpy.context.scene.frame_start} - {bpy.context.scene.frame_end}")

# 确保输出目录存在
import os
output_dir = os.path.dirname(bpy.context.scene.render.filepath)
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
```

### 渲染空白
```python
# 检查渲染层
print(f"活跃场景: {bpy.context.scene.name}")

# 检查对象可见性
for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':
        print(f"{obj.name}: 隐藏={obj.hide_render}, 可见={obj.visible_get()}")

# 确保对象可见
for obj in bpy.context.scene.objects:
    obj.hide_render = False

# 检查相机
print(f"活动相机: {bpy.context.scene.camera}")

# 设置相机
if bpy.context.scene.camera is None:
    for obj in bpy.context.scene.objects:
        if obj.type == 'CAMERA':
            bpy.context.scene.camera = obj
            break
```

### 动画问题
```python
# 检查动画数据
print(f"帧数: {bpy.context.scene.frame_end - bpy.context.scene.frame_start + 1}")

# 检查帧速率
print(f"帧速率: {bpy.context.scene.render.fps}")

# 检查帧步长
print(f"帧步长: {bpy.context.scene.render.frame_step}")

# 设置正确的帧范围
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = 250
```

### 性能问题
```python
# 检查采样数
if bpy.context.scene.render.engine == 'CYCLES':
    print(f"采样数: {bpy.context.scene.cycles.samples}")

# 减少采样数
bpy.context.scene.cycles.samples = 64

# 启用降噪
bpy.context.scene.cycles.use_denoising = True

# 使用GPU渲染
bpy.context.scene.cycles.device = 'GPU'

# 检查显存
print(f"显存: {bpy.context.preferences.addons['cycles'].preferences.get_compute_device_type()}")
```

### 输出格式问题
```python
# 检查输出格式
print(f"输出格式: {bpy.context.scene.render.image_settings.file_format}")

# 设置输出格式
bpy.context.scene.render.image_settings.file_format = 'FFMPEG'
bpy.context.scene.render.ffmpeg.format = 'MPEG4'
bpy.context.scene.render.ffmpeg.codec = 'H264'

# 检查视频编码
print(f"视频编码: {bpy.context.scene.render.ffmpeg.codec}")

# 设置质量
bpy.context.scene.render.ffmpeg.video_bitrate = 8000
```

### 渲染时间过长
```python
# 检查渲染时间
import time
start_time = time.time()
bpy.ops.render.render(animation=True)
end_time = time.time()
print(f"渲染时间: {end_time - start_time} 秒")

# 减少分辨率
bpy.context.scene.render.resolution_percentage = 50

# 减少采样数
bpy.context.scene.cycles.samples = 32

# 跳过帧
bpy.context.scene.render.frame_step = 2
```
