# bpy.ops.view2d - 二维视图操作模块

Blender二维视图操作符，用于操作图形编辑器、时间线等二维视图区域的导航和显示。

## 概述

`bpy.ops.view2d` 模块提供用于在Blender的各种二维视图区域中进行平移、缩放和其他视图操作的功能。

## 核心功能

### 视图平移

```python
import bpy

# 向左平移
bpy.ops.view2d.pan(
    dx=-50,
    dy=0
)

# 向右平移
bpy.ops.view2d.pan(
    dx=50,
    dy=0
)

# 向上平移
bpy.ops.view2d.pan(
    dx=0,
    dy=50
)

# 向下平移
bpy.ops.view2d.pan(
    dx=0,
    dy=-50
)

# 平移到中心
bpy.ops.view2d.pan(
    dx='CENTER'
)
```

### 视图缩放

```python
# 放大
bpy.ops.view2d.zoom(
    factor=1.1
)

# 缩小
bpy.ops.view2d.zoom(
    factor=0.9
)

# 放大到鼠标位置
bpy.ops.view2d.zoom(
    factor=1.1,
    mx=200,
    my=300
)

# 缩小到鼠标位置
bpy.ops.view2d.zoom(
    factor=0.9,
    mx=200,
    my=300
)

# 放大到区域
bpy.ops.view2d.zoom(
    factor=1.0,
    xmin=100,
    ymin=100,
    xmax=300,
    ymax=300
)

# 重置缩放
bpy.ops.view2d.zoom(
    factor=1.0,
    mx=0,
    my=0
)

# 放大到适应
bpy.ops.view2d.zoom_out(
    factor=1.0
)

# 缩小到适应
bpy.ops.view2d.zoom_in(
    factor=1.0
)

# 适应所有曲线
bpy.ops.view2d.zoom_border(
    action='FIT'
)
```

### 区域选择

```python
# 框选
bpy.ops.view2d.select_box(
    xmin=100,
    ymin=100,
    xmax=300,
    ymax=300,
    gesture_mode=3
)

# 框选添加
bpy.ops.view2d.select_box(
    xmin=100,
    ymin=100,
    xmax=300,
    ymax=300,
    gesture_mode=1
)

# 框选减去
bpy.ops.view2d.select_box(
    xmin=100,
    ymin=100,
    xmax=300,
    ymax=300,
    gesture_mode=2
)

# 圆形选择
bpy.ops.view2d.select_circle(
    x=200,
    y=200,
    radius=50,
    gesture_mode=3
)

# 套索选择
bpy.ops.view2d.select_lasso(
    path=[(x, y) for x, y in [(100, 100), (200, 100), (200, 200), (100, 200)]]
)
```

### 关键帧导航

```python
# 跳转到开始帧
bpy.ops.view2d.go_to_first()

# 跳转到结束帧
bpy.ops.view2d.go_to_last()

# 跳转到下一帧
bpy.ops.view2d.frame_jump(
    forward=True
)

# 跳转到上一帧
bpy.ops.view2d.frame_jump(
    forward=False
)

# 跳转到指定帧
bpy.ops.view2d.frame_jump(
    frame=100
)

# 播放
bpy.ops.view2d.play(
    speed=1.0
)

# 播放反向
bpy.ops.view2d.play(
    speed=-1.0
)

# 停止播放
bpy.ops.view2d.play(
    speed=0.0
)
```

### 曲线导航

```python
# 跳转到曲线开始
bpy.ops.view2d.curve_start()

# 跳转到曲线结束
bpy.ops.view2d.curve_end()

# 跳转到下一个关键帧
bpy.ops.view2d.nla_next()

# 跳转到上一个关键帧
bpy.ops.view2d.nla_prev()

# 选择范围
bpy.ops.view2d.select_border(
    gesture_mode=3
)
```

## 实用函数

```python
def get_view2d_bounds():
    """获取当前视图边界"""
    area = bpy.context.area
    space = area.spaces.active
    
    if hasattr(space, 'show_region_ui'):
        # 考虑UI区域
        total_width = area.width - area.regions['UI'].width
        return {
            'left': 0,
            'top': 0,
            'right': total_width,
            'bottom': area.height
        }
    else:
        return {
            'left': 0,
            'top': 0,
            'right': area.width,
            'bottom': area.height
        }

def center_view_on_cursor():
    """将视图中心移动到光标位置"""
    bpy.ops.view2d.pan(dx='CENTER')

def zoom_to_selection():
    """缩放到选择"""
    bpy.ops.view2d.zoom_border(action='FIT')

def zoom_to_frame(frame_number):
    """缩放到指定帧"""
    bpy.context.scene.frame_set(frame_number)
    bpy.ops.view2d.frame_jump(frame=frame_number)

def scroll_to_left():
    """滚动到最左边"""
    bpy.ops.view2d.pan(dx='LEFT_MAX')

def scroll_to_right():
    """滚动到最右边"""
    bpy.ops.view2d.pan(dx='RIGHT_MAX')

def scroll_to_top():
    """滚动到最顶部"""
    bpy.ops.view2d.pan(dy='TOP_MAX')

def scroll_to_bottom():
    """滚动到最底部"""
    bpy.ops.view2d.pan(dy='BOTTOM_MAX')

def smooth_zoom(factor):
    """平滑缩放"""
    bpy.ops.view2d.zoom(factor=factor)

def batch_scroll(direction, amount):
    """批量滚动"""
    if direction == 'left':
        for _ in range(amount):
            bpy.ops.view2d.pan(dx=-10)
    elif direction == 'right':
        for _ in range(range):
            bpy.ops.view2d.pan(dx=10)
    elif direction == 'up':
        for _ in range(amount):
            bpy.ops.view2d.pan(dy=10)
    elif direction == 'down':
        for _ in range(amount):
            bpy.ops.view2d.pan(dy=-10)
```

## 常见问题排查

### 视图无法缩放
```python
# 检查区域类型
area = bpy.context.area
print(f"区域类型: {area.type}")
print(f"UI类型: {area.ui_type}")

# 检查空间
space = area.spaces.active
print(f"空间类型: {space.type}")

# 检查缩放限制
print(f"最小缩放: {space.zoom_min}")
print(f"最大缩放: {space.zoom_max}")

# 手动设置缩放
space.zoom = (1.0, 1.0)

# 重置缩放
space.zoom = (1.0, 1.0)
```

### 选择框不显示
```python
# 检查选择模式
print(f"选择模式: {bpy.context.tool_settings.select_mode}")

# 检查选择类型
space = bpy.context.area.spaces.active
print(f"选择类型: {space.ui_mode}")

# 重置选择
bpy.ops.view2d.select_box(
    xmin=0,
    ymin=0,
    xmax=0,
    ymax=0,
    gesture_mode=0
)

# 检查选择事件
print(f"选择手势: {bpy.context.scene.tool_settings.gesture_selection}")
```

### 播放无响应
```python
# 检查播放状态
print(f"正在播放: {bpy.context.scene.is_playing}")

# 检查帧范围
print(f"开始帧: {bpy.context.scene.frame_start}")
print(f"结束帧: {bpy.context.scene.frame_end}")
print(f"当前帧: {bpy.context.scene.frame_current}")

# 手动设置帧
bpy.context.scene.frame_set(100)

# 重新开始播放
bpy.ops.view2d.play(speed=1.0)

# 停止播放
bpy.ops.view2d.play(speed=0.0)
```
