# gpu.shader - GPU着色器模块

gpu.shader模块提供了GPU着色器程序的创建、编译和管理功能，用于编写自定义GPU渲染效果。

## 概述

GPU着色器模块是Blender GPU库的核心组件，提供了创建和操作GLSL着色器程序的能力。支持顶点着色器、片元着色器和计算着色器。

## 核心功能

### 着色器创建

```python
import gpu
from gpu.shader import (
    ShaderCreateInfo,
    shader_create_from_info,
    Shader,
    Uniform
)

def create_simple_vertex_shader():
    """创建简单顶点着色器"""
    info = ShaderCreateInfo()
    info.define('VERSION', '330')
    info.vertex_in(0, 'POSITION', 'vec3')
    info.vertex_out(0, 'texCoord', 'vec2')
    info.uniform_world_or_model_matrix('ModelMatrix')
    info.vertex_source('''
        in vec3 position;
        out vec2 texCoord;
        uniform mat4 ModelMatrix;
        void main() {
            gl_Position = ModelMatrix * vec4(position, 1.0);
            texCoord = position.xy * 0.5 + 0.5;
        }
    ''')
    info.fragment_source('''
        in vec2 texCoord;
        out vec4 fragColor;
        void main() {
            fragColor = vec4(texCoord, 0.0, 1.0);
        }
    ''')
    return shader_create_from_info(info)

def create_custom_shader(vert_src, frag_src):
    """创建自定义着色器"""
    info = ShaderCreateInfo()
    info.vertex_source(vert_src)
    info.fragment_source(frag_src)
    return shader_create_from_info(info)

def create_basic_color_shader():
    """创建基础颜色着色器"""
    info = ShaderCreateInfo()
    info.define('PRECISION', 'mediump float')
    info.vertex_in(0, 'pos', 'vec3')
    info.vertex_in(1, 'color', 'vec4')
    info.vertex_out(0, 'fragColor', 'vec4')
    info.uniform_world_or_model_matrix('ModelMatrix')
    info.uniform_view_projection_matrix('ViewProjectionMatrix')
    info.vertex_source('''
        in vec3 pos;
        in vec4 color;
        uniform mat4 ModelMatrix;
        uniform mat4 ViewProjectionMatrix;
        out vec4 fragColor;
        void main() {
            gl_Position = ViewProjectionMatrix * ModelMatrix * vec4(pos, 1.0);
            fragColor = color;
        }
    ''')
    info.fragment_source('''
        in vec4 fragColor;
        out vec4 color;
        void main() {
            color = fragColor;
        }
    ''')
    return shader_create_from_info(info)
```

### Uniform管理

```python
from gpu.shader import Uniform, UniformBuf

def set_uniform_float(shader, name, value):
    """设置浮点Uniform"""
    uniform = shader.uniforms.get(name)
    if uniform:
        uniform_float = Uniform(name, 'FLOAT')
        uniform_float.set(value)

def set_uniform_vec2(shader, name, value):
    """设置vec2 Uniform"""
    uniform = Uniform(name, 'VEC2')
    uniform.set(value)

def set_uniform_vec3(shader, name, value):
    """设置vec3 Uniform"""
    uniform = Uniform(name, 'VEC3')
    uniform.set(value)

def set_uniform_vec4(shader, name, value):
    """设置vec4 Uniform"""
    uniform = Uniform(name, 'VEC4')
    uniform.set(value)

def set_uniform_mat4(shader, name, value):
    """设置mat4 Uniform"""
    uniform = Uniform(name, 'MAT4')
    uniform.set(value)

def set_uniform_int(shader, name, value):
    """设置整数Uniform"""
    uniform = Uniform(name, 'INT')
    uniform.set(value)

def set_uniform_sampler(shader, name, unit):
    """设置采样器Uniform"""
    uniform = Uniform(name, 'SAMPLER_2D')
    uniform.set(unit)

def create_uniform_buffer(data, binding=0):
    """创建Uniform缓冲区"""
    ubo = UniformBuf(len(data), binding)
    ubo.update(data)
    return ubo
```

### 批处理渲染

```python
def begin_batch(batch_type='POINTS'):
    """开始批处理"""
    gpu.begin_batch(batch_type)

def end_batch():
    """结束批处理"""
    gpu.end_batch()

def batch_vertex_format(format):
    """设置批处理顶点格式"""
    gpu.batch_vertex_format(format)

def batch_push_vertex(x, y, z, u=0, v=0):
    """推送顶点数据"""
    gpu.batch_vertex_3f(x, y, z)
    gpu.batch_vertex_2f(u, v)

def draw_batch(shader, batch_type='POINTS'):
    """绘制批处理"""
    shader.bind()
    gpu.draw_batch(batch_type)

def create_point_batch(points, colors=None):
    """创建点批处理"""
    batch = gpu.create_batch(
        'POINTS',
        [
            ('POSITION', '3f'),
            ('COLOR', '4f')
        ],
 if colors else None        points,
        colors
    )
    return batch

def create_line_batch(lines, color=(1, 1, 1, 1)):
    """创建线批处理"""
    batch = gpu.create_batch(
        'LINES',
        [
            ('POSITION', '3f'),
            ('COLOR', '4f')
        ],
        lines,
        [color] * len(lines)
    )
    return batch

def create_triangle_batch(triangles, colors=None):
    """创建三角形批处理"""
    batch = gpu.create_batch(
        'TRIANGLES',
        [
            ('POSITION', '3f'),
            ('COLOR', '4f' if colors else None)
        ],
        triangles,
        colors
    )
    return batch
```

## 实用函数

### 着色器编译

```python
def compile_shader(source, shader_type='VERTEX'):
    """编译着色器"""
    shader = gpu.Shader()
    shader.set_source(source)
    return shader.compile(shader_type)

def compile_shader_from_file(filepath, shader_type='VERTEX'):
    """从文件编译着色器"""
    with open(filepath, 'r') as f:
        source = f.read()
    return compile_shader(source, shader_type)

def check_shader_errors(shader):
    """检查着色器错误"""
    log = shader.get_log()
    return log if log else None

def validate_shader(shader):
    """验证着色器"""
    return shader.validate()
```

### 着色器程序

```python
def create_program(vertex_shader, fragment_shader):
    """创建着色器程序"""
    program = gpu.ShaderProgram()
    program.attach_shader(vertex_shader)
    program.attach_shader(fragment_shader)
    return program

def link_program(program):
    """链接程序"""
    return program.link()

def use_program(program):
    """使用程序"""
    program.bind()

def release_program():
    """释放程序"""
    gpu.ShaderProgram.unbind_all()

def get_active_program():
    """获取当前使用的程序"""
    return gpu.ShaderProgram.active_get()
```

### 高级渲染

```python
def draw_instanced(mesh, count, shader):
    """实例化绘制"""
    shader.bind()
    mesh.draw(shader, count=count)

def draw_elements(mesh, shader, mode='TRIANGLES'):
    """索引绘制"""
    shader.bind()
    mesh.draw_elements(shader, mode)

def draw_arrays(mesh, shader, mode='TRIANGLES'):
    """数组绘制"""
    shader.bind()
    mesh.draw(shader, mode)

def draw_range_arrays(mesh, start, end, shader, mode='TRIANGLES'):
    """范围数组绘制"""
    shader.bind()
    mesh.draw_range(shader, start, end, mode)
```

## 常见问题排查

### 着色器编译失败

GLSL语法错误：
- 检查着色器源代码语法
- 确认GLSL版本兼容
- 查看编译日志获取详细信息

### Uniform设置无效

名称或类型错误：
- 确认Uniform名称与着色器中一致
- 检查Uniform类型匹配
- 验证Uniform是否被优化掉

### 批处理性能问题

顶点数量过大：
- 减少单次批处理的顶点数量
- 使用合适的绘制模式
- 考虑分批处理
