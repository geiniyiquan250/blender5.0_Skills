# bpy.ops.cloth 模块

布料模拟操作模块，用于配置和管理布料物理模拟。

## 概述

bpy.ops.world 模块包含用于配置场景世界环境的运算符。世界环境控制场景的背景颜色、环境光照、雾效和整体氛围。

## 常用操作

### 预设应用

```python
import bpy

# 应用布料预设
bpy.ops.cloth.preset_add(preset='Cotton')

# 应用丝绸预设
bpy.ops.cloth.preset_add(preset='Silk')

# 应用皮革预设
bpy.ops.cloth.preset_add(preset='Leather')

# 应用橡胶预设
bpy.ops.cloth.preset_add(preset='Rubber')

# 应用 denim 预设
bpy.ops.cloth.preset_add(preset='Denim')

# 应用胶水预设
bpy.ops.cloth.preset_add(preset='Glue')

# 应用塑料预设
bpy.ops.cloth.preset_add(preset='Plastic')

# 应用薄纱预设
bpy.ops.cloth.preset_add(preset='Sheer')
```

### 属性设置

```python
# 设置质量
bpy.ops.cloth.mass_set(value=0.3)

# 设置结构刚度
bpy.ops.cloth.structural_set(value=50.0)

# 设置剪切刚度
bpy.ops.cloth.shear_set(value=5.0)

# 设置弯曲刚度
bpy.ops.cloth.bending_set(value=1.0)

# 设置阻尼
bpy.ops.cloth.damping_set(value=5.0)

# 设置空气阻力
bpy.ops.cloth.air_damping_set(value=1.0)

# 设置重力影响
bpy.ops.cloth.gravity_set(value=9.8)
```

### 碰撞设置

```python
# 设置碰撞质量
bpy.ops.cloth.collision_quality_set(value=2)

# 设置自碰撞
bpy.ops.cloth.self_collision_set(value=True)

# 设置自碰撞距离
bpy.ops.cloth.self_collision_distance_set(value=0.02)

# 设置自碰撞刚度
bpy.ops.cloth.self_collision_stiffness_set(value=100.0)

# 设置顶点组质量
bpy.ops.cloth.pinning_group_add(group_name='PinningGroup')
```

### 缓存操作

```python
# 创建缓存
bpy.ops.cloth.cache_create()

# 删除缓存
bpy.ops.cloth.cache_delete()

# 清除缓存
bpy.ops.cloth.cache_clear()

# 重置缓存
bpy.ops.cloth.cache_reset()

# 重新计算缓存
bpy.ops.cloth.cache_rebuild()
```

### 模拟控制

```python
# 开始模拟
bpy.ops.cloth.simulate()

# 停止模拟
bpy.ops.cloth.stop_simulation()

# 重置模拟
bpy.ops.cloth.reset_simulation()

# 清除模拟
bpy.ops.cloth.clear_simulation()

# 应用为形状键
bpy.ops.cloth.shape_key_add(from_current=True)

# 应用为骨架变形
bpy.ops.cloth.applied_modifier_add()
```

## 实际应用示例

### 创建布料模拟

```python
def setup_cloth_simulation(obj, preset='Cotton'):
    """设置布料模拟"""
    # 确保物体有足够的顶点
    if len(obj.data.vertices) < 100:
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.subdivide(number_cuts=3)
        bpy.ops.object.mode_set(mode='OBJECT')
    
    # 添加布料修改器
    cloth_mod = obj.modifiers.new(name='Cloth', type='CLOTH')
    
    # 应用预设
    bpy.ops.cloth.preset_add(preset=preset)
    
    # 设置碰撞
    cloth_mod.settings.collision_quality = 3
    cloth_mod.settings.self_collision = True
    cloth_mod.settings.self_collision_distance = 0.01
    cloth_mod.settings.self_collision_stiffness = 100.0
    
    return cloth_mod
```

### 创建旗帜模拟

```python
def create_flag_simulation(pole_obj, flag_obj, wind_strength=5.0):
    """创建旗帜模拟"""
    # 将旗帜绑定到旗杆
    pole_obj.select_set(True)
    flag_obj.select_set(True)
    bpy.context.view_layer.objects.active = pole_obj
    bpy.ops.object.parent_set(type='OBJECT')
    
    # 添加布料修改器
    cloth_mod = flag_obj.modifiers.new(name='FlagCloth', type='CLOTH')
    
    # 设置为丝绸
    bpy.ops.cloth.preset_add(preset='Silk')
    
    # 设置物理属性
    cloth_mod.settings.mass = 0.1
    cloth_mod.settings.air_damping = 0.5
    
    # 添加固定点组
    bpy.ops.object.vertex_group_add()
    flag_obj.vertex_groups.active.name = 'Pinning'
    
    # 选择旗帜左侧顶点
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')
    
    # 固定左侧顶点
    for vert in flag_obj.data.vertices:
        if vert.co.x < -0.01:
            vert.select = True
    
    bpy.ops.object.vertex_group_assign()
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 设置固定组
    cloth_mod.settings.pinning_point = 'VERTEX'
    cloth_mod.settings.vertex_group_mass = flag_obj.vertex_groups['Pinning']
    
    # 添加风力
    cloth_mod.settings.use_air_damping = True
    cloth_mod.settings.air_damping = wind_strength
    
    return cloth_mod
```

### 创建窗帘模拟

```python
def create_curtain_simulation(curtain_obj, anchor_group='TopEdge'):
    """创建窗帘模拟"""
    # 添加布料修改器
    cloth_mod = curtain_obj.modifiers.new(name='CurtainCloth', type='CLOTH')
    
    # 设置为轻薄布料
    bpy.ops.cloth.preset_add(preset='Sheer')
    
    # 设置质量
    cloth_mod.settings.mass = 0.05
    
    # 设置阻尼
    cloth_mod.settings.damping = 3.0
    cloth_mod.settings.air_damping = 2.0
    
    # 设置固定组
    if anchor_group in curtain_obj.vertex_groups:
        cloth_mod.settings.pinning_point = 'VERTEX'
        cloth_mod.settings.vertex_group_mass = curtain_obj.vertex_groups[anchor_group]
    
    # 设置碰撞
    cloth_mod.settings.collision_quality = 4
    cloth_mod.settings.self_collision = True
    
    return cloth_mod
```

### 创建桌布模拟

```python
def create_tablecloth_simulation(tablecloth_obj, table_obj):
    """创建桌布模拟"""
    # 添加布料修改器
    cloth_mod = tablecloth_obj.modifiers.new(name='TableCloth', type='CLOTH')
    
    # 设置为棉布
    bpy.ops.cloth.preset_add(preset='Cotton')
    
    # 设置物理属性
    cloth_mod.settings.mass = 0.3
    cloth_mod.settings.structural_stiffness = 80.0
    cloth_mod.settings.bending_stiffness = 2.0
    
    # 添加碰撞
    tablecloth_obj.select_set(True)
    bpy.context.view_layer.objects.active = tablecloth_obj
    
    # 设置与桌子的碰撞
    cloth_mod.settings.collision_quality = 3
    cloth_mod.settings.use_collision = True
    
    return cloth_mod
```

### 创建披风模拟

```python
def create_cape_simulation(cape_obj, character_obj):
    """创建披风模拟"""
    # 添加布料修改器
    cloth_mod = cape_obj.modifiers.new(name='CapeCloth', type='CLOTH')
    
    # 设置为皮革
    bpy.ops.cloth.preset_add(preset='Leather')
    
    # 设置物理属性
    cloth_mod.settings.mass = 0.5
    cloth_mod.settings.structural_stiffness = 100.0
    cloth_mod.settings.bending_stiffness = 5.0
    
    # 创建固定点组
    bpy.ops.object.vertex_group_add()
    cape_obj.vertex_groups.active.name = 'CapeTop'
    
    # 固定顶部顶点
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')
    
    for vert in cape_obj.data.vertices:
        if vert.co.y > 0.95:
            vert.select = True
    
    bpy.ops.object.vertex_group_assign()
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 设置固定
    cloth_mod.settings.pinning_point = 'VERTEX'
    cloth_mod.settings.vertex_group_mass = cape_obj.vertex_groups['CapeTop']
    
    # 添加碰撞
    cloth_mod.settings.self_collision = True
    
    return cloth_mod
```

### 创建弹簧布料

```python
def create_spring_cloth(obj, stiffness=200.0, damping=10.0):
    """创建弹簧布料效果"""
    # 添加布料修改器
    cloth_mod = obj.modifiers.new(name='SpringCloth', type='CLOTH')
    
    # 应用胶水预设
    bpy.ops.cloth.preset_add(preset='Glue')
    
    # 设置高刚度
    cloth_mod.settings.structural_stiffness = stiffness
    cloth_mod.settings.shear_stiffness = stiffness * 0.5
    cloth_mod.settings.bending_stiffness = stiffness * 0.2
    
    # 设置阻尼
    cloth_mod.settings.damping = damping
    
    # 禁用重力影响
    cloth_mod.settings.gravity = (0, 0, 0)
    
    return cloth_mod
```

## 使用场景

- **服装制作**：创建衣物、裙子、披风等
- **旗帜飘动**：创建旗帜、条幅动画
- **窗帘效果**：创建窗帘、帷幕动画
- **布料动画**：桌布、餐巾等
- **物理模拟**：需要布料物理效果的场景
- **角色动画**：角色的服装和配饰

## 注意事项

- 布料模拟需要足够的网格密度
- 固定点组用于控制布料固定位置
- 碰撞设置影响模拟精度和性能
- 高刚度设置可能导致不稳定
- 缓存管理影响模拟速度
- 自碰撞增加计算负担
- 风力设置需要平衡效果和稳定性
- 布料预设提供良好的起点
