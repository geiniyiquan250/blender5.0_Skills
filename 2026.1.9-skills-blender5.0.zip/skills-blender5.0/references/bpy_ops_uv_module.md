# bpy.ops.uv - UV Operations Module

Blender UV 操作符，用于在 UV 编辑器中管理和操作网格的 UV 坐标。

## Overview

`bpy.ops.uv` 模块包含 UV 编辑器中的所有操作命令，涵盖 UV 的选择、编辑、对齐、投影等核心功能。这个模块主要用于纹理映射和 UV 展开的管理。

## 核心功能

### UV 选择操作

```python
import bpy

# 全选 UV
bpy.ops.uv.select_all(action='SELECT')

# 全不选
bpy.ops.uv.select_all(action='DESELECT')

# 反选
bpy.ops.uv.select_all(action='INVERT')

# 选择相似
bpy.ops.uv.select_similar(type='AREA', threshold=0.01)
bpy.ops.uv.select_similar(type='LENGTH', threshold=0.01)
bpy.ops.uv.select_similar(type='PERIMETER', threshold=0.01)

# 选择循环
bpy.ops.uv.select_loop()

# 选择边环
bpy.ops.uv.select_edge_ring()

# 边框选择
bpy.ops.uv.select_border(gesture_mode=0, xmin=100, xmax=300, ymin=100, ymax=300)

# 圆形选择
bpy.ops.uv.select_circle(x=200, y=200, radius=50)

# 套索选择
bpy.ops.uv.select_lasso(path=[(100, 100), (200, 100), (200, 200), (100, 200)])

# 取消选择连接的
bpy.ops.uv.select_less()

# 扩大选择
bpy.ops.uv.select_more()

# 同步选择
bpy.ops.uv.select_sync_from_mode()

def select_uv_by_material_slot(material_slot_name):
    """按材质槽选择 UV"""
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')
    
    obj = bpy.context.active_object
    for i, slot in enumerate(obj.material_slots):
        if slot.name == material_slot_name:
            bpy.ops.object.material_slot_select(slot_index=i)
            break

def select_uv_faces_by_size(threshold=0.01):
    """选择小于阈值的 UV 面"""
    bpy.ops.uv.select_all(action='SELECT')
    bpy.ops.uv.select_similar(type='AREA', threshold=threshold)
    bpy.ops.uv.select_all(action='INVERT')
```

### UV 编辑操作

```python
# 移动 UV
bpy.ops.uv.translate(delta_x=0.1, delta_y=0.1)

# 旋转 UV
bpy.ops.uv.rotate(value=0.785398)  # 45度

# 缩放 UV
bpy.ops.uv.scale(value=1.5)

# 剪切 UV
bpy.ops.uv.cut(cut_through=True)

# 复制 UV
bpy.ops.uv.duplicate()

# 粘贴 UV
bpy.ops.uv.paste()

# 清除 UV
bpy.ops.uv.delete(selected=True, type='VERTEX')

# 排列 UV
bpy.ops.uv.align(axis='X')
bpy.ops.uv.align(axis='Y')

# 修正 UV 宽高比
bpy.ops.uv.reveal(select=True)

# 最小化拉伸
bpy.ops.uv.minimize_stretch(iterations=10)

# 焊接 UV 顶点
bpy.ops.uv.weld()

# 合并 UV 顶点
bpy.ops.uv.stitch(use_limit=False, limit=0.01, static_thresh=0.1)

# 细分 UV
bpy.ops.uv.subdivide()

# 排序 UV
bpy.ops.uv.sort(type='TOP_TO_BOTTOM')
bpy.ops.uv.sort(type='LEFT_TO_RIGHT')

def move_uv_selection(x, y):
    """移动选中的 UV"""
    bpy.ops.uv.translate(delta_x=x, delta_y=y)

def rotate_uv_90_degrees(direction='CW'):
    """旋转 UV 90 度"""
    if direction == 'CW':
        bpy.ops.uv.rotate(value=-1.5708)  # -90度
    else:
        bpy.ops.uv.rotate(value=1.5708)   # 90度

def scale_uv_uniform(factor):
    """统一缩放 UV"""
    bpy.ops.uv.scale(value=factor)
```

### UV 投影操作

```python
# 智能 UV 投影
bpy.ops.uv.smart_project(
    angle_limit=66,
    island_margin=0.08,
    area_weight=0.75,
    correct_aspect=True
)

# 立方体投影
bpy.ops.uv.cube_project(
    cube_size=1,
    gap=0.02
)

# 圆柱投影
bpy.ops.uv.cylinder_project(
    direction='ALIGN_TO_OBJECT',
    align_pole='UP',
    area_weight=0.75
)

# 球形投影
bpy.ops.uv.sphere_project(
    direction='ALIGN_TO_OBJECT',
    area_weight=0.75
)

# 从视图投影
bpy.ops.uv.project_from_view(
    scale_to_bounds=False,
    correct_aspect=True
)

# 遵循活动面
bpy.ops.uv.follow_active_quads(mode='LENGTH_AVERAGE')

def smart_project_selected(angle=66, margin=0.08):
    """对选中的面进行智能投影"""
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='EDIT')
    
    bpy.ops.uv.smart_project(
        angle_limit=angle,
        island_margin=margin,
        area_weight=0.75,
        correct_aspect=True
    )

def project_from_view_scaled():
    """从视图投影并缩放到边界"""
    bpy.ops.uv.project_from_view(
        scale_to_bounds=True,
        correct_aspect=True
    )
```

### UV 展开操作

```python
# 展开
bpy.ops.uv.unwrap(
    method='ANGLE_BASED',
    fill_holes=True,
    correct_aspect=True,
    use_subsurf_data=False,
    margin=0.001
)

# 收缩包裹
bpy.ops.uv.shrinkwrap(
    target=bpy.data.objects['TargetObject'],
    offset=0.001
)

def unwrap_with_margin(margin=0.05):
    """带边距展开"""
    bpy.ops.uv.unwrap(
        method='ANGLE_BASED',
        fill_holes=True,
        correct_aspect=True,
        margin=margin
    )

def reset_uv():
    """重置 UV"""
    bpy.ops.uv.reset()
```

## 实际应用示例

### UV 布局管理器

```python
import bpy
import math

class UVLayoutManager:
    """UV 布局管理器"""
    
    def __init__(self, texel_density=1024):
        self.texel_density = texel_density
    
    def get_uv_area(self, uv_layer):
        """计算 UV 面积"""
        mesh = bpy.context.active_object.data
        area = 0
        
        for poly in mesh.polygons:
            if not poly.select:
                continue
            
            verts = [mesh.vertices[v].co for v in poly.vertices]
            
            if len(verts) == 4:
                # 四边形分解为两个三角形
                area += self._triangle_area(verts[0], verts[1], verts[2])
                area += self._triangle_area(verts[0], verts[2], verts[3])
            else:
                # 三角形
                area += self._triangle_area(verts[0], verts[1], verts[2])
        
        return area
    
    def _triangle_area(self, a, b, c):
        """计算三角形面积"""
        ab = (b[0] - a[0], b[1] - a[1], b[2] - a[2])
        ac = (c[0] - a[0], c[1] - a[1], c[2] - a[2])
        
        cross = (
            ab[1] * ac[2] - ab[2] * ac[1],
            ab[2] * ac[0] - ab[0] * ac[2],
            ab[0] * ac[1] - ab[1] * ac[0]
        )
        
        return 0.5 * math.sqrt(sum(x**2 for x in cross))
    
    def calculate_texel_density(self, obj, uv_layer_name="UVMap"):
        """计算纹理密度"""
        mesh = obj.data
        uv_layer = mesh.uv_layers[uv_layer_name]
        
        total_uv_area = 0
        total_mesh_area = 0
        
        for poly in mesh.polygons:
            uv_area = 0
            mesh_area = 0
            
            verts = [mesh.vertices[v].co for v in poly.vertices]
            
            # 计算网格面积
            if len(verts) == 4:
                mesh_area = self._triangle_area(verts[0], verts[1], verts[2])
                mesh_area += self._triangle_area(verts[0], verts[2], verts[3])
            else:
                mesh_area = self._triangle_area(verts[0], verts[1], verts[2])
            
            # 计算 UV 面积
            uvs = [uv_layer.data[loop].uv for loop in poly.loop_indices]
            if len(uvs) == 4:
                uv_area = self._triangle_area_uv(uvs[0], uvs[1], uvs[2])
                uv_area += self._triangle_area_uv(uvs[0], uvs[2], uvs[3])
            else:
                uv_area = self._triangle_area_uv(uvs[0], uvs[1], uvs[2])
            
            total_uv_area += uv_area
            total_mesh_area += mesh_area
        
        # 计算纹理密度 (pixels per unit)
        texture_size = self.texel_density
        texel_density = math.sqrt(uv_area / mesh_area) * texture_size if mesh_area > 0 else 0
        
        return texel_density
    
    def _triangle_area_uv(self, a, b, c):
        """计算 UV 三角形面积"""
        ab = (b[0] - a[0], b[1] - a[1])
        ac = (c[0] - a[0], c[1] - a[1])
        
        return 0.5 * abs(ab[0] * ac[1] - ab[1] * ac[0])
    
    def normalize_texel_density(self, target_density=1024):
        """标准化纹理密度"""
        obj = bpy.context.active_object
        
        # 获取当前密度
        current_density = self.calculate_texel_density(obj)
        
        if current_density > 0:
            scale_factor = target_density / current_density
            bpy.ops.uv.scale(value=math.sqrt(scale_factor))
    
    def pack_uv_islands(self, margin=0.02, rotate=True, scale=True):
        """打包 UV 岛屿"""
        bpy.ops.uv.select_all(action='SELECT')
        bpy.ops.uv.pack_islands(
            margin=margin,
            rotate=rotate,
            scale=scale
        )
    
    def export_uv_layout(self, filepath, resolution=(2048, 2048)):
        """导出 UV 布局"""
        # 创建渲染设置
        bpy.ops.object.mode_set(mode='OBJECT')
        
        scene = bpy.context.scene
        old_engine = scene.render.engine
        scene.render.engine = 'CYCLES'
        
        # 设置渲染分辨率
        scene.render.resolution_x = resolution[0]
        scene.render.resolution_y = resolution[1]
        
        # 启用 UV 同步选择
        bpy.context.scene.tool_settings.use_uv_select_sync = True
        
        # 渲染 UV 布局
        scene.render.filepath = filepath
        bpy.ops.render.render(write_still=True)
        
        # 恢复设置
        scene.render.engine = old_engine
        
        return filepath
    
    def layout_uv_grid(self, cols=4):
        """将 UV 排列成网格"""
        mesh = bpy.context.active_object.data
        
        # 获取所有 UV 面
        uv_layer = mesh.uv_layers.active
        faces = [poly for poly in mesh.polygons if poly.select]
        
        # 排列
        for i, poly in enumerate(faces):
            row = i // cols
            col = i % cols
            
            # 移动 UV 到网格位置
            for loop_idx in poly.loop_indices:
                uv = uv_layer.data[loop_idx].uv
                uv[0] = col + uv[0] / cols
                uv[1] = 1 - row - uv[1] / cols


def setup_uv_layout():
    """设置 UV 布局"""
    manager = UVLayoutManager(texel_density=1024)
    
    # 智能投影
    bpy.ops.uv.smart_project(
        angle_limit=66,
        island_margin=0.08,
        area_weight=0.75,
        correct_aspect=True
    )
    
    # 打包
    manager.pack_uv_islands(margin=0.02)
    
    return manager
```

### UV 检查工具

```python
import bpy
import math

class UVChecker:
    """UV 检查工具"""
    
    def check_overlapping_faces(self):
        """检查重叠面"""
        mesh = bpy.context.active_object.data
        uv_layer = mesh.uv_layers.active
        
        overlapping = []
        
        for i, poly1 in enumerate(mesh.polygons):
            if not poly1.select:
                continue
            
            uv1 = [uv_layer.data[loop].uv for loop in poly1.loop_indices]
            
            for j, poly2 in enumerate(mesh.polygons):
                if i >= j or not poly2.select:
                    continue
                
                uv2 = [uv_layer.data[loop].uv for loop in poly2.loop_indices]
                
                if self._uvs_overlap(uv1, uv2):
                    overlapping.append((i, j))
        
        # 高亮重叠面
        bpy.ops.uv.select_all(action='DESELECT')
        for i, j in overlapping:
            mesh.polygons[i].select = True
            mesh.polygons[j].select = True
        
        return overlapping
    
    def _uvs_overlap(self, uvs1, uvs2):
        """检查 UV 是否重叠"""
        bounds1 = self._get_uv_bounds(uvs1)
        bounds2 = self._get_uv_bounds(uvs2)
        
        # 简单的边界框检查
        return not (
            bounds1[0] >= bounds2[2] or
            bounds1[2] <= bounds2[0] or
            bounds1[1] >= bounds2[3] or
            bounds1[3] <= bounds2[1]
        )
    
    def _get_uv_bounds(self, uvs):
        """获取 UV 边界"""
        min_u = min(uv[0] for uv in uvs)
        max_u = max(uv[0] for uv in uvs)
        min_v = min(uv[1] for uv in uvs)
        max_v = max(uv[1] for uv in uvs)
        
        return (min_u, min_v, max_u, max_v)
    
    def check_stretched_faces(self, threshold=0.1):
        """检查拉伸面"""
        mesh = bpy.context.active_object.data
        uv_layer = mesh.uv_layers.active
        
        stretched = []
        
        for poly in mesh.polygons:
            if not poly.select:
                continue
            
            # 获取 UV 和 3D 面积比
            uvs = [uv_layer.data[loop].uv for loop in poly.loop_indices]
            verts = [mesh.vertices[v].co for v in poly.vertices]
            
            uv_area = self._triangle_area_uv(uvs[0], uvs[1], uvs[2])
            mesh_area = self._triangle_area_verts(verts[0], verts[1], verts[2])
            
            if mesh_area > 0:
                ratio = uv_area / mesh_area
                if ratio < threshold:
                    stretched.append(poly)
        
        return stretched
    
    def _triangle_area_uv(self, a, b, c):
        """计算 UV 三角形面积"""
        ab = (b[0] - a[0], b[1] - a[1])
        ac = (c[0] - a[0], c[1] - a[1])
        return 0.5 * abs(ab[0] * ac[1] - ab[1] * ac[0])
    
    def _triangle_area_verts(self, a, b, c):
        """计算 3D 三角形面积"""
        ab = (b[0] - a[0], b[1] - a[1], b[2] - a[2])
        ac = (c[0] - a[0], c[1] - a[1], c[2] - a[2])
        
        cross = (
            ab[1] * ac[2] - ab[2] * ac[1],
            ab[2] * ac[0] - ab[0] * ac[2],
            ab[0] * ac[1] - ab[1] * ac[0]
        )
        
        return 0.5 * math.sqrt(sum(x**2 for x in cross))
    
    def check_uv_bounds(self):
        """检查 UV 边界"""
        mesh = bpy.context.active_object.data
        uv_layer = mesh.uv_layers.active
        
        min_u = float('inf')
        max_u = float('-inf')
        min_v = float('inf')
        max_v = float('-inf')
        
        for poly in mesh.polygons:
            for loop_idx in poly.loop_indices:
                uv = uv_layer.data[loop_idx].uv
                min_u = min(min_u, uv[0])
                max_u = max(max_u, uv[0])
                min_v = min(min_v, uv[1])
                max_v = max(max_v, uv[1])
        
        return {
            'min_u': min_u,
            'max_u': max_u,
            'min_v': min_v,
            'max_v': max_v,
            'width': max_u - min_u,
            'height': max_v - min_v,
            'total_area': (max_u - min_u) * (max_v - min_v)
        }
    
    def select_distorted_faces(self, distortion_threshold=1.5):
        """选择变形面"""
        mesh = bpy.context.active_object.data
        uv_layer = mesh.uv_layers.active
        
        bpy.ops.uv.select_all(action='DESELECT')
        
        for poly in mesh.polygons:
            if not poly.select:
                continue
            
            uvs = [uv_layer.data[loop].uv for loop in poly.loop_indices]
            verts = [mesh.vertices[v].co for v in poly.vertices]
            
            uv_area = self._triangle_area_uv(uvs[0], uvs[1], uvs[2])
            mesh_area = self._triangle_area_verts(verts[0], verts[1], verts[2])
            
            if mesh_area > 0:
                ratio = mesh_area / uv_area if uv_area > 0 else float('inf')
                if ratio > distortion_threshold:
                    poly.select = True


def check_uv_quality():
    """检查 UV 质量"""
    checker = UVChecker()
    
    # 检查重叠
    overlapping = checker.check_overlapping_faces()
    print(f"发现 {len(overlapping)} 对重叠面")
    
    # 检查拉伸
    stretched = checker.check_stretched_faces(threshold=0.05)
    print(f"发现 {len(stretched)} 个拉伸面")
    
    # 检查边界
    bounds = checker.check_uv_bounds()
    print(f"UV 边界: U [{bounds['min_u']:.2f}, {bounds['max_u']:.2f}], "
          f"V [{bounds['min_v']:.2f}, {bounds['max_v']:.2f}]")
    
    return {
        'overlapping': overlapping,
        'stretched': stretched,
        'bounds': bounds
    }
```

### UV 自动化工具

```python
import bpy

class UVAutomationTool:
    """UV 自动化工具"""
    
    def setup_texture_atlas(self, objects, atlas_size=4096, padding=16):
        """创建纹理图集"""
        # 收集所有 UV
        all_uvs = []
        total_area = 0
        
        for obj in objects:
            if obj.type != 'MESH':
                continue
            
            mesh = obj.data
            
            for poly in mesh.polygons:
                uv_area = 0
                for loop_idx in poly.loop_indices:
                    uv = mesh.uv_layers.active.data[loop_idx].uv
                    all_uvs.append(uv)
        
        # 计算每个对象的 UV 区域
        object_areas = {}
        for obj in objects:
            if obj.type != 'MESH':
                continue
            
            mesh = obj.data
            area = sum(poly.area for poly in mesh.polygons)
            object_areas[obj.name] = area
        
        total_area = sum(object_areas.values())
        
        # 计算缩放比例
        scale_factor = math.sqrt(total_area) / atlas_size * (1 - padding / atlas_size)
        
        # 重新缩放 UV
        for obj in objects:
            if obj.type != 'MESH':
                continue
            
            mesh = obj.data
            
            for poly in mesh.polygons:
                for loop_idx in poly.loop_indices:
                    uv = mesh.uv_layers.active.data[loop_idx].uv
                    uv[0] *= scale_factor
                    uv[1] *= scale_factor
    
    def batch_unwrap(self, objects, method='smart', **kwargs):
        """批量展开"""
        for obj in objects:
            if obj.type != 'MESH':
                continue
            
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            
            if method == 'smart':
                bpy.ops.uv.smart_project(**kwargs)
            elif method == 'cube':
                bpy.ops.uv.cube_project(**kwargs)
            elif method == 'cylinder':
                bpy.ops.uv.cylinder_project(**kwargs)
            elif method == 'sphere':
                bpy.ops.uv.sphere_project(**kwargs)
            
            bpy.ops.object.mode_set(mode='OBJECT')
    
    def transfer_uv_from_object(self, source, target):
        """从源对象传递 UV 到目标对象"""
        bpy.context.view_layer.objects.active = target
        
        # 确保两个对象都在编辑模式
        bpy.ops.object.mode_set(mode='EDIT')
        
        # 选择源对象
        bpy.ops.mesh.select_all(action='DESELECT')
        source.select_set(True)
        
        # 传递 UV
        bpy.ops.object.join_uvs()
        
        # 分离
        bpy.ops.mesh.separate(type='SELECTED')
    
    def create_uv_template(self, obj, output_path):
        """创建 UV 模板"""
        # 临时设置所有面为单一材质
        temp_mat = bpy.data.materials.new(name="UVTemplate")
        temp_mat.use_nodes = True
        nodes = temp_mat.node_tree.nodes
        
        # 创建纯色材质
        principled = nodes.get('Principled BSDF')
        if principled:
            principled.inputs['Base Color'].default_value = (1, 1, 1, 1)
        
        # 应用材质
        if obj.data.materials:
            obj.data.materials[0] = temp_mat
        else:
            obj.data.materials.append(temp_mat)
        
        # 导出 UV 布局
        manager = UVLayoutManager()
        manager.export_uv_layout(output_path, resolution=(4096, 4096))
        
        # 恢复
        bpy.data.materials.remove(temp_mat)


def automate_uv_workflow(objects):
    """自动化 UV 工作流程"""
    tool = UVAutomationTool()
    
    # 批量展开
    tool.batch_unwrap(
        objects,
        method='smart',
        angle_limit=75,
        island_margin=0.03,
        area_weight=1.0,
        correct_aspect=True
    )
    
    # 选择并优化
    checker = UVChecker()
    checker.select_distorted_faces(distortion_threshold=2.0)
    
    # 重新展开选中的面
    bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.uv.unwrap(
        method='ANGLE_BASED',
        fill_holes=True,
        correct_aspect=True,
        margin=0.05
    )
    
    # 打包
    manager = UVLayoutManager()
    manager.pack_uv_islands(margin=0.02)
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return True
```
