# mathutils.interpolate - Interpolation Utilities Module

interpolate模块提供了各种插值功能，包括曲线插值、面片插值和散乱数据插值。

## 概述

mathutils.interpolate提供了在Blender中进行数据插值的实用工具。这些函数支持不同类型的插值需求，从简单的线性插值到复杂的三维曲面插值。

## 核心功能

### 曲线插值

```python
import bpy
import mathutils
from mathutils.interpolate import bezier_curve_easing
```
def linear_interpolate(start, end, factor):
    """线性插值"""
    return start + (end - start) * factor

def ease_in_quad(t):
    """二次缓动进入"""
    return t * t

def ease_out_quad(t):
    """二次缓动退出"""
    return t * (2 - t)

def ease_in_out_cubic(t):
    """三次缓动进出"""
    return 4 * t * t * t if t < 0.5 else 1 - pow(-2 * t + 2, 3) / 2

def bezier_ease(t, easing=0):
    """贝塞尔曲线缓动"""
    return bezier_curve_easing(t, easing)
```

### 三维插值

```python
def interpolate_vector_list(vectors, factor):
    """插值向量列表"""
    result = []
    for i, v in enumerate(vectors):
        result.append(linear_interpolate(vectors[0], vectors[-1], factor))
    return result

def interpolate_between_points(points, num_steps):
    """在多个点之间插值生成路径"""
    if len(points) < 2:
        return points
    path = []
    for i in range(len(points) - 1):
        for j in range(num_steps):
            t = j / (num_steps - 1)
            path.append(linear_interpolate(points[i], points[i+1], t))
    return path

def interpolate_surface(grid, u, v):
    """双线性表面插值"""
    x00 = grid[0][0]
    x10 = grid[1][0]
    x01 = grid[0][1]
    x11 = grid[1][1]
    top = linear_interpolate(x00, x10, u)
    bottom = linear_interpolate(x01, x11, u)
    return linear_interpolate(top, bottom, v)
```

### 散乱数据插值

```python
def interpolate_from_scatter(coords, values, target_point, kernel='shepard'):
    """散乱数据插值"""
    weights = []
    total_weight = 0
    for coord, value in zip(coords, values):
        dist = (coord - target_point).length
        if dist > 0:
            weight = 1.0 / (dist ** 2)
            weights.append(value * weight)
            total_weight += weight
    if total_weight > 0:
        return sum(weights) / total_weight
    return values[0] if values else None

def idw_interpolation(points, values, target, power=2):
    """反距离加权插值"""
    numerator = 0
    denominator = 0
    for p, v in zip(points, values):
        dist = (p - target).length
        if dist > 0:
            weight = 1.0 / (dist ** power)
            numerator += v * weight
            denominator += weight
    return numerator / denominator if denominator > 0 else 0
```

## 实用函数

### 动画路径插值

```python
def create_smooth_path(points, num_interpolations=10):
    """创建平滑动画路径"""
    if len(points) < 2:
        return points
    path = []
    for i in range(len(points) - 1):
        segment = create_bezier_segment(
            points[i],
            points[i],
            points[i+1],
            points[i+1],
            num_interpolations
        )
        path.extend(segment[1:])
    return path

def create_bezier_segment(p0, p1, p2, p3, num_points):
    """创建三次贝塞尔曲线段"""
    t_values = [i / (num_points - 1) for i in range(num_points)]
    curve = []
    for t in t_values:
        curve.append(bezier(p0, p1, p2, p3, t))
    return curve

def bezier(p0, p1, p2, p3, t):
    """三次贝塞尔曲线公式"""
    mt = 1 - t
    return (mt**3 * p0 + 
            3 * mt**2 * t * p1 + 
            3 * mt * t**2 * p2 + 
            t**3 * p3)
```

### 颜色插值

```python
def interpolate_color(color1, color2, factor):
    """插值颜色"""
    return type(color1)(
        color1[0] + (color2[0] - color1[0]) * factor,
        color1[1] + (color2[1] - color1[1]) * factor,
        color1[2] + (color2[2] - color1[2]) * factor,
        color1[3] + (color2[3] - color1[3]) * factor if len(color1) > 3 else 1.0
    )

def gradient_colors(colors, num_steps):
    """生成渐变颜色序列"""
    gradient = []
    segment_length = num_steps // (len(colors) - 1)
    for i in range(len(colors) - 1):
        for j in range(segment_length):
            factor = j / segment_length
            gradient.append(interpolate_color(colors[i], colors[i+1], factor))
    return gradient
```

### 权重插值

```python
def interpolate_vertex_weights(weights1, weights2, factor):
    """插值顶点权重"""
    return [w1 + (w2 - w1) * factor for w1, w2 in zip(weights1, weights2)]

def blend_weights(weight_dict1, weight_dict2, factor):
    """混合两组权重"""
    all_vertices = set(weight_dict1.keys()) | set(weight_dict2.keys())
    result = {}
    for v in all_vertices:
        w1 = weight_dict1.get(v, 0)
        w2 = weight_dict2.get(v, 0)
        result[v] = w1 + (w2 - w1) * factor
    return result

def normalize_weights(weights):
    """归一化权重"""
    total = sum(weights.values())
    if total > 0:
        return {k: v / total for k, v in weights.items()}
    return weights
```

## 常见问题排查

### 插值不稳定

结果出现NaN或无穷大：
- 检查输入值是否有效
- 避免除以零的距离值
- 使用epsilon值防止除零

### 性能问题

插值计算太慢：
- 对于实时计算，减少插值点数量
- 预计算常用插值曲线
- 使用向量化操作代替循环

### 边界问题

插值超出预期范围：
- 确保factor在0到1之间
- 使用clamp函数限制factor范围
- 检查输入数据的有效性

### 颜色插值异常

颜色值超出0-1范围：
- 插值后使用clamp限制范围
- 确保输入颜色值有效
- 使用正确的颜色空间
