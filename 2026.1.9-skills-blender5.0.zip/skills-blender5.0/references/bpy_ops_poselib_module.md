# bpy.ops.poselib 模块

姿态库操作模块，用于管理、保存和应用骨骼姿态。

## 概述

bpy.ops.poselib 模块包含用于创建和管理姿态库的运算符。姿态库允许你保存和重用骨骼的各种姿态，方便动画制作和角色动作管理。

## 常用操作

### 姿态库管理

```python
import bpy

# 读取姿态库
bpy.ops.poselib.read(filepath="path/to/pose_library.blend")

# 写入姿态库
bpy.ops.poselib.write(filepath="path/to/pose_library.blend")

# 读取所有姿态
bpy.ops.poselib.read_internally(filepath="path/to/file.blend")

# 导出姿态
bpy.ops.poselib.pose_export(filepath="path/to/pose.json")

# 导入姿态
bpy.ops.poselib.pose_import(filepath="path/to/pose.json")
```

### 姿态操作

```python
# 添加当前姿态
bpy.ops.poselib.pose_add(name='NewPose')

# 删除姿态
bpy.ops.poselib.pose_remove(pose_index=0)

# 重命名姿态
bpy.ops.poselib.pose_rename(old_name='OldName', new_name='NewName')

# 复制姿态
bpy.ops.poselib.pose_copy()

# 粘贴姿态
bpy.ops.poselib.pose_paste()

# 应用姿态
bpy.ops.poselib.apply_pose(pose_index=0)
```

### 姿态插值

```python
# 插值到姿态
bpy.ops.poselib.pose_blend(pose_index=0, factor=0.5)

# 混合姿态
bpy.ops.poselib.pose_mix(pose1_index=0, pose2_index=1, factor=0.5)

# 姿态循环
bpy.ops.poselib.pose_cyclic(factor=1.0)
```

## 实际应用示例

### 创建姿态库

```python
def create_pose_library(armature_obj, pose_names):
    """创建姿态库"""
    # 确保选中骨架
    bpy.context.view_layer.objects.active = armature_obj
    armature_obj.select_set(True)
    
    # 进入姿态模式
    bpy.ops.object.mode_set(mode='POSE')
    
    # 为每个名称创建姿态
    for i, pose_name in enumerate(pose_names):
        # 设置姿态
        set_specific_pose(armature_obj, i)
        
        # 添加到姿态库
        bpy.ops.poselib.pose_add(name=pose_name)
    
    return armature_obj.data.poselib

def set_specific_pose(armature_obj, pose_index):
    """设置特定姿态"""
    # 根据索引设置不同的姿态
    if pose_index == 0:
        # T字姿态
        set_t_pose(armature_obj)
    elif pose_index == 1:
        # 休息姿态
        set_rest_pose(armature_obj)
    elif pose_index == 2:
        # 行走姿态
        set_walk_pose(armature_obj)

def set_t_pose(armature_obj):
    """设置T字姿态"""
    for bone in armature_obj.pose.bones:
        bone.rotation_mode = 'XYZ'
        bone.rotation_euler = (0, 0, 0)
        bone.location = (0, 0, 0)

def set_rest_pose(armature_obj):
    """设置休息姿态"""
    for bone in armature_obj.pose.bones:
        bone.rotation_mode = 'XYZ'
        bone.rotation_euler = (0, 0, 0)
        if 'arm' in bone.name.lower():
            bone.rotation_euler = (0, 0, -0.3)
        if 'leg' in bone.name.lower():
            bone.rotation_euler = (0, 0, 0.1)
```

### 保存所有姿态

```python
def save_all_poses(armature_obj, filepath):
    """保存所有姿态到文件"""
    # 确保选中骨架
    bpy.context.view_layer.objects.active = armature_obj
    
    # 保存姿态库
    bpy.ops.poselib.write(filepath=filepath)
```

### 加载姿态库

```python
def load_pose_library(filepath):
    """加载姿态库"""
    # 读取姿态库文件
    bpy.ops.poselib.read(filepath=filepath)
    
    # 返回姿态库
    return bpy.context.scene.poselib
```

### 应用姿态动画

```python
def apply_pose_sequence(armature_obj, pose_indices, frame_duration=10):
    """应用姿态序列动画"""
    # 确保选中骨架
    bpy.context.view_layer.objects.active = armature_obj
    armature_obj.select_set(True)
    
    # 进入姿态模式
    bpy.ops.object.mode_set(mode='POSE')
    
    current_frame = 1
    
    for pose_index in pose_indices:
        # 应用姿态
        bpy.ops.poselib.apply_pose(pose_index=pose_index)
        
        # 插入关键帧
        for bone in armature_obj.pose.bones:
            bone.keyframe_insert(data_path='rotation_euler', frame=current_frame)
            bone.keyframe_insert(data_path='location', frame=current_frame)
        
        # 移动到下一帧
        current_frame += frame_duration
```

### 创建姿态过渡

```python
def create_pose_transition(armature_obj, from_pose_index, to_pose_index, duration=10):
    """创建姿态过渡动画"""
    # 确保选中骨架
    bpy.context.view_layer.objects.active = armature_obj
    armature_obj.select_set(True)
    
    # 进入姿态模式
    bpy.ops.object.mode_set(mode='POSE')
    
    # 设置起始姿态
    bpy.ops.poselib.apply_pose(pose_index=from_pose_index)
    
    start_frame = bpy.context.scene.frame_current
    
    # 设置结束姿态
    bpy.ops.poselib.apply_pose(pose_index=to_pose_index)
    
    end_frame = start_frame + duration
    
    # 插值中间帧
    bpy.ops.poselib.pose_blend(pose_index=to_pose_index, factor=0.5)
    
    # 插入关键帧
    for bone in armature_obj.pose.bones:
        bone.keyframe_insert(data_path='rotation_euler', frame=start_frame)
        bone.keyframe_insert(data_path='location', frame=start_frame)
        bone.keyframe_insert(data_path='rotation_euler', frame=end_frame)
        bone.keyframe_insert(data_path='location', frame=end_frame)
```

### 批量处理姿态

```python
def batch_process_poses(armature_obj, process_func):
    """批量处理姿态"""
    # 获取姿态库
    poselib = armature_obj.data.poselib
    
    # 保存原始姿态
    save_current_pose(armature_obj)
    
    # 处理每个姿态
    for i in range(len(poselib.pose_markers)):
        # 应用姿态
        bpy.ops.poselib.apply_pose(pose_index=i)
        
        # 应用处理函数
        process_func(armature_obj)
        
        # 重新保存姿态
        poselib.pose_markers[i].pose_library.pose_markers[i].name = poselib.pose_markers[i].name
        save_current_pose(armature_obj)

def save_current_pose(armature_obj):
    """保存当前姿态"""
    # 在当前帧保存姿态
    for bone in armature_obj.pose.bones:
        bone.keyframe_insert(data_path='rotation_euler')
        bone.keyframe_insert(data_path='location')
```

### 创建随机姿态

```python
def create_random_poses(armature_obj, count=10):
    """创建随机姿态库"""
    # 确保选中骨架
    bpy.context.view_layer.objects.active = armature_obj
    armature_obj.select_set(True)
    
    # 进入姿态模式
    bpy.ops.object.mode_set(mode='POSE')
    
    import random
    
    for i in range(count):
        # 随机设置每个骨骼的姿态
        for bone in armature_obj.pose.bones:
            if not bone.lock_rotation[0]:
                bone.rotation_euler.x = random.uniform(-0.5, 0.5)
            if not bone.lock_rotation[1]:
                bone.rotation_euler.y = random.uniform(-0.5, 0.5)
            if not bone.lock_rotation[2]:
                bone.rotation_euler.z = random.uniform(-0.5, 0.5)
        
        # 添加到姿态库
        bpy.ops.poselib.pose_add(name=f'RandomPose_{i}')
```

### 镜像姿态

```python
def mirror_pose_library(armature_obj):
    """镜像姿态库"""
    # 获取姿态库
    poselib = armature_obj.data.poselib
    
    # 遍历所有姿态
    for marker in poselib.pose_markers:
        # 应用姿态
        bpy.ops.poselib.apply_pose(pose_index=marker.index)
        
        # 镜像每个骨骼
        for bone in armature_obj.pose.bones:
            # 检查是否是对称骨骼
            if bone.name.endswith('.L') or bone.name.endswith('.L'):
                # 获取对称骨骼
                mirror_name = bone.name.replace('.L', '.R').replace('.R', '.L')
                mirror_bone = armature_obj.pose.bones.get(mirror_name)
                
                if mirror_bone:
                    # 镜像旋转
                    mirror_bone.rotation_euler.x = bone.rotation_euler.x
                    mirror_bone.rotation_euler.y = bone.rotation_euler.y
                    mirror_bone.rotation_euler.z = -bone.rotation_euler.z
        
        # 添加镜像姿态
        bpy.ops.poselib.pose_add(name=f'{marker.name}_Mirror')
```

### 导出姿态为JSON

```python
def export_poses_to_json(armature_obj, filepath):
    """导出姿态为JSON文件"""
    # 确保选中骨架
    bpy.context.view_layer.objects.active = armature_obj
    
    # 导出姿态
    bpy.ops.poselib.pose_export(filepath=filepath)

def import_poses_from_json(armature_obj, filepath):
    """从JSON文件导入姿态"""
    # 确保选中骨架
    bpy.context.view_layer.objects.active = armature_obj
    armature_obj.select_set(True)
    
    # 导入姿态
    bpy.ops.poselib.pose_import(filepath=filepath)
```

### 创建姿态预览动画

```python
def create_pose_preview_animation(armature_obj, fps=12, frames_per_pose=8):
    """创建姿态预览动画"""
    # 确保选中骨架
    bpy.context.view_layer.objects.active = armature_obj
    armature_obj.select_set(True)
    
    # 进入姿态模式
    bpy.ops.object.mode_set(mode='POSE')
    
    # 获取姿态库
    poselib = armature_obj.data.poselib
    pose_count = len(poselib.pose_markers)
    
    # 设置帧率
    bpy.context.scene.render.fps = fps
    
    current_frame = 1
    
    for i, marker in enumerate(poselib.pose_markers):
        # 应用姿态
        bpy.ops.poselib.apply_pose(pose_index=marker.index)
        
        # 在每帧插入关键帧
        for j in range(frames_per_pose):
            frame = current_frame + j
            bpy.context.scene.frame_set(frame)
            
            for bone in armature_obj.pose.bones:
                bone.keyframe_insert(data_path='rotation_euler', frame=frame)
                bone.keyframe_insert(data_path='location', frame=frame)
        
        current_frame += frames_per_pose
    
    # 设置场景帧范围
    bpy.context.scene.frame_end = current_frame - 1
```

## 使用场景

- **角色动画**：保存和重用角色姿态
- **动作捕捉**：处理动作捕捉数据
- **游戏开发**：导出姿态用于游戏引擎
- **动画制作**：快速创建姿态转换
- **角色设计**：探索不同的姿态选项
- **批量处理**：自动化姿态处理流程
- **姿态预览**：创建姿态预览动画
- **数据交换**：与其他软件交换姿态数据
- **版本管理**：管理不同版本姿态
- **团队协作**：共享姿态库

## 注意事项

- 姿态库需要在骨架数据中创建
- 应用姿态前需要进入姿态模式
- 骨骼名称必须一致才能正确应用
- 镜像姿态需要对称骨骼命名
- 大型姿态库需要组织管理
- 导出前应验证姿态完整性
- 定期备份姿态库文件
- 注意骨骼约束对姿态的影响
- 锁定骨骼不会被姿态影响
- 插值动画需要平滑的关键帧
