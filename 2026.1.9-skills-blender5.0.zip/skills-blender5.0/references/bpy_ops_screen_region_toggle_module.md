# bpy.ops.screen - 区域切换操作模块

Blender屏幕区域切换操作符，用于控制编辑器区域的显示和隐藏。

## 概述

`bpy.ops.screen.region_toggle` 模块提供用于切换Blender编辑器区域显示状态的功能，包括工具栏、侧边栏、面板等区域的显示控制。

## 核心功能

### 区域切换

```python
import bpy

# 切换工具栏
bpy.ops.screen.region_toggle(
    region_type='TOOL_PROPS'
)

# 切换侧边栏
bpy.ops.screen.region_toggle(
    region_type='UI'
)

# 切换导航面板
bpy.ops.screen.region_toggle(
    region_type='NAVIGATION_REGION'
)

# 切换头部区域
bpy.ops.screen.region_toggle(
    region_type='HEADER'
)

# 切换脚部区域
bpy.ops.screen.region_toggle(
    region_type='FOOTER'
)
```

### 工具栏切换

```python
# 打开工具栏
bpy.ops.screen.region_toggle(
    region_type='TOOL_PROPS'
)

# 关闭工具栏
bpy.ops.screen.region_toggle(
    region_type='TOOL_PROPS'
)

# 切换工具栏
def toggle_toolbar():
    bpy.ops.screen.region_toggle(region_type='TOOL_PROPS')
```

### UI区域切换

```python
# 打开侧边栏
bpy.ops.screen.region_toggle(
    region_type='UI'
)

# 关闭侧边栏
bpy.ops.screen.region_toggle(
    region_type='UI'
)

# 切换侧边栏
def toggle_sidebar():
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_ui = not space.show_region_ui
```

### 导航区域切换

```python
# 打开导航面板
bpy.ops.screen.region_toggle(
    region_type='NAVIGATION_REGION'
)

# 关闭导航面板
bpy.ops.screen.region_toggle(
    region_type='NAVIGATION_REGION'
)
```

### 头部区域切换

```python
# 切换头部
bpy.ops.screen.region_toggle(
    region_type='HEADER'
)

# 显示头部
def show_header():
    for area in bpy.context.screen.areas:
        area.show_menus = True

# 隐藏头部
def hide_header():
    for area in bpy.context.screen.areas:
        area.show_menus = False
```

### 脚部区域切换

```python
# 切换脚部
bpy.ops.screen.region_toggle(
    region_type='FOOTER'
)
```

## 实用函数

```python
def toggle_toolshelf():
    """切换工具架"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = not space.show_region_toolbar

def toggle_ui_panel():
    """切换UI面板"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_ui = not space.show_region_ui

def toggle_navigation():
    """切换导航面板"""
    bpy.ops.screen.region_toggle(region_type='NAVIGATION_REGION')

def show_all_regions():
    """显示所有区域"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = True
            space.show_region_ui = True
            space.show_region_header = True

def hide_all_regions():
    """隐藏所有区域"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = False
            space.show_region_ui = False
            space.show_region_header = False

def maximize_3d_view():
    """最大化3D视图"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = False
            space.show_region_ui = False
            space.show_region_header = False

def restore_regions():
    """恢复区域显示"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = True
            space.show_region_ui = True
            space.show_region_header = True

def toggle_fullscreen():
    """切换全屏"""
    bpy.ops.screen.screen_full_area()
```

## 常见问题排查

### 区域不显示
```python
# 检查区域状态
space = bpy.context.area.spaces.active
print(f"工具架: {space.show_region_toolbar}")
print(f"UI面板: {space.show_region_ui}")
print(f"头部: {space.show_region_header}")

# 启用所有区域
space.show_region_toolbar = True
space.show_region_ui = True
space.show_region_header = True

# 检查区域类型
print(f"区域类型: {bpy.context.area.type}")

# 确保在3D视图
if bpy.context.area.type != 'VIEW_3D':
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            bpy.context.window.screen.areas[0] = area
            break
```

### 区域切换无响应
```python
# 检查区域类型
print(f"当前区域类型: {bpy.context.area.type}")

# 检查区域是否存在
region_types = ['TOOL_PROPS', 'UI', 'NAVIGATION_REGION', 'HEADER', 'FOOTER']
for rtype in region_types:
    print(f"{rtype}: 支持")

# 重置视图
bpy.ops.screen.screen_full_area(use_hide_panels=False)

# 刷新UI
bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
```

### 全屏问题
```python
# 检查全屏状态
space = bpy.context.area.spaces.active
print(f"全屏: {space.use_fullscreen}")

# 退出全屏
if space.use_fullscreen:
    bpy.ops.screen.screen_full_area(use_hide_panels=False)

# 切换全屏
bpy.ops.screen.screen_full_area(use_hide_panels=True)
```

### 区域布局混乱
```python
# 重置工作区
bpy.ops.wm.read_homefile(use_empty=True)

# 重置当前工作区
bpy.ops.wm.read_homefile()

# 保存当前布局为默认
# 在Blender中: 工作区 -> 保存为默认
```
