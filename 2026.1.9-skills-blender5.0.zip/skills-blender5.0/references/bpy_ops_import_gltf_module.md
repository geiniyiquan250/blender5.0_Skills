# bpy.ops.import_gltf - GLTF导入操作模块

Blender GLTF格式导入操作符，用于从glTF/glb文件导入场景和模型。

## 概述

`bpy.ops.import_gltf` 模块提供用于将glTF 2.0标准格式文件导入Blender的功能，支持glb、gltf和嵌入式格式。

## 核心功能

### 基础导入

```python
import bpy

# 导入GLB文件
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_pack_images=True,
    merge_vertices=False,
    import_shading='ORIGINAL',
    import_colors=True,
    import_cameras=True,
    import_lights=True,
    import_materials=True,
    import_modifiers=True,
    import_normals=True,
    import_animations=True,
    import_current_frame=True
)

# 导入glTF文件
bpy.ops.import_gltf(
    filepath='//model.gltf',
    import_pack_images=True
)

# 导入并合并顶点
bpy.ops.import_gltf(
    filepath='//model.glb',
    merge_vertices=True
)
```

### 图像处理选项

```python
# 打包图像到blend文件
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_pack_images=True
)

# 不打包图像
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_pack_images=False
)

# 保留外部纹理
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_pack_images=False
)
```

### 几何体处理

```python
# 合并顶点
bpy.ops.import_gltf(
    filepath='//model.glb',
    merge_vertices=True,
    tolerance=0.001
)

# 导入法线
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_normals=True
)

# 不导入法线
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_normals=False
)

# 导入变形目标
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_morph=True
)

# 导入顶点颜色
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_colors=True
)
```

### 材质和着色

```python
# 使用原始着色
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_shading='ORIGINAL'
)

# 转换为标准着色
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_shading='VERTEX'
)

# 转换为面着色
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_shading='FACE'
)

# 导入材质
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_materials=True
)

# 不导入材质
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_materials=False
)
```

### 导入修改器

```python
# 导入修改器
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_modifiers=True
)

# 不导入修改器
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_modifiers=False
)
```

### 动画导入

```python
# 导入动画
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_animations=True
)

# 不导入动画
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_animations=False
)

# 导入到当前帧
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_current_frame=True
)

# 设置导入帧范围
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_animations=True,
    import_frame_range=(1, 100)
)
```

### 相机和灯光

```python
# 导入相机
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_cameras=True
)

# 导入灯光
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_lights=True
)

# 不导入相机
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_cameras=False
)

# 不导入灯光
bpy.ops.import_gltf(
    filepath='//model.glb',
    import_lights=False
)
```

## 实用函数

```python
def import_gltf_model(filepath):
    """导入GLTF模型"""
    bpy.ops.import_gltf(
        filepath=filepath,
        import_pack_images=True,
        import_shading='ORIGINAL',
        import_materials=True,
        import_normals=True,
        import_animations=True,
        import_cameras=True,
        import_lights=True
    )
    return list(bpy.context.selected_objects)

def import_gltf_for_editing(filepath):
    """导入GLTF用于编辑"""
    bpy.ops.import_gltf(
        filepath=filepath,
        import_pack_images=False,
        merge_vertices=False,
        import_shading='ORIGINAL',
        import_materials=True,
        import_normals=True,
        import_modifiers=False,
        import_animations=False
    )
    return list(bpy.context.selected_objects)

def import_gltf_with_animations(filepath):
    """导入GLTF带动画"""
    bpy.ops.import_gltf(
        filepath=filepath,
        import_pack_images=True,
        import_shading='ORIGINAL',
        import_materials=True,
        import_normals=True,
        import_morph=True,
        import_animations=True,
        import_colors=True
    )
    return list(bpy.context.selected_objects)

def import_gltf_and_merge(filepath):
    """导入GLTF并合并顶点"""
    bpy.ops.import_gltf(
        filepath=filepath,
        merge_vertices=True,
        tolerance=0.0001,
        import_pack_images=False,
        import_materials=True
    )
    return list(bpy.context.selected_objects)

def batch_import_gltf_files(filepaths):
    """批量导入GLTF文件"""
    all_objects = []
    for filepath in filepaths:
        bpy.ops.import_gltf(filepath=filepath)
        imported = list(bpy.context.selected_objects)
        all_objects.extend(imported)
    return all_objects

def import_gltf_optimized(filepath):
    """导入优化版本"""
    bpy.ops.import_gltf(
        filepath=filepath,
        import_pack_images=True,
        merge_vertices=True,
        import_shading='ORIGINAL',
        import_normals=True,
        import_morph=True,
        import_colors=True,
        import_modifiers=True
    )
    return list(bpy.context.selected_objects)
```

## 常见问题排查

### 导入后模型不可见
```python
# 检查选中对象
selected = bpy.context.selected_objects
print(f"导入对象数: {len(selected)}")

# 检查对象类型
for obj in selected:
    print(f"{obj.name}: 类型={obj.type}")

# 检查隐藏状态
for obj in selected:
    print(f"{obj.name}: 隐藏={obj.hide_viewport}")

# 显示所有对象
bpy.ops.object.select_all(action='SELECT')
for obj in bpy.context.selected_objects:
    obj.hide_viewport = False
```

### 纹理丢失
```python
# 检查材质
obj = bpy.context.active_object
if obj.data.materials:
    for mat in obj.data.materials:
        print(f"材质: {mat.name}")
        if mat.use_nodes:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE':
                    print(f"纹理: {node.image}")

# 重新导入并打包图像
bpy.ops.import_gltf(filepath='//model.glb', import_pack_images=True)

# 检查纹理路径
print(f"纹理路径: {bpy.path.abspath('//')}")
```

### 动画不播放
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 检查帧范围
if obj.animation_data.action:
    print(f"帧范围: {obj.animation_data.action.frame_range}")

# 启用动画播放
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = 250

# 检查NLA
for track in obj.animation_data.nla_tracks:
    print(f"NLA轨道: {track.name}")
```

### 材质显示问题
```python
# 检查着色设置
space = bpy.context.area.spaces.active
print(f"着色类型: {space.shading.type}")

# 切换到材质预览
space.shading.type = 'MATERIAL'

# 检查材质节点
mat = bpy.context.active_object.active_material
if mat and mat.use_nodes:
    bsdf = mat.node_tree.nodes.get('Principled BSDF')
    if bsdf:
        print(f"基础颜色: {bsdf.inputs['Base Color'].default_value}")

# 重新导入原始着色
bpy.ops.import_gltf(filepath='//model.glb', import_shading='ORIGINAL')
```
