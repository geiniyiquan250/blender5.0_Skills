# bpy.ops.animation - Animation Operations Module

Blender 动画操作符，用于创建、编辑和管理动画关键帧、动画曲线和动画播放。

## Overview

`bpy.ops.animation` 模块包含动画编辑器中的所有操作命令，涵盖关键帧操作、动画曲线编辑、时间轴控制、播放和导出等功能。

## 核心功能

### 关键帧操作

```python
import bpy

# 插入关键帧
bpy.ops.anim.keyframe_insert(type='Location')
bpy.ops.anim.keyframe_insert(type='Rotation')
bpy.ops.anim.keyframe_insert(type='Scaling')
bpy.ops.anim.keyframe_insert(type='Location, Rotation, Scaling')

# 删除关键帧
bpy.ops.anim.keyframe_delete(type='Location')
bpy.ops.anim.keyframe_delete(type='Rotation')
bpy.ops.anim.keyframe_delete(type='Scaling')

# 删除所有关键帧
bpy.ops.anim.keyframe_delete_v3d()

# 清除关键帧
bpy.ops.anim.keyframe_clear(type='Location')
bpy.ops.anim.keyframe_clear(type='Rotation')
bpy.ops.anim.keyframe_clear(type='Scaling')

def insert_keyframe_at_frame(obj, frame, data_path, value):
    """在指定帧插入关键帧"""
    bpy.context.scene.frame_set(frame)
    
    # 设置值
    if '.' in data_path:
        parts = data_path.split('.')
        if parts[0] == 'location':
            obj.location = eval(value)
        elif parts[0] == 'rotation_euler':
            obj.rotation_euler = eval(value)
        elif parts[0] == 'rotation_quaternion':
            obj.rotation_quaternion = eval(value)
        elif parts[0] == 'scale':
            obj.scale = eval(value)
    else:
        setattr(obj, data_path, value)
    
    # 插入关键帧
    bpy.ops.anim.keyframe_insert(data_path=data_path)
    
    return True

def insert_keyframe_for_object(obj, frame):
    """为对象的所有变换插入关键帧"""
    bpy.context.scene.frame_set(frame)
    
    # 插入位置
    obj.keyframe_insert(data_path="location", frame=frame)
    obj.keyframe_insert(data_path="rotation_euler", frame=frame)
    obj.keyframe_insert(data_path="scale", frame=frame)
    
    return True
```

### 动画曲线操作

```python
# 选择所有关键帧
bpy.ops.anim.select_all(action='SELECT')

# 取消选择
bpy.ops.anim.select_all(action='DESELECT')

# 反选
bpy.ops.anim.select_all(action='INVERT')

# 选择关键帧
bpy.ops.anim.select_border(gesture_mode=0, xmin=0, xmax=100, ymin=0, ymax=100)

# 关键帧类型
bpy.ops.anim.keyframe_type(type='KEYFRAME')
bpy.ops.anim.keyframe_type(type='BREAKDOWN')
bpy.ops.anim.keyframe_type(type='EXTREME')
bpy.ops.anim.keyframe_type(type='JITTER')

# 添加衰减
bpy.ops.anim.keyframe_insert(type='Location')

# 清洁关键帧
bpy.ops.anim.cleankeyframes(threshold=0.001, channels=False)

# 清洁曲线
bpy.ops.anim.channels_clean_empty()

# 展开所有
bpy.ops.anim.channels_expand()

# 折叠所有
bpy.ops.anim.channels_collapse()

# 切换选择
bpy.ops.anim.channels_select_all(action='TOGGLE')

# 反转选择
bpy.ops.anim.channels_select_all(action='INVERT')

# 选择层级
bpy.ops.anim.channels_select_hierarchy(direction='UP')
bpy.ops.anim.channels_select_hierarchy(direction='DOWN')
```

### 时间轴操作

```python
# 播放
bpy.ops.screen.animation_play(reverse=False, speed=1.0)

# 暂停
bpy.ops.screen.animation_play(reverse=True)

# 跳转到开始
bpy.ops.screen.frame_jump(end=False)

# 跳转到结束
bpy.ops.screen.frame_jump(end=True)

# 跳转到前一关键帧
bpy.ops.screen.keyframe_jump(next=False)

# 跳转到下一关键帧
bpy.ops.screen.keyframe_jump(next=True)

# 插入帧
bpy.ops.screen.frame_offset(delta=1)

# 删除帧
bpy.ops.screen.delete()

# 拆分帧
bpy.ops.screen.split()

# 添加标记
bpy.ops.marker.add()

# 转到标记
bpy.ops.marker.jump_to_next()
bpy.ops.marker.jump_to_prev()

def goto_frame(frame):
    """跳转到指定帧"""
    bpy.context.scene.frame_set(frame)

def play_animation():
    """播放动画"""
    bpy.ops.screen.animation_play(reverse=False)

def stop_animation():
    """停止动画"""
    bpy.ops.screen.animation_play(reverse=True)
```

### 动画选择

```python
# 选择可见动画
bpy.ops.anim.select_filter_by_valid_data(data_filter=True)

# 清除选择过滤器
bpy.ops.anim.clear_poseleec()

# 转到活动对象
bpy.ops.anim.go_to_node(action='FIRST')
bpy.ops.anim.go_to_node(action='LAST')
bpy.ops.anim.go_to_node(action='LEFT')
bpy.ops.anim.go_to_node(action='RIGHT')
bpy.ops.anim.go_to_node(action='UP')
bpy.ops.anim.go_to_node(action='DOWN')
```

## 动画编辑

### 关键帧编辑

```python
import bpy

def copy_keyframes(source_obj, dest_obj, data_path="location"):
    """复制关键帧"""
    # 获取源对象的关键帧
    source_fcurves = []
    if source_obj.animation_data:
        for fcurve in source_obj.animation_data.action.fcurves:
            if data_path in fcurve.data_path:
                source_fcurves.append(fcurve)
    
    if not source_fcurves:
        return False
    
    # 确保目标有动画数据
    if not dest_obj.animation_data:
        dest_obj.animation_data_create()
    
    # 获取或创建动作
    if not dest_obj.animation_data.action:
        dest_obj.animation_data.action = bpy.data.actions.new(name=f"{dest_obj.name}_Action")
    
    action = dest_obj.animation_data.action
    
    # 复制关键帧
    for src_curve in source_fcurves:
        dst_curve = None
        for dst_fcurve in action.fcurves:
            if dst_fcurve.data_path == src_curve.data_path:
                dst_curve = dst_fcurve
                break
        
        if not dst_curve:
            dst_curve = action.fcurves.new(data_path=src_curve.data_path)
        
        # 复制关键帧点
        dst_curve.keyframe_points.add(len(src_curve.keyframe_points))
        for i, kp in enumerate(src_curve.keyframe_points):
            dst_kp = dst_curve.keyframe_points[i]
            dst_kp.co = kp.co
            dst_kp.handle_left = kp.handle_left
            dst_kp.handle_right = kp.handle_right
            dst_kp.interpolation = kp.interpolation
            dst_kp.easing = kp.easing
    
    return True

def move_keyframes(obj, data_path, frame_offset):
    """移动关键帧"""
    if not obj.animation_data or not obj.animation_data.action:
        return False
    
    for fcurve in obj.animation_data.action.fcurves:
        if data_path in fcurve.data_path:
            for kp in fcurve.keyframe_points:
                kp.co_ui.x += frame_offset
    
    return True

def scale_keyframes(obj, data_path, scale_factor, pivot_frame=None):
    """缩放关键帧"""
    if not obj.animation_data or not obj.animation_data.action:
        return False
    
    for fcurve in obj.animation_data.action.fcurves:
        if data_path in fcurve.data_path:
            for kp in fcurve.keyframe_points:
                if pivot_frame is None:
                    kp.co_ui.x *= scale_factor
                else:
                    # 以 pivot_frame 为中心缩放
                    distance = kp.co_ui.x - pivot_frame
                    kp.co_ui.x = pivot_frame + distance * scale_factor
    
    return True

def delete_keyframes_in_range(obj, data_path, start_frame, end_frame):
    """删除指定范围内的关键帧"""
    if not obj.animation_data or not obj.animation_data.action:
        return False
    
    for fcurve in obj.animation_data.action.fcurves:
        if data_path in fcurve.data_path:
            keyframe_points_to_remove = []
            for kp in fcurve.keyframe_points:
                if start_frame <= kp.co.x <= end_frame:
                    keyframe_points_to_remove.append(kp)
            
            for kp in keyframe_points_to_remove:
                fcurve.keyframe_points.remove(kp)
    
    return True
```

### 插值和外推

```python
import bpy

def set_interpolation(obj, data_path, interpolation='BEZIER'):
    """设置插值类型"""
    if not obj.animation_data or not obj.animation_data.action:
        return False
    
    inter_map = {
        'CONSTANT': 'CONSTANT',
        'LINEAR': 'LINEAR',
        'BEZIER': 'BEZIER',
        'SINE': 'SINE',
        'QUAD': 'QUAD',
        'CUBIC': 'CUBIC',
        'QUART': 'QUART',
        'EXPO': 'EXPO',
        'CIRC': 'CIRC',
        'BACK': 'BACK',
        'BOUNCE': 'BOUNCE',
        'ELASTIC': 'ELASTIC',
    }
    
    for fcurve in obj.animation_data.action.fcurves:
        if data_path in fcurve.data_path:
            for kp in fcurve.keyframe_points:
                if interpolation in inter_map:
                    kp.interpolation = inter_map[interpolation]
    
    return True

def set_easing(obj, data_path, easing='AUTO'):
    """设置缓动类型"""
    if not obj.animation_data or not obj.animation_data.action:
        return False
    
    easing_map = {
        'AUTO': 'AUTO',
        'EASE_IN': 'EASE_IN',
        'EASE_OUT': 'EASE_OUT',
        'EASE_IN_OUT': 'EASE_IN_OUT',
    }
    
    for fcurve in obj.animation_data.action.fcurves:
        if data_path in fcurve.data_path:
            for kp in fcurve.keyframe_points:
                if easing in easing_map:
                    kp.easing = easing_map[easing]
    
    return True

def set_extrapolation(obj, data_path, extrapolation='CONSTANT'):
    """设置外推类型"""
    if not obj.animation_data or not obj.animation_data.action:
        return False
    
    extrap_map = {
        'CONSTANT': 'CONSTANT',
        'LINEAR': 'LINEAR',
        'MAKE_CYCLIC': 'MAKE_CYCLIC',
        'MAKE_CYCLIC_OFFSET': 'MAKE_CYCLIC_OFFSET',
    }
    
    for fcurve in obj.animation_data.action.fcurves:
        if data_path in fcurve.data_path:
            if extrapolation in extrap_map:
                fcurve.extrapolation = extrap_map[extrapolation]
    
    return True

def make_cyclic(obj, data_path):
    """使动画循环"""
    set_extrapolation(obj, data_path, 'MAKE_CYCLIC')
```

### 关键帧操作符

```python
import bpy

class KeyframeOperator:
    """关键帧操作器"""
    
    @staticmethod
    def insert_keyframes(obj, frame, keyable_properties=None):
        """为对象插入关键帧"""
        bpy.context.scene.frame_set(frame)
        
        if keyable_properties is None:
            keyable_properties = ['location', 'rotation_euler', 'rotation_quaternion', 'scale']
        
        for prop in keyable_properties:
            if hasattr(obj, prop):
                obj.keyframe_insert(data_path=prop, frame=frame)
    
    @staticmethod
    def insert_keyframe_at_value(obj, frame, data_path, value):
        """在指定值处插入关键帧"""
        bpy.context.scene.frame_set(frame)
        
        # 设置值
        parts = data_path.split('.')
        if len(parts) > 1:
            if parts[0] == 'location':
                obj.location = value
            elif parts[0] == 'rotation_euler':
                obj.rotation_euler = value
            elif parts[0] == 'scale':
                obj.scale = value
        else:
            setattr(obj, data_path, value)
        
        # 插入关键帧
        obj.keyframe_insert(data_path=data_path, frame=frame)
    
    @staticmethod
    def delete_keyframes(obj, data_path=None, frame_range=None):
        """删除关键帧"""
        if not obj.animation_data:
            return
        
        action = obj.animation_data.action
        if not action:
            return
        
        fcurves = action.fcurves if data_path is None else [f for f in action.fcurves if data_path in f.data_path]
        
        for fcurve in fcurves:
            if frame_range is None:
                # 删除所有关键帧
                for kp in list(fcurve.keyframe_points):
                    fcurve.keyframe_points.remove(kp)
            else:
                # 删除范围内的关键帧
                for kp in list(fcurve.keyframe_points):
                    if frame_range[0] <= kp.co.x <= frame_range[1]:
                        fcurve.keyframe_points.remove(kp)
    
    @staticmethod
    def offset_keyframes(obj, data_path, frame_offset, value_offset=None):
        """偏移关键帧"""
        if not obj.animation_data or not obj.animation_data.action:
            return
        
        for fcurve in obj.animation_data.action.fcurves:
            if data_path in fcurve.data_path:
                for kp in fcurve.keyframe_points:
                    kp.co.x += frame_offset
                    if value_offset is not None:
                        kp.co.y += value_offset
    
    @staticmethod
    def mirror_keyframes(obj, data_path, pivot_frame=None):
    镜像关键帧
        if pivot_frame is None:
            scene = bpy.context.scene
            pivot_frame = (scene.frame_end + scene.frame_start) / 2
        
        if not obj.animation_data or not obj.animation_data.action:
            return
        
        for fcurve in obj.animation_data.action.fcurves:
            if data_path in fcurve.data_path:
                for kp in fcurve.keyframe_points:
                    distance = kp.co.x - pivot_frame
                    kp.co.x = pivot_frame - distance
    
    @staticmethod
    def blend_keyframes(obj, start_frame, end_frame, blend_type='MIX'):
        """混合关键帧"""
        # 这个功能通常需要更复杂的实现
        pass
```

## 动画播放控制

```python
import bpy

class AnimationPlayer:
    """动画播放器"""
    
    def __init__(self):
        self.is_playing = False
    
    def play(self, reverse=False, speed=1.0):
        """播放动画"""
        bpy.ops.screen.animation_play(reverse=reverse)
        self.is_playing = True
    
    def pause(self):
        """暂停动画"""
        if self.is_playing:
            bpy.ops.screen.animation_play()
            self.is_playing = False
    
    def stop(self):
        """停止动画"""
        self.pause()
        bpy.context.scene.frame_set(bpy.context.scene.frame_current)
    
    def goto_frame(self, frame):
        """跳转到指定帧"""
        bpy.context.scene.frame_set(frame)
    
    def goto_start(self):
        """跳转到开始"""
        bpy.context.scene.frame_set(bpy.context.scene.frame_start)
    
    def goto_end(self):
        """跳转到结束"""
        bpy.context.scene.frame_set(bpy.context.scene.frame_end)
    
    def step_forward(self, steps=1):
        """前进"""
        bpy.context.scene.frame_set(bpy.context.scene.frame_current + steps)
    
    def step_backward(self, steps=1):
        """后退"""
        bpy.context.scene.frame_set(bpy.context.scene.frame_current - steps)
    
    def goto_previous_keyframe(self):
        """跳转到前一关键帧"""
        bpy.ops.screen.keyframe_jump(next=False)
    
    def goto_next_keyframe(self):
        """跳转到下一关键帧"""
        bpy.ops.screen.keyframe_jump(next=True)
```

## 动画数据操作

### 动作管理

```python
import bpy

class ActionManager:
    """动作管理器"""
    
    @staticmethod
    def create_action(name, obj=None):
        """创建新动作"""
        action = bpy.data.actions.new(name=name)
        
        if obj and obj.animation_data:
            obj.animation_data.action = action
        
        return action
    
    @staticmethod
    def assign_action(obj, action):
        """为对象分配动作"""
        if not obj.animation_data:
            obj.animation_data_create()
        
        obj.animation_data.action = action
    
    @staticmethod
    def push_action(obj, action):
        """推送动作到 NLA"""
        if not obj.animation_data:
            obj.animation_data_create()
        
        if not obj.animation_data.nla_track:
            track = obj.animation_data.nla_tracks.new()
            track.name = f"{obj.name}_Track"
        
        strip = track.strips.new(action.name, action, 0)
        return strip
    
    @staticmethod
    def push_down_action(obj):
        """将动作推送到 NLA"""
        if not obj.animation_data or not obj.animation_data.action:
            return None
        
        action = obj.animation_data.action
        
        bpy.ops.nla.push_down()
        
        return action
    
    @staticmethod
    def find_unused_actions():
        """查找未使用的动作"""
        unused = []
        for action in bpy.data.actions:
            used = False
            for obj in bpy.data.objects:
                if obj.animation_data:
                    if obj.animation_data.action == action:
                        used = True
                        break
                    if obj.animation_data.nla_tracks:
                        for track in obj.animation_data.nla_tracks:
                            for strip in track.strips:
                                if strip.action == action:
                                    used = True
                                    break
                            if used:
                                break
                        if used:
                            break
            if not used:
                unused.append(action)
        
        return unused
    
    @staticmethod
    def delete_unused_actions():
        """删除所有未使用的动作"""
        unused = ActionManager.find_unused_actions()
        for action in unused:
            bpy.data.actions.remove(action)
        print(f"已删除 {len(unused)} 个未使用的动作")
    
    @staticmethod
    def merge_actions(source_action, target_action):
        """合并动作"""
        # 复制源动作的关键帧到目标动作
        for src_fcurve in source_action.fcurves:
            dst_fcurve = None
            for dst_fcurve in target_action.fcurves:
                if dst_fcurve.data_path == src_fcurve.data_path:
                    dst_fcurve = dst_fcurve
                    break
            
            if not dst_fcurve:
                dst_fcurve = target_action.fcurves.new(data_path=src_fcurve.data_path)
            
            # 复制关键帧
            dst_fcurve.keyframe_points.add(len(src_fcurve.keyframe_points))
            for i, kp in enumerate(src_fcurve.keyframe_points):
                dst_kp = dst_fcurve.keyframe_points[i]
                dst_kp.co = kp.co
                dst_kp.handle_left = kp.handle_left
                dst_kp.handle_right = kp.handle_right
    
    @staticmethod
    def copy_action(source_obj, dest_obj):
        """复制动作"""
        if not source_obj.animation_data or not source_obj.animation_data.action:
            return None
        
        source_action = source_obj.animation_data.action
        new_action = source_action.copy()
        new_action.name = f"{source_action.name}_{dest_obj.name}"
        
        ActionManager.assign_action(dest_obj, new_action)
        
        return new_action
```

### NLA 操作

```python
import bpy

class NLAManager:
    """NLA 管理器"""
    
    @staticmethod
    def create_track(obj, name):
        """创建 NLA 轨道"""
        if not obj.animation_data:
            obj.animation_data_create()
        
        track = obj.animation_data.nla_tracks.new()
        track.name = name
        
        return track
    
    @staticmethod
    def add_strip(track, action, frame_start, frame_end, name=None):
        """在轨道上添加片段"""
        if name is None:
            name = action.name
        
        strip = track.strips.new(name, action, frame_start)
        strip.frame_end = frame_end
        
        return strip
    
    @staticmethod
    def apply_action_as_nla(obj, action):
        """将动作应用为 NLA"""
        if not obj.animation_data:
            obj.animation_data_create()
        
        # 创建轨道
        track = NLAManager.create_track(obj, f"{action.name}_Track")
        
        # 添加片段
        NLAManager.add_strip(track, action, 0, action.frame_end)
        
        return track
    
    @staticmethod
    def mute_track(track, mute=True):
        """静音轨道"""
        track.mute = mute
    
    @staticmethod
    def delete_track(track):
        """删除轨道"""
        obj = track.id_data
        if obj.animation_data:
            obj.animation_data.nla_tracks.remove(track)
    
    @staticmethod
    def move_strip(strip, frame_offset):
        """移动片段"""
        strip.frame_start += frame_offset
        strip.frame_end += frame_offset
    
    @staticmethod
    def trim_strip(strip, new_start, new_end):
        """裁剪片段"""
        strip.frame_start = new_start
        strip.frame_end = new_end
    
    @staticmethod
    def blend_strips(track, blend_type='CROSS'):
        """混合片段"""
        # 复杂的混合功能
        pass
```

## 动画工程面板

```python
class AnimationPanel(bpy.types.Panel):
    """动画面板"""
    bl_label = "动画工具"
    bl_idname = "ANIMATION_PT_animation_tools"
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        layout.label(text="时间轴:")
        
        row = layout.row()
        row.operator("screen.frame_jump", text="开始").end=False
        row.operator("screen.frame_jump", text="结束").end=True
        
        row = layout.row()
        row.operator("screen.keyframe_jump", text="上一帧").next=False
        row.operator("screen.keyframe_jump", text="下一帧").next=True
        
        row = layout.row()
        row.operator("screen.animation_play", text="播放").reverse=False
        row.operator("screen.animation_play", text="暂停").reverse=True
        
        layout.separator()
        layout.label(text="关键帧:")
        
        row = layout.row(align=True)
        row.operator("anim.keyframe_insert", text="插入").type='Location, Rotation, Scaling'
        row.operator("anim.keyframe_delete", text="删除").type='Location, Rotation, Scaling'
        
        layout.separator()
        layout.label(text="选择:")
        
        row = layout.row()
        row.operator("anim.select_all", text="全选").action='SELECT'
        row.operator("anim.select_all", text="反选").action='INVERT'
        
        row = layout.row()
        row.operator("anim.keyframe_type", text="关键帧").type='KEYFRAME'
        row.operator("anim.keyframe_type", text="衰减").type='BREAKDOWN'

class KeyframeEngineeringPanel(bpy.types.Panel):
    """关键帧工程面板"""
    bl_label = "关键帧工程"
    bl_idname = "ANIMATION_PT_keyframe_engineering"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '动画'
    
    def draw(self, context):
        layout = self.layout
        obj = context.object
        
        if not obj:
            layout.label(text="请选择对象")
            return
        
        layout.label(text=f"对象: {obj.name}")
        
        layout.separator()
        layout.label(text="关键帧操作:")
        
        row = layout.row(align=True)
        row.operator("keyframe_engineering.insert_all", text="插入全部")
        row.operator("keyframe_engineering.delete_all", text="删除全部")
        
        row = layout.row()
        row.operator("keyframe_engineering.copy", text="复制")
        row.operator("keyframe_engineering.paste", text="粘贴")
        
        layout.separator()
        layout.label(text="插值:")
        
        row = layout.row()
        row.operator("keyframe_engineering.set_linear", text="线性")
        row.operator("keyframe_engineering.set_bezier", text="贝塞尔")
        
        row = layout.row()
        row.operator("keyframe_engineering.set_constant", text="常数")
        row.operator("keyframe_engineering.set_cyclic", text="循环")
```

## 最佳实践

### 1. 动画优化

```python
def optimize_keyframes(obj, threshold=0.001):
    """优化关键帧"""
    if not obj.animation_data or not obj.animation_data.action:
        return
    
    action = obj.animation_data.action
    
    for fcurve in action.fcurves:
        keyframe_points = list(fcurve.keyframe_points)
        
        for i in range(len(keyframe_points) - 1):
            curr = keyframe_points[i]
            next_kp = keyframe_points[i + 1]
            
            # 检查是否可以合并
            if abs(curr.co.y - next_kp.co.y) < threshold:
                # 计算中间帧
                mid_frame = (curr.co.x + next_kp.co.x) / 2
                mid_value = (curr.co.y + next_kp.co.y) / 2
                
                # 删除中间关键帧
                # 这里需要更复杂的逻辑
                pass
```

### 2. 动画备份

```python
def backup_animation(obj):
    """备份动画"""
    if not obj.animation_data:
        return None
    
    action = obj.animation_data.action
    if not action:
        return None
    
    # 复制动作
    backup_action = action.copy()
    backup_action.name = f"{action.name}_backup"
    
    return backup_action

def restore_animation(obj, backup_action):
    """恢复动画"""
    if not obj.animation_data:
        obj.animation_data_create()
    
    obj.animation_data.action = backup_action
```

### 3. 动画验证

```python
def validate_animation(obj):
    """验证动画"""
    issues = []
    
    if not obj.animation_data:
        issues.append("对象没有动画数据")
        return issues
    
    action = obj.animation_data.action
    if not action:
        issues.append("对象没有动作")
        return issues
    
    # 检查关键帧
    for fcurve in action.fcurves:
        if len(fcurve.keyframe_points) < 2:
            issues.append(f"曲线 {fcurve.data_path} 关键帧不足")
        
        # 检查排序
        frames = [kp.co.x for kp in fcurve.keyframe_points]
        if frames != sorted(frames):
            issues.append(f"曲线 {fcurve.data_path} 关键帧未排序")
    
    return issues
```

## 常见问题

### Q: 关键帧不工作
A: 检查对象是否有动画数据，确保在正确的帧插入关键帧。

### Q: 动画不流畅
A: 调整插值类型，使用贝塞尔或弹性缓动。

### Q: 动画无法循环
A: 设置外推类型为 `MAKE_CYCLIC`，确保首尾关键帧值一致。

## 相关模块

- [bpy.ops](bpy_ops_detailed_module.md) - Blender 操作符
- [bpy.types](bpy_types_detailed_module.md) - 数据类型
- [bpy.data](bpy_data_module.md) - 数据访问
- [bpy.context](bpy_context_module.md) - 上下文访问
