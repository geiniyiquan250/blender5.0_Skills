# bpy_extras.keyconfig_utils - 键位配置工具模块

bpy_extras.keyconfig_utils模块提供了键位配置管理、快捷键操作和自定义键位映射的实用工具函数。

## 概述

键位配置工具模块用于管理Blender的快捷键配置，支持快捷键的添加、移除、查询和导出等操作。适用于开发自定义键位映射和键位管理工具。

## 核心功能

### 键位配置管理

```python
import bpy
from bpy_extras.keyconfig_utils import (
    keyconfig_init_from_data,
    keyconfig_test
)

def get_all_keyconfigs():
    """获取所有键位配置"""
    return bpy.context.window_manager.keyconfigs

def get_user_keyconfig():
    """获取用户键位配置"""
    return bpy.context.window_manager.keyconfigs.user

def get_addon_keyconfigs():
    """获取插件键位配置"""
    return bpy.context.window_manager.keyconfigs.addon

def get_prefs_keyconfig():
    """获取默认键位配置"""
    return bpy.context.window_manager.keyconfigs.default

def get_keyconfig_by_name(name):
    """通过名称获取键位配置"""
    for kc in bpy.context.window_manager.keyconfigs:
        if kc.name == name:
            return kc
    return None
```

### 快捷键操作

```python
def add_shortcut(keyconfig, idname, type, value, shift=False, ctrl=False, alt=False, oskey=False):
    """添加快捷键"""
    if not keyconfig:
        return None
    keymap = keyconfig.keymaps.new(name='Object Mode', space_type='EMPTY')
    return keymap.keymap_items.new(
        idname=idname,
        type=type,
        value=value,
        shift=shift,
        ctrl=ctrl,
        alt=alt,
        oskey=oskey
    )

def remove_shortcut(keyconfig, idname, type=None, value=None):
    """移除快捷键"""
    for keymap in keyconfig.keymaps:
        for item in list(keymap.keymap_items):
            if item.idname == idname:
                if type is None or (item.type == type and (value is None or item.value == value)):
                    keymap.keymap_items.remove(item)

def find_shortcut(keyconfig, idname):
    """查找快捷键"""
    results = []
    for keymap in keyconfig.keymaps:
        for item in keymap.keymap_items:
            if item.idname == idname:
                results.append({
                    'keymap': keymap.name,
                    'type': item.type,
                    'value': item.value,
                    'shift': item.shift,
                    'ctrl': item.ctrl,
                    'alt': item.alt
                })
    return results

def get_shortcut_string(keymap_item):
    """获取快捷键字符串"""
    parts = []
    if keymap_item.ctrl:
        parts.append('Ctrl')
    if keymap_item.shift:
        parts.append('Shift')
    if keymap_item.alt:
        parts.append('Alt')
    if keymap_item.oskey:
        parts.append('OS')
    parts.append(keymap_item.type)
    return '+'.join(parts)
```

### 键位配置导出导入

```python
def export_keyconfig(keyconfig, filepath):
    """导出键位配置"""
    import json
    data = {}
    for keymap in keyconfig.keymaps:
        keymap_data = []
        for item in keymap.keymap_items:
            keymap_data.append({
                'idname': item.idname,
                'type': item.type,
                'value': item.value,
                'shift': item.shift,
                'ctrl': item.ctrl,
                'alt': item.alt,
                'oskey': item.oskey,
                'properties': dict(item.properties)
            })
        data[keymap.name] = keymap_data
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def import_keyconfig(filepath, keyconfig_name='Custom'):
    """导入键位配置"""
    import json
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    kc = bpy.context.window_manager.keyconfigs.addon.new(keyconfig_name)
    for keymap_name, items in data.items():
        keymap = kc.keymaps.new(name=keymap_name, space_type='EMPTY')
        for item_data in items:
            item = keymap.keymap_items.new(
                idname=item_data['idname'],
                type=item_data['type'],
                value=item_data['value'],
                shift=item_data.get('shift', False),
                ctrl=item_data.get('ctrl', False),
                alt=item_data.get('alt', False),
                oskey=item_data.get('oskey', False)
            )
            for prop_name, prop_value in item_data.get('properties', {}).items():
                setattr(item.properties, prop_name, prop_value)
    return kc
```

## 实用函数

### 键位查询

```python
def get_keymap_items_for_operator(operator_id):
    """获取操作符的所有键位项"""
    results = []
    for kc in bpy.context.window_manager.keyconfigs:
        for keymap in kc.keymaps:
            for item in keymap.keymap_items:
                if item.idname == operator_id:
                    results.append({
                        'keyconfig': kc.name,
                        'keymap': keymap.name,
                        'item': item
                    })
    return results

def get_assigned_keys(idname):
    """获取操作符的已分配键位"""
    all_assignments = find_shortcut(
        bpy.context.window_manager.keyconfigs.user,
        idname
    )
    return all_assignments

def search_keymaps(search_term):
    """搜索键位映射"""
    results = []
    for kc in bpy.context.window_manager.keyconfigs:
        for keymap in kc.keymaps:
            for item in keymap.keymap_items:
                if (search_term in item.idname or 
                    search_term in keymap.name or
                    search_term in item.type):
                    results.append({
                        'keyconfig': kc.name,
                        'keymap': keymap.name,
                        'idname': item.idname,
                        'type': item.type,
                        'value': item.value
                    })
    return results
```

### 键位冲突检测

```python
def find_key_conflicts(keyconfig=None):
    """查找键位冲突"""
    if keyconfig is None:
        keyconfig = bpy.context.window_manager.keyconfigs.user
    
    key_map = {}
    conflicts = []
    
    for keymap in keyconfig.keymaps:
        for item in keymap.keymap_items:
            key = (item.type, item.value, item.shift, item.ctrl, item.alt, item.oskey)
            if key in key_map:
                conflicts.append({
                    'key': key,
                    'first': key_map[key],
                    'second': {
                        'keymap': keymap.name,
                        'idname': item.idname
                    }
                })
            else:
                key_map[key] = {
                    'keymap': keymap.name,
                    'idname': item.idname
                }
    
    return conflicts

def check_key_available(key_type, key_value='PRESS', shift=False, ctrl=False, alt=False):
    """检查键位是否可用"""
    for kc in bpy.context.window_manager.keyconfigs:
        for keymap in kc.keymaps:
            for item in keymap.keymap_items:
                if (item.type == key_type and 
                    item.value == key_value and
                    item.shift == shift and
                    item.ctrl == ctrl and
                    item.alt == alt):
                    return False
    return True
```

### 键位重置

```python
def reset_keyconfig(keyconfig_name):
    """重置键位配置"""
    kc = get_keyconfig_by_name(keyconfig_name)
    if kc:
        bpy.context.window_manager.keyconfigs.remove(kc)

def reset_to_default():
    """重置为默认键位"""
    bpy.ops.wm.keyconfig_preset_add(name='Blender')

def restore_factory_keyconfig():
    """恢复出厂设置"""
    bpy.ops.wm.read_factory_keyconfig()
```

## 常见问题排查

### 快捷键不生效

键位配置未激活：
- 确认键位配置已启用
- 检查快捷键是否被覆盖
- 重启Blender使更改生效

### 键位冲突

多个操作符使用相同键位：
- 使用find_key_conflicts查找冲突
- 修改其中一个快捷键
- 使用修饰键区分

### 导入失败

配置格式错误：
- 确认JSON格式正确
- 检查必要的字段是否存在
- 验证操作符ID有效
