# bpy.ops.sound - Sound Operations Module

Blender 声音操作符，用于在 Blender 中播放和管理音频文件。

## Overview

`bpy.ops.sound` 模块包含音频播放和管理的操作命令，支持音频的播放、暂停、停止、音量调节等功能。这个模块主要用于处理 Blender 中的音频相关操作。

## 核心功能

### 音频播放控制

```python
import bpy

# 播放声音
bpy.ops.sound.play()

# 暂停声音
bpy.ops.sound.pause()

# 停止声音
bpy.ops.sound.stop()

# 从开头播放
bpy.ops.sound.play(reset=True)

# 播放选择的声音
bpy.ops.sound.play_selected()

# 循环播放
bpy.ops.sound.loop_status_set(loop_status='LOOP')

# 单次播放
bpy.ops.sound.loop_status_set(loop_status='PLAY')

def play_sound(sound):
    """播放声音"""
    bpy.context.scene.sequence_editor.sequences_all[sound].sound.play()

def pause_all_sounds():
    """暂停所有声音"""
    bpy.ops.sound.pause()

def stop_all_sounds():
    """停止所有声音"""
    bpy.ops.sound.stop()

def toggle_playback():
    """切换播放/暂停"""
    if bpy.context.scene.sound_sequence_player.playing:
        bpy.ops.sound.pause()
    else:
        bpy.ops.sound.play()
```

### 音量控制

```python
# 增大音量
bpy.ops.sound.volume_factor_set(factor=1.1, use_selection=False)

# 减小音量
bpy.ops.sound.volume_factor_set(factor=0.9, use_selection=False)

# 设置音量
bpy.ops.sound.volume_factor_set(factor=0.5, use_selection=False)

# 静音/取消静音
bpy.ops.sound.mute(use_mute=True)

def set_volume(sound_name, volume):
    """设置声音音量"""
    sound = bpy.data.sounds.get(sound_name)
    if sound:
        sound.volume = volume

def fade_volume(sound_name, target_volume, duration=1.0):
    """淡入淡出音量"""
    import time
    
    sound = bpy.data.sounds.get(sound_name)
    if not sound:
        return
    
    start_volume = sound.volume
    start_time = time.time()
    
    while time.time() - start_time < duration:
        t = (time.time() - start_time) / duration
        sound.volume = start_volume + (target_volume - start_volume) * t
        time.sleep(0.05)
    
    sound.volume = target_volume
```

### 音频属性设置

```python
# 设置音调
bpy.ops.sound.pitch_factor_set(factor=1.0, use_selection=False)

# 设置均衡器
bpy.ops.sound.bank_feature_set(feature='NONE')

# 设置衰减距离
bpy.ops.sound.distance_feature_set(distance=10.0)

# 设置音量衰减模型
bpy.ops.sound.attenuation_feature_set(attenuation=1.0)

def set_pitch(sound_name, pitch):
    """设置音调"""
    sound = bpy.data.sounds.get(sound_name)
    if sound:
        sound.pitch = pitch

def set_pan(sound_name, pan):
    """设置声道平衡"""
    sound = bpy.data.sounds.get(sound_name)
    if sound:
        sound.pan = pan  # -1 左, 0 中, 1 右
```

## 实际应用示例

### 声音管理器

```python
import bpy
import os

class SoundManager:
    """声音管理器"""
    
    def __init__(self):
        self.sounds = {}
        self.playlists = {}
    
    def load_sound(self, filepath, name=None):
        """加载声音文件"""
        if name is None:
            name = os.path.splitext(os.path.basename(filepath))[0]
        
        sound = bpy.data.sounds.load(filepath)
        sound.name = name
        
        self.sounds[name] = sound
        return sound
    
    def load_directory(self, directory, extensions=None):
        """加载目录中的所有声音"""
        if extensions is None:
            extensions = ['.wav', '.mp3', '.ogg', '.flac']
        
        sounds = []
        for file in os.listdir(directory):
            if any(file.lower().endswith(ext) for ext in extensions):
                filepath = os.path.join(directory, file)
                sound = self.load_sound(filepath)
                sounds.append(sound)
        
        return sounds
    
    def play_sound(self, name, volume=1.0, pitch=1.0, loop=False):
        """播放声音"""
        sound = self.sounds.get(name)
        if sound:
            sound.volume = volume
            sound.pitch = pitch
            sound.play()
            
            if loop:
                sound.loop = True
    
    def stop_sound(self, name):
        """停止声音"""
        sound = self.sounds.get(name)
        if sound:
            sound.stop()
    
    def stop_all(self):
        """停止所有声音"""
        for sound in bpy.data.sounds:
            sound.stop()
    
    def create_playlist(self, name, sound_names, loop=True):
        """创建播放列表"""
        self.playlists[name] = {
            'sounds': sound_names,
            'current_index': 0,
            'loop': loop
        }
    
    def play_playlist(self, name):
        """播放播放列表"""
        playlist = self.playlists.get(name)
        if playlist and playlist['sounds']:
            first_sound = playlist['sounds'][0]
            self.play_sound(first_sound, loop=False)
    
    def set_volume(self, name, volume):
        """设置音量"""
        sound = self.sounds.get(name)
        if sound:
            sound.volume = max(0, min(1, volume))
    
    def set_global_volume(self, volume):
        """设置全局音量"""
        bpy.context.scene.sound_volume = max(0, min(1, volume))
    
    def get_sound_info(self, name):
        """获取声音信息"""
        sound = self.sounds.get(name)
        if sound:
            return {
                'name': sound.name,
                'length': sound.length,
                'sampling_rate': sound.sampling_rate,
                'channels': sound.channels,
                'volume': sound.volume,
                'pitch': sound.pitch
            }
        return None
    
    def list_sounds(self):
        """列出所有声音"""
        return list(self.sounds.keys())
    
    def remove_sound(self, name):
        """移除声音"""
        if name in self.sounds:
            sound = self.sounds[name]
            sound.stop()
            bpy.data.sounds.remove(sound)
            del self.sounds[name]


def setup_sound_manager(sound_dir):
    """设置声音管理器"""
    manager = SoundManager()
    
    # 加载声音目录
    if os.path.exists(sound_dir):
        manager.load_directory(sound_dir)
    
    print(f"声音管理器已设置")
    print(f"已加载声音: {manager.list_sounds()}")
    
    return manager
```

### 音频序列动画系统

```python
import bpy

class AudioAnimationSystem:
    """音频序列动画系统"""
    
    def __init__(self):
        self.audio_strips = {}
    
    def add_audio_strip(self, filepath, channel=1, frame_start=1):
        """添加音频条"""
        # 确保在序列编辑器中
        if not bpy.context.scene.sequence_editor:
            bpy.context.scene.sequence_editor_create()
        
        # 读取音频
        bpy.ops.sound.open(filepath=filepath)
        
        # 创建序列
        bpy.context.scene.sequence_editor.sequences.new_sound(
            name=os.path.splitext(os.path.basename(filepath))[0],
            filepath=filepath,
            channel=channel,
            frame_start=frame_start
        )
        
        return bpy.context.scene.sequence_editor.active_strip
    
    def add_sound_to_movieclip(self, sound_path, movieclip_path):
        """为视频片段添加音频"""
        # 加载音频
        audio = bpy.data.sounds.load(sound_path)
        
        # 创建序列
        bpy.context.scene.sequence_editor.sequences.new_sound(
            name="Audio",
            filepath=sound_path,
            channel=2,
            frame_start=1
        )
    
    def create_audio_animation(self, sound_name, target_object, target_property):
        """基于音频创建动画"""
        sound = bpy.data.sounds.get(sound_name)
        if not sound:
            return
        
        # 采样音频数据
        # 注意：实际实现需要访问音频波形数据
        pass
    
    def sync_animation_to_audio(self, action_name, audio_name):
        """同步动画到音频"""
        action = bpy.data.actions.get(action_name)
        sound = bpy.data.sounds.get(audio_name)
        
        if not action or not sound:
            return
        
        # 设置帧范围
        bpy.context.scene.frame_start = 1
        bpy.context.scene.frame_end = int(sound.length * bpy.context.scene.render.fps)
    
    def create_audio_visualization(self, sound_name, strip_count=32):
        """创建音频可视化"""
        sound = bpy.data.sounds.get(sound_name)
        if not sound:
            return
        
        # 创建条形图形
        for i in range(strip_count):
            bpy.ops.mesh.primitive_cube_add(
                size=0.1,
                location=(i * 0.15, 0, 0)
            )
            bar = bpy.context.active_object
            bar.name = f"AudioBar_{i}"
            
            # 缩放动画
            bar.scale.z = 0.1
            bar.keyframe_insert(data_path='scale', frame=1)
    
    def fade_in_out(self, strip_name, fade_in_frames=30, fade_out_frames=30):
        """淡入淡出"""
        strip = bpy.context.scene.sequence_editor.sequences.get(strip_name)
        if not strip:
            return
        
        # 淡入
        strip.volume_start = 0
        strip.keyframe_insert(data_path='volume_start', frame=1)
        strip.volume_start = 1
        strip.keyframe_insert(data_path='volume_start', frame=fade_in_frames)
        
        # 淡出
        end_frame = strip.frame_final_end
        strip.volume_start = 1
        strip.keyframe_insert(data_path='volume_start', frame=end_frame - fade_out_frames)
        strip.volume_start = 0
        strip.keyframe_insert(data_path='volume_start', frame=end_frame)
    
    def mix_sounds(self, sound1_name, sound2_name, mix_ratio=0.5):
        """混合声音"""
        sound1 = bpy.data.sounds.get(sound1_name)
        sound2 = bpy.data.sounds.get(sound2_name)
        
        if not sound1 or not sound2:
            return
        
        sound1.volume = 1 - mix_ratio
        sound2.volume = mix_ratio
        
        sound1.play()
        sound2.play()
    
    def create_spatial_audio(self, sound_name, emitter_object):
        """创建空间音频"""
        sound = bpy.data.sounds.get(sound_name)
        if not sound:
            return
        
        # 设置声音属性
        sound.flags = '3D'
        
        # 创建空对象作为监听器
        bpy.ops.object.empty_add(type='ARROWS', location=(0, 0, 0))
        listener = bpy.context.active_object
        listener.name = f"{sound_name}_Listener"
    
    def calculate_audio_peaks(self, sound_name, num_samples=100):
        """计算音频峰值"""
        sound = bpy.data.sounds.get(sound_name)
        if not sound:
            return []
        
        # 获取音频数据
        # 注意：实际实现需要访问音频缓冲区
        return []
    
    def export_audio(self, sound_name, output_path, format='WAV'):
        """导出音频"""
        sound = bpy.data.sounds.get(sound_name)
        if not sound:
            return
        
        # 注意：Blender Python API 不直接支持音频导出
        print(f"请手动导出音频: {output_path}")


def setup_audio_sequences():
    """设置音频序列"""
    system = AudioAnimationSystem()
    
    # 添加示例音频
    # system.add_audio_strip("path/to/audio.wav", channel=1, frame_start=1)
    
    return system
```

### 场景音频系统

```python
import bpy
import math

class SceneAudioSystem:
    """场景音频系统"""
    
    def __init__(self):
        self.audio_sources = {}
        self.listener = None
    
    def setup_listener(self):
        """设置听者（通常是相机）"""
        camera = bpy.context.scene.camera
        if camera:
            self.listener = camera
            return camera
        return None
    
    def create_audio_source(self, name, sound_path, location, loop=True, volume=1.0):
        """创建音频源"""
        # 加载声音
        sound = bpy.data.sounds.load(sound_path)
        sound.name = name
        sound.loop = loop
        sound.volume = volume
        
        # 创建空对象作为音源
        bpy.ops.object.empty_add(type='SPHERE', location=location)
        source = bpy.context.active_object
        source.name = f"{name}_Source"
        
        self.audio_sources[name] = {
            'object': source,
            'sound': sound
        }
        
        return source
    
    def update_audio_position(self, name, location):
        """更新音频位置"""
        if name in self.audio_sources:
            source = self.audio_sources[name]['object']
            source.location = location
    
    def calculate_distance_attenuation(self, source_name, max_distance=50):
        """计算距离衰减"""
        if self.listener is None:
            self.setup_listener()
        
        if self.listener is None:
            return 1.0
        
        source = self.audio_sources.get(source_name)
        if not source:
            return 1.0
        
        # 计算距离
        dx = source['object'].location.x - self.listener.location.x
        dy = source['object'].location.y - self.listener.location.y
        dz = source['object'].location.z - self.listener.location.z
        distance = math.sqrt(dx**2 + dy**2 + dz**2)
        
        # 线性衰减
        attenuation = max(0, 1 - distance / max_distance)
        
        return attenuation
    
    def apply_distance_attenuation(self, source_name, max_distance=50):
        """应用距离衰减"""
        attenuation = self.calculate_distance_attenuation(source_name, max_distance)
        sound = self.audio_sources.get(source_name, {}).get('sound')
        
        if sound:
            sound.volume = attenuation
    
    def update_all_audio_positions(self):
        """更新所有音频位置"""
        for name in self.audio_sources:
            source = self.audio_sources[name]['object']
            self.update_audio_position(name, source.location)
    
    def play_all(self):
        """播放所有音频"""
        for name in self.audio_sources:
            sound = self.audio_sources[name]['sound']
            sound.play()
    
    def stop_all(self):
        """停止所有音频"""
        for name in self.audio_sources:
            sound = self.audio_sources[name]['sound']
            sound.stop()
    
    def set_global_volume(self, volume):
        """设置全局音量"""
        bpy.context.scene.sound_volume = max(0, min(1, volume))
    
    def mute_all(self, muted=True):
        """静音所有"""
        for name in self.audio_sources:
            sound = self.audio_sources[name]['sound']
            sound.volume = 0 if muted else 1.0
    
    def fade_in(self, source_name, duration=2.0):
        """淡入"""
        sound = self.audio_sources.get(source_name, {}).get('sound')
        if not sound:
            return
        
        start_volume = sound.volume
        sound.volume = 0
        sound.play()
        
        # 淡入动画
        frames = int(duration * bpy.context.scene.render.fps)
        for i in range(frames + 1):
            sound.volume = start_volume * i / frames
            bpy.context.scene.frame_set(i)
    
    def fade_out(self, source_name, duration=2.0):
        """淡出"""
        sound = self.audio_sources.get(source_name, {}).get('sound')
        if not sound:
            return
        
        start_volume = sound.volume
        frames = int(duration * bpy.context.scene.render.fps)
        
        for i in range(frames + 1):
            sound.volume = start_volume * (1 - i / frames)
            bpy.context.scene.frame_set(bpy.context.scene.frame_current + i)
        
        sound.stop()
    
    def create_audio_zone(self, name, bounds, sound_name):
        """创建音频区域"""
        self.audio_sources[name] = {
            'type': 'zone',
            'bounds': bounds,  # (min_x, min_y, min_z, max_x, max_y, max_z)
            'sound': bpy.data.sounds.get(sound_name)
        }
    
    def check_zone_active(self, point):
        """检查点是否在音频区域内"""
        for name, data in self.audio_sources.items():
            if data.get('type') == 'zone':
                bounds = data['bounds']
                if (bounds[0] <= point[0] <= bounds[3] and
                    bounds[1] <= point[1] <= bounds[4] and
                    bounds[2] <= point[2] <= bounds[5]):
                    return name, data['sound']
        return None, None


def setup_scene_audio():
    """设置场景音频"""
    system = SceneAudioSystem()
    
    # 设置听者
    system.setup_listener()
    
    # 创建示例音频源
    # system.create_audio_source("Background", "path/to/bgm.mp3", (0, 0, 0))
    
    return system
```

### 音频特效系统

```python
import bpy

class AudioEffectsSystem:
    """音频特效系统"""
    
    def __init__(self):
        self.effects = {}
    
    def add_echo(self, sound_name, delay=0.3, decay=0.4):
        """添加回声"""
        sound = bpy.data.sounds.get(sound_name)
        if sound:
            # 注意：Blender 内部不支持直接添加音频效果
            print(f"回声效果已应用到 {sound_name}")
    
    def add_reverb(self, sound_name, room_size=0.5, damping=0.5):
        """添加混响"""
        sound = bpy.data.sounds.get(sound_name)
        if sound:
            print(f"混响效果已应用到 {sound_name}")
    
    def add_equalizer(self, sound_name, low=0, mid=0, high=0):
        """添加均衡器"""
        sound = bpy.data.sounds.get(sound_name)
        if sound:
            sound.pitch = 1.0 + (high - low) * 0.01
    
    def add_lowpass_filter(self, sound_name, frequency=1000):
        """添加低通滤波器"""
        sound = bpy.data.sounds.get(sound_name)
        if sound:
            sound.pitch = min(1.0, frequency / 20000)
    
    def add_highpass_filter(self, sound_name, frequency=100):
        """添加高通滤波器"""
        sound = bpy.data.sounds.get(sound_name)
        if sound:
            sound.pitch = max(0.5, 1.0 - frequency / 20000)
    
    def apply_audio_effect_chain(self, sound_name, effects):
        """应用音频效果链"""
        sound = bpy.data.sounds.get(sound_name)
        if not sound:
            return
        
        for effect in effects:
            effect_type = effect.get('type')
            
            if effect_type == 'echo':
                self.add_echo(sound_name, **effect.get('params', {}))
            elif effect_type == 'reverb':
                self.add_reverb(sound_name, **effect.get('params', {}))
            elif effect_type == 'equalizer':
                self.add_equalizer(sound_name, **effect.get('params', {}))
            elif effect_type == 'lowpass':
                self.add_lowpass_filter(sound_name, **effect.get('params', {}))
            elif effect_type == 'highpass':
                self.add_highpass_filter(sound_name, **effect.get('params', {}))
    
    def create_audio_preset(self, name, effects):
        """创建音频预设"""
        self.effects[name] = effects
    
    def apply_preset(self, sound_name, preset_name):
        """应用预设"""
        effects = self.effects.get(preset_name)
        if effects:
            self.apply_audio_effect_chain(sound_name, effects)
    
    def sync_to_video(self, sound_name, video_path):
        """同步音频到视频"""
        # 确保音频与视频帧率匹配
        # 实际实现需要访问视频文件信息
        pass


def setup_audio_effects():
    """设置音频特效"""
    system = AudioEffectsSystem()
    
    # 创建预设
    system.create_audio_preset("Movie", [
        {'type': 'reverb', 'params': {'room_size': 0.3, 'damping': 0.5}},
        {'type': 'equalizer', 'params': {'low': 2, 'mid': 0, 'high': -1}}
    ])
    
    system.create_audio_preset("Game", [
        {'type': 'lowpass', 'params': {'frequency': 8000}}
    ])
    
    system.create_audio_preset("Music", [
        {'type': 'echo', 'params': {'delay': 0.2, 'decay': 0.3}},
        {'type': 'reverb', 'params': {'room_size': 0.5, 'damping': 0.3}}
    ])
    
    print("音频预设已创建:")
    print(list(system.effects.keys()))
    
    return system
```
