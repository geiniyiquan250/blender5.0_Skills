# bpy.ops.grease_pencil - 画笔操作模块

Blender画笔操作符，用于在画笔编辑器中管理画笔设置。

## 概述

`bpy.ops.gpencil` 模块提供用于操作画笔编辑器和画笔设置的功能。这与 grease_pencil 模块不同，这是专门用于画笔本身的编辑操作。

## 核心功能

### 画笔选择

```python
import bpy

# 选择画笔
bpy.ops.gpencil.select(
    extend=False,
    deselect=False,
    toggle=False,
    deselect_all=True
)

# 选择所有画笔
bpy.ops.gpencil.select_all(
    action='SELECT'
)

# 取消选择所有画笔
bpy.ops.gpencil.select_all(
    action='DESELECT'
)

# 反选
bpy.ops.gpencil.select_all(
    action='INVERT'
)

# 选择相似的画笔
bpy.ops.gpencil.select_similar(
    type='TYPE',
    threshold=0.1
)
```

### 画笔编辑

```python
# 新建画笔
bpy.ops.gpencil.brush_add(
    name='NewBrush'
)

# 复制画笔
bpy.ops.gpencil.brush_duplicate()

# 重命名画笔
bpy.ops.gpencil.brush_rename(
    name='MyBrush'
)

# 删除画笔
bpy.ops.gpencil.brush_delete()

# 重置画笔
bpy.ops.gpencil.brush_reset()

# 清除画笔
bpy.ops.gpencil.brush_clear()
```

### 画笔设置

```python
# 设置画笔类型
bpy.ops.gpencil.brush_type_set(
    type='DRAW'
)

# 设置画笔颜色
bpy.ops.gpencil.brush_color_set(
    color=(1.0, 0.0, 0.0, 1.0)
)

# 设置画笔大小
bpy.ops.gpencil.brush_size_set(
    size=20
)

# 设置画笔强度
bpy.ops.gpencil.brush_strength_set(
    strength=0.5
)

# 设置画笔混合模式
bpy.ops.gpencil.brush_blend_set(
    mode='MIX'
)

# 应用画笔预设
bpy.ops.gpencil.brush_preset_apply(
    preset='Basic'
)

# 保存画笔预设
bpy.ops.gpencil.brush_preset_save(
    name='MyPreset'
)

# 删除画笔预设
bpy.ops.gpencil.brush_preset_delete(
    name='MyPreset'
)
```

### 画笔纹理

```python
# 添加纹理
bpy.ops.gpencil.texture_add()

# 清除纹理
bpy.ops.gpencil.texture_remove()

# 设置纹理缩放
bpy.ops.gpencil.texture_scale_set(
    scale=1.0
)

# 设置纹理旋转
bpy.ops.gpencil.texture_rotate_set(
    angle=0.0
)
```

### 画笔曲线

```python
# 设置曲线
bpy.ops.gpencil.curve_preset(
    preset='SHARP'
)

# 编辑曲线
bpy.ops.gpencil.curve_edit()

# 重置曲线
bpy.ops.gpencil.curve_reset()

# 设置曲线点
bpy.ops.gpencil.curve_point_add()
```

### 画笔模板

```python
# 添加模板
bpy.ops.gpencil.stencil_add()

# 移除模板
bpy.ops.gpencil.stencil_remove()

# 显示模板
bpy.ops.gpencil.stencil_show()

# 隐藏模板
bpy.ops.gpencil.stencil_hide()

# 旋转模板
bpy.ops.gpencil.stencil_rotate(
    angle=45
)

# 缩放模板
bpy.ops.gpencil.stencil_scale(
    scale=1.5
)

# 移动模板
bpy.ops.gpencil.stencil_offset(
    factor=(0.1, 0.1)
)
```

### 画笔变换

```python
# 变换画笔
bpy.ops.gpencil.brush_transform()

# 旋转画笔
bpy.ops.gpencil.brush_rotate(
    angle=45
)

# 缩放画笔
bpy.ops.gpencil.brush_scale(
    factor=1.5
)

# 移动画笔
bpy.ops.gpencil.brush_offset(
    factor=(0.1, 0.1)
)
```

### 画笔工具

```python
# 采样颜色
bpy.ops.gpencil.sample_color()

# 采样活动颜色
bpy.ops.gpencil.sample_active()

# 切换画笔编辑器
bpy.ops.gpencil.toggle_toolshelf()

# 切换画笔属性
bpy.ops.gpencil.toggle_brush_panel()
```

### 画笔库操作

```python
# 导入画笔库
bpy.ops.gpencil.brush_library_import(
    filepath='//brushes.blend'
)

# 导出画笔库
bpy.ops.gpencil.brush_library_export(
    filepath='//brushes.blend'
)

# 添加画笔到库
bpy.ops.gpencil.brush_to_library()

# 从库中移除画笔
bpy.ops.gpencil.brush_from_library()
```

## 实用函数

```python
def get_all_brushes():
    """获取所有画笔"""
    return list(bpy.data.gpencil_brushes)

def get_brush_by_name(name):
    """根据名称获取画笔"""
    return bpy.data.gpencil_brushes.get(name)

def get_active_brush():
    """获取当前画笔"""
    return bpy.context.tool_settings.gpencil_brush

def set_active_brush(brush_name):
    """设置当前画笔"""
    brush = bpy.data.gpencil_brushes.get(brush_name)
    if brush:
        bpy.context.tool_settings.gpencil_brush = brush

def create_brush(name, brush_type='DRAW'):
    """创建新画笔"""
    brush = bpy.data.gpencil_brushes.new(name=name)
    brush.gpencil_brush_type = brush_type
    return brush

def duplicate_brush(brush_name, new_name):
    """复制画笔"""
    brush = get_brush_by_name(brush_name)
    if brush:
        new_brush = brush.copy()
        new_brush.name = new_name
        return new_brush
    return None

def delete_brush(brush_name):
    """删除画笔"""
    brush = get_brush_by_name(brush_name)
    if brush:
        bpy.data.gpencil_brushes.remove(brush)

def reset_all_brushes():
    """重置所有画笔"""
    for brush in bpy.data.gpencil_brushes:
        brush.reset()

def batch_set_brush_size(brushes, size):
    """批量设置画笔大小"""
    for brush_name in brushes:
        brush = get_brush_by_name(brush_name)
        if brush:
            brush.size = size

def batch_set_brush_color(brushes, color):
    """批量设置画笔颜色"""
    for brush_name in brushes:
        brush = get_brush_by_name(brush_name)
        if brush:
            brush.color = color

def compare_brushes(brush1_name, brush2_name):
    """比较两个画笔设置"""
    brush1 = get_brush_by_name(brush1_name)
    brush2 = get_brush_by_name(brush2_name)
    if brush1 and brush2:
        return {
            'size': brush1.size == brush2.size,
            'strength': brush1.strength == brush2.strength,
            'color': brush1.color == brush2.color
        }
    return False
```

## 常见问题排查

### 画笔不生效
```python
# 检查当前画笔
brush = bpy.context.tool_settings.gpencil_brush
print(f"当前画笔: {brush}")

# 检查画笔类型
print(f"画笔类型: {brush.gpencil_brush_type}")

# 确保在正确的工作区
print(f"当前区域类型: {bpy.context.area.type}")

# 检查画笔是否被锁定
print(f"锁定: {brush.locked}")

# 解锁画笔
brush.locked = False
```

### 画笔设置无法保存
```python
# 检查画笔是否来自库
brush = bpy.context.tool_settings.gpencil_brush
print(f"库: {brush.library}")

# 复制到本地
if brush.library:
    local_brush = brush.copy()
    local_brush.name = brush.name + '_local'
    bpy.context.tool_settings.gpencil_brush = local_brush

# 保存为预设
bpy.ops.gpencil.brush_preset_save(name='MySettings')
```

### 画笔纹理不显示
```python
# 检查纹理
brush = bpy.context.tool_settings.gpencil_brush
print(f"纹理: {brush.texture}")

# 检查纹理图像
if brush.texture:
    print(f"纹理图像: {brush.texture.image}")

# 检查纹理混合
print(f"纹理混合: {brush.texture_mode}")

# 重新加载纹理
if brush.texture and brush.texture.image:
    brush.texture.image.reload()
```
