# bpy.ops.spreadsheet - 电子表格操作模块

Blender电子表格操作符，用于在Blender内置电子表格编辑器中管理数据。

## 概述

`bpy.ops.spreadsheet` 模块提供用于操作Blender电子表格编辑器的功能，用于查看和编辑属性集合、几何节点数据等表格化数据。

## 核心功能

### 表格选择操作

```python
import bpy

# 全选
bpy.ops.spreadsheet.select_all(action='SELECT')

# 全不选
bpy.ops.spreadsheet.select_all(action='DESELECT')

# 反选
bpy.ops.spreadsheet.select_all(action='INVERT')

# 选择行
bpy.ops.spreadsheet.select_row(row=0)

# 选择列
bpy.ops.spreadsheet.select_column(column=0)

# 选择单元格
bpy.ops.spreadsheet.select_cell(row=0, column=0)

# 选择范围
bpy.ops.spreadsheet.select_range(row_start=0, row_end=10, column_start=0, column_end=5)

# 选择行范围
bpy.ops.spreadsheet.select_row_range(row_start=0, row_end=10)

# 选择列范围
bpy.ops.spreadsheet.select_column_range(column_start=0, column_end=5)

# 选择整列
bpy.ops.spreadsheet.select_column_all()

# 选择整行
bpy.ops.spreadsheet.select_row_all()
```

### 表格编辑操作

```python
# 复制选中
bpy.ops.spreadsheet.copy()

# 粘贴
bpy.ops.spreadsheet.paste()

# 粘贴值
bpy.ops.spreadsheet.paste_values()

# 清除内容
bpy.ops.spreadsheet.clear_contents()

# 清除格式
bpy.ops.spreadsheet.clear_formatting()

# 删除行
bpy.ops.spreadsheet.delete_rows()

# 删除列
bpy.ops.spreadsheet.delete_columns()

# 插入行
bpy.ops.spreadsheet.insert_rows(count=1)

# 插入列
bpy.ops.spreadsheet.insert_columns(count=1)

# 重命名列
bpy.ops.spreadsheet.rename_column(name='New Name')

# 重命名表
bpy.ops.spreadsheet.rename_sheet(name='New Sheet')
```

### 单元格操作

```python
# 设置单元格值
bpy.ops.spreadsheet.set_value(value='text', row=0, column=0)

# 获取单元格值
bpy.ops.spreadsheet.get_value(row=0, column=0)

# 设置公式
bpy.ops.spreadsheet.set_formula(formula='=SUM(A1:A10)', row=0, column=0)

# 计算公式
bpy.ops.spreadsheet.calculate_formulas()

# 设置单元格格式
bpy.ops.spreadsheet.set_cell_format(format='NUMBER', row=0, column=0)

# 合并单元格
bpy.ops.spreadsheet.merge_cells(row_start=0, row_end=2, column_start=0, column_end=2)

# 取消合并
bpy.ops.spreadsheet.unmerge_cells(row=0, column=0)
```

### 排序和筛选

```python
# 排序
bpy.ops.spreadsheet.sort(column=0, order='ASCENDING')

# 降序排序
bpy.ops.spreadsheet.sort(column=0, order='DESCENDING')

# 筛选
bpy.ops.spreadsheet.filter(column=0, criteria='EQUALS', value='text')

# 清除筛选
bpy.ops.spreadsheet.clear_filter()

# 高级筛选
bpy.ops.spreadsheet.advanced_filter(criteria={'column': 0, 'operator': 'GREATER', 'value': 10})

# 按颜色筛选
bpy.ops.spreadsheet.filter_by_color(color='RED')

# 排序筛选
bpy.ops.spreadsheet.sort_filter(column=0, filter_criteria={'column': 1, 'value': 'text'})
```

### 查找和替换

```python
# 查找
bpy.ops.spreadsheet.find(text='search_text')

# 查找下一个
bpy.ops.spreadsheet.find_next()

# 查找上一个
bpy.ops.spreadsheet.find_previous()

# 替换
bpy.ops.spreadsheet.replace(text='old', new='new')

# 替换所有
bpy.ops.spreadsheet.replace_all(text='old', new='new')

# 使用正则表达式查找
bpy.ops.spreadsheet.find_regex(pattern='regex')

# 高亮所有匹配
bpy.ops.spreadsheet.highlight_all(text='search_text')

# 清除高亮
bpy.ops.spreadsheet.clear_highlight()
```

### 格式设置

```python
# 设置数字格式
bpy.ops.spreadsheet.set_number_format(format='0.00', row=0, column=0)

# 设置日期格式
bpy.ops.spreadsheet.set_date_format(format='YYYY-MM-DD', row=0, column=0)

# 设置百分比
bpy.ops.spreadsheet.set_percentage(row=0, column=0)

# 设置货币
bpy.ops.spreadsheet.set_currency(currency='USD', row=0, column=0)

# 设置字体
bpy.ops.spreadsheet.set_font(font='Arial', row=0, column=0)

# 设置字号
bpy.ops.spreadsheet.set_font_size(size=12, row=0, column=0)

# 设置粗体
bpy.ops.spreadsheet.set_bold(row=0, column=0, bold=True)

# 设置斜体
bpy.ops.spreadsheet.set_italic(row=0, column=0, italic=True)

# 设置对齐
bpy.ops.spreadsheet.set_alignment(alignment='CENTER', row=0, column=0)

# 设置背景色
bpy.ops.spreadsheet.set_background_color(color=(1.0, 1.0, 1.0, 1.0), row=0, column=0)

# 设置文字颜色
bpy.ops.spreadsheet.set_text_color(color=(0.0, 0.0, 0.0, 1.0), row=0, column=0)

# 设置边框
bpy.ops.spreadsheet.set_border(style='THIN', row=0, column=0)

# 应用格式到整列
bpy.ops.spreadsheet.format_column(column=0, format='NUMBER')

# 应用格式到整行
bpy.ops.spreadsheet.format_row(row=0, format='TEXT')
```

### 视图操作

```python
# 调整列宽
bpy.ops.spreadsheet.set_column_width(width=100, column=0)

# 调整行高
bpy.ops.spreadsheet.set_row_height(height=20, row=0)

# 自动调整列宽
bpy.ops.spreadsheet.auto_fit_column(column=0)

# 自动调整所有列
bpy.ops.spreadsheet.auto_fit_all_columns()

# 冻结窗格
bpy.ops.spreadsheet.freeze_panes(row=5, column=2)

# 取消冻结
bpy.ops.spreadsheet.unfreeze_panes()

# 隐藏列
bpy.ops.spreadsheet.hide_column(column=0)

# 显示列
bpy.ops.spreadsheet.show_column(column=0)

# 隐藏行
bpy.ops.spreadsheet.hide_row(row=0)

# 显示行
bpy.ops.spreadsheet.show_row(row=0)

# 滚动到单元格
bpy.ops.spreadsheet.scroll_to_cell(row=0, column=0)

# 切换行号显示
bpy.ops.spreadsheet.toggle_row_numbers()

# 切换列标显示
bpy.ops.spreadsheet.toggle_column_letters()
```

### 条件格式

```python
# 添加条件格式
bpy.ops.spreadsheet.add_conditional_format(
    range='A1:C10',
    criteria={'type': 'GREATER', 'value': 100},
    format={'background': (1.0, 0.0, 0.0, 1.0)}
)

# 清除条件格式
bpy.ops.spreadsheet.clear_conditional_format(range='A1:C10')

# 管理条件格式规则
bpy.ops.spreadsheet.manage_conditional_formats()

# 数据条
bpy.ops.spreadsheet.add_data_bars(range='A1:A10')

# 色阶
bpy.ops.spreadsheet.add_color_scale(range='A1:A10')

# 图标集
bpy.ops.spreadsheet.add_icon_set(range='A1:A10', icons='TRAFFIC_LIGHTS')
```

### 数据操作

```python
# 去除重复项
bpy.ops.spreadsheet.remove_duplicates(range='A1:C10')

# 删除空行
bpy.ops.spreadsheet.remove_empty_rows()

# 删除空列
bpy.ops.spreadsheet.remove_empty_columns()

# 填充序列
bpy.ops.spreadsheet.fill_series(start_value=1, step=1)

# 填充公式
bpy.ops.spreadsheet.fill_formula()

# 填充向下
bpy.ops.spreadsheet.fill_down()

# 填充向右
bpy.ops.spreadsheet.fill_right()

# 转置
bpy.ops.spreadsheet.transpose(range='A1:C10')

# 删除重复值
bpy.ops.spreadsheet.remove_duplicate_values()
```

### 导入导出

```python
# 导出到CSV
bpy.ops.spreadsheet.export_csv(filepath='//data.csv')

# 导出到TSV
bpy.ops.spreadsheet.export_tsv(filepath='//data.tsv')

# 导出到JSON
bpy.ops.spreadsheet.export_json(filepath='//data.json')

# 导出到Excel
bpy.ops.spreadsheet.export_excel(filepath='//data.xlsx')

# 导入CSV
bpy.ops.spreadsheet.import_csv(filepath='//data.csv')

# 导入TSV
bpy.ops.spreadsheet.import_tsv(filepath='//data.tsv')

# 导入JSON
bpy.ops.spreadsheet.import_json(filepath='//data.json')
```

### 公式和函数

```python
# 插入求和公式
bpy.ops.spreadsheet.insert_sum(row=0, column=0, range='A1:A10')

# 插入平均值公式
bpy.ops.spreadsheet.insert_average(row=0, column=0, range='A1:A10')

# 插入计数公式
bpy.ops.spreadsheet.insert_count(row=0, column=0, range='A1:A10')

# 插入最大值公式
bpy.ops.spreadsheet.insert_max(row=0, column=0, range='A1:A10')

# 插入最小值公式
bpy.ops.spreadsheet.insert_min(row=0, column=0, range='A1:A10')

# 插入IF公式
bpy.ops.spreadsheet.insert_if(row=0, column=0, condition='A1>10', true='Yes', false='No')

# 显示所有公式
bpy.ops.spreadsheet.show_formulas()

# 隐藏公式
bpy.ops.spreadsheet.hide_formulas()

# 计算所有
bpy.ops.spreadsheet.calculate_all()

# 重新计算
bpy.ops.spreadsheet.recalculate()
```

## 实用函数

```python
def get_sheet_data(sheet_name):
    """获取工作表数据"""
    sheet = bpy.data.spreadsheets.get(sheet_name)
    if sheet:
        return sheet.to_pydata()
    return None

def get_selected_cells():
    """获取选中的单元格"""
    context = bpy.context
    return context.space_data.selected_cells

def get_cell_value(row, column):
    """获取单元格值"""
    sheet = bpy.context.space_data.spreadsheet
    return sheet.get_value(row, column)

def set_cell_value(row, column, value):
    """设置单元格值"""
    sheet = bpy.context.space_data.spreadsheet
    sheet.set_value(row, column, value)

def get_row_count():
    """获取行数"""
    return len(bpy.context.space_data.spreadsheet.rows)

def get_column_count():
    """获取列数"""
    return len(bpy.context.space_data.spreadsheet.columns)

def export_to_dataframe(sheet_name):
    """导出为pandas DataFrame"""
    try:
        import pandas as pd
        sheet = bpy.data.spreadsheets.get(sheet_name)
        if sheet:
            return pd.DataFrame(sheet.to_pydata())
    except ImportError:
        print("pandas未安装")
    return None

def import_from_dataframe(df, sheet_name='Imported'):
    """从pandas DataFrame导入"""
    sheet = bpy.data.spreadsheets.new(name=sheet_name)
    sheet.from_pydata(df.values.tolist())
    return sheet

def filter_by_value(column, value):
    """按值筛选"""
    bpy.ops.spreadsheet.clear_filter()
    bpy.ops.spreadsheet.filter(column=column, criteria='EQUALS', value=value)

def get_column_stats(column):
    """获取列统计信息"""
    data = [get_cell_value(row, column) for row in range(get_row_count())]
    numeric_data = [d for d in data if isinstance(d, (int, float))]
    if numeric_data:
        return {
            'sum': sum(numeric_data),
            'avg': sum(numeric_data) / len(numeric_data),
            'min': min(numeric_data),
            'max': max(numeric_data),
            'count': len(numeric_data)
        }
    return None
```

## 常见问题排查

### 数据不显示
```python
# 检查当前工作表
print(f"当前工作表: {bpy.context.space_data.spreadsheet}")

# 检查行数列数
print(f"行数: {get_row_count()}")
print(f"列数: {get_column_count()}")

# 检查数据类型
sheet = bpy.context.space_data.spreadsheet
print(f"数据类型: {type(sheet)}")

# 刷新数据
bpy.ops.spreadsheet.refresh()
```

### 选择操作问题
```python
# 清除选择
bpy.ops.spreadsheet.select_all(action='DESELECT')

# 检查选择范围
print(f"选中行: {bpy.context.space_data.selected_rows}")
print(f"选中列: {bpy.context.space_data.selected_columns}")

# 重置选择
bpy.ops.spreadsheet.select_cell(row=0, column=0)
```

### 导入导出问题
```python
# 检查文件路径
import os
print(f"文件存在: {os.path.exists('//data.csv')}")

# 检查权限
print("检查文件读写权限")

# 尝试不同格式
bpy.ops.spreadsheet.export_csv(filepath='//test.csv')
```
