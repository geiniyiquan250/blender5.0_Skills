# bpy.ops.eevee - EEVEE渲染操作模块

bpy.ops.eevee模块提供了EEVEE实时渲染引擎的操作功能，用于渲染设置、采样控制和后期处理。

## 概述

EEVEE是Blender的实时渲染引擎，基于OpenGL。这个模块提供了EEVEE特有的渲染操作和设置调整功能。

## 核心功能

### 渲染操作

```python
import bpy

def render_screenshot(filepath=None):
    """渲染截图"""
    bpy.ops.eevee.render_screenshot(filepath=filepath)

def bake_direct_diffuse():
    """烘焙直接漫反射"""
    bpy.ops.eevee.bake(
        type='DIFFUSE',
        direct=True,
        indirect=False
    )

def bake_indirect_diffuse():
    """烘焙间接漫反射"""
    bpy.ops.eevee.bake(
        type='DIFFUSE',
        direct=False,
        indirect=True
    )

def bake_shadows():
    """烘焙阴影"""
    bpy.ops.eevee.bake(type='SHADOW')
```

### 采样控制

```python
def set_aa_samples(samples):
    """设置抗锯齿采样数"""
    bpy.context.scene.eevee.taa_render_samples = samples

def set_shadow_samples(samples):
    """设置阴影采样数"""
    bpy.context.scene.eevee.shadow_cube_size = samples
    bpy.context.scene.eevee.shadow_cascade_size = samples

def set_gi_samples(samples):
    """设置GI采样数"""
    bpy.context.scene.eevee.gi_render_samples = samples
```

## 实用函数

### 光照设置

```python
def setup_sun_light(
    energy=3.0,
    color=(1, 0.9, 0.8),
    angle=0.1
):
    """设置太阳光"""
    bpy.context.scene.eevee.sun_light_direction = (0, 0, 1)
    bpy.context.scene.eevee.sun_light_color = color
    bpy.context.scene.eevee.sun_soft_shadows = True
    bpy.context.scene.eevee.sun_angle = angle

def enable_shadows():
    """启用阴影"""
    bpy.context.scene.eevee.use_shadows = True

def disable_shadows():
    """禁用阴影"""
    bpy.context.scene.eevee.use_shadows = False
```

### 间接光

```python
def enable_indirect_lighting():
    """启用间接光"""
    bpy.context.scene.eevee.use_gtao = True
    bpy.context.scene.eevee.use_ambient_occlusion = True

def set_gtao_radius(radius):
    """设置GTAO半径"""
    bpy.context.scene.eevee.gtao_radius = radius

def set_gtao_distance(distance):
    """设置GTAO距离"""
    bpy.context.scene.eevee.gtao_distance = distance

def set_ao_distance(distance):
    """设置AO距离"""
    bpy.context.scene.eevee.ao_distance = distance
```

### 屏幕空间反射

```python
def enable_reflections():
    """启用反射"""
    bpy.context.scene.eevee.use_refraction = True
    bpy.context.scene.eevee.use_screen_space_reflections = True

def set_reflection_quality(quality):
    """设置反射质量"""
    bpy.context.scene.eevee.ssr_quality = quality

def set_refraction_quality(quality):
    """设置折射质量"""
    bpy.context.scene.eevee.refraction_quality = quality
```

## 常见问题排查

### 渲染问题

画面异常：
- 检查采样数是否足够
- 确认光照设置正确
- 验证纹理压缩设置

### 性能问题

渲染慢：
- 降低采样数
- 禁用阴影或反射
- 减少后期处理效果
