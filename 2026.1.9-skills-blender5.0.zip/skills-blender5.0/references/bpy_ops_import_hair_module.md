# bpy.ops.object - 粒子毛发导入操作模块

Blender粒子毛发导入操作符，用于导入和转换毛发系统。

## 概述

`bpy.ops.object` 模块中与毛发相关的操作符提供用于处理和导入毛发系统的功能，支持从各种格式导入粒子毛发并进行转换。

## 核心功能

### 转换为毛发

```python
import bpy

# 将曲线转换为毛发
bpy.ops.object.convert(
    target='HAIR'
)

# 将曲线转换为粒子
bpy.ops.object.convert(
    target='PARTICLE'
)

# 将网格转换为毛发
bpy.ops.object.convert(
    target='HAIR',
    source='MESH'
)
```

### 粒子系统设置

```python
# 添加粒子系统
bpy.ops.object.particle_system_add()

# 移除粒子系统
bpy.ops.object.particle_system_remove()

# 复制粒子系统
bpy.ops.object.particle_system_copy()
```

### 毛发编辑

```python
# 切换到毛发编辑模式
bpy.ops.object.mode_set(
    mode='PARTICLE_EDIT'
)

# 切换到对象模式
bpy.ops.object.mode_set(
    mode='OBJECT'
)
```

### 毛发系统属性

```python
# 获取活动粒子系统
particle_system = bpy.context.active_object.particle_systems.active

# 设置毛发长度
particle_system.settings.length = 1.0

# 设置毛发数量
particle_system.settings.count = 1000

# 设置毛发粗细
particle_system.settings.hair_thickness = 0.01

# 设置毛发分段
particle_system.settings.hair_step = 3
```

### 粒子发射设置

```python
# 设置发射类型
particle_system.settings.emitter_type = 'HAIR'

# 设置发射源
particle_system.settings.emitter = bpy.context.active_object

# 设置发射模式
particle_system.settings.use_emit_random = False
particle_system.settings.use_even_distribution = True

# 设置发射密度
particle_system.settings.distribution = 'RANDOM'
```

### 物理设置

```python
# 重力影响
particle_system.settings.gravity = 1.0

# 速度设置
particle_system.settings.normal_factor = 1.0

# 随机设置
particle_system.settings.random_factor = 0.2

# 生命周期
particle_system.settings.lifetime = 50
particle_system.settings.lifetime_random = 10
```

### 碰撞设置

```python
# 启用碰撞
particle_system.settings.collision_type = 'NONE'

# 设置碰撞对象
particle_system.settings.collider = None
```

### 渲染设置

```python
# 渲染类型
particle_system.settings.render_type = 'PATH'

# 路径渲染设置
particle_system.settings.render_step = 3

# 材质设置
particle_system.settings.material = 0

# 颜色设置
particle_system.settings.color = (1.0, 1.0, 1.0, 1.0)
```

### 引导设置

```python
# 引导设置
particle_system.settings.guides = 0

# 引导权重
particle_system.settings.guide_weight = 0.5

# 引导收集
particle_system.settings.guide_collection = None
```

### 子粒子设置

```python
# 子粒子设置
particle_system.settings.child_type = 'NONE'

# 子粒子数量
particle_system.settings.child_nbr = 0

# 子粒子半径
particle_system.settings.child_radius = 0.2

# 子粒子长度
particle_system.settings.child_length = 0.5
```

## 实用函数

```python
def create_hair_from_curves(curves_object, target_object, count=1000, length=1.0):
    """从曲线创建毛发"""
    # 选择曲线
    bpy.ops.object.select_all(action='DESELECT')
    curves_object.select_set(True)
    bpy.context.view_layer.objects.active = curves_object
    
    # 转换为毛发
    bpy.ops.object.convert(target='HAIR')
    
    # 设置发射对象
    hair = bpy.context.active_object
    hair.particle_systems.active.settings.emitter = target_object
    
    # 设置毛发参数
    settings = hair.particle_systems.active.settings
    settings.count = count
    settings.length = length
    
    return hair

def create_particle_hair(obj, count=1000, length=1.0, material_index=0):
    """创建粒子毛发"""
    # 选择对象
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    # 添加粒子系统
    bpy.ops.object.particle_system_add()
    
    # 获取粒子系统
    ps = obj.particle_systems.active
    
    # 设置参数
    ps.settings.count = count
    ps.settings.length = length
    ps.settings.render_type = 'PATH'
    ps.settings.hair_step = 3
    ps.settings.material = material_index
    
    # 设置为毛发类型
    ps.settings.type = 'HAIR'
    
    return ps

def convert_mesh_to_hair(obj, count=500, length=0.5):
    """将网格转换为毛发"""
    # 选择对象
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    # 添加粒子系统
    bpy.ops.object.particle_system_add()
    
    # 设置参数
    ps = obj.particle_systems.active
    ps.settings.count = count
    ps.settings.length = length
    ps.settings.type = 'HAIR'
    ps.settings.use_even_distribution = True
    ps.settings.distribution = 'RANDOM'
    
    return ps

def copy_hair_system(source_obj, target_obj):
    """复制毛发系统"""
    # 选择源对象
    bpy.ops.object.select_all(action='DESELECT')
    source_obj.select_set(True)
    bpy.context.view_layer.objects.active = source_obj
    
    # 复制粒子系统
    bpy.ops.object.particle_system_copy()
    
    # 获取新的粒子系统
    new_ps = source_obj.particle_systems[-1]
    
    # 设置发射对象
    new_ps.settings.emitter = target_obj
    
    return new_ps

def add_child_hair(obj, child_count=100, child_radius=0.2):
    """添加子毛发"""
    ps = obj.particle_systems.active
    if ps:
        ps.settings.child_type = 'SIMPLE'
        ps.settings.child_nbr = child_count
        ps.settings.child_radius = child_radius
        ps.settings.child_length = 0.5
        
        return ps
    
    return None

def set_hair_material(obj, material):
    """设置毛发材质"""
    ps = obj.particle_systems.active
    if ps:
        if isinstance(material, bpy.types.Material):
            ps.settings.material = obj.data.materials.find(material.name)
        else:
            ps.settings.material = material
        
        return True
    
    return False

def adjust_hair_density(obj, density_factor):
    """调整毛发密度"""
    ps = obj.particle_systems.active
    if ps:
        original_count = ps.settings.count
        ps.settings.count = int(original_count * density_factor)
        print(f"毛发数量: {original_count} -> {ps.settings.count}")
        return ps.settings.count
    
    return None

def adjust_hair_length(obj, length_factor):
    """调整毛发长度"""
    ps = obj.particle_systems.active
    if ps:
        original_length = ps.settings.length
        ps.settings.length = original_length * length_factor
        print(f"毛发长度: {original_length:.4f} -> {ps.settings.length:.4f}")
        return ps.settings.length
    
    return None

def set_hair_color(obj, color):
    """设置毛发颜色"""
    ps = obj.particle_systems.active
    if ps:
        ps.settings.color = color
        return True
    
    return False

def add_hair_collision(collision_obj, hair_obj):
    """添加毛发碰撞"""
    ps = hair_obj.particle_systems.active
    if ps:
        ps.settings.collision_type = 'HAIR'
        ps.settings.collider = collision_obj
        
        # 确保碰撞对象是有效的
        if collision_obj:
            print(f"碰撞对象: {collision_obj.name}")
        
        return ps
    
    return None

def create_wet_hair(obj, wetness=0.5):
    """创建湿润毛发效果"""
    ps = obj.particle_systems.active
    if ps:
        # 减少重力影响
        ps.settings.gravity = 1.0 - wetness
        
        # 增加粗细
        ps.settings.hair_thickness *= (1 + wetness)
        
        # 减少子粒子数量
        if ps.settings.child_type != 'NONE':
            ps.settings.child_nbr = int(ps.settings.child_nbr * (1 - wetness * 0.5))
        
        return ps
    
    return None
```

## 常见问题排查

### 毛发不显示
```python
# 检查粒子系统
obj = bpy.context.active_object
print(f"粒子系统数: {len(obj.particle_systems)}")

if obj.particle_systems:
    ps = obj.particle_systems.active
    print(f"活跃粒子系统: {ps.name}")
    print(f"毛发数量: {ps.settings.count}")
    print(f"毛发长度: {ps.settings.length}")
    
    # 检查粒子类型
    print(f"粒子类型: {ps.settings.type}")

# 检查渲染类型
if ps.settings.type == 'HAIR':
    print(f"渲染类型: {ps.settings.render_type}")

# 确保粒子系统可见
ps.settings.render_step = 3
ps.settings.use_hair_dynamics = False
```

### 毛发穿透问题
```python
# 检查碰撞设置
ps = bpy.context.active_object.particle_systems.active
print(f"碰撞类型: {ps.settings.collision_type}")
print(f"碰撞对象: {ps.settings.collider}")

# 添加碰撞
for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':
        ps.settings.collider = obj
        ps.settings.collision_type = 'HAIR'
        break

# 增加碰撞质量
ps.settings.mass = 1.0

# 减少重力
ps.settings.gravity = 0.5
```

### 性能问题
```python
# 检查毛发数量
ps = bpy.context.active_object.particle_systems.active
print(f"毛发数量: {ps.settings.count}")

# 减少数量
ps.settings.count = int(ps.settings.count * 0.5)

# 减少分段数
ps.settings.hair_step = 2

# 禁用子粒子
ps.settings.child_type = 'NONE'

# 减少子粒子数量
ps.settings.child_nbr = int(ps.settings.child_nbr * 0.5)

# 检查渲染设置
ps.settings.render_step = 5
```

### 毛发造型问题
```python
# 检查毛发编辑模式
print(f"当前模式: {bpy.context.mode}")

# 切换到毛发编辑模式
bpy.ops.object.mode_set(mode='PARTICLE_EDIT')

# 检查选中的毛发
if bpy.context.mode == 'PARTICLE_EDIT':
    ps = bpy.context.active_object.particle_systems.active
    print(f"选中的毛发: {len(bpy.context.selected_editable_ particles)}")

# 重置毛发
bpy.ops.particle.reset()
```

### 材质问题
```python
# 检查材质
obj = bpy.context.active_object
ps = obj.particle_systems.active

print(f"材质槽数: {len(obj.data.materials)}")
print(f"分配的材质: {ps.settings.material}")

# 确保材质存在
if ps.settings.material >= len(obj.data.materials):
    ps.settings.material = 0

# 检查材质类型
if obj.data.materials:
    mat = obj.data.materials[ps.settings.material]
    print(f"材质: {mat.name}")
    print(f"使用节点: {mat.use_nodes}")
```

### 导出问题
```python
# 检查导出设置
print(f"导出粒子: {bpy.context.scene.particle_export_}

# 启用粒子导出
bpy.context.scene.particle_export = True

# 检查导出格式
print(f"导出格式: {bpy.context.scene.particle_export_format}")

# 转换为网格后导出
bpy.ops.object.convert(target='MESH')
bpy.ops.export_scene.obj(filepath='//hair_model.obj')
```
