# bpy.ops.palette - Palette Operations Module

Blender 调色板操作符，用于管理和操作颜色调色板。

## Overview

`bpy.ops.palette` 模块包含调色板的操作命令，支持颜色的添加、删除、排序和管理。这个模块主要用于culpt 绘画和纹理绘画中的颜色管理。

## 核心功能

```python
import bpy

# 添加颜色
bpy.ops.palette.add()

# 移除颜色
bpy.ops.palette.remove()

# 排序颜色
bpy.ops.palette.sort()

# 收缩调色板
bpy.ops.palette.shrink()

# 扩展调色板
bpy.ops.palette.expand()
```

## 实际应用示例

### 调色板管理器

```python
import bpy
import colorsys

class PaletteManager:
    """调色板管理器"""
    
    def __init__(self):
        self.palettes = {}
    
    def get_active_palette(self):
        """获取当前调色板"""
        return bpy.context.scene.tool_settings.sculpt_palette
    
    def create_palette(self, name, colors=None):
        """创建调色板"""
        palette = bpy.data.palettes.new(name=name)
        
        if colors:
            for color in colors:
                self.add_color(palette, color)
        
        self.palettes[name] = palette
        return palette
    
    def add_color(self, palette, color, position=-1):
        """添加颜色"""
        color_slot = palette.colors.add()
        color_slot.color = color
        
        if position >= 0:
            # 移动到指定位置
            palette.colors.move(position, len(palette.colors) - 1)
        
        return color_slot
    
    def add_color_from_hex(self, palette, hex_color, position=-1):
        """从十六进制添加颜色"""
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16) / 255.0
        g = int(hex_color[2:4], 16) / 255.0
        b = int(hex_color[4:6], 16) / 255.0
        
        return self.add_color(palette, (r, g, b, 1.0), position)
    
    def remove_color(self, palette, index):
        """移除颜色"""
        if index < len(palette.colors):
            palette.colors.remove(palette.colors[index])
    
    def remove_color_by_name(self, palette, name):
        """按名称移除颜色"""
        for i, color in enumerate(palette.colors):
            if color.name == name:
                self.remove_color(palette, i)
                return True
        return False
    
    def clear_palette(self, palette):
        """清空调色板"""
        while len(palette.colors) > 0:
            palette.colors.remove(palette.colors[0])
    
    def get_color(self, palette, index):
        """获取颜色"""
        if index < len(palette.colors):
            return palette.colors[index]
        return None
    
    def set_color(self, palette, index, color):
        """设置颜色"""
        if index < len(palette.colors):
            palette.colors[index].color = color
    
    def swap_colors(self, palette, index1, index2):
        """交换颜色"""
        if (index1 < len(palette.colors) and 
            index2 < len(palette.colors)):
            color1 = palette.colors[index1].color.copy()
            color2 = palette.colors[index2].color.copy()
            
            palette.colors[index1].color = color2
            palette.colors[index2].color = color1
    
    def duplicate_color(self, palette, index):
        """复制颜色"""
        color = self.get_color(palette, index)
        if color:
            return self.add_color(palette, color.color)
    
    def sort_by_hue(self, palette, reverse=False):
        """按色相排序"""
        colors = [(i, c.color) for i, c in enumerate(palette.colors)]
        
        def get_hue(c):
            if c[3] < 0.5:  # 跳过透明
                return -1
            return colorsys.rgb_to_hsv(c[0], c[1], c[2])[0]
        
        colors.sort(key=get_hue, reverse=reverse)
        
        # 重新排序
        for new_index, (old_index, color) in enumerate(colors):
            if new_index != old_index:
                palette.colors.move(old_index, new_index)
    
    def sort_by_saturation(self, palette, reverse=False):
        """按饱和度排序"""
        colors = [(i, c.color) for i, c in enumerate(palette.colors)]
        
        def get_saturation(c):
            if c[3] < 0.5:
                return -1
            return colorsys.rgb_to_hsv(c[0], c[1], c[2])[1]
        
        colors.sort(key=get_saturation, reverse=reverse)
        
        for new_index, (old_index, color) in enumerate(colors):
            if new_index != old_index:
                palette.colors.move(old_index, new_index)
    
    def sort_by_brightness(self, palette, reverse=False):
        """按亮度排序"""
        colors = [(i, c.color) for i, c in enumerate(palette.colors)]
        
        def get_brightness(c):
            if c[3] < 0.5:
                return -1
            return colorsys.rgb_to_hsv(c[0], c[1], c[2])[2]
        
        colors.sort(key=get_brightness, reverse=reverse)
        
        for new_index, (old_index, color) in enumerate(colors):
            if new_index != old_index:
                palette.colors.move(old_index, new_index)
    
    def create_gradient(self, palette, start_color, end_color, steps):
        """创建渐变"""
        colors = []
        for i in range(steps):
            t = i / (steps - 1)
            r = start_color[0] + (end_color[0] - start_color[0]) * t
            g = start_color[1] + (end_color[1] - start_color[1]) * t
            b = start_color[2] + (end_color[2] - start_color[2]) * t
            colors.append((r, g, b, 1.0))
        
        for color in colors:
            self.add_color(palette, color)
        
        return colors
    
    def create_rainbow(self, palette, steps=12):
        """创建彩虹色"""
        colors = []
        for i in range(steps):
            hue = i / steps
            rgb = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
            colors.append((rgb[0], rgb[1], rgb[2], 1.0))
        
        for color in colors:
            self.add_color(palette, color)
        
        return colors
    
    def create_grayscale(self, palette, steps=10):
        """创建灰度"""
        colors = []
        for i in range(steps):
            gray = i / (steps - 1)
            colors.append((gray, gray, gray, 1.0))
        
        for color in colors:
            self.add_color(palette, color)
        
        return colors
    
    def export_palette(self, palette, filepath):
        """导出调色板"""
        with open(filepath, 'w') as f:
            for color in palette.colors:
                r, g, b, a = color.color
                f.write(f"{r:.4f} {g:.4f} {b:.4f} {a:.4f}\n")
        
        return filepath
    
    def import_palette(self, filepath, palette_name="Imported"):
        """导入调色板"""
        colors = []
        
        with open(filepath, 'r') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 3:
                    colors.append((float(parts[0]), float(parts[1]), 
                                   float(parts[2]), 1.0))
        
        return self.create_palette(palette_name, colors)
    
    def duplicate_palette(self, palette, new_name):
        """复制调色板"""
        new_palette = self.create_palette(new_name)
        
        for color in palette.colors:
            self.add_color(new_palette, color.color)
        
        return new_palette
    
    def get_palette_info(self, palette):
        """获取调色板信息"""
        return {
            'name': palette.name,
            'color_count': len(palette.colors),
            'colors': [(c.color[0], c.color[1], c.color[2]) 
                      for c in palette.colors]
        }


def setup_palette_manager():
    """设置调色板管理器"""
    manager = PaletteManager()
    
    print("调色板管理器已设置")
    print("可用功能:")
    print("- create_palette: 创建调色板")
    print("- add_color: 添加颜色")
    print("- sort_by_hue: 按色相排序")
    print("- create_gradient: 创建渐变")
    
    return manager
```

### 颜色选择器工具

```python
import bpy
import colorsys

class ColorPickerTools:
    """颜色选择器工具"""
    
    def __init__(self):
        self.color_history = []
    
    def rgb_to_hsv(self, r, g, b):
        """RGB 转 HSV"""
        return colorsys.rgb_to_hsv(r, g, b)
    
    def hsv_to_rgb(self, h, s, v):
        """HSV 转 RGB"""
        return colorsys.hsv_to_rgb(h, s, v)
    
    def rgb_to_hex(self, r, g, b):
        """RGB 转十六进制"""
        return '#{:02x}{:02x}{:02x}'.format(
            int(r * 255), int(g * 255), int(b * 255)
        )
    
    def hex_to_rgb(self, hex_color):
        """十六进制转 RGB"""
        hex_color = hex_color.lstrip('#')
        return (
            int(hex_color[0:2], 16) / 255.0,
            int(hex_color[2:4], 16) / 255.0,
            int(hex_color[4:6], 16) / 255.0
        )
    
    def get_complementary(self, color):
        """获取互补色"""
        r, g, b = color[0], color[1], color[2]
        h, s, v = self.rgb_to_hsv(r, g, b)
        h = (h + 0.5) % 1.0
        rgb = self.hsv_to_rgb(h, s, v)
        return (rgb[0], rgb[1], rgb[2], color[3] if len(color) > 3 else 1.0)
    
    def get_analogous(self, color, angle=30):
        """获取类似色"""
        r, g, b = color[0], color[1], color[2]
        h, s, v = self.rgb_to_hsv(r, g, b)
        
        analogous = []
        for offset in [-angle, angle]:
            new_h = (h + offset / 360.0) % 1.0
            rgb = self.hsv_to_rgb(new_h, s, v)
            analogous.append((rgb[0], rgb[1], rgb[2], color[3] if len(color) > 3 else 1.0))
        
        return analogous
    
    def get_triadic(self, color):
        """获取三色"""
        r, g, b = color[0], color[1], color[2]
        h, s, v = self.rgb_to_hsv(r, g, b)
        
        triadic = []
        for offset in [1/3, 2/3]:
            new_h = (h + offset) % 1.0
            rgb = self.hsv_to_rgb(new_h, s, v)
            triadic.append((rgb[0], rgb[1], rgb[2], color[3] if len(color) > 3 else 1.0))
        
        return triadic
    
    def get_tetradic(self, color):
        """获取四色"""
        r, g, b = color[0], color[1], color[2]
        h, s, v = self.rgb_to_hsv(r, g, b)
        
        tetradic = []
        for offset in [1/4, 1/2, 3/4]:
            new_h = (h + offset) % 1.0
            rgb = self.hsv_to_rgb(new_h, s, v)
            tetradic.append((rgb[0], rgb[1], rgb[2], color[3] if len(color) > 3 else 1.0))
        
        return tetradic
    
    def adjust_brightness(self, color, factor):
        """调整亮度"""
        r, g, b = color[0], color[1], color[2]
        h, s, v = self.rgb_to_hsv(r, g, b)
        v = max(0, min(1, v * factor))
        rgb = self.hsv_to_rgb(h, s, v)
        return (rgb[0], rgb[1], rgb[2], color[3] if len(color) > 3 else 1.0)
    
    def adjust_saturation(self, color, factor):
        """调整饱和度"""
        r, g, b = color[0], color[1], color[2]
        h, s, v = self.rgb_to_hsv(r, g, b)
        s = max(0, min(1, s * factor))
        rgb = self.hsv_to_rgb(h, s, v)
        return (rgb[0], rgb[1], rgb[2], color[3] if len(color) > 3 else 1.0)
    
    def adjust_hue(self, color, offset):
        """调整色相"""
        r, g, b = color[0], color[1], color[2]
        h, s, v = self.rgb_to_hsv(r, g, b)
        h = (h + offset) % 1.0
        rgb = self.hsv_to_rgb(h, s, v)
        return (rgb[0], rgb[1], rgb[2], color[3] if len(color) > 3 else 1.0)
    
    def desaturate(self, color, factor=1.0):
        """去饱和"""
        r, g, b = color[0], color[1], color[2]
        gray = 0.299 * r + 0.587 * g + 0.114 * b
        return (
            r + (gray - r) * factor,
            g + (gray - g) * factor,
            b + (gray - b) * factor,
            color[3] if len(color) > 3 else 1.0
        )
    
    def create_color_scheme(self, base_color, scheme_type='complementary'):
        """创建配色方案"""
        if scheme_type == 'complementary':
            return [base_color, self.get_complementary(base_color)]
        elif scheme_type == 'analogous':
            return [base_color] + self.get_analogous(base_color)
        elif scheme_type == 'triadic':
            return [base_color] + self.get_triadic(base_color)
        elif scheme_type == 'tetradic':
            return [base_color] + self.get_tetradic(base_color)
        elif scheme_type == 'monochromatic':
            colors = []
            for i in range(5):
                factor = 0.5 + i * 0.125
                colors.append(self.adjust_brightness(base_color, factor))
            return colors
        
        return [base_color]
    
    def add_to_history(self, color):
        """添加到历史"""
        self.color_history.append(color)
        if len(self.color_history) > 10:
            self.color_history.pop(0)
    
    def get_history(self):
        """获取历史"""
        return self.color_history.copy()


def setup_color_tools():
    """设置颜色工具"""
    tools = ColorPickerTools()
    
    print("颜色选择器工具已设置")
    print("可用功能:")
    print("- get_complementary: 互补色")
    print("- get_analogous: 类似色")
    print("- get_triadic: 三色")
    print("- create_color_scheme: 创建配色方案")
    
    return tools
```
