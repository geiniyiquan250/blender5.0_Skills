# bpy.ops.node - 节点添加操作模块

bpy.ops.node模块提供了节点编辑器中添加和操作节点的功能，用于创建各种类型的节点。

## 概述

节点编辑器是Blender中用于创建材质、合成和几何节点树的重要工具。这个模块提供了添加、连接和编辑节点的操作。

## 核心功能

### 添加节点

```python
import bpy

def add_input_node(node_type):
    """添加输入节点"""
    bpy.ops.node.add_node(
        type=node_type,
        use_transform=True
    )

def add_output_node():
    """添加输出节点"""
    bpy.ops.node.add_node(
        type='ShaderNodeOutputMaterial',
        use_transform=True
    )

def add_texture_node():
    """添加纹理节点"""
    bpy.ops.node.add_node(
        type='ShaderNodeTexImage',
        use_transform=True
    )

def add_color_node():
    """添加颜色节点"""
    bpy.ops.node.add_node(
        type='ShaderNodeRGB',
        use_transform=True
    )

def add_value_node():
    """添加值节点"""
    bpy.ops.node.add_node(
        type='ShaderNodeValue',
        use_transform=True
    )

def add_vector_node():
    """添加向量节点"""
    bpy.ops.node.add_node(
        type='ShaderNodeVector',
        use_transform=True
    )
```

### 节点操作

```python
def delete_node():
    """删除节点"""
    bpy.ops.node.delete()

def duplicate_node():
    """复制节点"""
    bpy.ops.node.duplicate()

def detach_node():
    """分离节点"""
    bpy.ops.node.detach()

def hide_node():
    """隐藏节点"""
    bpy.ops.node.hide_toggle()

def mute_node():
    """静音节点"""
    bpy.ops.node.mute_toggle()
```

### 节点连接

```python
def link_nodes():
    """链接节点"""
    bpy.ops.node.link(

        type='NodeSocketVector',
        from_socket='Emission',
        to_socket='Surface'
    )

def unlink_nodes():
    """取消链接"""
    bpy.ops.node.links_detach()

def add_reroute():
    """添加路由点"""
    bpy.ops.node.add_reroute()
```

## 实用函数

### 选择操作

```python
def select_all():
    """全选"""
    bpy.ops.node.select_all(action='SELECT')

def deselect_all():
    """取消全选"""
    bpy.ops.node.select_all(action='DESELECT')

def select_hierarchy():
    """选择层级"""
    bpy.ops.node.select_hierarchy(
        direction='CHILD',
        extend=False
    )

def select_border():
    """框选"""
    bpy.ops.node.select_border(
        extend=False,
        tweak=False
    )
```

### 视口操作

```python
def view_center_cursor():
    """将视口居中到光标"""
    bpy.ops.node.view_center_cursor()

def view_selected():
    """查看选中"""
    bpy.ops.node.view_selected()

def zoom_in():
    """放大"""
    bpy.ops.node.zoom_in()

def zoom_out():
    """缩小"""
    bpy.ops.node.zoom_out()
```

### 节点组

```python
def join_nodes():
    """加入节点组"""
    bpy.ops.node.join_group()

def group_insert():
    """插入组"""
    bpy.ops.node.group_insert()

def group_ungroup():
    """取消组"""
    bpy.ops.node.group_ungroup()
```

## 常见问题排查

### 节点添加失败

类型错误：
- 确认节点类型名称正确
- 检查节点是否可用
- 验证编辑器类型匹配

### 链接问题

连接失败：
- 确认Socket类型兼容
- 检查输入输出是否存在
- 验证连接方向正确
