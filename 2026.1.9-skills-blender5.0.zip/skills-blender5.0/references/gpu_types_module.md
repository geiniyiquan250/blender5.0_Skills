# gpu.types - GPU类型定义模块

gpu.types模块定义了Blender GPU库中使用的核心数据类型，包括缓冲区类型、顶点格式、着色器类型等。

## 概述

GPU类型模块定义了GPU渲染所需的底层数据类型。这些类型是构建自定义GPU渲染效果的基础，理解这些类型对于开发GPU扩展至关重要。

## 核心类型

### 缓冲区类型

```python
from gpu.types import (
    GPUBuffer,
    GPUVertBuf,
    GPUIndexBuf,
    GPUUniformBuf
)

class GPUBuffer:
    """GPU缓冲区基类型"""
    def __init__(self, size=None, data=None):
        self._obj = None
        if size or data:
            self._obj = gpu.buffer.create(size or len(data))
            if data:
                self._obj.data = data
    
    def bind(self, binding_point):
        """绑定缓冲区"""
        self._obj.bind(binding_point)
    
    def unbind(self):
        """解绑缓冲区"""
        gpu.buffer.unbind(self._obj)
    
    def clear(self, value):
        """清除缓冲区"""
        self._obj.clear(value)
    
    def read(self, size=0, offset=0):
        """读取缓冲区数据"""
        return self._obj.read(size, offset)

class GPUVertBuf(GPUBuffer):
    """GPU顶点缓冲区"""
    def __init__(self, format, len):
        self._obj = gpu.vertex_buffer.create(format, len)
        self._format = format
        self._len = len
    
    def fill(self, data, start=0):
        """填充顶点数据"""
        self._obj.data = data
        self._obj.update(start)

class GPUIndexBuf(GPUBuffer):
    """GPU索引缓冲区"""
    def __init__(self, type, len):
        self._obj = gpu.index_buffer.create(type, len)
        self._type = type
        self._len = len
    
    def fill(self, data, start=0):
        """填充索引数据"""
        self._obj.data = data
        self._obj.update(start)

class GPUUniformBuf(GPUBuffer):
    """GPU Uniform缓冲区"""
    def __init__(self, size, binding=0):
        self._obj = gpu.uniform_buffer.create(size, binding)
        self._size = size
    
    def update(self, data, offset=0):
        """更新Uniform数据"""
        self._obj.update(data, offset)
```

### 顶点格式

```python
from gpu.types import GPUVertFormat

class GPUVertFormat:
    """GPU顶点格式"""
    def __init__(self):
        self._obj = gpu.vertex_format.create()
        self.attributes = []
    
    def attribute_add(self, name, comp_type, length, fetch_mode):
        """添加顶点属性"""
        self._obj.attribute_add(name, comp_type, length, fetch_mode)
        self.attributes.append({
            'name': name,
            'type': comp_type,
            'length': length,
            'mode': fetch_mode
        })
    
    def clear(self):
        """清除格式"""
        self._obj.clear()
    
    @staticmethod
    def create():
        """创建顶点格式"""
        return GPUVertFormat()
```

### 着色器类型

```python
from gpu.types import (
    GPUShader,
    GPUShaderCreateInfo,
    GPUShaderVertGen,
    GPUShaderVertIn
)

class GPUShader:
    """GPU着色器"""
    def __init__(self, vert, frag=None, geom=None, defines=None):
        self._obj = None
        self._uniforms = {}
        if vert and frag:
            self._obj = gpu.shader.create(vert, frag, geom, defines)
    
    def bind(self):
        """绑定着色器"""
        self._obj.bind()
    
    def unbind(self):
        """解绑着色器"""
        gpu.shader.unbind()
    
    def uniform_int(self, name, value):
        """设置整数Uniform"""
        self._obj.uniform_int(name, value)
    
    def uniform_float(self, name, value):
        """设置浮点Uniform"""
        self._obj.uniform_float(name, value)
    
    def uniform_float_array(self, name, value):
        """设置浮点数组Uniform"""
        self._obj.uniform_float_array(name, value)
    
    def uniform_2fv(self, name, value):
        """设置2维向量Uniform"""
        self._obj.uniform_2fv(name, value)
    
    def uniform_3fv(self, name, value):
        """设置3维向量Uniform"""
        self._obj.uniform_3fv(name, value)
    
    def uniform_4fv(self, name, value):
        """设置4维向量Uniform"""
        self._obj.uniform_4fv(name, value)
    
    def uniform_mat4(self, name, value):
        """设置矩阵Uniform"""
        self._obj.uniform_mat4(name, value)
```

## 扩展类型

### 批量绘制类型

```python
from gpu.types import (
    GPUBatch,
    GPUBatchPresets
)

class GPUBatch:
    """GPU批处理"""
    def __init__(self, type, vertbuf, indexbuf=None):
        self._obj = gpu.batch.create(type, vertbuf._obj, indexbuf._obj if indexbuf else None)
        self._type = type
        self._vertbuf = vertbuf
    
    def draw(self):
        """绘制批处理"""
        self._obj.draw()
    
    def draw_range(self, start, end):
        """绘制范围"""
        self._obj.draw_range(start, end)
    
    def instance(self, count):
        """实例化绘制"""
        self._obj.instance(count)
    
    @staticmethod
    def points(vertbuf):
        """创建点批处理"""
        return GPUBatch('POINTS', vertbuf)
    
    @staticmethod
    def line_strip(vertbuf):
        """创建线带批处理"""
        return GPUBatch('LINE_STRIP', vertbuf)
    
    @staticmethod
    def lines(vertbuf):
        """创建线批处理"""
        return GPUBatch('LINES', vertbuf)
    
    @staticmethod
    def triangles(vertbuf, indexbuf=None):
        """创建三角批处理"""
        return GPUBatch('TRIANGLES', vertbuf, indexbuf)
```

### 纹理类型

```python
from gpu.types import (
    GPUTexture,
    GPUTexture1D,
    GPUTexture2D,
    GPUTexture3D,
    GPUTextureCube
)

class GPUTexture:
    """GPU纹理基类型"""
    def __init__(self):
        self._obj = None
        self._format = 'RGBA8'
        self._size = (0, 0, 0)
    
    def bind(self, unit):
        """绑定纹理"""
        self._obj.bind(unit)
    
    def unbind(self, unit):
        """解绑纹理"""
        gpu.texture.unbind(unit)
    
    def clear(self, color):
        """清除纹理"""
        self._obj.clear(color)
    
    def read(self):
        """读取纹理数据"""
        return self._obj.read()

class GPUTexture2D(GPUTexture):
    """2D纹理"""
    def __init__(self, width, height, format='RGBA8', samples=0):
        super().__init__()
        self._format = format
        self._size = (width, height, 0)
        if samples > 0:
            self._obj = gpu.texture.create_2d_multisample(width, height, samples, format)
        else:
            self._obj = gpu.texture.create_2d(width, height, format)
    
    def update(self, data, level=0):
        """更新纹理数据"""
        self._obj.update(data, level)
    
    def read(self):
        """读取纹理"""
        return self._obj.read()
```

## 实用函数

### 类型创建

```python
def create_vertex_buffer(data, format):
    """创建顶点缓冲区"""
    vbo = GPUVertBuf(format, len(data))
    vbo.fill(data)
    return vbo

def create_index_buffer(data, type='UNSIGNED_INT'):
    """创建索引缓冲区"""
    ibo = GPUIndexBuf(type, len(data))
    ibo.fill(data)
    return ibo

def create_uniform_buffer(data, binding=0):
    """创建Uniform缓冲区"""
    ubo = GPUUniformBuf(len(data) * 4, binding)
    ubo.update(data)
    return ubo

def create_batch(type, vertbuf, indexbuf=None):
    """创建批处理"""
    return GPUBatch(type, vertbuf, indexbuf)
```

### 格式构建

```python
def build_vertex_format(*attributes):
    """构建顶点格式"""
    fmt = GPUVertFormat()
    for name, dtype, length in attributes:
        fmt.attribute_add(name, dtype, length, 'FLOAT')
    return fmt

def pos3_color4_format():
    """位置3分量颜色4分量格式"""
    return build_vertex_format(
        ('pos', 'FLOAT', 3),
        ('color', 'FLOAT', 4)
    )

def pos3_uv2_format():
    """位置3分量UV2分量格式"""
    return build_vertex_format(
        ('pos', 'FLOAT', 3),
        ('uv', 'FLOAT', 2)
    )

def pos3_normal3_format():
    """位置3分量法线3分量格式"""
    return build_vertex_format(
        ('pos', 'FLOAT', 3),
        ('normal', 'FLOAT', 3)
    )
```

## 常见问题排查

### 缓冲区创建失败

资源不足：
- 检查GPU内存
- 减少缓冲区大小
- 分批创建缓冲区

### 顶点格式错误

属性定义问题：
- 确认属性名称唯一
- 检查组件类型正确
- 验证属性数量限制

### 类型不匹配

类型使用错误：
- 使用正确的类型构造函数
- 确认参数类型匹配
- 检查GPU能力支持
