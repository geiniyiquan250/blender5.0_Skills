# bpy.ops.collection - Collection Operations Module

集合操作模块，用于创建、管理和组织Blender集合。

## 概述

`bpy.ops.collection` 模块提供了Blender集合系统的操作功能，包括集合的创建、删除、对象管理、批量导出等。集合是Blender组织场景数据的核心机制，支持复杂的层级结构和灵活的对象管理。

## 核心功能

### 集合创建

```python
import bpy

# 创建新集合
bpy.ops.collection.create(name='')
```

### 对象管理

```python
# 添加活动对象到集合
bpy.ops.collection.objects_add_active(collection='')

# 从集合移除对象
bpy.ops.collection.objects_remove(collection='')

# 从集合移除活动对象
bpy.ops.collection.objects_remove_active(collection='')

# 从所有集合移除对象
bpy.ops.collection.objects_remove_all()
```

### 批量导出

```python
# 添加导出器
bpy.ops.collection.exporter_add(name='')

# 执行导出
bpy.ops.collection.exporter_export(index=0)

# 移动导出器
bpy.ops.collection.exporter_move(direction='UP')

# 移除导出器
bpy.ops.collection.exporter_remove(index=0)

# 导出所有
bpy.ops.collection.export_all()
```

## 实用函数

```python
# 创建集合并添加选中对象
def create_collection_with_selected(name):
    # 创建集合
    bpy.ops.collection.create(name=name)
    # 添加选中对象
    bpy.ops.collection.objects_add_active(collection=name)

# 批量创建多个集合
def create_multiple_collections(names):
    for name in names:
        bpy.ops.collection.create(name=name)

# 清空对象的集合引用
def clear_all_collections(obj):
    bpy.ops.collection.objects_remove_all()

# 移动对象到新集合
def move_to_collection(obj_name, collection_name):
    # 选中对象
    bpy.ops.object.select_all(action='DESELECT')
    bpy.data.objects[obj_name].select_set(True)
    bpy.context.view_layer.objects.active = bpy.data.objects[obj_name]
    # 移除所有集合
    bpy.ops.collection.objects_remove_all()
    # 添加到新集合
    bpy.ops.collection.objects_add_active(collection=collection_name)

# 批量导出集合中的对象
def export_collection_objects(collection_name, filepath):
    # 设置导出参数
    # 执行导出操作
    pass
```

## 常见问题排查

**问题：创建集合失败**

- 检查名称是否重复
- 确认名称格式正确
- 验证权限是否足够

**问题：对象无法添加到集合**

- 确保对象存在
- 检查集合是否有效
- 确认对象类型支持集合

**问题：导出失败**

- 检查导出器配置
- 确认文件路径可写
- 验证导出格式支持

**问题：集合引用混乱**

- 使用`objects_remove_all()`清理引用
- 重新组织集合结构
- 避免循环引用

**问题：批量导出无响应**

- 检查导出队列
- 确认资源充足
- 尝试分批导出
