# bpy.ops.surface - Surface Operations Module

Blender 曲面操作符，用于创建和编辑 NURBS 曲面和曲面对象。

## Overview

`bpy.ops.surface` 模块包含曲面对象的操作命令，支持 NURBS 曲面的创建、编辑和参数调整。这个模块主要用于高级建模中的曲面创建。

## 核心功能

```python
import bpy

# 添加 NURBS 曲面
bpy.ops.surface.primitive_nurbs_surface_surface_add(location=(0, 0, 0))

# 添加 NURBS 圆柱
bpy.ops.surface.primitive_nurbs_surface_cylinder_add(location=(0, 0, 0))

# 添加 NURBS 球体
bpy.ops.surface.primitive_nurbs_surface_sphere_add(location=(0, 0, 0))

# 添加 NURBS 圆环
bpy.ops.surface.primitive_nurbs_surface_torus_add(location=(0, 0, 0))
```

## 实际应用示例

### 曲面管理器

```python
import bpy
import math

class SurfaceManager:
    """曲面管理器"""
    
    def __init__(self):
        self.surfaces = {}
    
    def create_nurbs_surface(self, name, location=(0, 0, 0),
                             u_size=1, v_size=1,
                             u_resolution=4, v_resolution=4):
        """创建 NURBS 曲面"""
        bpy.ops.surface.primitive_nurbs_surface_surface_add(
            location=location
        )
        surface = bpy.context.active_object
        surface.name = name
        
        # 设置分辨率
        surface.data.u_resolution = u_resolution
        surface.data.v_resolution = v_resolution
        
        self.surfaces[name] = surface
        return surface
    
    def create_nurbs_cylinder(self, name, location=(0, 0, 0),
                              radius=1, depth=2,
                              resolution_u=8, resolution_v=4):
        """创建 NURBS 圆柱"""
        bpy.ops.surface.primitive_nurbs_surface_cylinder_add(
            location=location
        )
        cylinder = bpy.context.active_object
        cylinder.name = name
        
        # 设置参数
        cylinder.data.radius = radius
        cylinder.data.depth = depth
        cylinder.data.resolution_u = resolution_u
        cylinder.data.resolution_v = resolution_v
        
        self.surfaces[name] = cylinder
        return cylinder
    
    def create_nurbs_sphere(self, name, location=(0, 0, 0),
                           radius=1, resolution_u=16, resolution_v=12):
        """创建 NURBS 球体"""
        bpy.ops.surface.primitive_nurbs_surface_sphere_add(
            location=location
        )
        sphere = bpy.context.active_object
        sphere.name = name
        
        # 设置参数
        sphere.data.radius = radius
        sphere.data.resolution_u = resolution_u
        sphere.data.resolution_v = resolution_v
        
        self.surfaces[name] = sphere
        return sphere
    
    def create_nurbs_torus(self, name, location=(0, 0, 0),
                          major_radius=2, minor_radius=0.5,
                          resolution_u=16, resolution_v=8):
        """创建 NURBS 圆环"""
        bpy.ops.surface.primitive_nurbs_surface_torus_add(
            location=location
        )
        torus = bpy.context.active_object
        torus.name = name
        
        # 设置参数
        torus.data.major_radius = major_radius
        torus.data.minor_radius = minor_radius
        torus.data.resolution_u = resolution_u
        torus.data.resolution_v = resolution_v
        
        self.surfaces[name] = torus
        return torus
    
    def add_surface_primitive(self, surface_type, name, **kwargs):
        """添加曲面图元"""
        if surface_type == 'surface':
            return self.create_nurbs_surface(name, **kwargs)
        elif surface_type == 'cylinder':
            return self.create_nurbs_cylinder(name, **kwargs)
        elif surface_type == 'sphere':
            return self.create_nurbs_sphere(name, **kwargs)
        elif surface_type == 'torus':
            return self.create_nurbs_torus(name, **kwargs)
    
    def convert_to_mesh(self, surface_name):
        """转换为网格"""
        surface = self.surfaces.get(surface_name)
        if surface:
            bpy.context.view_layer.objects.active = surface
            bpy.ops.object.convert(target='MESH')
    
    def convert_to_curve(self, surface_name):
        """转换为曲线"""
        surface = self.surfaces.get(surface_name)
        if surface:
            bpy.context.view_layer.objects.active = surface
            bpy.ops.object.convert(target='CURVE')
    
    def set_resolution(self, surface_name, u_res, v_res):
        """设置分辨率"""
        surface = self.surfaces.get(surface_name)
        if surface:
            surface.data.u_resolution = u_res
            surface.data.v_resolution = v_res
    
    def set_u_knots(self, surface_name, knots):
        """设置 U 方向节点"""
        surface = self.surfaces.get(surface_name)
        if surface:
            surface.data.u_knots = knots
    
    def set_v_knots(self, surface_name, knots):
        """设置 V 方向节点"""
        surface = self.surfaces.get(surface_name)
        if surface:
            surface.data.v_knots = knots
    
    def get_surface_info(self, surface_name):
        """获取曲面信息"""
        surface = self.surfaces.get(surface_name)
        if not surface:
            return None
        
        data = surface.data
        return {
            'name': surface.name,
            'type': data.type,
            'u_resolution': data.u_resolution,
            'v_resolution': data.v_resolution,
            'u_knots': len(data.u_knots),
            'v_knots': len(data.v_knots)
        }
    
    def duplicate_surface(self, surface_name, new_name):
        """复制曲面"""
        surface = self.surfaces.get(surface_name)
        if surface:
            bpy.context.view_layer.objects.active = surface
            bpy.ops.object.duplicate()
            duplicate = bpy.context.active_object
            duplicate.name = new_name
            self.surfaces[new_name] = duplicate
            return duplicate
    
    def delete_surface(self, surface_name):
        """删除曲面"""
        surface = self.surfaces.get(surface_name)
        if surface:
            bpy.data.objects.remove(surface, do_unlink=True)
            del self.surfaces[surface_name]


def setup_surface_workflow():
    """设置曲面工作流程"""
    manager = SurfaceManager()
    
    print("曲面管理器已设置")
    print("可用功能:")
    print("- create_nurbs_surface: 创建 NURBS 曲面")
    print("- create_nurbs_cylinder: 创建 NURBS 圆柱")
    print("- convert_to_mesh: 转换为网格")
    
    return manager
```

### 曲面建模工具

```python
import bpy
import math

class SurfaceModelingTool:
    """曲面建模工具"""
    
    def __init__(self):
        self.control_points = {}
    
    def create_surface_from_points(self, points, u_segments, v_segments,
                                   name="Surface"):
        """从点创建曲面"""
        # 创建 NURBS 曲面
        surface = bpy.ops.surface.primitive_nurbs_surface_surface_add()
        surface = bpy.context.active_object
        surface.name = name
        
        # 设置控制点
        data = surface.data
        
        # 调整分辨率以匹配点网格
        data.u_resolution = u_segments + 1
        data.v_resolution = v_segments + 1
        
        # 设置点位置
        for i in range(u_segments + 1):
            for j in range(v_segments + 1):
                if i * (v_segments + 1) + j < len(points):
                    point = points[i * (v_segments + 1) + j]
                    # 设置控制点位置
                    pass
        
        return surface
    
    def create_ruled_surface(self, curve1, curve2, name="RuledSurface"):
        """创建直纹面"""
        # 创建两个 NURBS 曲线
        # 然后创建直纹面
        pass
    
    def create_revolved_surface(self, curve, axis=(0, 0, 1), angle=360,
                                name="RevolvedSurface"):
        """创建旋转面"""
        # 旋转曲线创建曲面
        pass
    
    def create_lofted_surface(self, curves, name="LoftedSurface"):
        """创建放样面"""
        # 通过多个曲线放样创建曲面
        pass
    
    def create_bezier_patch(self, name, resolution=4, size=2):
        """创建贝塞尔曲面"""
        surface = self.create_nurbs_surface(
            name,
            u_resolution=resolution,
            v_resolution=resolution
        )
        
        # 设置为贝塞尔类型
        surface.data.nurbs_type = 'BEZIER'
        surface.data.u_order = 4
        surface.data.v_order = 4
        
        return surface
    
    def add_control_point(self, surface_name, u, v, location):
        """添加控制点"""
        surface = self.surfaces.get(surface_name)
        if not surface:
            return
        
        # 获取控制点层
        pass
    
    def move_control_point(self, surface_name, u, v, offset):
        """移动控制点"""
        surface = self.surfaces.get(surface_name)
        if not surface:
            return
        
        # 移动控制点
        pass
    
    def insert_knot_u(self, surface_name, u_param):
        """插入 U 方向节点"""
        surface = self.surfaces.get(surface_name)
        if surface:
            surface.data.u_knots.append(u_param)
    
    def insert_knot_v(self, surface_name, v_param):
        """插入 V 方向节点"""
        surface = self.surfaces.get(surface_name)
        if surface:
            surface.data.v_knots.append(v_param)
    
    def increase_resolution(self, surface_name, u_increase=1, v_increase=1):
        """增加分辨率"""
        surface = self.surfaces.get(surface_name)
        if surface:
            surface.data.u_resolution += u_increase
            surface.data.v_resolution += v_increase
    
    def decrease_resolution(self, surface_name, u_decrease=1, v_decrease=1):
        """降低分辨率"""
        surface = self.surfaces.get(surface_name)
        if surface:
            surface.data.u_resolution = max(1, surface.data.u_resolution - u_decrease)
            surface.data.v_resolution = max(1, surface.data.v_resolution - v_decrease)
    
    def match_surface_to_mesh(self, surface_name, mesh_name):
        """匹配曲面到网格"""
        surface = self.surfaces.get(surface_name)
        mesh = bpy.data.objects.get(mesh_name)
        
        if not surface or not mesh:
            return
        
        # 设置曲面边界框匹配网格
        pass
    
    def create_patch_from_mesh_face(self, mesh_name, face_index,
                                   resolution=4):
        """从网格面创建曲面"""
        mesh = bpy.data.objects.get(mesh_name)
        if not mesh:
            return
        
        # 获取面顶点
        pass
    
    def export_surface_to_obj(self, surface_name, filepath):
        """导出曲面到 OBJ"""
        surface = self.surfaces.get(surface_name)
        if surface:
            # 转换为网格后导出
            self.convert_to_mesh(surface_name)
            
            bpy.ops.wm.obj_export(
                filepath=filepath,
                export_selected=True
            )


def setup_surface_modeling():
    """设置曲面建模"""
    tool = SurfaceModelingTool()
    
    print("曲面建模工具已设置")
    print("可用功能:")
    print("- create_surface_from_points: 从点创建")
    print("- create_bezier_patch: 创建贝塞尔曲面")
    print("- increase_resolution: 增加分辨率")
    
    return tool
```

### NURBS 曲线工具

```python
import bpy
import math

class NurbsCurveTool:
    """NURBS 曲线工具"""
    
    def __init__(self):
        self.curves = {}
    
    def create_nurbs_path(self, name, points, resolution=4):
        """创建 NURBS 路径"""
        bpy.ops.curve.primitive_nurbs_path_add()
        curve = bpy.context.active_object
        curve.name = name
        
        # 设置点
        data = curve.data
        data.resolution_u = resolution
        
        self.curves[name] = curve
        return curve
    
    def create_nurbs_circle(self, name, radius=1, resolution=16):
        """创建 NURBS 圆"""
        bpy.ops.curve.primitive_nurbs_circle_add(radius=radius)
        curve = bpy.context.active_object
        curve.name = name
        curve.data.resolution_u = resolution
        
        self.curves[name] = curve
        return curve
    
    def set_curve_resolution(self, curve_name, resolution):
        """设置曲线分辨率"""
        curve = self.curves.get(curve_name)
        if curve:
            curve.data.resolution_u = resolution
    
    def add_curve_point(self, curve_name, location, index=-1):
        """添加曲线点"""
        curve = self.curves.get(curve_name)
        if curve:
            bpy.ops.curve.duplicate()
    
    def remove_curve_point(self, curve_name, index):
        """移除曲线点"""
        curve = self.curves.get(curve_name)
        if curve and index < len(curve.data.splines[0].points):
            curve.data.splines[0].points.remove(
                curve.data.splines[0].points[index]
            )
    
    def set_curve_order(self, curve_name, order):
        """设置曲线阶数"""
        curve = self.curves.get(curve_name)
        if curve:
            curve.data.nurbs_type = 'POLY' if order == 1 else 'NURBS'
    
    def close_curve(self, curve_name):
        """闭合曲线"""
        curve = self.curves.get(curve_name)
        if curve:
            curve.data.splines[0].use_cyclic_u = True
    
    def open_curve(self, curve_name):
        """打开曲线"""
        curve = self.curves.get(curve_name)
        if curve:
            curve.data.splines[0].use_cyclic_u = False
    
    def create_curve_from_mesh(self, mesh_name, edge_indices,
                               name="Curve"):
        """从网格边创建曲线"""
        mesh = bpy.data.objects.get(mesh_name)
        if not mesh:
            return None
        
        # 选择边
        bpy.context.view_layer.objects.active = mesh
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        
        # 创建曲线
        pass
    
    def convert_to_nurbs(self, curve_name):
        """转换为 NURBS"""
        curve = self.curves.get(curve_name)
        if curve:
            curve.data.nurbs_type = 'NURBS'
    
    def convert_to_poly(self, curve_name):
        """转换为多边形"""
        curve = self.curves.get(curve_name)
        if curve:
            curve.data.nurbs_type = 'POLY'
    
    def get_curve_length(self, curve_name):
        """获取曲线长度"""
        curve = self.curves.get(curve_name)
        if curve:
            return curve.data.splines[0].calc_length()
        return 0
    
    def sample_curve(self, curve_name, num_samples=10):
        """采样曲线"""
        curve = self.curves.get(curve_name)
        if not curve:
            return []
        
        points = []
        for i in range(num_samples):
            t = i / (num_samples - 1)
            point = curve.data.splines[0].point_at_index(t)
            points.append(point)
        
        return points
    
    def create_offset_curve(self, curve_name, offset, name="Offset"):
        """创建偏移曲线"""
        curve = self.curves.get(curve_name)
        if not curve:
            return None
        
        # 创建偏移曲线
        pass
    
    def export_curve_to_svg(self, curve_name, filepath):
        """导出曲线到 SVG"""
        curve = self.curves.get(curve_name)
        if not curve:
            return
        
        # 生成 SVG
        svg_content = '<svg xmlns="http://www.w3.org/2000/svg">'
        svg_content += '<path d="'
        
        # 添加路径数据
        pass
        
        svg_content += '"/>'
        svg_content += '</svg>'
        
        with open(filepath, 'w') as f:
            f.write(svg_content)


def setup_nurbs_workflow():
    """设置 NURBS 工作流程"""
    tool = NurbsCurveTool()
    
    print("NURBS 曲线工具已设置")
    print("可用功能:")
    print("- create_nurbs_path: 创建路径")
    print("- create_nurbs_circle: 创建圆")
    print("- sample_curve: 采样曲线")
    
    return tool
```
