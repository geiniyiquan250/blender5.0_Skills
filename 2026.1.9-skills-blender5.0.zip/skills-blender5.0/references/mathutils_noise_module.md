# mathutils.noise 模块

## 模块概述

mathutils.noise 模块提供了一系列程序化噪波生成函数，这些函数是程序化内容生成的核心工具。噪波函数能够生成看似随机的但实际上具有连续性的数值分布，这种特性使得它们非常适合用于模拟自然界中的纹理、地形、云层等复杂现象。与纯随机数不同，噪波函数生成的数值在空间中具有相关性，相邻的点会产生相似的数值。

该模块实现了多种经典的噪波算法，每种算法都有其独特的特性适用场景。Blender 噪波提供基础的随机性分布，Cellular 噪波产生细胞状的图案，Voronoi 噪波生成基于距离场的特征，Musgrave 噪波系列则专门用于地形和表面纹理的程序化生成。这些函数的输出值通常在 -1 到 1 或 0 到 1 的范围内，可以通过参数调整频率、幅度、偏移等属性。

在 Blender 中，噪波函数被广泛应用于材质节点、几何节点、雕刻工具等各个模块。通过 Python API 直接使用这些函数可以实现更灵活的自动化处理，如批量生成纹理、程序化地形建模、动画噪波效果等。理解各种噪波算法的特性对于选择合适的工具解决特定问题至关重要。

## 基础噪波类型

### Blender 噪波

Blender 噪波是模块中最基础的随机噪波函数，它生成连续的随机值分布。这种噪波类似于 Perlin 噪波，但使用不同的算法实现。Blender 噪波适合用于创建基础的随机纹理、颜色变化、材质表面的微小变化等效果。通过调整输入坐标可以控制噪波的空间分布。

```python
from mathutils.noise import noise
from mathutils import Vector

# 一维 Blender 噪波
print("一维 Blender 噪波:")
for i in range(10):
    x = i * 0.1
    value = noise(x)
    print(f"  x={x:.1f}: {value:.4f}")

# 二维 Blender 噪波
print("\n二维 Blender 噪波:")
for i in range(5):
    for j in range(5):
        x, y = i * 0.5, j * 0.5
        value = noise(Vector((x, y)))
        print(f"  ({x:.1f}, {y:.1f}): {value:.4f}")

# 三维 Blender 噪波（用于动画）
print("\n三维 Blender 噪波（时间维度）:")
for t in range(5):
    value = noise(Vector((0.5, 0.5, t * 0.2)))
    print(f"  t={t}: {value:.4f}")

# 生成一维噪波序列
def generate_noise_sequence(start, end, steps, scale=1.0):
    """生成一维噪波序列"""
    values = []
    for i in range(steps):
        x = start + (end - start) * i / (steps - 1)
        values.append(scale * noise(x))
    return values

sequence = generate_noise_sequence(0, 10, 100, scale=0.5)
print(f"\n噪波序列统计:")
print(f"  长度: {len(sequence)}")
print(f"  最小值: {min(sequence):.4f}")
print(f"  最大值: {max(sequence):.4f}")
print(f"  平均值: {sum(sequence) / len(sequence):.4f}")
```

### 基础坐标变换

噪波函数的行为很大程度上取决于输入坐标的取值和变换。通过对坐标进行缩放、平移、旋转等变换，可以控制噪波的频率、相位和方向。这些变换对于获得期望的噪波效果至关重要。

```python
from mathutils.noise import noise
from mathutils import Vector, Matrix

# 频率缩放控制噪波的密度
def scaled_noise(x, y, scale):
    """缩放坐标后的噪波"""
    return noise(Vector((x * scale, y * scale)))

# 多尺度叠加（分形布朗运动基础）
def fbm_base(x, y, octaves=4, persistence=0.5, lacunarity=2.0):
    """基础的分形布朗运动"""
    total = 0.0
    frequency = 1.0
    amplitude = 1.0
    max_value = 0.0

    for _ in range(octaves):
        total += noise(Vector((x * frequency, y * frequency))) * amplitude
        max_value += amplitude
        amplitude *= persistence
        frequency *= lacunarity

    return total / max_value

# 测试不同频率的效果
print("不同频率的噪波对比:")
for scale in [0.5, 1.0, 2.0, 4.0]:
    value = scaled_noise(1.0, 1.0, scale)
    print(f"  频率 {scale}: {value:.4f}")

# 测试分形叠加
print("\n分形布朗运动测试:")
for octaves in [1, 2, 4, 8]:
    value = fbm_base(1.0, 1.0, octaves=octaves)
    print(f"  {octaves} 层叠加: {value:.4f}")
```

### 坐标偏移应用

通过在噪波调用前对坐标进行预处理，可以实现各种效果控制。添加时间偏移可以创建动画噪波，添加随机偏移可以生成多个不相关的噪波层，添加空间偏移可以移动噪波图案。

```python
from mathutils.noise import noise
from mathutils import Vector

def offset_noise(x, y, offset_x, offset_y):
    """带偏移的噪波"""
    return noise(Vector((x + offset_x, y + offset_y)))

def animated_noise(x, y, time, time_speed=1.0):
    """带时间动画的噪波"""
    return noise(Vector((x, y, time * time_speed)))

def layered_noise(x, y, layers):
    """多层噪波叠加"""
    total = 0.0
    for i, (offset, scale, weight) in enumerate(layers):
        layer_value = offset_noise(x, y, offset[0], offset[1])
        layer_value = offset_noise(x * scale, y * scale, 0, 0)
        total += layer_value * weight
    return total

# 时间动画示例
print("噪波动画帧:")
for frame in range(10):
    value = animated_noise(0.5, 0.5, frame, time_speed=0.1)
    print(f"  帧 {frame}: {value:.4f}")

# 多层噪波示例
layers = [
    ((0, 0), 1.0, 1.0),      # 基础层
    ((5.2, 1.3), 2.0, 0.5),  # 高频细节层
    ((3.4, 2.1), 4.0, 0.25)  # 更高频细节层
]
value = layered_noise(1.0, 1.0, layers)
print(f"\n多层噪波叠加结果: {value:.4f}")
```

## Cellular 噪波

### Cellular 噪波基础

Cellular 噪波生成基于细胞分裂模式的特征图案，它在每个输入点周围查找最近的细胞中心点，并计算到该中心的距离。这种噪波产生细胞状、斑点状的图案，非常适合创建皮肤、鳞片、细胞组织等自然纹理。

```python
from mathutils.noise import cellular
from mathutils import Vector

# 二维 Cellular 噪波
print("二维 Cellular 噪波:")
for i in range(5):
    for j in range(5):
        x, y = i * 0.5, j * 0.5
        value = cellular(Vector((x, y)))
        print(f"  ({x:.1f}, {y:.1f}): {value:.4f}")

# 三维 Cellular 噪波
print("\n三维 Cellular 噪波:")
for i in range(3):
    for j in range(3):
        x, y, z = i * 0.5, j * 0.5, 0.0
        value = cellular(Vector((x, y, z)))
        print(f"  ({x:.1f}, {y:.1f}, {z:.1f}): {value:.4f}")

# 生成 Cellular 纹理图
def generate_cellular_map(width, height, scale=1.0):
    """生成 Cellular 纹理图"""
    texture = []
    for y in range(height):
        row = []
        for x in range(width):
            nx = x / width * scale
            ny = y / height * scale
            value = cellular(Vector((nx, ny)))
            row.append(value)
        texture.append(row)
    return texture

texture = generate_cellular_map(32, 32, scale=2.0)
print(f"\n纹理图统计:")
print(f"  尺寸: {len(texture)} x {len(texture[0])}")
print(f"  值范围: {min(min(row) for row in texture):.4f} - {max(max(row) for row in texture):.4f}")
```

### Cellular 噪波变体

Cellular 噪波有多种变体，通过传入不同的维度参数可以生成不同空间维度的细胞图案。一维 Cellular 噪波产生间隔性的条纹，二维产生斑点图案，三维产生更加复杂的三维细胞结构。

```python
from mathutils.noise import cellular
from mathutils import Vector

# 一维 Cellular 噪波（条纹状）
print("一维 Cellular 噪波:")
for i in range(10):
    x = i * 0.2
    value = cellular(x)
    print(f"  x={x:.1f}: {value:.4f}")

# 二维 Cellular 噪波（斑点状）
print("\n二维 Cellular 噪波:")
for i in range(5):
    for j in range(5):
        value = cellular(Vector((i * 0.3, j * 0.3)))
        bar = "█" * int(abs(value) * 20)
        print(f"  ({i}, {j}): {value:.3f} {bar}")

# 三维 Cellular 噪波
print("\n三维 Cellular 噪波:")
for z in range(3):
    print(f"  Z={z}:")
    for y in range(3):
        values = []
        for x in range(3):
            value = cellular(Vector((x * 0.3, y * 0.3, z * 0.3)))
            values.append(f"{value:.2f}")
        print(f"    Y={y}: {', '.join(values)}")
```

## Voronoi 噪波

### Voronoi 基础

Voronoi 噪波基于 Voronoi 图算法，它计算输入点到一组随机特征点的最近距离。这种噪波产生独特的细胞状边界图案，非常适合创建鳞片、皮肤、细胞组织、裂纹等效果。与 Cellular 噪波类似但具有不同的特征点分布模式。

```python
from mathutils.noise import voronoi
from mathutils import Vector

# 二维 Voronoi 噪波
print("二维 Voronoi 噪波:")
for i in range(5):
    for j in range(5):
        x, y = i * 0.5, j * 0.5
        value = voronoi(Vector((x, y)))
        print(f"  ({x:.1f}, {y:.1f}): {value:.4f}")

# 生成 Voronoi 纹理
def generate_voronoi_texture(width, height, scale=1.0):
    """生成 Voronoi 纹理"""
    texture = []
    for y in range(height):
        row = []
        for x in range(width):
            nx = x / width * scale
            ny = y / height * scale
            value = voronoi(Vector((nx, ny)))
            row.append(value)
        texture.append(row)
    return texture

texture = generate_voronoi_texture(20, 20, scale=2.0)
print(f"\nVoronoi 纹理统计:")
print(f"  最小值: {min(min(row) for row in texture):.4f}")
print(f"  最大值: {max(max(row) for row in texture):.4f}")

# 可视化 Voronoi 图案
def visualize_voronoi(scale=1.0, resolution=20):
    """可视化 Voronoi 图案"""
    print(f"\nVoronoi 图案可视化 (scale={scale}):")
    for y in range(resolution):
        line = ""
        for x in range(resolution):
            value = voronoi(Vector((x / resolution * scale, y / resolution * scale)))
            char = "██" if value > 0.8 else "▒▒" if value > 0.4 else "  "
            line += char
        print(f"  {line}")

visualize_voronoi(scale=1.0)
visualize_voronoi(scale=2.0)
```

### Voronoi 距离场

Voronoi 噪波的输出是距离值，表示到最近特征点的距离。这个距离场可以用于创建各种效果，如距离边缘的距离、特征点密度等。通过分析距离场可以提取 Voronoi 单元的边界和特征点位置。

```python
from mathutils.noise import voronoi
from mathutils import Vector
import math

def analyze_voronoi_cell(center, radius, samples=100):
    """分析 Voronoi 单元特征"""
    center_distance = voronoi(Vector(center))

    # 采样周围区域
    min_dist = float('inf')
    max_dist = 0
    avg_dist = 0

    for i in range(samples + 1):
        angle = 2 * math.pi * i / samples
        dx = math.cos(angle) * radius
        dy = math.sin(angle) * radius
        point = (center[0] + dx, center[1] + dy)
        dist = voronoi(Vector(point))
        min_dist = min(min_dist, dist)
        max_dist = max(max_dist, dist)
        avg_dist += dist

    avg_dist /= samples

    return {
        "center_distance": center_distance,
        "min_distance": min_dist,
        "max_distance": max_dist,
        "avg_distance": avg_dist,
        "range": max_dist - min_dist
    }

# 分析多个位置
print("Voronoi 距离场分析:")
for x in [0.0, 0.5, 1.0]:
    for y in [0.0, 0.5, 1.0]:
        analysis = analyze_voronoi_cell((x, y), 0.1, samples=50)
        print(f"\n  位置 ({x}, {y}):")
        print(f"    中心距离: {analysis['center_distance']:.4f}")
        print(f"    距离范围: {analysis['min_distance']:.4f} - {analysis['max_distance']:.4f}")
```

## Musgrave 噪波类型

### Musgrave 噪波基础

Musgrave 噪波是一系列程序化地形生成算法的统称，包括 Musgrave Fractal、Musgrave Ridged Multifractal、Musgrave Hybrid Multifractal、Musgrave Hetero Terrain 等变体。这些算法专门设计用于生成自然地貌般的地形纹理。

```python
from mathutils.noise import musgrave_fractal, musgrave_ridgedmf, musgrave_hetero, musgrave_hybridmf, musgrave_multifractal

# Musgrave Fractal - 基础分形噪波
print("Musgrave Fractal 噪波:")
for i in range(5):
    x, y = i * 0.2, i * 0.2
    value = musgrave_fractal(x, y, noise_basis='PERLIN_ORIGINAL')
    print(f"  ({x:.1f}, {y:.1f}): {value:.4f}")

# Musgrave Ridged Multifractal - 岭状多重分形
print("\nMusgrave Ridged Multifractal 噪波:")
for i in range(5):
    x, y = i * 0.2, i * 0.2
    value = musgrave_ridgedmf(x, y, noise_basis='PERLIN_ORIGINAL')
    print(f"  ({x:.1f}, {y:.1f}): {value:.4f}")

# Musgrave Hetero Terrain - 异质地貌
print("\nMusgrave Hetero Terrain 噪波:")
for i in range(5):
    x, y = i * 0.2, i * 0.2
    value = musgrave_hetero(x, y, noise_basis='PERLIN_ORIGINAL')
    print(f"  ({x:.1f}, {y:.1f}): {value:.4f}")

# Musgrave Hybrid Multifractal - 混合多重分形
print("\nMusgrave Hybrid Multifractal 噪波:")
for i in range(5):
    x, y = i * 0.2, i * 0.2
    value = musgrave_hybridmf(x, y, noise_basis='PERLIN_ORIGINAL')
    print(f"  ({x:.1f}, {y:.1f}): {value:.4f}")

# Musgrave Multifractal - 多重分形
print("\nMusgrave Multifractal 噪波:")
for i in range(5):
    x, y = i * 0.2, i * 0.2
    value = musgrave_multifractal(x, y, noise_basis='PERLIN_ORIGINAL')
    print(f"  ({x:.1f}, {y:.1f}): {value:.4f}")
```

### Musgrave 参数对比

每种 Musgrave 噪波算法都有特定的参数可以调整，包括基噪波类型、H 值（分形维数）、拉卡尼蒂（频率倍增）、倍频程数等。理解这些参数的作用对于获得期望的地形效果至关重要。

```python
from mathutils.noise import musgrave_fractal, musgrave_ridgedmf

def test_musgrave_params():
    """测试 Musgrave 噪波参数"""
    x, y = 1.0, 1.0

    # 测试不同的基噪波
    noise_bases = ['PERLIN_ORIGINAL', 'PERLIN_NEW', 'SIMPLEX', 'CELLULAR', 'VORONOI', 'VORONOI_F1']

    print("不同基噪波类型:")
    for basis in noise_bases:
        try:
            value = musgrave_fractal(x, y, noise_basis=basis)
            print(f"  {basis}: {value:.4f}")
        except Exception as e:
            print(f"  {basis}: 错误 - {e}")

    # 测试不同 H 值（分形维数）
    print("\n不同 H 值 (Fractal):")
    for h in [0.1, 0.5, 1.0, 1.5, 2.0]:
        value = musgrave_fractal(x, y, h=h)
        print(f"  H={h}: {value:.4f}")

    # 测试不同倍频程
    print("\n不同倍频郎数:")
    for octaves in [1, 2, 4, 8, 16]:
        value = musgrave_fractal(x, y, octaves=octaves)
        print(f"  octaves={octaves}: {value:.4f}")

    # 测试拉卡尼蒂
    print("\n不同拉卡尼蒂:")
    for lacunarity in [1.5, 2.0, 2.5, 3.0]:
        value = musgrave_fractal(x, y, lacunarity=lacunarity)
        print(f"  lacunarity={lacunarity}: {value:.4f}")

test_musgrave_params()
```

### 地形生成示例

使用 Musgrave 噪波生成程序化地形高度图是常见的应用场景。通过组合多种噪波类型和参数调整，可以创建各种地貌特征。

```python
from mathutils.noise import musgrave_fractal, musgrave_ridgedmf, noise
from mathutils import Vector

def generate_heightmap(width, height, scale=1.0, height_scale=1.0):
    """生成地形高度图"""
    heightmap = []

    for y in range(height):
        row = []
        for x in range(width):
            nx = x / width * scale
            ny = y / height * scale

            # 基础地形（低频）
            base = musgrave_fractal(nx, ny, noise_basis='PERLIN_ORIGINAL',
                                   h=1.0, lacunarity=2.0, octaves=4)

            # 细节（高频）
            detail = musgrave_fractal(nx, ny, noise_basis='PERLIN_ORIGINAL',
                                     h=0.5, lacunarity=2.0, octaves=8)

            # 组合
            height_value = base * 0.6 + detail * 0.4
            row.append(height_value * height_scale)
        heightmap.append(row)

    return heightmap

def generate_terrain_texture(width, height, scale=2.0):
    """生成复杂的地形纹理"""
    texture = []

    for y in range(height):
        row = []
        for x in range(width):
            nx = x / width * scale
            ny = y / height * scale

            # 主地形特征
            main_terrain = musgrave_fractal(nx, ny, noise_basis='PERLIN_ORIGINAL',
                                           h=0.8, lacunarity=2.0, octaves=6)

            # 岭状特征（山脉）
            ridges = musgrave_ridgedmf(nx, ny, noise_basis='PERLIN_ORIGINAL',
                                      h=1.5, lacunarity=2.0, octaves=6)

            # 异质地貌特征
            hetero = musgrave_hetero(nx, ny, noise_basis='PERLIN_ORIGINAL',
                                    h=0.5, lacunarity=2.5, octaves=4)

            # 组合
            value = main_terrain * 0.4 + ridges * 0.4 + hetero * 0.2
            row.append(value)
        texture.append(row)

    return texture

# 生成高度图
heightmap = generate_heightmap(64, 64, scale=2.0, height_scale=10.0)
print("地形高度图统计:")
print(f"  尺寸: {len(heightmap)} x {len(heightmap[0])}")
print(f"  高度范围: {min(min(row) for row in heightmap):.2f} - {max(max(row) for row in heightmap):.2f}")

# 生成地形纹理
terrain = generate_terrain_texture(32, 32, scale=2.0)
print(f"\n地形纹理统计:")
print(f"  尺寸: {len(terrain)} x {len(terrain[0])}")
print(f"  值范围: {min(min(row) for row in terrain):.4f} - {max(max(row) for row in terrain):.4f}")
```

## 实践示例

### 程序化纹理生成器

这个示例展示了如何组合各种噪波函数创建复杂的程序化纹理。

```python
from mathutils.noise import (
    noise, cellular, voronoi,
    musgrave_fractal, musgrave_ridgedmf, musgrave_hetero
)
from mathutils import Vector
import math

class ProceduralTextureGenerator:
    def __init__(self):
        self.scale = 1.0

    def set_scale(self, scale):
        """设置纹理缩放"""
        self.scale = scale

    def generate_wood_texture(self, width, height):
        """生成木纹纹理"""
        texture = []
        for y in range(height):
            row = []
            for x in range(width):
                nx = x / width * self.scale
                ny = y / height * self.scale

                # 基础噪波
                base = noise(Vector((nx, ny)))

                # 添加年轮效果
                rings = abs(cellular(Vector((nx, ny))))

                # 组合
                value = base * 0.3 + rings * 0.7
                row.append(value)
            texture.append(row)
        return texture

    def generate_marble_texture(self, width, height):
        """生成大理石纹理"""
        texture = []
        for y in range(height):
            row = []
            for x in range(width):
                nx = x / width * self.scale
                ny = y / height * self.scale

                # 分形噪波（用于裂纹）
                cracks = musgrave_fractal(nx, ny, noise_basis='PERLIN_ORIGINAL',
                                         h=1.5, lacunarity=2.0, octaves=4)

                # 扭曲效果
                warped_x = nx + noise(Vector((nx * 2, ny * 2))) * 0.1
                warped_y = ny + noise(Vector((nx * 2 + 1, ny * 2 + 1))) * 0.1
                base = noise(Vector((warped_x, warped_y)))

                # 组合（使用正弦函数模拟大理石纹路）
                value = math.sin((cracks + base) * 20.0)
                value = (value + 1) / 2  # 归一化到 0-1
                row.append(value)
            texture.append(row)
        return texture

    def generate_cloud_texture(self, width, height):
        """生成云层纹理"""
        texture = []
        for y in range(height):
            row = []
            for x in range(width):
                nx = x / width * self.scale
                ny = y / height * self.scale

                # 多尺度叠加
                cloud = 0.0
                for i in range(5):
                    scale = self.scale * (2 ** i)
                    weight = 0.5 ** i
                    cloud += noise(Vector((nx * scale, ny * scale, i * 0.5))) * weight

                # 阈值处理（使云更清晰）
                cloud = max(0, cloud - 0.2) / 0.8
                row.append(cloud)
            texture.append(row)
        return texture

    def generate_camo_texture(self, width, height):
        """生成迷彩纹理"""
        texture = []
        for y in range(height):
            row = []
            for x in range(width):
                nx = x / width * self.scale
                ny = y / height * self.scale

                # 使用 Voronoi 创建斑块
                voron = voronoi(Vector((nx, ny)))

                # 添加噪波扰动
                noise_val = noise(Vector((nx * 3, ny * 3)))

                # 组合
                value = voron + noise_val * 0.3
                row.append(value)
            texture.append(row)
        return texture

# 使用示例
generator = ProceduralTextureGenerator()
generator.set_scale(2.0)

print("程序化纹理生成:")
wood = generator.generate_wood_texture(32, 32)
marble = generator.generate_marble_texture(32, 32)
cloud = generator.generate_cloud_texture(32, 32)
camo = generator.generate_camo_texture(32, 32)

for name, texture in [("木纹", wood), ("大理石", marble), ("云层", cloud), ("迷彩", camo)]:
    flat = [v for row in texture for v in row]
    print(f"  {name}: 范围 {min(flat):.4f} - {max(flat):.4f}")
```

### 噪波动画生成器

这个示例展示了如何创建噪波动画效果。

```python
from mathutils.noise import noise, voronoi, cellular
from mathutils import Vector

class NoiseAnimator:
    def __init__(self):
        self.speed = 1.0
        self.scale = 1.0

    def set_speed(self, speed):
        """设置动画速度"""
        self.speed = speed

    def set_scale(self, scale):
        """设置空间缩放"""
        self.scale = scale

    def animate_2d(self, frames, width, height, noise_type='blender'):
        """生成 2D 噪波动画帧"""
        frames_data = []

        for frame in range(frames):
            frame_data = []
            for y in range(height):
                row = []
                for x in range(width):
                    nx = x / width * self.scale
                    ny = y / height * self.scale
                    nz = frame / frames * self.speed

                    if noise_type == 'blender':
                        value = noise(Vector((nx, ny, nz)))
                    elif noise_type == 'voronoi':
                        value = voronoi(Vector((nx, ny, nz)))
                    elif noise_type == 'cellular':
                        value = cellular(Vector((nx, ny, nz)))
                    else:
                        value = noise(Vector((nx, ny)))

                    row.append(value)
                frame_data.append(row)
            frames_data.append(frame_data)

        return frames_data

    def get_frame_stats(self, frames_data, frame_idx):
        """获取指定帧的统计信息"""
        frame = frames_data[frame_idx]
        flat = [v for row in frame for v in row]
        return {
            'frame': frame_idx,
            'min': min(flat),
            'max': max(flat),
            'avg': sum(flat) / len(flat)
        }

# 使用示例
animator = NoiseAnimator()
animator.set_speed(2.0)
animator.set_scale(3.0)

# 生成动画
frames = animator.animate_2d(frames=10, width=20, height=20, noise_type='blender')

print("噪波动画统计:")
for i in [0, 4, 9]:
    stats = animator.get_frame_stats(frames, i)
    print(f"  帧 {stats['frame']}: 最小={stats['min']:.4f}, 最大={stats['max']:.4f}, 平均={stats['avg']:.4f}")

# 对比不同噪波类型
print("\n不同噪波类型动画帧对比:")
for noise_type in ['blender', 'voronoi', 'cellular']:
    frames = animator.animate_2d(frames=5, width=10, height=10, noise_type=noise_type)
    first_frame = [v for row in frames[0] for v in row]
    print(f"  {noise_type}: 范围 {min(first_frame):.4f} - {max(first_frame):.4f}")
```

## 注意事项

### 坐标范围

噪波函数的输出值范围因具体函数而异，但通常在 -1 到 1 或 0 到 1 之间。某些 Musgrave 函数的输出范围可能更大，在使用时应该注意进行适当的缩放和偏移以获得期望的效果。

### 性能考虑

复杂的噪波计算，特别是高倍频郎数的分形叠加，会消耗较多的计算资源。在实时应用或处理大量数据时，应该考虑使用适当的分辨率和缓存策略。对于静态纹理，可以预先计算并存储结果。

### 种子变化

默认情况下，噪波函数使用固定的内部种子，每次运行产生相同的结果。如果需要每次运行产生不同的结果，可以通过偏移坐标或使用外部种子生成器来实现随机化。