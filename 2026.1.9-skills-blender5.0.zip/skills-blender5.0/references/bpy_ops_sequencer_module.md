# bpy.ops.sequencer 模块

序列编辑器操作模块，用于管理视频编辑的时间线和媒体片段。

## 概述

bpy.ops.sequencer 模块包含用于在序列编辑器中操作视频、音频和图像序列的运算符。序列编辑器允许你组合多个媒体片段、应用特效、调整时间并创建最终的视频输出。

## 常用操作

### 片段操作

```python
import bpy

# 剪切片段
bpy.ops.sequencer.cut(frame=100, type='SOFT', side='LEFT')

# 删除选中片段
bpy.ops.sequencer.delete()

# 复制片段
bpy.ops.sequencer.duplicate()

# 分离片段
bpy.ops.sequencer.split(type='EDITOR', frame=100)

# 拼接片段
bpy.ops.sequencer.snap(frame=100)

# 清除间隙
bpy.ops.sequencer.gap_remove(all=False)

# 填充间隙
bpy.ops.sequencer.gap_insert()
```

### 片段移动

```python
# 移动片段
bpy.ops.sequencer.move(type='START', frame=100)

# 左移一帧
bpy.ops.sequencer.offset_left()

# 右移一帧
bpy.ops.sequencer.offset_right()

# 移动到结束
bpy.ops.sequencer.move_to_end()

# 交换片段
bpy.ops.sequencer.swap()

# 滑动片段
bpy.ops.sequencer.slide()
```

### 选择操作

```python
# 全选
bpy.ops.sequencer.select_all(action='SELECT')

# 取消全选
bpy.ops.sequencer.select_all(action='DESELECT')

# 反选
bpy.ops.sequencer.select_all(action='INVERT')

# 选择左侧
bpy.ops.sequencer.select_lefthand()

# 选择右侧
bpy.ops.sequencer.select_righthand()

# 框选
bpy.ops.sequencer.select_border(gesture_mode=0, xmin=100, xmax=200, ymin=50, ymax=150)

# 选择链接片段
bpy.ops.sequencer.select_linked()

# 选择同组
bpy.ops.sequencer.select_grouped(type='TYPE')
```

### 播放控制

```python
# 播放
bpy.ops.sequencer.play( reverse=False, sync=False )

# 暂停
bpy.ops.sequencer.play()

# 跳转到开始
bpy.ops.sequencer.recenter()

# 跳转到上一个标记
bpy.ops.sequencer.prev_marker()

# 跳转到下一个标记
bpy.ops.sequencer.next_marker()
```

### 特效操作

```python
# 添加特效
bpy.ops.sequencer.effect_strip_add(type='CROSS', frame_start=100, frame_end=200)

# 应用颜色分级
bpy.ops.sequencer.color_tag_set(tag='RED')

# 应用速度控制
bpy.ops.sequencer.speed_factor_set(factor=1.0)

# 设置混合模式
bpy.ops.sequencer.blend_mode_set(mode='REPLACE')

# 设置不透明度
bpy.ops.sequencer.opacity_set(opacity=1.0)

# 设置音量
bpy.ops.sequencer.volume_set(volume=1.0)
```

### 时间线操作

```python

# 标记时间点
bpy.ops.sequencer.marker_add(name='Marker')

# 重命名标记
bpy.ops.sequencer.rename_marker(name='NewName')

# 删除标记
bpy.ops.sequencer.delete_marker()

# 添加工作区域
bpy.ops.sequencer.view_toggle()

# 设置预览范围
bpy.ops.sequencer.view_all()

# 设置显示比例
bpy.ops.sequencer.zoom(10.0)

# 吸附到帧
bpy.ops.sequencer.snap(frame=100)
```

## 实际应用示例

### 创建基本视频序列

```python
def create_video_sequence(filepath, start_frame=1, channel=1):
    """创建视频序列"""
    # 确保在序列编辑器中
    bpy.context.area.type = 'SEQUENCE_EDITOR'
    
    # 添加视频片段
    bpy.ops.sequencer.movie_strip_add(
        filepath=filepath,
        frame_start=start_frame,
        channel=channel
    )
    
    return bpy.context.active_strip
```

### 创建多轨混合

```python
def create_multi_track_sequence(video_files, audio_files):
    """创建多轨混合序列"""
    bpy.context.area.type = 'SEQUENCE_EDITOR'
    
    # 创建视频轨道
    for i, video_file in enumerate(video_files):
        bpy.ops.sequencer.movie_strip_add(
            filepath=video_file,
            frame_start=1,
            channel=i + 1
        )
    
    # 创建音频轨道
    for i, audio_file in enumerate(audio_files):
        bpy.ops.sequencer.sound_strip_add(
            filepath=audio_file,
            frame_start=1,
            channel=len(video_files) + i + 1
        )
```

### 创建转场效果

```python
def create_transition(strip1_name, strip2_name, transition_type='CROSS'):
    """创建转场效果"""
    # 获取片段
    seq_editor = bpy.context.scene.sequence_editor
    strips = seq_editor.sequences_all
    
    strip1 = strips.get(strip1_name)
    strip2 = strips.get(strip2_name)
    
    if strip1 and strip2:
        # 计算重叠区域
        overlap_start = max(strip1.frame_final_end, strip2.frame_final_start)
        overlap_end = min(strip1.frame_final_end, strip2.frame_final_end)
        
        if overlap_start < overlap_end:
            # 添加转场
            bpy.ops.sequencer.effect_strip_add(
                type=transition_type,
                frame_start=overlap_start,
                frame_end=overlap_end,
                channel=strip2.channel + 1
            )
```

### 创建速度变化

```python
def adjust_playback_speed(strip_name, speed_factor):
    """调整播放速度"""
    seq_editor = bpy.context.scene.sequence_editor
    strip = seq_editor.sequences_all.get(strip_name)
    
    if strip:
        # 计算新长度
        original_length = strip.frame_end - strip.frame_start + 1
        new_length = int(original_length / speed_factor)
        
        # 应用速度控制
        bpy.ops.sequencer.strip_modifier_add(type='SPEED')
        
        # 获取速度控制修改器
        for modifier in strip.modifiers:
            if modifier.type == 'SPEED':
                modifier.speed_factor = speed_factor
                modifier.use_frame_blending = True
```

### 创建颜色校正

```python
def apply_color_correction(strip_name, contrast=1.0, saturation=1.0):
    """应用颜色校正"""
    seq_editor = bpy.context.scene.sequence_editor
    strip = seq_editor.sequences_all.get(strip_name)
    
    if strip:
        # 添加颜色校正效果
        bpy.ops.sequencer.strip_modifier_add(type='COLOR_BALANCE')
        
        # 获取颜色平衡修改器
        for modifier in strip.modifiers:
            if modifier.type == 'COLOR_BALANCE':
                modifier.color_balance.contrast = contrast
                modifier.color_balance.saturation = saturation
```

### 创建文本叠加

```python
def add_text_overlay(text, start_frame, end_frame, channel=1):
    """添加文本叠加"""
    bpy.ops.sequencer.effect_strip_add(
        type='TEXT',
        frame_start=start_frame,
        frame_end=end_frame,
        channel=channel
    )
    
    # 设置文本内容
    text_strip = bpy.context.active_strip
    text_strip.text = text
    text_strip.font_size = 24
    text_strip.color = (1, 1, 1, 1)
```

### 创建画面合成

```python
def create_composite(video_strip, overlay_strip, blend_mode='ALPHA_OVER'):
    """创建画面合成"""
    # 确保覆盖层在视频上方
    if overlay_strip.channel <= video_strip.channel:
        overlay_strip.channel = video_strip.channel + 1
    
    # 设置混合模式
    overlay_strip.blend_method = blend_mode
    
    # 调整位置和大小
    bpy.ops.sequencer.select_all(action='DESELECT')
    overlay_strip.select = True
    bpy.context.scene.sequence_editor.active_strip = overlay_strip
    
    # 移动到正确位置
    bpy.ops.sequencer.move(
        type='START',
        frame=video_strip.frame_start
    )
```

### 创建音频淡入淡出

```python
def add_audio_fades(strip_name, fade_in=1.0, fade_out=1.0):
    """添加音频淡入淡出"""
    seq_editor = bpy.context.scene.sequence_editor
    strip = seq_editor.sequences_all.get(strip_name)
    
    if strip and strip.type == 'SOUND':
        # 添加淡入
        if fade_in > 0:
            bpy.ops.sequencer.strip_modifier_add(type='SOUND_FADE_IN')
            for modifier in strip.modifiers:
                if modifier.type == 'SOUND_FADE_IN':
                    modifier.frame_start = strip.frame_start
                    modifier.frame_end = strip.frame_start + fade_in
        
        # 添加淡出
        if fade_out > 0:
            bpy.ops.sequencer.strip_modifier_add(type='SOUND_FADE_OUT')
            for modifier in strip.modifiers:
                if modifier.type == 'SOUND_FADE_OUT':
                    modifier.frame_start = strip.frame_end - fade_out
                    modifier.frame_end = strip.frame_end
```

### 创建画面稳定

```python
def add_stabilization(strip_name, clip_source):
    """添加画面稳定"""
    seq_editor = bpy.context.scene.sequence_editor
    strip = seq_editor.sequences_all.get(strip_name)
    
    if strip:
        # 添加稳定器效果
        bpy.ops.sequencer.strip_modifier_add(type='STABILIZE_2D')
        
        # 获取稳定器修改器
        for modifier in strip.modifiers:
            if modifier.type == 'STABILIZE_2D':
                modifier.clip = clip_source
                modifier.sensor_width = 32
                modifier.sensor_height = 18
                modifier.focal_length = 35
```

## 使用场景

- **视频编辑**：组合和编辑多个视频片段
- **音频混合**：混合多个音轨和音效
- **转场效果**：创建平滑的场景转换
- **颜色校正**：调整视频色彩和对比度
- **特效叠加**：添加文字、图形和视觉特效
- **速度调整**：创建慢动作或快进效果
- **画面合成**：合成多个视频层
- **音频处理**：调整音量、淡入淡出

## 注意事项

- 序列编辑器需要在正确的区域类型下操作
- 片段操作前需要确保选中目标片段
- 效果叠加需要考虑渲染顺序
- 混合模式影响最终输出效果
- 速度变化会改变片段长度
- 大文件序列需要足够的内存
- 预览时注意帧率设置
- 导出前应检查时间线完整性
- 特效链不要太长以免影响性能
- 定期保存工作进度
