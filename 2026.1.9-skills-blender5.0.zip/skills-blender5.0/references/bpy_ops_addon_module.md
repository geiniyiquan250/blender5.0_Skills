# bpy.ops.addon - 插件操作模块

bpy.ops.addon模块提供了插件（ addon）管理的操作功能，用于安装、启用和禁用Blender插件。

## 概述

Blender的插件系统允许扩展功能。这个模块提供了插件的安装、启用、禁用和管理操作。

## 核心功能

### 插件安装

```python
import bpy

def install_addon(filepath):
    """安装插件"""
    bpy.ops.wm.addon_install(
        filepath=filepath,
        overwrite=True,
        target='DEFAULT'
    )

def enable_addon(module_name):
    """启用插件"""
    bpy.ops.wm.addon_enable(module=module_name)

def disable_addon(module_name):
    """禁用插件"""
    bpy.ops.wm.addon_disable(module=module_name)

def uninstall_addon(module_name):
    """卸载插件"""
    bpy.ops.wm.addon_remove(module=module_name)
```

### 插件管理

```python
def refresh_addons():
    """刷新插件列表"""
    bpy.ops.wm.addon_refresh()

def get_enabled_addons():
    """获取已启用的插件"""
    prefs = bpy.context.preferences.addons
    return [addon.module for addon in prefs]

def get_addon_info(module_name):
    """获取插件信息"""
    import addon_utils
    return addon_utils.module_get_info(module_name)
```

## 实用函数

### 插件搜索

```python
def find_addon_by_name(name):
    """按名称查找插件"""
    import addon_utils
    for addon in addon_utils.addons_fake_modules.values():
        if name.lower() in addon.module.lower():
            return addon
    return None

def list_all_addons():
    """列出所有插件"""
    import addon_utils
    return [(mod, info) for mod, info in 
            addon_utils.module_get_info().items()]
```

### 插件状态

```python
def is_addon_enabled(module_name):
    """检查插件是否启用"""
    return module_name in bpy.context.preferences.addons

def is_addon_installed(module_name):
    """检查插件是否安装"""
    import addon_utils
    return module_name in [m.module for m in 
                          addon_utils.addons_fake_modules.values()]
```

## 常见问题排查

### 安装失败

文件问题：
- 确认文件路径正确
- 检查文件权限
- 验证插件格式有效

### 启用失败

依赖问题：
- 检查Python依赖
- 确认Blender版本兼容
- 查看错误日志
