# blf Module Reference

blf 模块提供字体渲染和文本测量功能，用于在 Blender 界面和 3D 视图中绘制自定义文本。

## blf 概述

blf（Blender Font）是 Blender 的字体渲染模块，允许开发者：
- 在 3D 视图中绘制文本
- 测量文本尺寸
- 设置字体属性（大小、位置、颜色等）
- 处理自定义字体

### 何时使用 blf

- 创建自定义 UI 元素
- 在 3D 场景中显示标签
- 实现数据可视化
- 创建标题和注释

## 基础函数

### blf.position

设置字体位置。

```python
import blf

# 设置绘制位置
blf.position(font_id, x, y, z)

# 参数
# font_id: 字体 ID (0 为默认字体)
# x, y, z: 位置坐标
```

### blf.size

设置字体大小。

```python
import blf

# 设置字体大小
blf.size(font_id, size, dpi)

# 参数
# font_id: 字体 ID (0 为默认字体)
# size: 字体大小（点数）
# dpi: 屏幕 DPI（通常为 72 或 96）
```

### blf.draw

绘制文本。

```python
import blf

# 绘制文本
blf.draw(font_id, text)

# 参数
# font_id: 字体 ID
# text: 要绘制的文本字符串
```

### blf.dimensions

获取文本尺寸。

```python
import blf

# 获取文本宽度和高度
width, height = blf.dimensions(font_id, text)

# 返回值
# width: 文本宽度
# height: 文本高度
```

## 字体管理

### blf.load

加载自定义字体。

```python
import blf

# 加载字体文件
font_id = blf.load(filepath)

# 参数
# filepath: 字体文件路径 (.ttf, .otf 等)

# 返回值
# font_id: 新字体的 ID
```

### blf.unload

卸载字体。

```python
import blf

# 卸载字体
blf.unload(font_id)

# 参数
# font_id: 要卸载的字体 ID
```

### blf.default

获取默认字体 ID。

```python
import blf

# 获取默认字体 ID
default_font = blf.default()

# 返回值
# default_font: 默认字体的 ID（通常为 0）
```

## 文本样式

### blf.color

设置文本颜色。

```python
import blf

# 设置 RGBA 颜色
blf.color(font_id, r, g, b, a)

# 参数
# font_id: 字体 ID
# r, g, b, a: 颜色分量 (0.0-1.0)
```

### blf.enable

启用字体功能。

```python
import blf

# 启用功能
blf.enable(font_id, option)

# 可用选项
# blf.SHADOW: 启用阴影
# blf.BLUR: 启用模糊
# blf.ROTATION: 启用旋转
```

### blf.disable

禁用字体功能。

```python
import blf

# 禁用功能
blf.disable(font_id, option)

# 参数
# font_id: 字体 ID
# option: 要禁用的功能
```

### blf.shadow

设置阴影参数。

```python
import blf

# 设置阴影
blf.shadow(font_id, level, r, g, b, a, offset_x, offset_y, blur)

# 参数
# font_id: 字体 ID
# level: 阴影级别
# r, g, b, a: 阴影颜色
# offset_x, offset_y: 偏移量
# blur: 模糊半径
```

### blf.shadow_offset

设置阴影偏移。

```python
import blf

# 设置阴影偏移
blf.shadow_offset(font_id, x, y)

# 参数
# font_id: 字体 ID
# x, y: 偏移量
```

### blf.blur

设置模糊半径。

```python
import blf

# 设置模糊
blf.blur(font_id, radius)

# 参数
# font_id: 字体 ID
# radius: 模糊半径 (0-8)
```

### blf.rotation

设置文本旋转。

```python
import blf

# 设置旋转角度（弧度）
blf.rotation(font_id, angle)

# 参数
# font_id: 字体 ID
# angle: 旋转角度（弧度）
```

## 剪裁和换行

### blf.clip

设置文本剪裁区域。

```python
import blf

# 设置剪裁
blf.clip(font_id, x1, y1, x2, y2)

# 参数
# font_id: 字体 ID
# x1, y1: 左下角坐标
# x2, y2: 右上角坐标
```

### blf.word_wrap

设置自动换行。

```python
import blf

# 设置换行宽度
blf.word_wrap(font_id, wrap_width)

# 参数
# font_id: 字体 ID
# wrap_width: 换行宽度（像素）
```

## 剪贴板操作

### blf.clipboard_get

从剪贴板获取文本。

```python
import blf

# 获取剪贴板文本
text = blf.clipboard_get()

# 返回值
# text: 剪贴板中的文本
```

### blf.clipboard_set

设置剪贴板文本。

```python
import blf

# 设置剪贴板文本
blf.clipboard_set(text)

# 参数
# text: 要设置的文本
```

## 字体信息

### blf.aspect

获取字体宽高比。

```python
import blf

# 获取宽高比
aspect = blf.aspect(font_id)

# 返回值
# aspect: 字体的宽高比
```

### blf.aspect_set

设置字体宽高比。

```python
import blf

# 设置宽高比
blf.aspect_set(font_id, aspect)

# 参数
# font_id: 字体 ID
# aspect: 宽高比
```

## 完整示例

### 绘制 3D 标签

```python
import bpy
import blf
import math

def draw_label_3d():
    font_id = 0
    blf.position(font_id, 100, 100, 0)
    blf.size(font_id, 24, 72)
    blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
    blf.draw(font_id, "Hello World")

# 注册绘制回调
handle = bpy.types.SpaceView3D.draw_handler_add(
    draw_label_3d, (), 'WINDOW', 'POST_PIXEL'
)

# 注销回调
# bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
```

### 绘制居中文本

```python
import bpy
import blf

def draw_centered_text():
    font_id = 0
    text = "Centered Text"
    
    # 获取屏幕尺寸
    width = bpy.context.region.width
    height = bpy.context.region.height
    
    # 获取文本尺寸
    text_width, text_height = blf.dimensions(font_id, text)
    
    # 计算居中位置
    x = (width - text_width) / 2
    y = height / 2
    
    # 绘制文本
    blf.position(font_id, x, y, 0)
    blf.size(font_id, 32, 72)
    blf.color(font_id, 1.0, 0.5, 0.0, 1.0)
    blf.draw(font_id, text)

handle = bpy.types.SpaceView3D.draw_handler_add(
    draw_centered_text, (), 'WINDOW', 'POST_PIXEL'
)
```

### 使用自定义字体

```python
import bpy
import blf
import os

def draw_custom_font():
    # 加载自定义字体
    font_path = os.path.join(bpy.path.abspath("//"), "fonts", "myfont.ttf")
    
    if os.path.exists(font_path):
        font_id = blf.load(font_path)
        
        # 设置字体属性
        blf.position(font_id, 50, 50, 0)
        blf.size(font_id, 36, 96)
        blf.color(font_id, 0.2, 0.6, 1.0, 1.0)
        
        # 绘制文本
        blf.draw(font_id, "Custom Font Text")
        
        # 卸载字体
        blf.unload(font_id)

handle = bpy.types.SpaceView3D.draw_handler_add(
    draw_custom_font, (), 'WINDOW', 'POST_PIXEL'
)
```

### 绘制带阴影的文本

```python
import bpy
import blf

def draw_shadowed_text():
    font_id = 0
    
    # 启用阴影
    blf.enable(font_id, blf.SHADOW)
    blf.shadow(font_id, 5, 0.0, 0.0, 0.0, 0.8, 2, 2, 5)
    
    # 设置文本
    blf.position(font_id, 100, 200, 0)
    blf.size(font_id, 48, 72)
    blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
    blf.draw(font_id, "Text with Shadow")
    
    # 禁用阴影
    blf.disable(font_id, blf.SHADOW)

handle = bpy.types.SpaceView3D.draw_handler_add(
    draw_shadowed_text, (), 'WINDOW', 'POST_PIXEL'
)
```

## 性能优化建议

1. **重用字体 ID**：避免频繁加载和卸载字体
2. **批量绘制**：将多个文本绘制调用分组
3. **使用适当的大小**：根据实际显示需求设置字体大小
4. **禁用不需要的功能**：不使用时关闭阴影和模糊
5. **考虑分辨率**：DPI 设置应与显示分辨率匹配
