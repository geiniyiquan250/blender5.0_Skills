# bpy.ops.sculpt 模块

雕塑操作模块，用于在雕塑模式下编辑网格几何体。

## 概述

bpy.ops.sculpt 模块包含用于雕塑模式下编辑网格的运算符。这些运算符提供各种雕塑工具和操作，包括绘制笔触、雕刻工具和几何体修改。

## 常用操作

### 笔触操作

```python
import bpy

# 执行笔触
bpy.ops.sculpt.brush_stroke(
    stroke=stroke_data,
    mode='NORMAL',
    weight=0.5
)

# 笔触数据格式
stroke_data = [
    {"name": "", "location": (x, y, z), "mouse": (mx, my), "pressure": 1.0, "time": 0.0, "pen_flip": False, "active": True},
]
```

### 工具切换

```python
# 切换到绘制工具
bpy.ops.sculpt.set_tool(tool='DRAW')

# 切换到平滑工具
bpy.ops.sculpt.set_tool(tool='SMOOTH')

# 切换到抓取工具
bpy.ops.sculpt.set_tool(tool='GRAB')

# 切换到膨胀工具
bpy.ops.sculpt.set_tool(tool='INFLATE')

# 切换到折痕工具
bpy.ops.sculpt.set_tool(tool='CREASE')

# 切换到层工具
bpy.ops.sculpt.set_tool(tool='LAYER')

# 切换到折痕工具
bpy.ops.sculpt.set_tool(tool='BELD')

# 切换到滑动工具
bpy.ops.sculpt.set_tool(tool='SLIDE')

# 切换到旋转工具
bpy.ops.sculpt.set_tool(tool='ROTATE')

# 切换到细节工具
bpy.ops.sculpt.set_tool(tool='DETAIL')

# 切换到简化工具
bpy.ops.sculpt.set_tool(tool='SIMPLIFY')
```

### 细节操作

```python
# Dyntopo细节
bpy.ops.sculpt.dynamic_topology_toggle()

# 重新计算法线
bpy.ops.sculpt.recalculate_normals(mode='ORIGINAL')

# 对称切换
bpy.ops.sculpt.symmetry_set(sym_axis='X', toggle=True)

# 锁定表面
bpy.ops.sculpt.dyntopo_detail_size(size=6, mode='ABSOLUTE')

# 优化细节
bpy.ops.sculpt.detail_flood_fill()

# 细分网格
bpy.ops.sculpt.subdivide(

stroke_mode='DRAG')
```

### 遮罩操作

```python
# 全选遮罩
bpy.ops.sculpt.mask_flood_fill(mode='VALUE', value=1.0)

# 反转遮罩
bpy.ops.sculpt.mask_flood_fill(mode='INVERT', value=0.0)

# 清除遮罩
bpy.ops.sculpt.mask_flood_fill(mode='VALUE', value=0.0)

# 扩大遮罩
bpy.ops.sculpt.mask_expand(
    offset=2,
    iterations=1,
    mask_mode='GROW',
    smooth_mask=True
)

# 收缩遮罩
bpy.ops.sculpt.mask_expand(
    offset=2,
    iterations=1,
    mask_mode='SHRINK',
    smooth_mask=True
)

# 绘制遮罩
bpy.ops.sculpt.mask_draw(
    value=1.0,
    auto_normalize=True,
    symmetric=False
)

# 清除绘制遮罩
bpy.ops.sculpt.mask_delete(type='MASK')
```

### 对称和镜像

```python
# X轴对称
bpy.ops.sculpt.symmetrize(direction='NEGATIVE_X')

# Y轴对称
bpy.ops.sculpt.symmetrize(direction='NEGATIVE_Y')

# Z轴对称
bpy.ops.sculpt.symmetrize(direction='NEGATIVE_Z')
```

### 可见性操作

```python
# 隐藏选定
bpy.ops.sculpt.hide_show(action='HIDE', areas='MASKED')

# 显示所有
bpy.ops.sculpt.hide_show(action='SHOW', areas='ALL')

# 反转可见性
bpy.ops.sculpt.hide_show(action='INVERT', areas='ALL')

# 框选可见
bpy.ops.sculpt._border_gesture_2d(mode='HIDE', value=0.0)

# 框选遮罩
bpy.ops.sculpt.border_gesture_2d(mode='MASK', value=1.0)
```

## 实际应用示例

### 自动化雕塑笔触

```python
def apply_sculpt_stroke(obj, locations, tool='DRAW', strength=1.0):
    """在指定位置应用雕塑笔触"""
    # 切换到雕塑模式
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='SCULPT')
    
    # 设置工具
    bpy.ops.sculpt.set_tool(tool=tool)
    
    # 创建笔触数据
    stroke = []
    for i, loc in enumerate(locations):
        stroke.append({
            "name": f"stroke_{i}",
            "location": loc,
            "mouse": (0, 0),
            "pressure": strength,
            "time": i * 0.1,
            "pen_flip": False,
            "active": True
        })
    
    # 执行笔触
    bpy.ops.sculpt.brush_stroke(
        stroke=stroke,
        mode='NORMAL',
        weight=0.5
    )
```

### 批量遮罩处理

```python
def mask_object_edges(obj, distance=0.5, value=1.0):
    """遮罩物体边缘"""
    import bmesh
    from mathutils import Vector
    
    bpy.ops.object.mode_set(mode='EDIT')
    bm = bmesh.from_edit_mesh(obj.data)
    
    # 获取边缘顶点
    edge_verts = set()
    for edge in bm.edges:
        for v in edge.verts:
            edge_verts.add(v)
    
    # 遮罩边缘顶点
    mask_layer = bm.verts.layers.paint_mask.verify()
    
    for v in bm.verts:
        if v in edge_verts:
            v[mask_layer] = value
    
    bmesh.update_edit_mesh(obj.data)
    bpy.ops.object.mode_set(mode='OBJECT')

def grow_mask(obj, iterations=2):
    """扩大遮罩"""
    for _ in range(iterations):
        bpy.ops.sculpt.mask_expand(
            offset=1,
            iterations=1,
            mask_mode='GROW',
            smooth_mask=True
        )
```

### 对称雕刻脚本

```python
def symmetric_sculpt(obj, axis='X', num_iterations=5):
    """执行对称雕刻"""
    bpy.ops.object.mode_set(mode='SCULPT')
    
    # 确保对称开启
    for ax in ['X', 'Y', 'Z']:
        bpy.ops.sculpt.symmetry_set(sym_axis=ax, toggle=(ax == axis))
    
    # 应用多次雕刻笔触
    for i in range(num_iterations):
        bpy.ops.sculpt.brush_stroke(
            stroke=[{
                "name": f"stroke_{i}",
                "location": obj.location,
                "mouse": (100 + i * 10, 100),
                "pressure": 1.0,
                "time": i * 0.1,
                "pen_flip": False,
                "active": True
            }],
            mode='NORMAL',
            weight=0.5
        )
```

## 使用场景

- **数字雕刻**：创建有机形状和角色模型
- **细节雕刻**：添加表面细节和纹理
- **拓扑编辑**：使用Dyntopo动态调整网格密度
- **遮罩管理**：控制雕刻影响区域
- **对称操作**：快速创建对称模型
- **自动化脚本**：批量处理和脚本化雕刻操作

## 注意事项

- 雕塑操作需要高密度网格或Dyntopo
- Dyntopo影响性能和细节级别
- 遮罩可以保护已完成的区域
- 对称雕刻需要正确对齐模型
- 笔触数据需要精确的位置和压力值
