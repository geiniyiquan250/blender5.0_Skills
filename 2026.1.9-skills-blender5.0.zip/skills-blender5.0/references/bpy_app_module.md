# bpy.app 应用程序模块

bpy.app 模块提供对 Blender 应用程序级别信息和工具的访问，包括版本信息、图标管理、定时器、翻译等。

```python
import bpy.app
```

## 应用程序信息

### version

Blender 版本号。

类型：`tuple[int, int, int]`

```python
print(f"Blender 版本: {bpy.app.version}")
# (5, 0, 0)

major, minor, patch = bpy.app.version
print(f"主版本: {major}, 次版本: {minor}, 补丁: {patch}")
```

### version_string

Blender 版本字符串。

类型：`str`

```python
print(f"版本字符串: {bpy.app.version_string}")
# "5.0.0"
```

### binary_path

Blender 可执行文件路径。

类型：`str`

```python
print(f"Blender 路径: {bpy.app.binary_path}")
```

### tempdir

Blender 临时目录。

类型：`str`

```python
import os
print(f"临时目录: {bpy.app.tempdir}")
# 可以用于存储临时文件
temp_file = os.path.join(bpy.app.tempdir, "my_temp_file.txt")
```

### driver_namespace

驱动命名空间，用于存储自定义驱动函数。

类型：`dict`

```python
# 注册自定义驱动函数
def my_driver_func(args):
    return args * 2

bpy.app.driver_namespace["my_driver"] = my_driver_func

# 在表达式驱动中使用
# #my_driver(5)
```

## bpy.app.icons 图标模块

bpy.app.icons 模块用于创建和管理自定义 UI 图标。

### new_triangles(range, coords, colors)

从三角形几何体创建新图标。

参数：
- `range` (tuple[int, int])：两个整数的元组
- `coords` (bytes)：坐标字节序列（每个三角形6个浮点数表示X, Y坐标）
- `colors` (bytes)：颜色字节序列（每个三角形12个字节表示RGBA）

返回：
- `int`：唯一图标值（传递给界面的 icon_value 参数）

```python
import bpy.app.icons
import struct

coords = struct.pack('6f', 0.0, 0.0, 1.0, 0.0, 0.5, 1.0)
colors = struct.pack('12f', 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0)

icon_id = bpy.app.icons.new_triangles((0, 1), coords, colors)

# 在 UI 中使用
icon_value = icon_id
```

### new_triangles_from_file(filepath)

从文件创建图标。

参数：
- `filepath` (str | bytes)：文件路径

返回：
- `int`：唯一图标值

```python
import bpy.app.icons

# 从文件创建图标
icon_id = bpy.app.icons.new_triangles_from_file("//icons/my_icon.bin")
print(f"图标 ID: {icon_id}")
```

### release(icon_id)

释放图标资源。

参数：
- `icon_id` (int)：要释放的图标 ID

```python
import bpy.app.icons

icon_id = bpy.app.icons.new_triangles_from_file("//icons/my_icon.png")
# 使用图标...
bpy.app.icons.release(icon_id)
```

## bpy.app.timers 定时器模块

bpy.app.timers 模块用于注册在指定时间后调用的回调函数。

### register(function, first_interval=0, persistent=False)

注册新的定时器回调。

参数：
- `function` (Callable[[], float | None])：要调用的函数
- `first_interval` (float)：首次调用前的等待秒数
- `persistent` (bool)：加载新文件时不移除定时器

函数说明：
- 函数不接受参数
- 返回 None 表示取消注册定时器
- 返回浮点数指定下次调用前的延迟

```python
import bpy.app.timers

# 5秒后执行一次
def in_5_seconds():
    print("5秒后执行")

bpy.app.timers.register(in_5_seconds, first_interval=5)

# 每2秒执行一次
def every_2_seconds():
    print("每2秒执行")
    return 2.0  # 返回下次调用前的延迟

bpy.app.timers.register(every_2_seconds)
```

### is_registered(function)

检查函数是否已注册为定时器。

参数：
- `function` (Callable[[], float | None])：要检查的函数

返回：
- `bool`：函数是否已注册

```python
import bpy.app.timers

def my_timer():
    return 1.0

bpy.app.timers.register(my_timer)

if bpy.app.timers.is_registered(my_timer):
    print("定时器已注册")
```

### unregister(function)

取消注册定时器。

参数：
- `function` (Callable[[], float | None])：要取消注册的函数

```python
import bpy.app.timers

def my_timer():
    return 1.0

bpy.app.timers.register(my_timer)
# 稍后...
bpy.app.timers.unregister(my_timer)
```

### 定时器应用示例

#### 倒计时定时器

```python
import bpy.app.timers

counter = 10

def countdown():
    global counter
    print(f"倒计时: {counter}")
    counter -= 1
    if counter < 0:
        return None
    return 1.0  # 每秒执行一次

bpy.app.timers.register(countdown)
```

#### 带参数的定时器

```python
import bpy.app.timers
import functools

def print_message(message, count):
    print(f"{message}: {count}")
    return None

# 使用 functools.partial 传递参数
bpy.app.timers.register(
    functools.partial(print_message, "Hello", 5),
    first_interval=2.0
)
```

#### 持久化定时器

```python
import bpy.app.timers

def persistent_timer():
    print("这个定时器在加载新文件后仍然存在")
    return 60.0  # 每60秒执行一次

bpy.app.timers.register(persistent_timer, persistent=True)
```

## bpy.app.translations 翻译模块

bpy.app.translations 模块用于管理界面翻译。

### 常用函数

```python
import bpy.app.translations

# 注册翻译域
def register():
    bpy.app.translations.register(__name__, translations_dict)

def unregister():
    bpy.app.translations.unregister(__name__)
```

### 使用翻译

```python
import bpy
import bpy.app.translations

# 获取翻译文本
translated_text = bpy.app.translations.pgettext("Original Text", "MyAddon")
```

## bpy.app.handlers 处理器模块

bpy.app.handlers 模块用于注册在特定事件发生时调用的回调函数。

### 帧变更处理器

```python
import bpy.app.handlers

def frame_change_pre_handler(scene, depsgraph):
    print(f"帧变化前: {scene.frame_current}")

def frame_change_post_handler(scene, depsgraph):
    print(f"帧变化后: {scene.frame_current}")

bpy.app.handlers.frame_change_pre.append(frame_change_pre_handler)
bpy.app.handlers.frame_change_post.append(frame_change_post_handler)
```

### 渲染处理器

```python
def render_pre_handler(scene):
    print("开始渲染")

def render_post_handler(scene, result):
    print(f"渲染完成: {result}")

def render_cancel_handler(scene):
    print("渲染取消")

bpy.app.handlers.render_pre.append(render_pre_handler)
bpy.app.handlers.render_post.append(render_post_handler)
bpy.app.handlers.render_cancel.append(render_cancel_handler)
```

### 保存加载处理器

```python
def save_pre_handler(filepath):
    print(f"保存前: {filepath}")

def save_post_handler(filepath):
    print(f"保存后: {filepath}")

def load_pre_handler(filepath):
    print(f"加载前: {filepath}")

def load_post_handler(scene):
    print("加载后")

bpy.app.handlers.save_pre.append(save_pre_handler)
bpy.app.handlers.save_post.append(save_post_handler)
bpy.app.handlers.load_pre.append(load_pre_handler)
bpy.app.handlers.load_post.append(load_post_handler)
```

### 依赖图更新处理器

```python
def depsgraph_update_pre_handler(scene, depsgraph):
    print("依赖图更新前")

def depsgraph_update_post_handler(scene, depsgraph):
    print("依赖图更新后")

bpy.app.handlers.depsgraph_update_pre.append(depsgraph_update_pre_handler)
bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post_handler)
```

## 实际应用示例

### 自动保存备份

```python
import bpy
import os
import shutil
from datetime import datetime

backup_dir = "//backups"

def auto_backup(filepath):
    """在保存时自动创建备份"""
    if not filepath:
        return
    
    backup_path = bpy.path.abspath(backup_dir)
    if not os.path.exists(backup_path):
        os.makedirs(backup_path)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = os.path.basename(filepath)
    backup_file = os.path.join(backup_path, f"{timestamp}_{filename}")
    
    shutil.copy2(filepath, backup_file)
    print(f"Backup created: {backup_file}")

bpy.app.handlers.save_post.append(auto_backup)
```

### 帧自动保存

```python
import bpy

def auto_save_every_frame(scene, depsgraph):
    """每帧自动保存"""
    bpy.ops.wm.save_mainfile()

# 每10帧保存一次
frame_counter = 0

def conditional_save(scene, depsgraph):
    global frame_counter
    frame_counter += 1
    if frame_counter >= 10:
        bpy.ops.wm.save_mainfile()
        frame_counter = 0

bpy.app.handlers.frame_change_post.append(conditional_save)
```

### 定时自动保存

```python
import bpy.app.timers
import os

autosave_interval = 300  # 5分钟
autosave_dir = "//autosaves"

def auto_save():
    """自动保存文件"""
    if not os.path.exists(bpy.path.abspath(autosave_dir)):
        os.makedirs(bpy.path.abspath(autosave_dir))
    
    filepath = bpy.data.filepath
    if filepath:
        filename = os.path.basename(filepath)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        save_path = os.path.join(autosave_dir, f"autosave_{timestamp}_{filename}")
        bpy.ops.wm.save_as_mainfile(filepath=save_path)
        print(f"Auto saved: {save_path}")
    
    return autosave_interval

bpy.app.timers.register(auto_save)
```

### 性能监控

```python
import bpy.app.timers
import time

last_time = time.time()
frame_times = []

def monitor_performance():
    global last_time, frame_times
    
    current_time = time.time()
    delta = current_time - last_time
    last_time = current_time
    
    frame_times.append(delta)
    if len(frame_times) > 60:
        frame_times.pop(0)
    
    avg_frame_time = sum(frame_times) / len(frame_times)
    fps = 1.0 / avg_frame_time if avg_frame_time > 0 else 0
    
    print(f"FPS: {fps:.1f}, Frame Time: {avg_frame_time*1000:.1f}ms")
    
    return 1.0  # 每秒更新一次

bpy.app.timers.register(monitor_performance)
```

### 自定义图标按钮

```python
import bpy.app.icons
import struct

def create_custom_icon():
    """创建自定义三角形图标"""
    coords = struct.pack('6f', 
        0.0, 0.0,   # 左下
        1.0, 0.0,   # 右下
        0.5, 1.0    # 顶部
    )
    colors = struct.pack('12f',
        0.2, 0.6, 1.0, 1.0,  # 左下颜色 (RGBA)
        0.2, 0.6, 1.0, 1.0,  # 右下颜色
        0.2, 0.6, 1.0, 1.0   # 顶部颜色
    )
    
    icon_id = bpy.app.icons.new_triangles((0, 1), coords, colors)
    return icon_id

# 创建图标
my_icon = create_custom_icon()

# 在 UI 中使用
class MyOperator(bpy.types.Operator):
    bl_idname = "my.operator"
    bl_label = "My Operator"
    
    def execute(self, context):
        return {'FINISHED'}

# 添加图标到菜单
def menu_func(self, context):
    self.layout.operator(MyOperator.bl_idname, icon_value=my_icon)
```

### 场景更新通知

```python
import bpy.app.handlers

def scene_update_handler(scene, depsgraph):
    """处理场景更新"""
    for obj in depsgraph.objects:
        if obj.is_modified:
            print(f"对象已修改: {obj.name}")

bpy.app.handlers.depsgraph_update_post.append(scene_update_handler)
```

### 加载后初始化

```python
import bpy.app.handlers

def initialize_scene(scene):
    """在新场景加载后初始化"""
    # 设置默认渲染分辨率
    scene.render.resolution_x = 1920
    scene.render.resolution_y = 1080
    
    # 添加默认灯光
    if not scene.objects.find("Sun"):
        bpy.ops.object.light_add(type='SUN', location=(0, 0, 10))
    
    print(f"场景已初始化: {scene.name}")

bpy.app.handlers.load_post.append(initialize_scene)
```
