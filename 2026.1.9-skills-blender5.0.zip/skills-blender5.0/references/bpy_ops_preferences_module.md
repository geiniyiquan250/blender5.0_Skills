# bpy.ops.preferences 模块

用户偏好操作模块，用于管理Blender的全局用户设置。

## 概述

bpy.ops.preferences 模块包含用于访问和修改Blender用户偏好设置的运算符。这些设置控制界面、输入、文件路径和系统级选项。

## 常用操作

### 界面设置

```python
import bpy

# 打开用户偏好
bpy.ops.screen.userpref_show()

# 切换主题
bpy.ops.preferences.theme_install(filepath='//theme.xml')

# 选择主题
bpy.ops.preferences.active_theme_update()

# 设置界面缩放
bpy.ops.preferences.addons_enable(module='add-on_name')
bpy.ops.preferences.addons_disable(module='add-on_name')
```

### 插件管理

```python
# 启用插件
bpy.ops.preferences.addon_enable(module='module_name')

# 禁用插件
bpy.ops.preferences.addon_disable(module='module_name')

# 安装插件
bpy.ops.preferences.addon_install(filepath='//addon.py')

# 卸载插件
bpy.ops.preferences.addon_remove(module='module_name')

# 更新插件
bpy.ops.preferences.addon_refresh()

# 显示插件信息
bpy.ops.preferences.addon_expand(module='module_name')

# 折叠插件信息
bpy.ops.preferences.addon_collapse(module='module_name')
```

### 快捷键设置

```python
# 分配快捷键
bpy.ops.preferences.keyconfig_assign(filepath='//keymap.xml')

# 重置快捷键
bpy.ops.preferences.keyconfig_presets_edit(idname='Blender')

# 导出快捷键
bpy.ops.preferences.keyconfig_export(filepath='//keymap.xml')

# 添加快捷键
bpy.ops.preferences.keyitem_add()

# 删除快捷键
bpy.ops.preferences.keyitem_remove()

# 重命名快捷键
bpy.ops.preferences.keyitem_rename()
```

### 文件路径

```python
# 设置文件路径
bpy.ops.preferences.app_install_build(filepath='//blender.exe')

# 配置搜索路径
bpy.ops.preferences.file_paths(
    font_directory='//fonts/',
    texture_directory='//textures/',
    render_output_directory='//renders/',
    sound_directory='//sounds/',
    temporary_directory='//temp/'
)

# 设置渲染输出
bpy.ops.preferences.render_output(
    filepath='//renders/frame_'
)

# 设置资源路径
bpy.ops.preferences.asset_libraries(
    library='//assets/'
)
```

### 系统设置

```python
# 设置光标
bpy.ops.preferences.cursor_draw_add()
bpy.ops.preferences.cursor_draw_remove()

# 设置音频设备
bpy.ops.preferences.addon_disable(module='module_name')

# OpenCL设置
bpy.ops.preferences.open_last_problem()

# 撤销设置
bpy.ops.preferences.undo_presets_edit()
```

### 主题设置

```python
# 安装主题
bpy.ops.preferences.theme_install(filepath='//theme.xml')

# 重置主题
bpy.ops.preferences.theme_reset()

# 导出主题
bpy.ops.preferences.theme_export(filepath='//theme.xml')

# 选择颜色集
bpy.ops.preferences.active_theme_update()
```

### 编辑器设置

```python

```

### 快捷键导入导出

```python
# 导入快捷键配置
bpy.ops.preferences.keyconfig_assign(filepath='//keymap.xml')

# 导出快捷键配置
bpy.ops.preferences.keyconfig_export(filepath='//keymap.xml')

# 重置默认快捷键
bpy.ops.preferences.keyconfig_presets_edit(idname='Blender')
```

## 实际应用示例

### 安装和启用插件

```python
def install_and_enable_addon(filepath, module_name):
    """安装并启用插件"""
    # 安装插件
    bpy.ops.preferences.addon_install(filepath=filepath)
    
    # 启用插件
    bpy.ops.preferences.addon_enable(module=module_name)
    
    # 刷新
    bpy.ops.preferences.addon_refresh()
    
    return True
```

### 批量启用插件

```python
def batch_enable_addons(addons_list):
    """批量启用插件"""
    for module in addons_list:
        try:
            bpy.ops.preferences.addon_enable(module=module)
            print(f"已启用: {module}")
        except Exception as e:
            print(f"无法启用 {module}: {e}")
```

### 导出自定义快捷键

```python
def export_custom_keymap(output_path):
    """导出当前快捷键配置"""
    bpy.ops.preferences.keyconfig_export(filepath=output_path)
    print(f"快捷键已导出到: {output_path}")
```

### 配置项目文件路径

```python
def setup_project_paths(project_path):
    """配置项目文件路径"""
    bpy.ops.preferences.file_paths(
        font_directory=f'{project_path}/assets/fonts/',
        texture_directory=f'{project_path}/assets/textures/',
        render_output_directory=f'{project_path}/renders/',
        sound_directory=f'{project_path}/assets/audio/',
        temporary_directory=f'{project_path}/temp/'
    )
```

### 备份用户设置

```python
def backup_user_preferences(output_path):
    """备份用户偏好设置"""
    # 导出快捷键
    bpy.ops.preferences.keyconfig_export(
        filepath=f'{output_path}/keymap.xml'
    )
    
    # 复制用户配置目录
    import shutil
    import os
    
    prefs_dir = os.path.expanduser('~/.config/blender')
    backup_dir = f'{output_path}/blender_prefs'
    
    shutil.copytree(prefs_dir, backup_dir)
    
    return backup_dir
```

### 恢复用户设置

```python
def restore_user_preferences(backup_path):
    """恢复用户偏好设置"""
    # 导入快捷键
    bpy.ops.preferences.keyconfig_assign(
        filepath=f'{backup_path}/keymap.xml'
    )
    
    # 复制用户配置
    import shutil
    import os
    
    prefs_dir = os.path.expanduser('~/.config/blender')
    backup_dir = f'{backup_path}/blender_prefs'
    
    if os.path.exists(backup_dir):
        shutil.copytree(backup_dir, prefs_dir, dirs_exist_ok=True)
```

### 创建团队插件配置

```python
def create_team_addon_config(addons_list, config_file):
    """创建团队插件配置"""
    import json
    
    config = {
        'required_addons': addons_list,
        'version': '1.0',
        'date': '2024-01-01'
    }
    
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    return config_file
```

### 应用团队插件配置

```python
def apply_team_addon_config(config_file):
    """应用团队插件配置"""
    import json
    
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    # 启用所有必需插件
    for module in config['required_addons']:
        try:
            bpy.ops.preferences.addon_enable(module=module)
        except Exception as e:
            print(f"插件 {module} 未找到或无法启用")
```

## 使用场景

- **插件管理**：安装和管理插件
- **快捷键定制**：个性化快捷键配置
- **团队协作**：统一团队设置
- **环境配置**：设置项目文件路径
- **主题定制**：应用自定义主题
- **设置备份**：保存和恢复设置

## 注意事项

- 修改设置后可能需要重启
- 插件可能与其他功能冲突
- 快捷键可能覆盖默认设置
- 主题可能不兼容所有版本
- 路径使用绝对路径更可靠
- 团队设置需要版本控制
