# bpy.ops.particle 模块

粒子系统操作模块，用于创建和管理粒子发射系统。

## 概述

bpy.ops.particle 模块包含用于创建、编辑和管理粒子系统的运算符。这些运算符控制粒子发射、粒子编辑和粒子特效。

## 常用操作

### 粒子系统创建

```python
import bpy

# 添加粒子系统
bpy.ops.object.particle_system_add()

# 从选中物体添加粒子系统
bpy.ops.object.particle_system_add_from_scaned()

# 添加毛发粒子
bpy.ops.object.particle_system_add()
bpy.context.object.particle_systems.active.settings.type = 'HAIR'

# 添加关键粒子
bpy.ops.object.particle_system_add()
bpy.context.object.particle_systems.active.settings.type = 'EMITTER'
```

### 粒子模式

```python
# 切换到粒子编辑模式
bpy.ops.object.mode_set(mode='PARTICLE_EDITOR')

# 切换到粒子模式
bpy.ops.particle.mode_set(mode='PARTICLE')

# 切换到软体模式
bpy.ops.particle.mode_set(mode='SOFT_BODY')

# 切换到布料模式
bpy.ops.particle.mode_set(mode='CLOTH')

# 切换到刚体模式
bpy.ops.particle.mode_set(mode='RIGID_BODY')
```

### 粒子选择

```python
# 全选
bpy.ops.particle.select_all(action='SELECT')
bpy.ops.particle.select_all(action='DESELECT')
bpy.ops.particle.select_all(action='INVERT')

# 选择排列类型
bpy.ops.particle.select_rrf()

# 选择路径
bpy.ops.particle.select_path(action='SELECT')

# 清除路径
bpy.ops.particle.select_path(action='DELETE')
```

### 粒子编辑

```python
# 梳子
bpy.ops.particle.comb()

# 平滑
bpy.ops.particle.smooth()

# 滑动
bpy.ops.particle.slide()

# 增长
bpy.ops.particle.grow()

# 缩短
bpy.ops.particle.shrink()

# 添加
bpy.ops.particle.add()

# 删除
bpy.ops.particle.delete(type='PARTICLE')

# 旋转
bpy.ops.particle.rotate()

# 复制
bpy.ops.particle.duplicate()

# 对称
bpy.ops.particle.symmetric()
```

### 毛发编辑

```python
# 设置切点
bpy.ops.particle.set_cut_point()

# 吸附到网格
bpy.ops.particle吸附_to_mesh()

# 对齐到法线
bpy.ops.particle.align_normal()

# 切分
bpy.ops.particle.subdivide()

# 切分次数
bpy.ops.particle.subdivide(number_cuts=2)
```

### 动力学

```python
# 添加简单动力学
bpy.ops.particle.add_simple_kinematics()

# 移除简单动力学
bpy.ops.particle.remove_simple_kinematics()

# 转换为刚体
bpy.ops.particle.convert()

# 添加布料模拟
bpy.ops.particle.cloth_add()

# 添加软体模拟
bpy.ops.particle.softbody_add()
```

### 绘制模式

```python
# 绘制路径
bpy.ops.particle.paint(
    stroke=stroke_data,
    mode='NORMAL'
)

# 清除绘制
bpy.ops.particle.paint(stroke=[], mode='RELEASE')

# 笔触数据
stroke_data = [
    {"name": "", "location": (x, y, z), "mouse": (mx, my), "pressure": 1.0, "time": 0.0},
]
```

### 着色器

```python
# 切换着色器
bpy.ops.particle.shader_add()

# 选择着色器
bpy.ops.particle.shader_select()

# 移除着色器
bpy.ops.particle.shader_remove()
```

## 实际应用示例

### 创建程序化发型

```python
def create_procedural_hair(obj, num_strands=100, length=0.5, clumps=5):
    """创建程序化发型"""
    # 添加粒子系统
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.particle_system_add()
    
    psys = obj.particle_systems.active
    psys.name = "Hair"
    
    # 配置粒子设置
    settings = psys.settings
    settings.type = 'HAIR'
    settings.count = num_strands
    settings.hair_length = length
    settings.clump_factor = clumps
    settings.tip_clump = 0.8
    
    # 随机化
    settings.randomness = 0.5
    
    # 长度渐变
    settings.length_mode = 'ROOT'
    
    return psys
```

### 批量修改粒子

```python
def modify_particle_lengths(obj, scale_factor, pattern='ALL'):
    """批量修改粒子长度"""
    bpy.ops.object.mode_set(mode='PARTICLE_EDITOR')
    
    # 获取活动粒子系统
    psys = obj.particle_systems.active
    if not psys:
        return
    
    # 选择粒子
    if pattern == 'ALL':
        bpy.ops.particle.select_all(action='SELECT')
    elif pattern == 'TIPS':
        bpy.ops.particle.select_tips()
    elif pattern == 'ROOTS':
        bpy.ops.particle.select_roots()
    
    # 应用缩放
    bpy.ops.particle.scale(scale_factor)
```

### 粒子动画重置

```python
def reset_particle_simulation(obj, frame_range):
    """重置粒子模拟到指定帧范围"""
    psys = obj.particle_systems.active
    if not psys:
        return
    
    # 取消粒子系统链接
    bpy.ops.particle.unlink()
    
    # 设置帧范围
    bpy.context.scene.frame_start = frame_range[0]
    bpy.context.scene.frame_end = frame_range[1]
    
    # 重新添加粒子系统
    bpy.ops.object.particle_system_add()
```

### 粒子数据导出

```python
def export_particle_data(obj, filepath):
    """导出粒子数据到CSV"""
    import csv
    
    psys = obj.particle_systems.active
    if not psys:
        return
    
    with open(filepath, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Particle', 'Location_X', 'Location_Y', 'Location_Z', 'Velocity_X', 'Velocity_Y', 'Velocity_Z'])
        
        for i, particle in enumerate(psys.particles):
            writer.writerow([
                i,
                particle.location.x,
                particle.location.y,
                particle.location.z,
                particle.velocity.x,
                particle.velocity.y,
                particle.velocity.z
            ])
```

### 创建粒子特效

```python
def create_particle_effect(
    emitter_obj,
    target_obj=None,
    particle_count=1000,
    lifetime=50,
    emission_type='VOLUME',
    color=(1.0, 0.5, 0.0)
):
    """创建粒子特效"""
    # 添加粒子系统
    bpy.ops.object.select_all(action='DESELECT')
    emitter_obj.select_set(True)
    bpy.context.view_layer.objects.active = emitter_obj
    bpy.ops.object.particle_system_add()
    
    psys = emitter_obj.particle_systems.active
    psys.name = "Effect"
    
    settings = psys.settings
    settings.type = 'EMITTER'
    settings.count = particle_count
    settings.lifetime = lifetime
    settings.normal_factor = 1.0
    
    # 发射类型
    settings.emission_source = emission_type
    
    # 渲染设置
    settings.render_type = 'OBJECT'
    settings.instance_object = target_obj
    
    # 颜色
    settings.color = color
    
    return psys
```

## 使用场景

- **粒子特效**：创建烟雾、火焰、灰尘等特效
- **发型设计**：创建程序化发型和毛发
- **植被生成**：创建草地和植被
- **物理模拟**：创建布料、软体、刚体模拟
- **数据导出**：导出粒子数据进行外部处理
- **批量编辑**：批量修改粒子属性和行为

## 注意事项

- 粒子模拟需要设置物理属性
- 高粒子数量影响性能
- 毛发编辑需要切换到粒子编辑模式
- 粒子渲染类型决定显示方式
- 粒子数据导出需要考虑时间序列
