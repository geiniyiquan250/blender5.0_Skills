# bpy.types - Blender Data Types Reference

Blender Python API 所有数据类型的完整参考，涵盖核心对象、场景元素和UI组件。

## Overview

`bpy.types` 模块定义了 Blender 中所有数据结构的类。这些类型继承自 `bpy_struct`，提供了访问和修改 Blender 数据的接口。

## 核心数据类型分类

### 场景与对象管理

```python
import bpy

# Scene - 场景数据容器
scene = bpy.context.scene
print(f"场景名称: {scene.name}")
print(f"当前帧: {scene.frame_current}")
print(f"帧范围: {scene.frame_start} - {scene.frame_end}")

# 设置场景属性
scene.render.engine = 'CYCLES'
scene.unit_settings.system = 'METRIC'

# Object - 对象是场景中的基本元素
obj = bpy.context.active_object
print(f"对象名称: {obj.name}")
print(f"对象类型: {obj.type}")  # MESH, CURVE, ARMATURE, etc.
print(f"对象位置: {obj.location}")
print(f"对象旋转: {obj.rotation_euler}")
print(f"对象缩放: {obj.scale}")

# 对象变换操作
obj.location = (1.0, 2.0, 3.0)
obj.rotation_euler = (0.0, 0.0, 0.785)  # 45度
obj.scale = (1.5, 1.5, 1.5)

# 对象层级关系
print(f"父对象: {obj.parent}")
print(f"子对象数量: {len(obj.children)}")

# Collection - 集合用于组织对象
collection = bpy.data.collections.new("MyCollection")
bpy.context.scene.collection.children.link(collection)
collection.objects.link(obj)
```

### 网格数据类型

```python
# Mesh - 网格几何数据
mesh = bpy.context.active_object.data
print(f"顶点数: {len(mesh.vertices)}")
print(f"边数: {len(mesh.edges)}")
print(f"面数: {len(mesh.polygons)}")

# 访问顶点数据
for i, vert in enumerate(mesh.vertices):
    print(f"顶点 {i}: {vert.co}")
    print(f"  法线: {vert.normal}")

# 访问边数据
for edge in mesh.edges:
    print(f"边: {edge.vertices}")

# 访问面数据
for poly in mesh.polygons:
    print(f"面 {poly.index}: 顶点 {poly.vertices}")
    print(f"  法线: {poly.normal}")
    print(f"  面积: {poly.area}")

# Mesh 属性
mesh.use_auto_smooth = True
mesh.shade_smooth()

# UV层
uv_layer = mesh.uv_layers.new(name="UVMap")
for loop in mesh.loops:
    uv = uv_layer.data[loop.index].uv
    print(f"UV: {uv}")

# 顶点颜色层
vcol_layer = mesh.vertex_colors.new(name="Col")
for poly in mesh.polygons:
    for loop_idx in poly.loop_indices:
        color = vcol_layer.data[loop_idx].color
        print(f"颜色: {color}")
```

### 材质与着色

```python
# Material - 材质定义
mat = bpy.data.materials.new(name="MyMaterial")
mat.use_nodes = True

# 获取节点树
nodes = mat.node_tree.nodes
links = mat.node_tree.links

# 创建 Principled BSDF 材质
principled = nodes.get("Principled BSDF")
if principled:
    principled.inputs["Base Color"].default_value = (1.0, 0.2, 0.2, 1.0)
    principled.inputs["Metallic"].default_value = 0.5
    principled.inputs["Roughness"].default_value = 0.3

# 创建新材质槽
obj.data.materials.append(mat)

# 获取活动材质
if obj.active_material:
    print(f"活动材质: {obj.active_material.name}")

# 纹理
tex = bpy.data.textures.new(name="MyTexture", type='CLOUDS')
tex.noise_scale = 2.0
```

### 曲线与曲面

```python
# Curve - 曲线数据
curve = bpy.context.active_object.data
print(f"曲线类型: {curve.type}")  # BEZIER, POLY, SURFACE, etc.

# Bezier曲线
if curve.type == 'BEZIER':
    for spline in curve.splines:
        print(f"点数: {len(spline.points)}")
        for point in spline.points:
            print(f"  坐标: {point.co}")
            print(f"  句柄: {point.handle_type}")

# NURBS曲线
if curve.type == 'NURBS':
    for spline in curve.splines:
        print(f"阶数: {spline.order_u}")
        print(f"闭合: {spline.use_cyclic_u}")

# Surface - 曲面
surface = bpy.context.active_object.data
print(f"U向点数: {surface.point_count_u}")
print(f"V向点数: {surface.point_count_v}")
```

### 骨骼与动画

```python
# Armature - 骨骼系统
armature = bpy.context.active_object.data
print(f"骨骼数量: {len(armature.bones)}")

# 遍历骨骼
for bone in armature.bones:
    print(f"骨骼: {bone.name}")
    print(f"  头部: {bone.head}")
    print(f"  尾部: {bone.tail}")
    print(f"  长度: {bone.length}")

# Edit Bones (编辑模式)
if armature.edit_bones:
    for bone in armature.edit_bones:
        print(f"编辑骨骼: {bone.name}")

# Pose - 姿态数据
pose = bpy.context.active_object.pose
for pose_bone in pose.bones:
    print(f"姿态骨骼: {pose_bone.name}")
    print(f"  位置: {pose_bone.location}")
    print(f"  旋转: {pose_bone.rotation_quaternion}")
    print(f"  缩放: {pose_bone.scale}")

# 约束
for constraint in pose_bone.constraints:
    print(f"约束: {constraint.name}")
    print(f"  类型: {constraint.type}")
```

### 相机与灯光

```python
# Camera - 相机
camera = bpy.context.active_object.data
print(f"相机类型: {camera.type}")
print(f"焦距: {camera.lens}")
print(f"传感器尺寸: {camera.sensor_width}")

# 相机变换
camera.shift_x = 0.1
camera.shift_y = -0.05

# 景深设置
camera.dof.use_dof = True
camera.dof.focus_distance = 5.0
camera.dof.aperture_fstop = 2.8

# Light - 灯光
light = bpy.context.active_object.data
print(f"灯光类型: {light.type}")  # POINT, SUN, SPOT, AREA
print(f"功率: {light.energy}")
print(f"颜色: {light.color}")

# 设置灯光属性
if light.type == 'SPOT':
    light.spot_size = 0.5  # 弧度
    light.spot_blend = 0.5
    light.falloff_type = 'INVERSE_LINEAR'
```

### 节点与合成

```python
# NodeTree - 节点树
node_tree = bpy.context.active_object.data.node_tree
print(f"节点数: {len(node_tree.nodes)}")

# 遍历节点
for node in node_tree.nodes:
    print(f"节点: {node.name}")
    print(f"  类型: {node.type}")
    print(f"  位置: {node.location}")

# 创建节点
new_node = node_tree.nodes.new(type='ShaderNodeMixRGB')
new_node.location = (200, 300)
new_node.blend_type = 'MIX'
new_node.inputs[0].default_value = 0.5

# 连接节点
links = node_tree.links
link = links.new(output_node.outputs[0], input_node.inputs[0])

# 合成节点树
comp_tree = bpy.context.scene.node_tree
render_layers = comp_tree.nodes.get("Render Layers")
composite = comp_tree.nodes.get("Composite")
if render_layers and composite:
    links.new(render_layers.outputs[0], composite.inputs[0])
```

### UI 组件类型

```python
# Panel - UI面板
class MyPanel(bpy.types.Panel):
    bl_label = "我的面板"
    bl_idname = "OBJECT_PT_my_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '工具'

    def draw(self, context):
        layout = self.layout
        layout.label(text="Hello World")

# Menu - UI菜单
class MyMenu(bpy.types.Menu):
    bl_idname = "OBJECT_MT_my_menu"
    bl_label = "我的菜单"

    def draw(self, context):
        layout = self.layout
        layout.operator("object.select_all", text="全选")
        layout.operator("object.delete", text="删除")

# Operator - 操作符
class MyOperator(bpy.types.Operator):
    bl_idname = "object.my_operator"
    bl_label = "我的操作符"

    def execute(self, context):
        print("操作执行")
        return {'FINISHED'}

# UIList - UI列表
class MyList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        layout.label(text=item.name)
```

### 动画数据类型

```python
# Action - 动画动作
action = bpy.data.actions.new(name="MyAction")
print(f"帧范围: {action.frame_range}")

# F-Curves
for fcurve in action.fcurves:
    print(f"数据路径: {fcurve.data_path}")
    print(f"数组索引: {fcurve.array_index}")
    
    # 关键帧
    for keyframe in fcurve.keyframe_points:
        print(f"  帧: {keyframe.co.x}, 值: {keyframe.co.y}")

# AnimData - 动画数据
anim_data = obj.animation_data
if anim_data:
    print(f"动作: {anim_data.action}")
    print(f"驱动: {len(anim_data.drivers)}")

# Drivers - 驱动
for driver in anim_data.drivers:
    print(f"驱动数据路径: {driver.data_path}")
    print(f"数组索引: {driver.array_index}")

# NLA Tracks
for track in anim_data.nla_tracks:
    print(f"NLA轨道: {track.name}")
    for strip in track.strips:
        print(f"  条带: {strip.name}")
        print(f"  帧范围: {strip.frame_start} - {strip.frame_end}")
```

## 重要类型详细说明

### ID 类型层次

```python
# ID 是所有可识别数据的基础类型
# 所有 bpy.types.* 都继承自 bpy_struct -> ID

# ID 属性
mat = bpy.data.materials[0]
print(f"名称: {mat.name}")
print(f"库: {mat.library}")
print(f"用户数: {mat.users}")
print(f"fake用户: {mat.use_fake_user}")

# 复制数据
new_mat = mat.copy()
new_mat.name = mat.name + ".001"

# 用户管理
mat.use_fake_user = True
bpy.data.materials.remove(mat)

# 标签
mat.tag = True
mat.tags.clear()
```

### 集合管理

```python
# 场景集合
scene_collection = bpy.context.scene.collection
print(f"子集合数: {len(scene_collection.children)}")
print(f"直接对象数: {len(scene_collection.objects)}")

# 遍历所有集合
for collection in bpy.data.collections:
    print(f"集合: {collection.name}")
    print(f"  对象数: {len(collection.objects)}")
    for obj in collection.objects:
        print(f"    - {obj.name}")

# 链接和取消链接
collection.objects.link(obj)
collection.objects.unlink(obj)

# 集合操作
new_collection = bpy.data.collections.new("Test")
scene.collection.children.link(new_collection)
bpy.data.collections.remove(new_collection)
```

## 常见模式

### 安全的数据访问

```python
def safe_get_material(obj, slot=0):
    """安全获取材质"""
    if obj and obj.data and obj.data.materials:
        return obj.data.materials[slot]
    return None

def get_active_object_data():
    """获取活动对象的数据"""
    obj = bpy.context.active_object
    if obj and obj.data:
        return obj.data
    return None
```

### 批量修改数据

```python
def batch_rename_objects(prefix):
    """批量重命名对象"""
    for obj in bpy.context.selected_objects:
        obj.name = f"{prefix}_{obj.name}"

def batch_apply_modifiers():
    """批量应用修改器"""
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            for modifier in obj.modifiers:
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.modifier_apply(modifier=modifier.name)
```

## 性能注意事项

1. **避免频繁的 ID 查找**：使用引用而不是重复查找
2. **批量操作**：使用 bmesh 进行大量网格操作
3. **及时清理**：删除不再需要的数据
4. **使用 eval_depsgraph**：正确处理依赖图

## 相关模块

- [bpy.data](bpy_data_module.md) - 数据访问接口
- [bpy.context](bpy_context_module.md) - 上下文访问
- [bpy.ops](bpy_ops.md) - 操作符系统
- [bpy.props](bpy_props_module.md) - 属性定义
