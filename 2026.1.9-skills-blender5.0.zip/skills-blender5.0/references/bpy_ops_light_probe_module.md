# bpy.ops.light_probe - 光照探针操作模块

bpy.ops.light_probe模块提供了光照探针（ light probe）对象的创建和管理操作，用于改进光照渲染效果。

## 概述

光照探针是用于捕捉环境光照和反射的工具，在EEVEE和Cycles渲染中非常重要。这个模块提供了创建和编辑光照探针的操作。

## 核心功能

### 探针创建

```python
import bpy

def add_reflection_cube(location=None):
    """添加反射立方体贴图探针"""
    bpy.ops.object.lightprobe_add(
        type='CUBEMAP',
        location=location or bpy.context.scene.cursor.location
    )

def add_reflection_plane(location=None):
    """添加反射平面探针"""
    bpy.ops.object.lightprobe_add(
        type='PLANAR',
        location=location or bpy.context.scene.cursor.location
    )

def add_irradiance_volume(location=None):
    """添加辐照度体积探针"""
    bpy.ops.object.lightprobe_add(
        type='VOLUME_SAMPLE',
        location=location or bpy.context.scene.cursor.location
    )
```

### 探针设置

```python
def set_intensity(intensity):
    """设置强度"""
    probe = bpy.context.active_object
    if probe and probe.type == 'LIGHT_PROBE':
        probe.data.intensity = intensity

def set_radius(radius):
    """设置半径"""
    probe = bpy.context.active_object
    if probe and probe.type == 'LIGHT_PROBE':
        probe.data.radius = radius

def set_resolution(resolution):
    """设置分辨率"""
    probe = bpy.context.active_object
    if probe and probe.type == 'LIGHT_PROBE':
        probe.data.resolution = resolution

def set_clip_start(distance):
    """设置近裁剪"""
    probe = bpy.context.active_object
    if probe and probe.type == 'LIGHT_PROBE':
        probe.data.clip_start = distance

def set_clip_end(distance):
    """设置远裁剪"""
    probe = bpy.context.active_object
    if probe and probe.type == 'LIGHT_PROBE':
        probe.data.clip_end = distance
```

### 探针更新

```python
def hide_probe():
    """隐藏探针"""
    bpy.ops.object.hide_probe()

def show_probe():
    """显示探针"""
    bpy.ops.object.show_probe()

def duplicate_probe():
    """复制探针"""
    bpy.ops.object.duplicate()
```

## 实用函数

### 批处理创建

```python
def create_probe_grid(
    size=(3, 3, 3),
    spacing=2.0,
    probe_type='VOLUME_SAMPLE'
):
    """创建探针网格"""
    center = bpy.context.scene.cursor.location
    probes = []
    
    for x in range(size[0]):
        for y in range(size[1]):
            for z in range(size[2]):
                location = (
                    center.x + (x - size[0]//2) * spacing,
                    center.y + (y - size[1]//2) * spacing,
                    center.z + (z - size[2]//2) * spacing
                )
                bpy.ops.object.lightprobe_add(type=probe_type, location=location)
                probes.append(bpy.context.active_object)
    
    return probes
```

### 属性调整

```python
def adjust_probe_range(probe, influence_distance):
    """调整探针影响范围"""
    probe.data.influence_distance = influence_distance
    probe.data.falloff = 1.0

def optimize_for_realtime(probe):
    """优化实时渲染"""
    probe.data.resolution = 32
    probe.data.clip_end = 10.0

def optimize_for_quality(probe):
    """优化质量"""
    probe.data.resolution = 256
    probe.data.clip_end = 50.0
```

## 常见问题排查

### 探针不可见

显示问题：
- 检查探针是否隐藏
- 确认渲染引擎支持
- 验证图层可见性

### 光照异常

设置问题：
- 检查探针范围设置
- 确认分辨率足够
- 验证位置是否合理
