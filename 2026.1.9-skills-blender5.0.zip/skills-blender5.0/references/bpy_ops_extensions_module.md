# bpy.ops.extensions - 扩展操作模块

Blender扩展操作符，用于管理Blender扩展和插件系统。

## 概述

`bpy.ops.extensions` 模块提供用于安装、更新、管理和删除Blender扩展的操作功能。扩展系统是Blender 4.0+版本中新的插件管理机制。

## 核心功能

### 扩展仓库操作

```python
import bpy

# 打开扩展仓库
bpy.ops.extensions.open_ext_store()

# 刷新扩展仓库列表
bpy.ops.extensions.refresh()

# 更新扩展仓库索引
bpy.ops.extensions.update_repo_index()

# 搜索扩展
bpy.ops.extensions.search(query='material')

# 按分类浏览扩展
bpy.ops.extensions.browse(category='materials')

# 显示扩展详情
bpy.ops.extensions.view_details(extension_id='pkg_name')

# 返回扩展列表
bpy.ops.extensions.back_to_list()
```

### 扩展安装

```python
# 从仓库安装扩展
bpy.ops.extensions.install(extension_id='pkg_name')

# 从文件安装扩展
bpy.ops.extensions.install_from_file(filepath='//extension.zip')

# 从URL安装扩展
bpy.ops.extensions.install_from_url(url='https://example.com/extension.zip')

# 批量安装扩展
bpy.ops.extensions.batch_install(extension_ids=['pkg1', 'pkg2', 'pkg3'])

# 安装扩展到指定路径
bpy.ops.extensions.install(filepath='//extension.zip', target='//addons/')

# 检查依赖并安装
bpy.ops.extensions.install_with_deps(extension_id='pkg_name')
```

### 扩展更新

```python
# 检查更新
bpy.ops.extensions.check_for_updates()

# 更新单个扩展
bpy.ops.extensions.update(extension_id='pkg_name')

# 更新所有扩展
bpy.ops.extensions.update_all()

# 更新所有扩展到最新版本
bpy.ops.extensions.update_all_to_latest()

# 忽略特定扩展的更新
bpy.ops.extensions.ignore_update(extension_id='pkg_name')

# 取消忽略更新
bpy.ops.extensions.unignore_update(extension_id='pkg_name')

# 设置扩展更新策略
bpy.ops.extensions.set_update_policy(policy='auto')
```

### 扩展管理

```python
# 启用扩展
bpy.ops.extensions.enable(extension_id='pkg_name')

# 禁用扩展
bpy.ops.extensions.disable(extension_id='pkg_name')

# 切换扩展状态
bpy.ops.extensions.toggle(extension_id='pkg_name')

# 重新加载扩展
bpy.ops.extensions.reload(extension_id='pkg_name')

# 重启扩展
bpy.ops.extensions.restart(extension_id='pkg_name')

# 配置扩展
bpy.ops.extensions.configure(extension_id='pkg_name')

# 打开扩展设置面板
bpy.ops.extensions.open_preferences(extension_id='pkg_name')

# 查看扩展信息
bpy.ops.extensions.info(extension_id='pkg_name')

# 查看扩展使用统计
bpy.ops.extensions.usage_stats(extension_id='pkg_name')
```

### 扩展卸载

```python
# 卸载扩展
bpy.ops.extensions.remove(extension_id='pkg_name')

# 卸载并删除配置
bpy.ops.extensions.remove_with_config(extension_id='pkg_name')

# 批量卸载扩展
bpy.ops.extensions.batch_remove(extension_ids=['pkg1', 'pkg2'])

# 清理未使用的依赖
bpy.ops.extensions.cleanup_orphans()

# 清理扩展缓存
bpy.ops.extensions.clear_cache()
```

### 扩展备份

```python
# 备份扩展
bpy.ops.extensions.backup(extension_id='pkg_name', filepath='//backup.zip')

# 批量备份所有扩展
bpy.ops.extensions.backup_all(filepath='//all_extensions.zip')

# 从备份恢复扩展
bpy.ops.extensions.restore_from_backup(filepath='//backup.zip')

# 导入扩展设置
bpy.ops.extensions.import_settings(filepath='//settings.json')

# 导出扩展设置
bpy.ops.extensions.export_settings(extension_id='pkg_name', filepath='//settings.json')
```

### 扩展仓库管理

```python
# 添加自定义仓库
bpy.ops.extensions.repo_add(url='https://example.com/repo.json', name='My Repo')

# 移除自定义仓库
bpy.ops.extensions.repo_remove(repo_id='my_repo')

# 编辑仓库设置
bpy.ops.extensions.repo_edit(repo_id='my_repo', url='https://new_url.com/repo.json')

# 启用仓库
bpy.ops.extensions.repo_enable(repo_id='my_repo')

# 禁用仓库
bpy.ops.extensions.repo_disable(repo_id='my_repo')

# 刷新仓库
bpy.ops.extensions.repo_refresh(repo_id='my_repo')

# 设置仓库优先级
bpy.ops.extensions.repo_set_priority(repo_id='my_repo', priority=10)
```

### 扩展权限管理

```python
# 授予扩展权限
bpy.ops.extensions.grant_permission(extension_id='pkg_name', permission='internet')

# 撤销扩展权限
bpy.ops.extensions.revoke_permission(extension_id='pkg_name', permission='internet')

# 查看扩展权限
bpy.ops.extensions.view_permissions(extension_id='pkg_name')

# 重置所有权限
bpy.ops.extensions.reset_all_permissions(extension_id='pkg_name')
```

## 实用函数

```python
def get_installed_extensions():
    """获取所有已安装的扩展"""
    return list(bpy.context.preferences.extensions)

def get_enabled_extensions():
    """获取所有启用的扩展"""
    return [ext for ext in bpy.context.preferences.extensions if ext.enabled]

def get_extension_by_id(extension_id):
    """根据ID获取扩展"""
    for ext in bpy.context.preferences.extensions:
        if ext.module == extension_id:
            return ext
    return None

def is_extension_enabled(extension_id):
    """检查扩展是否已启用"""
    ext = get_extension_by_id(extension_id)
    return ext.enabled if ext else False

def get_extension_version(extension_id):
    """获取扩展版本"""
    ext = get_extension_by_id(extension_id)
    return ext.version if ext else None

def check_extension_updates():
    """检查扩展更新，返回有更新的扩展列表"""
    updates_available = []
    for ext in bpy.context.preferences.extensions:
        if ext.update_available:
            updates_available.append(ext)
    return updates_available

def install_required_extensions():
    """安装所有标记为需要安装的扩展"""
    for ext in bpy.context.preferences.extensions:
        if ext.pending_install:
            bpy.ops.extensions.install(extension_id=ext.module)

def get_extension_dependencies(extension_id):
    """获取扩展的依赖列表"""
    ext = get_extension_by_id(extension_id)
    return ext.dependencies if ext else []
```

## 常见问题排查

### 安装失败
```python
# 检查权限
bpy.ops.extensions.view_permissions(extension_id='pkg_name')

# 尝试手动安装
bpy.ops.extensions.install_from_file(filepath='//extension.zip')

# 检查日志
import logging
logging.basicConfig(level=logging.DEBUG)

# 验证文件完整性
import os
if os.path.exists('//extension.zip'):
    print("文件存在")
else:
    print("文件不存在")
```

### 扩展冲突
```python
# 列出所有扩展
for ext in bpy.context.preferences.extensions:
    print(f"{ext.module}: {ext.enabled}")

# 检查冲突
def check_conflicts():
    conflicts = []
    enabled = get_enabled_extensions()
    for ext in enabled:
        for dep in ext.dependencies:
            if not is_extension_enabled(dep):
                conflicts.append(f"{ext.module} 需要 {dep}")
    return conflicts

# 禁用冲突扩展
for ext_name in conflict_extensions:
    bpy.ops.extensions.disable(extension_id=ext_name)
```

### 更新问题
```python
# 强制刷新仓库
bpy.ops.extensions.update_repo_index()

# 手动检查更新
bpy.ops.extensions.check_for_updates()

# 回滚更新
for ext in updated_extensions:
    bpy.ops.extensions.install_from_file(filepath=ext.backup_path)
```
