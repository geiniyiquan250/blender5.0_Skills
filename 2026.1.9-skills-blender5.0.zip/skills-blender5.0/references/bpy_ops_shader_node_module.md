# bpy.ops.node - 着色器节点操作模块

bpy.ops.node模块提供了着色器节点编辑器中的操作功能，用于创建和连接材质节点。

## 概述

着色器节点编辑器是Blender中创建材质的重要工具。这个模块提供了添加、连接和编辑着色器节点的操作。

## 核心功能

### 添加节点

```python
import bpy

def add_shader_node(node_type):
    """添加着色器节点"""
    bpy.ops.node.add_node(
        type=node_type,
        use_transform=True
    )

def add_output_node():
    """添加输出节点"""
    add_shader_node('ShaderNodeOutputMaterial')

def add_material_output():
    """添加材质输出"""
    add_shader_node('ShaderNodeOutputMaterial')

def add_principled_bsdf():
    """添加Principled BSDF节点"""
    add_shader_node('ShaderNodeBsdfPrincipled')

def add_glossy_bsdf():
    """添加光滑BSDF节点"""
    add_shader_node('ShaderNodeBsdfGlossy')

def add_diffuse_bsdf():
    """添加漫反射BSDF节点"""
    add_shader_node('ShaderNodeBsdfDiffuse')

def add_emission():
    """添加自发光节点"""
    add_shader_node('ShaderNodeEmission')

def add_transparent_bsdf():
    """添加透明BSDF节点"""
    add_shader_node('ShaderNodeBsdfTransparent')

def add_glass_bsdf():
    """添加玻璃BSDF节点"""
    add_shader_node('ShaderNodeBsdfGlass')
```

### 纹理节点

```python
def add_image_texture():
    """添加图像纹理节点"""
    add_shader_node('ShaderNodeTexImage')

def add_noise_texture():
    """添加噪声纹理节点"""
    add_shader_node('ShaderNodeTexNoise')

def add_wave_texture():
    """添加波浪纹理节点"""
    add_shader_node('ShaderNodeTexWave')

def add_voronoi_texture():
    """添加Vorono纹理节点"""
    add_shader_node('ShaderNodeTexVoronoi')

def add_musgrave_texture():
    """添加Musgrave纹理节点"""
    add_shader_node('ShaderNodeTexMusgrave')

def add_gradient_texture():
    """添加渐变纹理节点"""
    add_shader_node('ShaderNodeTexGradient')
```

### 颜色节点

```python
def add_color_ramp():
    """添加颜色渐变"""
    add_shader_node('ShaderNodeValToRGB')

def add_hue_saturation():
    """添加色相饱和度"""
    add_shader_node('ShaderNodeHueSaturation')

def add_rgb_curves():
    """添加RGB曲线"""
    add_shader_node('ShaderNodeCurvesRGB')

def add_invert():
    """添加反相"""
    add_shader_node('ShaderNodeInvert')

def add_brightness_contrast():
    """添加亮度对比度"""
    add_shader_node('ShaderNodeBrightContrast')
```

## 实用函数

### 输入输出节点

```python
def add_texture_coordinate():
    """添加纹理坐标"""
    add_shader_node('ShaderNodeTexCoord')

def add_mapping():
    """添加映射"""
    add_shader_node('ShaderNodeMapping')

def add_normal():
    """添加法线"""
    add_shader_node('ShaderNodeNormal')

def add_bump():
    """添加凹凸"""
    add_shader_node('ShaderNodeBump')

def add_vector_rotate():
    """添加向量旋转"""
    add_shader_node('ShaderNodeVectorRotate')
```

### 混合节点

```python
def add_mix_shader():
    """添加混合着色器"""
    add_shader_node('ShaderNodeMixShader')

def add_add_shader():
    """添加添加着色器"""
    add_shader_node('ShaderNodeAddShader')

def add_mix_color():
    """添加混合颜色"""
    add_shader_node('ShaderNodeMixRGB')

def add_mix():
    """添加混合"""
    add_shader_node('ShaderNodeMath', 'Mix')
```

## 常见问题排查

### 节点添加失败

类型错误：
- 确认节点类型正确
- 检查编辑器类型
- 验证节点可用性

### 链接问题

连接失败：
- 确认Socket兼容
- 检查输入输出存在
- 验证连接方向
