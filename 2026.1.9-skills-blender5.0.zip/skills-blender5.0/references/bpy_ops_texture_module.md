# bpy.ops.texture 模块

纹理操作模块，用于创建和管理程序化纹理。

## 概述

bpy.ops.texture 模块包含用于创建和配置程序化纹理的运算符。这些运算符控制纹理类型、参数和预览显示。

## 常用操作

### 纹理创建

```python
import bpy

# 新建纹理
bpy.ops.texture.new(name='NewTexture')

# 新建程序纹理
bpy.ops.texture.new(name='ProceduralTexture')

# 复制纹理
bpy.ops.texture.copy()

# 粘贴纹理
bpy.ops.texture.paste()

# 删除纹理
bpy.ops.texture.delete()

# 重命名纹理
bpy.ops.texture.rename(name='RenamedTexture')
```

### 纹理类型

```python
# 新建云纹
bpy.ops.texture.new(name='Clouds')

# 新建木纹
bpy.ops.texture.new(name='Wood')

# 新建大理石纹
bpy.ops.texture.new(name='Marble')

# 新建电磁场
bpy.ops.texture.new(name='Electric')

# 新建漩涡
bpy.ops.texture.new(name='Swirl')

# 新建噪声
bpy.ops.texture.new(name='Noise')

# 新建混合
bpy.ops.texture.new(name='Blend')

# 新建魔法
bpy.ops.texture.new(name='Magic')

# 新建补丁
bpy.ops.texture.new(name='Patchy')

# 新建Voronoi
bpy.ops.texture.new(name='Voronoi')

# 新建Musgrave
bpy.ops.texture.new(name='Musgrave')

# 新建Ocean
bpy.ops.texture.new(name='Ocean')
```

### 纹理预览

```python
# 刷新预览
bpy.ops.texture.preview_refresh()

# 采样预览
bpy.ops.texture.preview_sample()

# 缩放预览
bpy.ops.texture.preview_use_size()
```

### 纹理插槽

```python
# 添加插槽
bpy.ops.texture.slot_add()

# 删除插槽
bpy.ops.texture.slot_remove()

# 移动插槽
bpy.ops.texture.slot_move(type='UP')
bpy.ops.texture.slot_move(type='DOWN')

# 复制插槽
bpy.ops.texture.slot_copy()

# 粘贴插槽
bpy.ops.texture.slot_paste()
```

## 实际应用示例

### 创建云纹

```python
def create_clouds_texture(name, size=1.0, nabla=0.1, depth=2):
    """创建云纹"""
    tex = bpy.data.textures.new(name=name, type='CLOUDS')
    tex.noise_scale = size
    tex.noise_depth = depth
    
    return tex
```

### 创建木纹

```python
def create_wood_texture(name, noise_scale=1.0, turbulence=5.0, depth=2):
    """创建木纹"""
    tex = bpy.data.textures.new(name=name, type='WOOD')
    tex.noise_scale = noise_scale
    tex.turbulence = turbulence
    tex.noise_depth = depth
    
    return tex
```

### 创建Voronoi纹理

```python
def create_voronoi_texture(name, distance_metric='SQUARED', color_mode='INTENSITY'):
    """创建Voronoi纹理"""
    tex = bpy.data.textures.new(name=name, type='VORONOI')
    tex.distance_metric = distance_metric
    tex.color_mode = color_mode
    
    return tex
```

### 创建Musgrave纹理

```python
def create_musgrave_texture(name, musgrave_type='FBM', dimension=2.0):
    """创建Musgrave纹理"""
    tex = bpy.data.textures.new(name=name, type='MUSGRAVE')
    tex.musgrave_type = musgrave_type
    tex.dimension = dimension
    
    return tex
```

### 创建Ocean纹理

```python
def create_ocean_texture(name, resolution=64, spatial_scale=1.0, time_scale=1.0):
    """创建Ocean纹理"""
    tex = bpy.data.textures.new(name=name, type='OCEAN')
    tex.resolution = resolution
    tex.spatial_scale = spatial_scale
    tex.time_scale = time_scale
    
    return tex
```

### 创建程序化材质纹理

```python
def create_procedural_material_texture():
    """创建程序化材质纹理集"""
    textures = {
        'procedural_brick': create_brick_texture('Brick'),
        'procedural_wood': create_wood_texture('Wood'),
        'procedural_metal': create_voronoi_texture('Metal'),
        'procedural_rock': create_musgrave_texture('Rock'),
    }
    
    return textures
```

### 创建无缝纹理

```python
def create_seamless_texture(source_texture):
    """创建无缝纹理"""
    # 复制纹理
    new_tex = source_texture.copy()
    new_tex.name = f'{source_texture.name}_seamless'
    
    # 设置无缝参数
    # 注意：Blender程序纹理本身是无缝的
    
    return new_tex
```

### 批量创建自然纹理

```python
def create_natural_textures():
    """创建自然纹理集"""
    textures = {
        'natural_grass': create_clouds_texture('Grass', size=2.0),
        'natural_rock': create_voronoi_texture('Rock', distance_metric='EUCLIDEAN'),
        'natural_sand': create_musgrave_texture('Sand', musgrave_type='RIDGED_MULTIFRACTAL'),
        'natural_water': create_ocean_texture('Water', resolution=128),
        'natural_wood': create_wood_texture('WoodGrain', noise_scale=1.5),
    }
    
    return textures
```

## 使用场景

- **程序化纹理**：创建可调节的纹理
- **材质制作**：为材质提供纹理输入
- **无缝纹理**：创建可平铺纹理
- **自然纹理**：创建自然材质效果
- **纹理库**：创建可复用纹理集合
- **批处理**：批量生成纹理

## 注意事项

- 程序纹理可以无限缩放
- 不同纹理类型有不同参数
- 纹理与材质配合使用
- 高分辨率影响性能
- 纹理可以混合使用
- 某些纹理类型已被节点系统替代
