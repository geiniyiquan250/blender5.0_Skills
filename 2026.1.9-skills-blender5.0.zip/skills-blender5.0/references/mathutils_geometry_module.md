# mathutils.geometry 模块

## 模块概述

mathutils.geometry 模块提供了一系列用于几何计算的函数，这些函数是进行 3D 几何操作和空间分析的基础工具。该模块包含了向量、矩阵之外的专门用于几何关系的计算功能，如点线距离、射线检测、面法线计算、曲线插值等。这些函数在游戏开发、动画制作、几何处理等场景中有着广泛的应用。

与其他 mathutils 子模块不同，geometry 模块不包含类定义，而是纯粹提供静态函数。这种设计使得这些几何计算函数可以直接调用，无需创建对象实例。所有的函数都经过优化，能够高效处理大规模的几何计算任务。函数的输入输出通常使用 Vector 对象，方便与其他 mathutils 模块配合使用。

该模块中的函数可以分为几个主要类别：距离计算函数用于测量空间中的各种距离关系，射线检测函数用于光线追踪和拾取操作，插值函数用于生成平滑的曲线路径，面积和法线函数用于网格几何分析。理解这些函数的功能和使用场景对于编写高效的 3D 脚本至关重要。

## 距离计算函数

### 点到点的距离

点到点距离是最基本的几何计算，用于测量两个三维空间点之间的直线距离。这个函数在碰撞检测、路径规划、相似度比较等场景中非常有用。mathutils.geometry.distance_point_to_point 函数接收两个 Vector 对象作为输入，返回它们之间的欧几里得距离。

除了距离值，有时还需要获取距离向量，即从一个点指向另一个点的向量。使用两个点的坐标相减即可得到距离向量，这个向量包含了方向信息，可以用于进一步的计算。

```python
from mathutils.geometry import distance_point_to_point
from mathutils import Vector

# 计算两点之间的距离
point_a = Vector((0.0, 0.0, 0.0))
point_b = Vector((3.0, 4.0, 0.0))

distance = distance_point_to_point(point_a, point_b)
print(f"两点距离: {distance:.4f}")  # 输出: 5.0000

# 使用勾股定理验证
expected = (3.0**2 + 4.0**2) ** 0.5
print(f"验证结果: {expected:.4f}")

# 计算距离向量
distance_vector = point_b - point_a
print(f"距离向量: {distance_vector}")

# 批量计算点之间的距离
points = [
    Vector((0, 0, 0)),
    Vector((1, 2, 3)),
    Vector((4, 5, 6)),
    Vector((7, 8, 9))
]

print("\n点对距离矩阵:")
for i, p1 in enumerate(points):
    for j, p2 in enumerate(points):
        if i < j:
            dist = distance_point_to_point(p1, p2)
            print(f"  点{i} 到 点{j}: {dist:.4f}")
```

### 点到直线的距离

点到直线的距离计算返回空间中任意一点到给定直线的最短距离。这在碰撞检测、光线投射、几何约束等场景中非常重要。直线由直线上的一点和方向向量定义，函数会计算目标点到这条直线的垂直距离。

计算原理是找到直线上距离目标点最近的点，然后计算这两点之间的距离。这个最近点就是目标点在直线上的投影。函数同时返回距离值和投影点的位置，便于进行后续计算。

```python
from mathutils.geometry import distance_point_to_line
from mathutils import Vector

# 定义直线（通过点+方向向量）
line_point = Vector((0.0, 0.0, 0.0))
line_direction = Vector((1.0, 0.0, 0.0))

# 目标点
target_point = Vector((5.0, 3.0, 0.0))

# 计算点到直线的距离
distance, closest_point = distance_point_to_line(target_point, line_point, line_direction)

print(f"目标点: {target_point}")
print(f"直线上的最近点: {closest_point}")
print(f"点到直线的距离: {distance:.4f}")

# 验证：最近点到目标点的向量应该与直线方向垂直
vector_to_target = target_point - closest_point
print(f"垂直验证 (点积应接近0): {line_direction.dot(vector_to_target):.6f}")

# 三维空间中的点到直线距离
line_point_3d = Vector((0.0, 0.0, 0.0))
line_direction_3d = Vector((1.0, 1.0, 1.0)).normalized()
target_3d = Vector((3.0, 0.0, 0.0))

distance_3d, closest_3d = distance_point_to_line(target_3d, line_point_3d, line_direction_3d)
print(f"\n三维示例:")
print(f"  距离: {distance_3d:.4f}")
print(f"  最近点: {closest_3d}")
```

### 点到平面的距离

点到平面的距离计算返回空间中任意一点到给定平面的最短距离。平面由平面上的一点和法线向量定义。这个函数在平面检测、切割操作、投影计算等场景中非常有用。距离的符号表示点在平面的哪一侧，正值表示法线方向一侧，负值表示相反方向。

```python
from mathutils.geometry import distance_point_to_plane
from mathutils import Vector

# 定义平面（通过点+法线向量）
plane_point = Vector((0.0, 0.0, 0.0))
plane_normal = Vector((0.0, 0.0, 1.0))

# 目标点
target_point = Vector((2.0, 3.0, 5.0))

# 计算点到平面的距离
distance = distance_point_to_plane(target_point, plane_point, plane_normal)

print(f"平面法线: {plane_normal}")
print(f"目标点: {target_point}")
print(f"点到平面的距离: {distance:.4f}")
print(f"点是否在平面上方: {distance > 0}")

# 任意方向的平面
plane_point_2 = Vector((1.0, 1.0, 1.0))
plane_normal_2 = Vector((1.0, 1.0, 1.0)).normalized()
target_point_2 = Vector((3.0, 3.0, 3.0))

distance_2 = distance_point_to_plane(target_point_2, plane_point_2, plane_normal_2)
print(f"\n任意平面示例:")
print(f"  距离: {distance_2:.4f}")

# 分类空间中的点
points_to_classify = [
    Vector((0, 0, 2)),
    Vector((0, 0, -1)),
    Vector((1, 1, 0))
]

print("\n点分类:")
for point in points_to_classify:
    dist = distance_point_to_plane(point, plane_point, plane_normal)
    side = "上方" if dist > 0 else ("下方" if dist < 0 else "平面上")
    print(f"  {point}: {side} (距离: {dist:.4f})")
```

### 球体之间的距离

两个球体之间的距离计算用于判断球体是否相交以及相交的程度。这个函数接收两个球心位置和半径作为输入，返回球心之间的距离。通过比较距离和半径之和，可以判断球体是否相交、分离或包含。

```python
from mathutils.geometry import intersect_sphere_sphere
from mathutils import Vector

# 定义两个球体
sphere1_center = Vector((0.0, 0.0, 0.0))
sphere1_radius = 1.0

sphere2_center = Vector((2.5, 0.0, 0.0))
sphere2_radius = 1.0

# 计算球体相交情况
intersection = intersect_sphere_sphere(sphere1_center, sphere1_radius,
                                        sphere2_center, sphere2_radius)

print(f"球体1: 中心 {sphere1_center}, 半径 {sphere1_radius}")
print(f"球体2: 中心 {sphere2_center}, 半径 {sphere2_radius}")
print(f"相交结果: {intersection}")

# 判断球体关系
center_distance = (sphere2_center - sphere1_center).length
combined_radius = sphere1_radius + sphere2_radius

if center_distance > combined_radius:
    print("球体分离")
elif center_distance < abs(sphere1_radius - sphere2_radius):
    print("一个球体包含另一个")
else:
    print("球体相交")

# 批量检测球体碰撞
spheres = [
    {"center": Vector((0, 0, 0)), "radius": 1.0},
    {"center": Vector((1.5, 0, 0)), "radius": 0.8},
    {"center": Vector((5, 0, 0)), "radius": 1.0},
    {"center": Vector((0, 2, 0)), "radius": 0.5}
]

print("\n球体碰撞检测:")
for i, s1 in enumerate(spheres):
    for j, s2 in enumerate(spheres):
        if i < j:
            result = intersect_sphere_sphere(s1["center"], s1["radius"],
                                              s2["center"], s2["radius"])
            collision = "相交" if result else "分离"
            print(f"  球{i} 和 球{j}: {collision}")
```

## 射线检测函数

### 射线与平面的交点

射线与平面的交点计算是光线追踪和拾取操作的基础。射线由起点和方向定义，平面由点和法线定义。函数返回交点的位置，如果没有交点则返回 None。这个函数在实现鼠标拾取、视线检测、阴影计算等方面非常有用。

```python
from mathutils.geometry import intersect_ray_plane
from mathutils import Vector

# 定义射线
ray_origin = Vector((0.0, 0.0, 0.0))
ray_direction = Vector((0.0, 0.0, 1.0)).normalized()

# 定义平面
plane_origin = Vector((0.0, 0.0, 5.0))
plane_normal = Vector((0.0, 0.0, 1.0))

# 计算交点
intersection = intersect_ray_plane(ray_origin, ray_direction, plane_origin, plane_normal)

print(f"射线起点: {ray_origin}")
print(f"射线方向: {ray_direction}")
print(f"平面位置: {plane_origin}")
print(f"平面法线: {plane_normal}")

if intersection:
    print(f"交点: {intersection}")
else:
    print("射线与平面无交点")

# 射线与多个平面的交点
planes = [
    {"origin": Vector((0, 0, 2)), "normal": Vector((0, 0, 1))},
    {"origin": Vector((0, 0, 5)), "normal": Vector((0, 0, 1))},
    {"origin": Vector((0, 0, 10)), "normal": Vector((0, 0, 1))}
]

print("\n射线与多个平面的交点:")
for i, plane in enumerate(planes):
    point = intersect_ray_plane(ray_origin, ray_direction,
                                plane["origin"], plane["normal"])
    if point:
        print(f"  平面{i}: {point}")
```

### 射线与球体的交点

射线与球体的交点计算用于检测光线是否与球体相交，并返回交点信息。函数返回一个包含所有交点的列表，如果没有交点则返回空列表。这个功能在实现球体光照、高光、碰撞检测等方面非常有用。

```python
from mathutils.geometry import intersect_ray_sphere
from mathutils import Vector

# 定义射线
ray_origin = Vector((0.0, 0.0, -5.0))
ray_direction = Vector((0.0, 0.0, 1.0)).normalized()

# 定义球体
sphere_center = Vector((0.0, 0.0, 0.0))
sphere_radius = 2.0

# 计算交点
intersections = intersect_ray_sphere(ray_origin, ray_direction,
                                     sphere_center, sphere_radius)

print(f"射线起点: {ray_origin}")
print(f"射线方向: {ray_direction}")
print(f"球心: {sphere_center}, 半径: {sphere_radius}")
print(f"交点数量: {len(intersections)}")

for i, point in enumerate(intersections):
    print(f"  交点{i}: {point}")

    # 计算从射线起点到交点的距离
    distance = (point - ray_origin).length
    print(f"    距离: {distance:.4f}")

# 视线检测示例
def check_visibility(from_point, to_point, obstacles):
    """检查两点之间是否有障碍物"""
    direction = (to_point - from_point).normalized()
    distance = (to_point - from_point).length

    for obstacle in obstacles:
        hits = intersect_ray_sphere(from_point, direction,
                                    obstacle["center"], obstacle["radius"])
        if hits:
            for hit in hits:
                hit_distance = (hit - from_point).length
                if hit_distance < distance:
                    return False, hit
    return True, None

# 使用示例
obstacles = [
    {"center": Vector((0, 0, 2)), "radius": 1.0},
    {"center": Vector((3, 0, 5)), "radius": 0.5}
]
visible, hit_point = check_visibility(Vector((0, 0, 0)), Vector((5, 0, 10)), obstacles)
print(f"\n可见性检测: {'可见' if visible else f'被阻挡，阻挡点: {hit_point}'}")
```

### 射线与三角形的交点

射线与三角形的交点计算是实现精确几何拾取的基础。三角形由三个顶点定义，函数检测射线是否与三角形相交，并返回交点信息。这个功能在实现网格拾取、光线追踪、碰撞检测等方面非常重要。

```python
from mathutils.geometry import intersect_ray_triangle
from mathutils import Vector

# 定义射线
ray_origin = Vector((0.0, 0.0, -3.0))
ray_direction = Vector((0.0, 0.0, 1.0)).normalized()

# 定义三角形
triangle = [
    Vector((-1.0, -1.0, 0.0)),
    Vector((1.0, -1.0, 0.0)),
    Vector((0.0, 1.0, 0.0))
]

# 计算交点
intersection = intersect_ray_triangle(ray_origin, ray_direction, triangle)

print(f"射线起点: {ray_origin}")
print(f"射线方向: {ray_direction}")
print(f"三角形顶点: {triangle}")

if intersection:
    print(f"交点: {intersection}")

    # 计算重心坐标
    barycentric = calculate_barycentric(intersection, triangle)
    print(f"重心坐标: {barycentric}")
else:
    print("射线与三角形无交点")

# 批量检测射线与多个三角形的交点
def ray_mesh_intersection(ray_origin, ray_direction, mesh):
    """检测射线与网格的交点"""
    closest_hit = None
    min_distance = float('inf')

    for polygon in mesh.polygons:
        triangle = [mesh.vertices[v].co for v in polygon.vertices]
        hit = intersect_ray_triangle(ray_origin, ray_direction, triangle)

        if hit:
            distance = (hit - ray_origin).length
            if distance < min_distance:
                min_distance = distance
                closest_hit = hit

    return closest_hit, min_distance

def calculate_barycentric(point, triangle):
    """计算重心坐标"""
    v0, v1, v2 = [Vector(v) for v in triangle]
    p = Vector(point)

    v0v1 = v1 - v0
    v0v2 = v2 - v0
    v0p = p - v0

    d00 = v0v1.dot(v0v1)
    d01 = v0v1.dot(v0v2)
    d11 = v0v2.dot(v0v2)
    d20 = v0p.dot(v0v1)
    d21 = v0p.dot(v0v2)

    denom = d00 * d11 - d01 * d01
    if abs(denom) < 1e-10:
        return (1.0, 0.0, 0.0)

    v = (d11 * d20 - d01 * d21) / denom
    w = (d00 * d21 - d01 * d20) / denom
    u = 1.0 - v - w

    return (u, v, w)
```

### 直线相交检测

直线与直线、直线与球体的相交检测用于判断几何元素之间的空间关系。这些函数在实现碰撞检测、几何约束、路径规划等方面非常有用。

```python
from mathutils.geometry import (
    intersect_line_line, intersect_line_sphere, intersect_line_plane
)
from mathutils import Vector

# 直线与直线的交点
line1_a = Vector((0.0, 0.0, 0.0))
line1_b = Vector((1.0, 0.0, 0.0))

line2_a = Vector((0.5, -1.0, 0.0))
line2_b = Vector((0.5, 1.0, 0.0))

intersection = intersect_line_line(line1_a, line1_b, line2_a, line2_b)

print("直线与直线的交点:")
print(f"  直线1: {line1_a} -> {line1_b}")
print(f"  直线2: {line2_a} -> {line2_b}")

if intersection:
    print(f"  交点: {intersection}")
else:
    print("  直线平行或不相交")

# 直线与球体的交点
line_a = Vector((-3.0, 0.0, 0.0))
line_b = Vector((3.0, 0.0, 0.0))
sphere_center = Vector((0.0, 0.0, 0.0))
sphere_radius = 1.0

intersections = intersect_line_sphere(line_a, line_b, sphere_center, sphere_radius)

print(f"\n直线与球体的交点:")
print(f"  直线: {line_a} -> {line_b}")
print(f"  球心: {sphere_center}, 半径: {sphere_radius}")
print(f"  交点数量: {len(intersections)}")

for i, point in enumerate(intersections):
    print(f"  交点{i}: {point}")

# 直线与平面的交点
plane_point = Vector((0.0, 0.0, 0.0))
plane_normal = Vector((0.0, 1.0, 0.0))

intersection_plane = intersect_line_plane(line_a, line_b, plane_point, plane_normal)

print(f"\n直线与平面的交点:")
print(f"  交点: {intersection_plane}")
```

## 插值函数

### 贝塞尔曲线插值

贝塞尔曲线插值函数用于在控制点之间生成平滑的曲线。这个函数接收多个控制点和一个插值因子（0到1之间），返回曲线上对应位置的点。三次贝塞尔曲线使用四个控制点，通过调整这些点的位置可以控制曲线的形状。

```python
from mathutils.geometry import interpolate_bezier
from mathutils import Vector

# 三次贝塞尔曲线控制点
knots = [
    Vector((0.0, 0.0, 0.0)),
    Vector((1.0, 3.0, 0.0)),
    Vector((3.0, 3.0, 0.0)),
    Vector((4.0, 0.0, 0.0))
]

# 生成曲线路径
resolution = 20
path_points = []

for i in range(resolution + 1):
    t = i / resolution
    point = interpolate_bezier(knots[0], knots[1], knots[2], knots[3], t)
    path_points.append(point)

print("贝塞尔曲线路径点:")
for i, point in enumerate(path_points):
    print(f"  t={i/resolution:.2f}: {point}")

# 可视化控制点和曲线
print(f"\n控制点:")
for i, knot in enumerate(knots):
    print(f"  P{i}: {knot}")

# 插值点与切线计算
def bezier_tangent(knots, t):
    """计算贝塞尔曲线的切线方向"""
    from mathutils.geometry import interpolate_bezier

    # 使用接近的点来近似切线
    delta = 0.001
    p1 = interpolate_bezier(knots[0], knots[1], knots[2], knots[3], t - delta)
    p2 = interpolate_bezier(knots[0], knots[1], knots[2], knots[3], t + delta)

    return (p2 - p1).normalized()

print("\n曲线切线方向:")
for i in range(0, resolution + 1, 5):
    t = i / resolution
    point = interpolate_bezier(knots[0], knots[1], knots[2], knots[3], t)
    tangent = bezier_tangent(knots, t)
    print(f"  t={t:.2f}: 位置={point}, 切线={tangent}")
```

### NURBS 曲线插值

NURBS 曲线插值函数用于生成更复杂的自由曲线。这种插值方法支持更多的控制点，可以创建更复杂的曲线形状。函数使用三阶样条插值，通过给定的控制点序列生成平滑曲线。

```python
from mathutils.geometry import interpolate_nurbs
from mathutils import Vector

# NURBS 控制点
control_points = [
    Vector((0.0, 0.0, 0.0)),
    Vector((1.0, 2.0, 0.0)),
    Vector((2.0, 1.0, 0.0)),
    Vector((3.0, 3.0, 0.0)),
    Vector((4.0, 0.0, 0.0)),
    Vector((5.0, 2.0, 0.0))
]

# 生成 NURBS 曲线路径
resolution = 50
nurbs_path = []

for i in range(resolution + 1):
    t = i / resolution
    point = interpolate_nurbs(control_points, t)
    nurbs_path.append(point)

print("NURBS 曲线路径点:")
print(f"  共 {len(nurbs_path)} 个点")
print(f"  起点: {nurbs_path[0]}")
print(f"  终点: {nurbs_path[-1]}")

# 线性插值与 NURBS 插值对比
def linear_interpolate(points, t):
    """线性插值"""
    i = t * (len(points) - 1)
    i0 = int(i)
    i1 = min(i0 + 1, len(points) - 1)
    local_t = i - i0
    return points[i0].lerp(points[i1], local_t)

print("\n线性插值 vs NURBS 插值对比:")
for i in [0, int(resolution/4), int(resolution/2), int(resolution*3/4), resolution]:
    t = i / resolution
    linear = linear_interpolate(control_points, t)
    nurbs_point = nurbs_path[i]
    print(f"  t={t:.2f}: 线性={linear}, NURBS={nurbs_point}")
```

## 几何属性计算

### 三角形面积

三角形面积计算函数用于确定三角形的表面积。这个函数在网格分析、碰撞体积计算、资源优化等方面非常有用。函数接收三个顶点作为输入，返回三角形的面积值。

```python
from mathutils.geometry import area_triangle
from mathutils import Vector

# 定义三角形顶点
vertex_a = Vector((0.0, 0.0, 0.0))
vertex_b = Vector((1.0, 0.0, 0.0))
vertex_c = Vector((0.0, 1.0, 0.0))

# 计算面积
area = area_triangle(vertex_a, vertex_b, vertex_c)

print(f"三角形顶点: A={vertex_a}, B={vertex_b}, C={vertex_c}")
print(f"三角形面积: {area:.4f}")

# 验证：直角三角形的面积应该是两直角边的乘积除以2
expected_area = 0.5 * 1.0 * 1.0
print(f"验证结果: {expected_area:.4f}")

# 计算网格的总表面积
def calculate_mesh_area(mesh):
    """计算网格的总表面积"""
    total_area = 0.0

    for polygon in mesh.polygons:
        vertices = [mesh.vertices[v].co for v in polygon.vertices]
        if len(vertices) == 3:
            area = area_triangle(vertices[0], vertices[1], vertices[2])
        elif len(vertices) == 4:
            area1 = area_triangle(vertices[0], vertices[1], vertices[2])
            area2 = area_triangle(vertices[0], vertices[2], vertices[3])
            area = area1 + area2
        else:
            # 对于多边形，使用三角形分割法
            area = 0.0
            for i in range(1, len(vertices) - 1):
                area += area_triangle(vertices[0], vertices[i], vertices[i + 1])

        total_area += area

    return total_area

# 使用示例
if bpy.context.active_object and bpy.context.active_object.type == 'MESH':
    mesh = bpy.context.active_object.data
    total_area = calculate_mesh_area(mesh)
    print(f"\n网格 '{mesh.name}' 的总表面积: {total_area:.4f}")
```

### 面法线计算

面法线计算函数用于确定面的垂直方向。这个函数在光照计算、碰撞检测、法线贴图生成等方面非常重要。函数接收三个顶点作为输入，返回面的单位法向量。

```python
from mathutils.geometry import normal
from mathutils import Vector

# 定义三角形顶点
vertex_a = Vector((0.0, 0.0, 0.0))
vertex_b = Vector((1.0, 0.0, 0.0))
vertex_c = Vector((0.0, 1.0, 0.0))

# 计算法线
face_normal = normal(vertex_a, vertex_b, vertex_c)

print(f"三角形顶点: A={vertex_a}, B={vertex_b}, C={vertex_c}")
print(f"面法线: {face_normal}")
print(f"法线长度: {face_normal.length:.4f}")

# 验证：结果应该是 Z 轴正方向
print(f"期望方向: (0, 0, 1)")

# 计算网格的法线
def calculate_mesh_normals(mesh):
    """计算网格的所有面法线"""
    normals = []

    for polygon in mesh.polygons:
        vertices = [mesh.vertices[v].co for v in polygon.vertices]
        if len(vertices) >= 3:
            poly_normal = normal(vertices[0], vertices[1], vertices[2])
            normals.append({
                'polygon_index': polygon.index,
                'normal': poly_normal,
                'area': polygon.area
            })

    return normals

# 使用示例
if bpy.context.active_object and bpy.context.active_object.type == 'MESH':
    mesh = bpy.context.active_object.data
    normals = calculate_mesh_normals(mesh)

    print(f"\n网格 '{mesh.name}' 的面法线:")
    for n in normals[:5]:  # 只显示前5个
        print(f"  面{n['polygon_index']}: 法线={n['normal']}, 面积={n['area']:.4f}")

    # 检查法线一致性
    avg_normal = sum((n['normal'] * n['area'] for n in normals), Vector((0, 0, 0)))
    avg_normal = avg_normal.normalized()
    print(f"\n面积加权平均法线: {avg_normal}")
```

## 实践示例

### 网格碰撞检测器

这个示例展示了如何使用几何计算函数实现简单的碰撞检测系统。

```python
from mathutils.geometry import (
    distance_point_to_point, intersect_sphere_sphere, intersect_ray_sphere
)
from mathutils import Vector

class CollisionDetector:
    def __init__(self):
        self.colliders = []

    def add_collider(self, center, radius, name="Collider"):
        """添加碰撞体"""
        self.colliders.append({
            "center": Vector(center),
            "radius": radius,
            "name": name
        })

    def check_collision(self, point, radius=0.0):
        """检查点是否与任何碰撞体碰撞"""
        for collider in self.colliders:
            center = collider["center"]
            collider_radius = collider["radius"]

            if radius > 0:
                # 点+半径 vs 球体
                distance = distance_point_to_point(point, center)
                if distance < radius + collider_radius:
                    return True, collider
            else:
                # 点 vs 球体
                if distance_point_to_point(point, center) < collider_radius:
                    return True, collider

        return False, None

    def check_sphere_collision(self, sphere_center, sphere_radius):
        """检查两个球体是否碰撞"""
        for i, collider1 in enumerate(self.colliders):
            for collider2 in self.colliders[i + 1:]:
                collision = intersect_sphere_sphere(
                    collider1["center"], collider1["radius"],
                    collider2["center"], collider2["radius"]
                )
                if collision:
                    return True, (collider1, collider2)
        return False, None

    def ray_cast(self, ray_origin, ray_direction, max_distance=float('inf')):
        """射线投射检测"""
        direction = Vector(ray_direction).normalized()

        for collider in self.colliders:
            hits = intersect_ray_sphere(ray_origin, direction,
                                        collider["center"], collider["radius"])
            for hit in hits:
                distance = (hit - ray_origin).length
                if distance <= max_distance:
                    return hit, collider, distance

        return None, None, None

# 使用示例
detector = CollisionDetector()
detector.add_collider(Vector((0, 0, 0)), 1.0, "球体1")
detector.add_collider(Vector((2, 0, 0)), 0.8, "球体2")
detector.add_collider(Vector((0, 3, 0)), 1.2, "球体3")

# 测试点碰撞
test_point = Vector((0.5, 0.5, 0.5))
collision, hit_collider = detector.check_collision(test_point)
print(f"点 {test_point} 碰撞检测: {'碰撞' if collision else '无碰撞'}")

# 射线投射
ray_origin = Vector((-2, 0, 0))
ray_direction = Vector((1, 0, 0))
hit, collider, distance = detector.ray_cast(ray_origin, ray_direction)
if hit:
    print(f"射线击中: {collider['name']}, 距离: {distance:.4f}")
```

### 几何测量工具

这个示例展示了如何使用几何计算函数创建一个实用的几何测量工具。

```python
from mathutils.geometry import (
    distance_point_to_point, distance_point_to_line, distance_point_to_plane,
    area_triangle, normal
)
from mathutils import Vector

class GeometryMeasurer:
    def __init__(self):
        self.unit = "米"

    def set_unit(self, unit_name):
        """设置测量单位"""
        self.unit = unit_name

    def measure_distance(self, point1, point2):
        """测量两点之间的距离"""
        distance = distance_point_to_point(Vector(point1), Vector(point2))
        return {"type": "点对距离", "value": distance, "unit": self.unit}

    def measure_point_to_line(self, point, line_point, line_direction):
        """测量点到直线的距离"""
        distance, closest = distance_point_to_line(
            Vector(point), Vector(line_point), Vector(line_direction)
        )
        return {
            "type": "点到直线距离",
            "value": distance,
            "closest_point": closest,
            "unit": self.unit
        }

    def measure_point_to_plane(self, point, plane_point, plane_normal):
        """测量点到平面的距离"""
        distance = distance_point_to_plane(
            Vector(point), Vector(plane_point), Vector(plane_normal)
        )
        return {
            "type": "点到平面距离",
            "value": distance,
            "unit": self.unit
        }

    def measure_triangle_area(self, vertex1, vertex2, vertex3):
        """测量三角形面积"""
        area = area_triangle(
            Vector(vertex1), Vector(vertex2), Vector(vertex3)
        )
        return {"type": "三角形面积", "value": area, "unit": self.unit + "²"}

    def measure_face_normal(self, vertex1, vertex2, vertex3):
        """测量面法线"""
        normal_vec = normal(
            Vector(vertex1), Vector(vertex2), Vector(vertex3)
        )
        return {"type": "面法线", "value": normal_vec}

    def generate_report(self, measurements):
        """生成测量报告"""
        report = []
        report.append("=" * 40)
        report.append("几何测量报告")
        report.append("=" * 40)
        report.append(f"测量单位: {self.unit}")
        report.append("-" * 40)

        for i, measurement in enumerate(measurements, 1):
            report.append(f"\n测量 {i}:")
            for key, value in measurement.items():
                if isinstance(value, float):
                    report.append(f"  {key}: {value:.4f}")
                else:
                    report.append(f"  {key}: {value}")

        return "\n".join(report)

# 使用示例
measurer = GeometryMeasurer()
measurer.set_unit("米")

measurements = [
    measurer.measure_distance((0, 0, 0), (3, 4, 0)),
    measurer.measure_point_to_line(
        (5, 3, 0),
        (0, 0, 0),
        (1, 0, 0)
    ),
    measurer.measure_triangle_area(
        (0, 0, 0),
        (1, 0, 0),
        (0, 1, 0)
    ),
    measurer.measure_face_normal(
        (0, 0, 0),
        (1, 0, 0),
        (0, 1, 0)
    )
]

report = measurer.generate_report(measurements)
print(report)
```

## 注意事项

### 数值精度

几何计算函数返回的浮点数值可能存在精度误差。在进行等值比较时，应该使用容差范围而不是精确相等判断。例如，判断两个距离是否相等时，可以使用 `abs(distance1 - distance2) < 1e-6`。

### 向量标准化

许多几何计算函数假设输入向量已经标准化，特别是方向向量。使用未标准化的方向向量可能导致计算结果不正确。如果不确定向量是否标准化，应该先调用 `.normalized()` 方法。

### 退化情况处理

某些几何配置可能导致退化情况，如零长度向量、共线点、重合顶点等。这些情况可能导致除零错误或无意义的结果。在进行几何计算之前，应该检查输入数据的有效性。