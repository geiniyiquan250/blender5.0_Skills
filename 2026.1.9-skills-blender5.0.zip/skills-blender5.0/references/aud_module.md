# aud 音频系统模块

aud（发音为 outer space）是一个高级音频库，基于 Audaspace 构建，提供了 Blender 的音频处理功能。

```python
import aud
```

## 基础音频播放

```python
import aud

# 创建设备
device = aud.Device()

# 加载音频文件（可以是带有音频的视频文件）
sound = aud.Sound('music.ogg')

# 播放音频，返回控制句柄
handle = device.play(sound)

# 如果音频不大且经常使用，可以缓冲它
sound_buffered = aud.Sound.cache(sound)
handle_buffered = device.play(sound_buffered)

# 停止播放
handle.stop()
handle_buffered.stop()
```

## aud.Device 类

Device 类代表音频播放设备，用于管理音频输出。

### 方法

#### play(sound, keep=False)

播放声音。

参数：
- `sound` (Sound)：要播放的声音
- `keep` (bool)：是否在播放结束后保持暂停状态

返回：
- `Handle`：播放控制句柄

```python
import aud

device = aud.Device()
sound = aud.Sound('//music.ogg')
handle = device.play(sound, keep=True)
```

#### lock()

锁定设备，阻止从流中读取数据，直到调用 unlock()。

```python
device.lock()
# 进行一些操作
device.unlock()
```

#### unlock()

解锁设备，与 lock() 配合使用。

#### stopAll()

停止所有正在播放的声音。

```python
device.stopAll()
```

### 属性

#### channels

设备的音频通道数。

类型：int

```python
print(f"音频通道: {device.channels}")
```

#### distance_model

距离衰减模型，影响 3D 音频的空间效果。

类型：int

可选值：
- `aud.DISTANCE_MODEL_INVERSE`：反比衰减
- `aud.DISTANCE_MODEL_INVERSE_CLAMPED`：反比衰减（限制）
- `aud.DISTANCE_MODEL_LINEAR`：线性衰减
- `aud.DISTANCE_MODEL_LINEAR_CLAMPED`：线性衰减（限制）
- `aud.DISTANCE_MODEL_EXPONENT`：指数衰减
- `aud.DISTANCE_MODEL_EXPONENT_CLAMPED`：指数衰减（限制）

```python
device.distance_model = aud.DISTANCE_MODEL_INVERSE
```

#### doppler_factor

多普勒效应因子。

类型：float

```python
device.doppler_factor = 1.0
```

#### format

设备的音频格式。

类型：int

```python
print(f"音频格式: {device.format}")
```

#### listener_location

听众位置，用于 3D 音频。

类型：tuple[float, float, float]

```python
device.listener_location = (0.0, 0.0, 0.0)
```

#### listener_orientation

听众朝向，作为四元数。

类型：tuple[float, float, float, float]

```python
device.listener_orientation = (0.0, 0.0, 1.0, 0.0)  # 面向 Z 轴
```

#### listener_velocity

听众速度。

类型：tuple[float, float, float]

```python
device.listener_velocity = (1.0, 0.0, 0.0)
```

#### rate

采样率。

类型：int

```python
print(f"采样率: {device.rate}")
```

#### speed_of_sound

声速，用于多普勒效应计算。

类型：float

```python
device.speed_of_sound = 343.0  # 米/秒
```

#### volume

设备主音量。

类型：float

```python
device.volume = 0.8
```

## aud.Sound 类

Sound 类代表音频数据，用于加载和管理音频文件。

### 特性

可以通过 `Sound.factory` 访问声音工厂方法进行高级操作。

### 静态方法

#### cache(sound)

缓存声音以提高重复播放性能。

参数：
- `sound` (Sound)：要缓存的声音

返回：
- `Sound`：缓存后的声音

```python
import aud

sound = aud.Sound('//music.ogg')
cached_sound = aud.Sound.cache(sound)
```

## aud.Handle 类

Handle 类是播放控制句柄，用于控制单个声音实例的播放。

### 方法

#### pause()

暂停播放。

返回：
- bool：操作是否成功

```python
handle.pause()
```

#### resume()

恢复播放。

返回：
- bool：操作是否成功

```python
handle.resume()
```

#### stop()

停止播放，使句柄失效。

返回：
- bool：操作是否成功

```python
handle.stop()
```

### 属性

#### attenuation

距离衰减因子，用于 3D 音频。

类型：float

```python
handle.attenuation = 1.0
```

#### cone_angle_inner

音源内部锥体的开合角度。

类型：float

```python
handle.cone_angle_inner = 30.0
```

#### cone_angle_outer

音源外部锥体的开合角度。

类型：float

```python
handle.cone_angle_outer = 45.0
```

#### cone_volume_outer

外部锥体外部的音量。

类型：float

```python
handle.cone_volume_outer = 0.5
```

#### distance_maximum

音源的最大可听距离。

类型：float

```python
handle.distance_maximum = 100.0  # 超出此距离音量为 0
```

#### distance_reference

参考距离，在此距离音量等于 `volume`。

类型：float

```python
handle.distance_reference = 1.0
```

#### keep

播放结束后是否保持暂停状态。

类型：bool

```python
handle.keep = True
```

警告：如果设为 true 且忘记停止，会导致内存泄漏。

#### location

音源在 3D 空间中的位置。

类型：tuple[float, float, float]

```python
handle.location = (5.0, 0.0, 2.0)
```

#### loop_count

剩余循环次数，负值表示无限循环。

类型：int

```python
handle.loop_count = -1  # 无限循环
```

#### orientation

音源朝向，作为四元数。

类型：tuple[float, float, float, float]

```python
handle.orientation = (0.0, 0.0, 1.0, 0.0)
```

#### pitch

音调。

类型：float

```python
handle.pitch = 1.0  # 正常速度
handle.pitch = 0.5  # 半速
handle.pitch = 2.0  # 2倍速
```

#### position

播放位置（秒）。

类型：float

```python
current_time = handle.position
handle.position = 10.0  # 跳转到 10 秒
```

#### relative

音源位置、速度、朝向是否相对于听众。

类型：bool

```python
handle.relative = False  # 绝对坐标
```

#### status

播放状态。

类型：int

```python
if handle.status == aud.STATUS_PLAYING:
    print("正在播放")
```

#### velocity

音源速度，用于多普勒效应。

类型：tuple[float, float, float]

```python
handle.velocity = (1.0, 0.0, 0.0)
```

#### volume

音量。

类型：float

```python
handle.volume = 0.8
```

## aud.DynamicMusic 类

DynamicMusic 类用于管理动态音乐，实现场景间的平滑过渡。

### 方法

#### addScene(scene, sound)

添加新场景。

参数：
- `scene` (int)：场景 ID
- `sound` (Sound)：场景声音

```python
import aud

dmusic = aud.DynamicMusic()
dmusic.addScene(0, aud.Sound('calm.ogg'))
dmusic.addScene(1, aud.Sound('action.ogg'))
```

#### addTransition(ini, end, transition)

添加场景过渡。

参数：
- `ini` (int)：起始场景
- `end` (int)：目标场景
- `transition` (Sound)：过渡声音

返回：
- bool：操作是否成功

```python
dmusic.addTransition(0, 1, aud.Sound('transition.ogg'))
```

#### pause()

暂停场景播放。

返回：
- bool：操作是否成功

#### resume()

恢复场景播放。

返回：
- bool：操作是否成功

#### stop()

停止场景播放。

返回：
- bool：操作是否成功

### 属性

#### fadeTime

交叉淡入淡出的时间（秒）。

类型：float

```python
dmusic.fadeTime = 2.0
```

#### position

当前场景的播放位置（秒）。

类型：float

```python
print(f"当前位置: {dmusic.position}")
```

#### scene

当前场景。

类型：int

```python
dmusic.scene = 1
```

#### status

播放状态。

类型：int

#### volume

场景音量。

类型：float

```python
dmusic.volume = 0.8
```

## aud.HRTF 类

HRTF 类用于头部相关传输函数，实现双耳音效（3D 空间音频）。

### 方法

#### loadLeftHrtfSet(extension, directory)

从目录加载左耳 HRTF 集合。

参数：
- `extension` (str)：HRTF 文件扩展名
- `directory` (str)：HRTF 文件目录路径

返回：
- `HRTF`：加载的 HRTF 对象

```python
hrtf = aud.HRTF()
hrtf.loadLeftHrtfSet('.wav', '//hrtf_left/')
```

#### loadRightHrtfSet(extension, directory)

从目录加载右耳 HRTF 集合。

参数：
- `extension` (str)：HRTF 文件扩展名
- `directory` (str)：HRTF 文件目录路径

返回：
- `HRTF`：加载的 HRTF 对象

```python
hrtf.loadRightHrtfSet('.wav', '//hrtf_right/')
```

#### addImpulseResponseFromSound(sound, azimuth, elevation)

添加脉冲响应。

参数：
- `sound` (Sound)：包含 HRTF 的声音
- `azimuth` (float)：方位角
- `elevation` (float)：仰角

返回：
- bool：操作是否成功

```python
hrtf.addImpulseResponseFromSound(aud.Sound('hrtf_sample.wav'), 0.0, 0.0)
```

## 音频常量

### 通道常量

```python
aud.CHANNELS_INVALID    # 无效
aud.CHANNELS_MONO       # 单声道
aud.CHANNELS_STEREO     # 立体声
aud.CHANNELS_STEREO_LFE # 立体声 + 低频
aud.CHANNELS_SURROUND4  # 4 环绕
aud.CHANNELS_SURROUND5  # 5 环绕
aud.CHANNELS_SURROUND51 # 5.1 环绕
aud.CHANNELS_SURROUND61 # 6.1 环绕
aud.CHANNELS_SURROUND71 # 7.1 环绕
```

### 编码器常量

```python
aud.CODEC_INVALID  # 无效
aud.CODEC_AAC      # AAC
aud.CODEC_AC3      # AC3
aud.CODEC_FLAC     # FLAC
aud.CODEC_MP2      # MP2
aud.CODEC_MP3      # MP3
aud.CODEC_PCM      # PCM
aud.CODEC_VORBIS   # Vorbis
aud.CODEC_OPUS     # Opus
```

### 容器格式常量

```python
aud.CONTAINER_INVALID  # 无效
aud.CONTAINER_AC3      # AC3
aud.CONTAINER_FLAC     # FLAC
aud.CONTAINER_MATROSKA # Matroska
aud.CONTAINER_MP2      # MP2
aud.CONTAINER_MP3      # MP3
aud.CONTAINER_OGG      # OGG
aud.CONTAINER_WAV      # WAV
aud.CONTAINER_AAC      # AAC
```

### 距离模型常量

```python
aud.DISTANCE_MODEL_INVALID            # 无效
aud.DISTANCE_MODEL_INVERSE            # 反比衰减
aud.DISTANCE_MODEL_INVERSE_CLAMPED    # 反比衰减（限制）
aud.DISTANCE_MODEL_LINEAR             # 线性衰减
aud.DISTANCE_MODEL_LINEAR_CLAMPED     # 线性衰减（限制）
aud.DISTANCE_MODEL_EXPONENT           # 指数衰减
aud.DISTANCE_MODEL_EXPONENT_CLAMPED   # 指数衰减（限制）
```

### 音频属性常量

```python
aud.AP_LOCATION       # 位置
aud.AP_ORIENTATION    # 朝向
aud.AP_PANNING        # 声像
aud.AP_PITCH          # 音调
aud.AP_TIME_STRETCH   # 时间拉伸
aud.AP_PITCH_SCALE    # 音调缩放
aud.AP_VOLUME         # 音量
```

## 实际应用示例

### 3D 空间音频

```python
import aud
import math

device = aud.Device()
device.distance_model = aud.DISTANCE_MODEL_INVERSE

# 加载声音并设置 3D 属性
sound = aud.Sound('//footsteps.ogg')
handle = device.play(sound)

# 设置音源位置
handle.location = (5.0, 0.0, 0.0)
handle.distance_reference = 1.0
handle.distance_maximum = 20.0
handle.attenuation = 1.0

# 设置听众位置
device.listener_location = (0.0, 0.0, 0.0)

# 模拟听众移动
for i in range(100):
    x = 5.0 * math.sin(i * 0.1)
    z = 5.0 * math.cos(i * 0.1)
    device.listener_location = (x, 0.0, z)
```

### 游戏背景音乐系统

```python
import aud

class MusicManager:
    def __init__(self):
        self.device = aud.Device()
        self.sounds = {}
        self.current_handle = None
        
    def load_music(self, name, filepath):
        self.sounds[name] = aud.Sound(filepath)
        
    def play(self, name, loop=-1):
        if self.current_handle:
            self.current_handle.stop()
            
        sound = self.sounds.get(name)
        if sound:
            self.current_handle = self.device.play(sound)
            self.current_handle.loop_count = loop
            
    def set_volume(self, volume):
        if self.current_handle:
            self.current_handle.volume = volume
            
    def fade_to(self, name, duration=2.0):
        # 淡出当前音乐
        if self.current_handle:
            import time
            start_volume = self.current_handle.volume
            start_time = time.time()
            
            while time.time() - start_time < duration:
                elapsed = time.time() - start_time
                factor = 1.0 - (elapsed / duration)
                self.current_handle.volume = start_volume * factor
                
            self.current_handle.stop()
            
        # 淡入新音乐
        self.play(name)
        self.current_handle.volume = 0
        import time
        start_time = time.time()
        start_volume = 1.0
        
        while time.time() - start_time < duration:
            elapsed = time.time() - start_time
            factor = elapsed / duration
            self.current_handle.volume = start_volume * factor

# 使用示例
music_mgr = MusicManager()
music_mgr.load_music('menu', '//music/menu.ogg')
music_mgr.load_music('game', '//music/game.ogg')
music_mgr.play('menu')
```

### 声音特效管理器

```python
import aud

class SfxManager:
    def __init__(self):
        self.device = aud.Device()
        self.effects = {}
        
    def load_sfx(self, name, filepath):
        self.effects[name] = aud.Sound(filepath)
        
    def play(self, name, volume=1.0, pitch=1.0):
        sound = self.effects.get(name)
        if sound:
            handle = self.device.play(sound)
            handle.volume = volume
            handle.pitch = pitch
            return handle
        return None
    
    def play_3d(self, name, position, listener_pos=(0, 0, 0)):
        sound = self.effects.get(name)
        if sound:
            handle = self.device.play(sound)
            handle.location = position
            handle.distance_reference = 1.0
            handle.distance_maximum = 50.0
            handle.relative = False
            return handle
        return None

# 使用示例
sfx = SfxManager()
sfx.load_sfx('jump', '//sfx/jump.ogg')
sfx.load_sfx('explosion', '//sfx/explosion.ogg')

# 播放普通音效
sfx.play('jump', volume=0.8, pitch=1.2)

# 播放 3D 音效
sfx.play_3d('explosion', position=(10, 0, 5))
```
