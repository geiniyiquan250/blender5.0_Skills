# bpy.utils.units - Units Utility Module

Blender 单位系统工具，用于单位管理和转换。

## Overview

`bpy.utils.units` 模块提供了 Blender 单位系统的工具函数，包括单位格式化和解析功能。这个模块主要用于处理测量单位的显示和转换。

## 关键概念

### 单位系统
- 公制系统（Metric）
- 英制系统（Imperial）
- Blender 内部使用弧度和米作为基础单位

### 单位类型
- 长度单位（米、厘米、英尺、英寸等）
- 角度单位（度、弧度）
- 时间单位（秒、帧）
- 质量单位（千克、磅等）

## 主要功能

### 单位格式化

```python
import bpy
from bpy.utils import units

# 格式化长度为字符串
def format_length(value, unit_system='METRIC', precision=3):
    """格式化长度值"""
    formatted = units.length(value, unit_system, precision)
    return formatted

# 格式化角度为字符串
def format_angle(value, unit_system='METRIC', precision=2):
    """格式化角度值"""
    formatted = units.angle(value, unit_system, precision)
    return formatted

# 格式化时间为字符串
def format_time(value, unit_system='METRIC', precision=2):
    """格式化时间值"""
    formatted = units.time(value, unit_system, precision)
    return formatted

# 使用示例
length_meters = 2.5  # 米
length_str = units.length(length_meters)
print(f"长度: {length_str}")

angle_degrees = 45.0  # 度
angle_str = units.angle(angle_degrees)
print(f"角度: {angle_str}")
```

### 单位系统切换

```python
import bpy

class UnitSystemManager:
    """单位系统管理器"""
    
    UNIT_SYSTEMS = {
        'METRIC': '公制',
        'IMPERIAL': '英制',
    }
    
    def __init__(self):
        self.current_system = self.get_system()
    
    def get_system(self):
        """获取当前单位系统"""
        return bpy.context.scene.unit_settings.system
    
    def set_system(self, system):
        """设置单位系统"""
        valid_systems = ['METRIC', 'IMPERIAL']
        if system in valid_systems:
            bpy.context.scene.unit_settings.system = system
            self.current_system = system
            print(f"单位系统已设置为: {system}")
        else:
            print(f"无效的单位系统: {system}")
    
    def get_system_display_name(self, system):
        """获取单位系统显示名称"""
        return self.UNIT_SYSTEMS.get(system, system)
    
    def format_value(self, value, unit_type='LENGTH'):
        """根据当前设置格式化值"""
        system = self.get_system()
        
        if unit_type == 'LENGTH':
            return units.length(value, system)
        elif unit_type == 'ANGLE':
            return units.angle(value, system)
        elif unit_type == 'TIME':
            return units.time(value, system)
        else:
            return str(value)

# 使用示例
manager = UnitSystemManager()
manager.set_system('METRIC')
print(f"当前单位系统: {manager.get_system_display_name(manager.current_system)}")

# 格式化各种值
length = 1.5
print(f"长度 {length}m = {manager.format_value(length, 'LENGTH')}")
```

### 自定义单位格式化

```python
import bpy
from bpy.utils import units

class CustomUnitFormatter:
    """自定义单位格式化器"""
    
    def __init__(self):
        self.unit_settings = bpy.context.scene.unit_settings
    
    def format_distance(self, distance, precision=3):
        """格式化距离值"""
        system = self.unit_settings.system
        use_separate = self.unit_settings.use_separate
        
        return units.length(distance, system, precision, use_separate)
    
    def format_rotation(self, angle, precision=2):
        """格式化旋转值"""
        system = self.unit_settings.system
        use_separate = self.unit_settings.use_separate
        
        return units.angle(angle, system, precision, use_separate)
    
    def format_scale(self, scale, precision=3):
        """格式化缩放值"""
        return f"{scale:.{precision}f}"
    
    def format_percentage(self, value, precision=1):
        """格式化百分比"""
        return f"{value * 100:.{precision}f}%"
    
    def format_file_size(self, bytes_size, precision=2):
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if abs(bytes_size) < 1024.0:
                return f"{bytes_size:.{precision}f} {unit}"
            bytes_size /= 1024.0
        return f"{bytes_size:.{precision}f} PB"
    
    def format_duration(self, seconds, precision=2):
        """格式化持续时间"""
        if seconds < 60:
            return f"{seconds:.{precision}f} 秒"
        elif seconds < 3600:
            minutes = seconds // 60
            secs = seconds % 60
            return f"{int(minutes)} 分 {secs:.{precision}f} 秒"
        else:
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            return f"{int(hours)} 小时 {int(minutes)} 分"

# 使用示例
formatter = CustomUnitFormatter()
distance = 2.3456
print(f"距离: {formatter.format_distance(distance)}")

rotation = 45.678
print(f"旋转: {formatter.format_rotation(rotation)}")

file_size = 1024 * 1024 * 2.5
print(f"文件大小: {formatter.format_file_size(file_size)}")

duration = 3661.5
print(f"持续时间: {formatter.format_duration(duration)}")
```

### 单位转换工具

```python
import bpy
from bpy.utils import units

class UnitConverter:
    """单位转换器"""
    
    # 转换表（以米为基础）
    LENGTH_CONVERSIONS = {
        'm': 1.0,
        'cm': 0.01,
        'mm': 0.001,
        'km': 1000.0,
        'in': 0.0254,
        'ft': 0.3048,
        'yd': 0.9144,
        'mi': 1609.344,
    }
    
    def __init__(self):
        self.unit_settings = bpy.context.scene.unit_settings
    
    def meters_to_unit(self, value, target_unit):
        """米转换为目标单位"""
        if target_unit in self.LENGTH_CONVERSIONS:
            return value / self.LENGTH_CONVERSIONS[target_unit]
        return value
    
    def unit_to_meters(self, value, source_unit):
        """源单位转换为米"""
        if source_unit in self.LENGTH_CONVERSIONS:
            return value * self.LENGTH_CONVERSIONS[source_unit]
        return value
    
    def convert_length(self, value, from_unit, to_unit):
        """长度单位转换"""
        # 先转换为米
        meters = self.unit_to_meters(value, from_unit)
        # 再转换为目标单位
        return self.meters_to_unit(meters, to_unit)
    
    def format_in_unit(self, value, unit):
        """格式化指定单位的值"""
        converted = self.meters_to_unit(value, unit)
        return f"{converted:.4g} {unit}"
    
    def format_all_units(self, value):
        """以所有单位显示值"""
        results = {}
        for unit, factor in self.LENGTH_CONVERSIONS.items():
            converted = value / factor
            results[unit] = f"{converted:.4g}"
        return results

# 使用示例
converter = UnitConverter()

# 转换示例
print(f"1米 = {converter.format_in_unit(1.0, 'cm')}")
print(f"1米 = {converter.format_in_unit(1.0, 'in')}")
print(f"1米 = {converter.format_in_unit(1.0, 'ft')}")

# 显示所有单位
print("\n1米在不同单位中的值:")
all_units = converter.format_all_units(1.0)
for unit, value in all_units.items():
    print(f"  {unit}: {value}")
```

### 批量处理测量值

```python
import bpy
from bpy.utils import units

class MeasurementProcessor:
    """测量值批量处理器"""
    
    def __init__(self):
        self.unit_settings = bpy.context.scene.unit_settings
    
    def process_object_dimensions(self, obj):
        """处理对象尺寸"""
        if obj.type != 'MESH':
            return None
        
        # 获取边界框尺寸
        dimensions = obj.dimensions
        system = self.unit_settings.system
        
        return {
            'x': units.length(dimensions.x, system),
            'y': units.length(dimensions.y, system),
            'z': units.length(dimensions.z, system),
            'volume': self._calculate_volume(obj),
        }
    
    def _calculate_volume(self, obj):
        """计算体积（近似）"""
        try:
            import bmesh
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            volume = bm.calc_volume()
            bm.free()
            return units.length(volume ** (1/3), self.unit_settings.system)
        except:
            return "N/A"
    
    def process_vertex_positions(self, obj, apply_transforms=True):
        """处理顶点位置"""
        if obj.type != 'MESH':
            return []
        
        # 获取网格数据
        if apply_transforms:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            eval_obj = obj.evaluated_get(depsgraph)
            mesh = eval_obj.to_mesh()
        else:
            mesh = obj.data
        
        system = self.unit_settings.system
        positions = []
        
        for v in mesh.vertices:
            pos = {
                'index': v.index,
                'x': units.length(v.co.x, system),
                'y': units.length(v.co.y, system),
                'z': units.length(v.co.z, system),
            }
            positions.append(pos)
        
        if apply_transforms:
            eval_obj.to_mesh_clear()
        
        return positions
    
    def format_all_measurements(self, obj):
        """格式化对象所有测量值"""
        info = {
            'name': obj.name,
            'type': obj.type,
            'location': self._format_vector(obj.location),
            'dimensions': self.process_object_dimensions(obj),
            'rotation_euler': self._format_rotation(obj.rotation_euler),
            'scale': self._format_scale(obj.scale),
        }
        return info
    
    def _format_vector(self, vector):
        """格式化向量"""
        system = self.unit_settings.system
        return [units.length(v, system) for v in vector]
    
    def _format_rotation(self, euler):
        """格式化旋转"""
        return [units.angle(a) for a in euler]
    
    def _format_scale(self, scale):
        """格式化缩放"""
        return [f"{s:.4f}" for s in scale]

# 使用示例
def analyze_selected_objects():
    """分析选中的对象"""
    processor = MeasurementProcessor()
    
    selected = bpy.context.selected_objects
    results = []
    
    for obj in selected:
        info = processor.format_all_measurements(obj)
        results.append(info)
        
        print(f"\n对象: {info['name']}")
        print(f"  类型: {info['type']}")
        print(f"  位置: {info['location']}")
        print(f"  尺寸: {info['dimensions']}")
        print(f"  旋转: {info['rotation_euler']}")
        print(f"  缩放: {info['scale']}")
    
    return results
```

### UI 显示格式化

```python
import bpy
from bpy.utils import units

class UIDisplayFormatter:
    """UI 显示格式化器"""
    
    def __init__(self):
        self.unit_settings = bpy.context.scene.unit_settings
    
    def create_info_string(self, label, value, unit_type='LENGTH'):
        """创建信息字符串"""
        if unit_type == 'LENGTH':
            formatted = units.length(value, self.unit_settings.system)
        elif unit_type == 'ANGLE':
            formatted = units.angle(value, self.unit_settings.system)
        else:
            formatted = str(value)
        
        return f"{label}: {formatted}"
    
    def create_dimension_string(self, obj):
        """创建维度信息字符串"""
        dims = obj.dimensions
        return f"尺寸: {units.length(dims.x)} × {units.length(dims.y)} × {units.length(dims.z)}"
    
    def create_location_string(self, obj):
        """创建位置信息字符串"""
        loc = obj.location
        return f"位置: ({units.length(loc.x)}, {units.length(loc.y)}, {units.length(loc.z)})"
    
    def create_rotation_string(self, obj):
        """创建旋转信息字符串"""
        rot = obj.rotation_euler
        return f"旋转: X={units.angle(rot.x)}, Y={units.angle(rot.y)}, Z={units.angle(rot.z)}"

class UnitInfoPanel(bpy.types.Panel):
    """单位信息面板"""
    bl_label = "测量信息"
    bl_idname = "OBJECT_PT_unit_info"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '信息'
    
    def draw(self, context):
        layout = self.layout
        obj = context.object
        
        if not obj:
            layout.label(text="未选择对象")
            return
        
        formatter = UIDisplayFormatter()
        
        # 显示单位系统
        system = context.scene.unit_settings.system
        layout.label(text=f"单位系统: {system}")
        
        col = layout.column()
        
        # 显示各种信息
        col.label(text=formatter.create_location_string(obj))
        col.label(text=formatter.create_dimension_string(obj))
        col.label(text=formatter.create_rotation_string(obj))
        
        # 顶点计数
        if obj.type == 'MESH':
            vert_count = len(obj.data.vertices)
            edge_count = len(obj.data.edges)
            face_count = len(obj.data.polygons)
            
            col.separator()
            col.label(text=f"顶点数: {vert_count}")
            col.label(text=f"边数: {edge_count}")
            col.label(text=f"面数: {face_count}")
```

### 单位验证

```python
import bpy
from bpy.utils import units

class UnitValidator:
    """单位验证器"""
    
    UNIT_PATTERNS = {
        'LENGTH': r'^\d+\.?\d*\s*(m|cm|mm|km|in|ft|yd|mi)?$',
        'ANGLE': r'^\d+\.?\d*\s*(°|deg|rad)?$',
    }
    
    def __init__(self):
        self.unit_settings = bpy.context.scene.unit_settings
    
    def validate_length_input(self, input_str):
        """验证长度输入"""
        import re
        pattern = self.UNIT_PATTERNS['LENGTH']
        
        if re.match(pattern, input_str.strip()):
            return True
        return False
    
    def parse_length_input(self, input_str):
        """解析长度输入"""
        input_str = input_str.strip()
        
        # 尝试提取数值和单位
        import re
        match = re.match(r'^(\d+\.?\d*)\s*(m|cm|mm|km|in|ft|yd|mi)?$', input_str)
        
        if match:
            value = float(match.group(1))
            unit = match.group(2) or 'm'  # 默认为米
            
            # 转换为米
            converter = UnitConverter()
            meters = converter.unit_to_meters(value, unit)
            
            return meters
        return None
    
    def format_for_input(self, value, target_unit='m'):
        """格式化用于输入的值"""
        converter = UnitConverter()
        return converter.format_in_unit(value, target_unit)

# 使用示例
validator = UnitValidator()

# 验证输入
test_inputs = ["1.5", "1.5m", "100cm", "12in", "3.5ft"]
print("输入验证:")
for inp in test_inputs:
    is_valid = validator.validate_length_input(inp)
    print(f"  {inp}: {'有效' if is_valid else '无效'}")
    
    if is_valid:
        meters = validator.parse_length_input(inp)
        print(f"    转换为米: {meters:.4f}m")
```

## 最佳实践

### 1. 使用 Blender 单位系统
```python
# 获取当前单位设置
system = bpy.context.scene.unit_settings.system

# 根据系统格式化
value = units.length(1.5, system)
```

### 2. 保持一致性
```python
# 统一使用 Blender 单位系统
class MeasurementMixin:
    def format_measurement(self, value):
        return units.length(value, bpy.context.scene.unit_settings.system)
```

### 3. 错误处理
```python
def safe_format_length(value):
    try:
        return units.length(value)
    except Exception as e:
        return f"{value} (格式错误)"
```

## 常见问题

### Q: 单位显示不一致
A: 检查 `bpy.context.scene.unit_settings.system` 设置是否一致。

### Q: 转换精度问题
```python
# 使用精度参数
units.length(value, system, precision=4)
```

### Q: 自定义单位不生效
A: Blender 只支持内置单位系统，自定义单位需要手动转换。

## 性能优化

1. **缓存格式化结果**：避免重复格式化相同值
2. **批量处理**：使用列表推导式批量格式化
3. **按需格式化**：只在需要显示时才格式化

## 相关模块

- [bpy.utils](bpy_utils_module.md) - Blender 工具函数
- [mathutils](mathutils_module.md) - 数学工具库
- [mathutils.geometry](mathutils_geometry_module.md) - 几何计算
