# bpy.ops.graph 模块

曲线编辑器操作模块，用于编辑动画曲线和关键帧。

## 概述

bpy.ops.graph 模块包含用于在曲线编辑器中操作动画曲线（F曲线）的运算符。曲线编辑器用于编辑动画的关键帧、曲线形状、插值方式等。

## 常用操作

### 关键帧操作

```python
import bpy

# 添加关键帧
bpy.ops.graph.keyframe_insert(type='ALL')

# 添加指定类型关键帧
bpy.ops.graph.keyframe_insert(type='LOC')
bpy.ops.graph.keyframe_insert(type='ROT')
bpy.ops.graph.keyframe_insert(type='SCALE')

# 删除关键帧
bpy.ops.graph.keyframe_delete(type='ALL')

# 删除选择的关键帧
bpy.ops.graph.delete()

# 清除所有关键帧
bpy.ops.graph.clean()

# 均化关键帧
bpy.ops.graph.euler_filter()
```

### 曲线选择操作

```python
# 选择所有曲线
bpy.ops.graph.select_all(action='SELECT')

# 取消选择
bpy.ops.graph.select_all(action='DESELECT')

# 反选
bpy.ops.graph.select_all(action='INVERT')

# 选择左边
bpy.ops.graph.select_border(extension=False, include_handles=False)

# 选择右边
bpy.ops.graph.select_border(extension=False, include_handles=False, left=False)

# 扩展选择
bpy.ops.graph.select_border(extension=True)

# 选择更少
bpy.ops.graph.select_less()

# 选择更多
bpy.ops.graph.select_more()
```

### 曲线编辑操作

```python
# 复制曲线
bpy.ops.graph.copy()

# 粘贴曲线
bpy.ops.graph.paste(offset='START')

# 粘贴到当前位置
bpy.ops.graph.paste(offset='CURRENT')

# 偏移粘贴
bpy.ops.graph.paste(offset='YES')

# 剪切曲线
bpy.ops.graph.cut()

# 删除曲线
bpy.ops.graph.delete(type='CURVE')

# 移除中间关键帧
bpy.ops.graph.decimate(type='SELECTED', ratio=0.1)
```

### 曲线平滑操作

```python
# 平滑曲线
bpy.ops.graph.smooth()

# 简化曲线
bpy.ops.graph.decimate(type='SELECTED', ratio=0.5)

# 采样关键帧
bpy.ops.graph.sample(type='SELECTED')

# 步进插值
bpy.ops.graph.handle_type(type='AUTO')

# 设置为自动
bpy.ops.graph.handle_type(type='AUTO')

# 设置为向量
bpy.ops.graph.handle_type(type='VECTOR')

# 设置为锚点
bpy.ops.graph.handle_type(type='ALIGNED')

# 设置为自由
bpy.ops.graph.handle_type(type='FREE')
```

### 插值类型操作

```python
# 设置插值类型
bpy.ops.graph.interpolation_type(type='BEZIER')

# 线性插值
bpy.ops.graph.interpolation_type(type='LINEAR')

# 常量插值
bpy.ops.graph.interpolation_type(type='CONSTANT')

# 弹性插值
bpy.ops.graph.interpolation_type(type='ELASTIC')

# 正弦插值
bpy.ops.graph.interpolation_type(type='SINE')

# 缓动插值
bpy.ops.graph.interpolation_type(type='EASE')

# 指数插值
bpy.ops.graph.interpolation_type(type='EXPO')
```

### 曲线外推

```python
# 循环外推
bpy.ops.graph.extrapolation_type(type='CYCLIC')

# 循环偏移外推
bpy.ops.graph.extrapolation_type(type='CYCLIC_OFFSET')

# 线性外推
bpy.ops.graph.extrapolation_type(type='LINEAR')

# 常量外推
bpy.ops.graph.extrapolation_type(type='CONSTANT')
```

### 曲线修饰器

```python
# 添加修饰器
bpy.ops.graph.modifier_add(type='CYCLES')

# 添加噪声修饰器
bpy.ops.graph.modifier_add(type='NOISE')

# 添加函数修饰器
bpy.ops.graph.modifier_add(type='FNGENERATOR')

# 添加限制范围修饰器
bpy.ops.graph.modifier_add(type='LIMITS')

# 添加Envelope修饰器
bpy.ops.graph.modifier_add(type='ENVELOPE')

# 应用修饰器
bpy.ops.graph.modifier_apply(modifier='Cycles')

# 删除修饰器
bpy.ops.graph.modifier_remove(modifier='Cycles')

# 移动修饰器
bpy.ops.graph.modifier_move_up(modifier='Noise')
bpy.ops.graph.modifier_move_down(modifier='Noise')
```

### 快照操作

```python
# 创建快照
bpy.ops.graph.snapshot(type='START')

# 创建完整快照
bpyops.graph.snapshot(type='FULL')

# 清除快照
bpy.ops.graph.snapshot_clear(type='START')

# 恢复到快照
bpy.ops.graph.snapshot_apply(type='START')

# 恢复到原始状态
bpy.ops.graph.snapshot_apply_original(type='START')
```

### 视图操作

```python
# 居中选区
bpy.ops.graph.view_selected()

# 居中全部
bpy.ops.graph.view_all()

# 跳转到关键帧
bpy.ops.graph.frame_jump()

# 跳转到第一个关键帧
bpy.ops.graph.first_frame()

# 跳转到最后一个关键帧
bpy.ops.graph.last_frame()

# 放大
bpy.ops.graph.zoom_in()

# 缩小
bpy.ops.graph.zoom_out()

# 平移
bpy.ops.graph.pan()
```

## 实际应用示例

### 动画曲线清理

```python
def clean_animation_curves():
    """清理动画曲线"""
    # 均化欧拉角
    bpy.ops.graph.euler_filter()
    
    # 清理多余关键帧
    bpy.ops.graph.clean()
    
    # 平滑选中的曲线
    bpy.ops.graph.select_all(action='SELECT')
    bpy.ops.graph.smooth()
    
    # 设置合适的插值
    for fcurve in bpy.context.active_object.animation_data.action.fcurves:
        bpy.ops.graph.select_all(action='DESELECT')
        fcurve.select = True
        bpy.context.area.type = 'GRAPH_EDITOR'
        bpy.ops.graph.interpolation_type(type='AUTO')
```

### 创建程序化动画曲线

```python
def create_bounce_animation(obj, frames=60, bounce_height=2.0):
    """创建弹跳动画曲线"""
    # 设置物体位置
    obj.location = (0, 0, 0)
    
    # 插入起始关键帧
    obj.keyframe_insert(data_path='location', frame=1)
    
    # 设置弹跳位置
    obj.location = (0, 0, bounce_height)
    obj.keyframe_insert(data_path='location', frame=15)
    
    obj.location = (0, 0, 0)
    obj.keyframe_insert(data_path='location', frame=30)
    
    obj.location = (0, 0, bounce_height * 0.6)
    obj.keyframe_insert(data_path='location', frame=45)
    
    obj.location = (0, 0, 0)
    obj.keyframe_insert(data_path='location', frame=60)
    
    # 编辑曲线插值
    bpy.context.area.type = 'GRAPH_EDITOR'
    bpy.ops.graph.select_all(action='SELECT')
    
    # 设置为弹性插值
    bpy.ops.graph.interpolation_type(type='ELASTIC')
    
    # 设置出点为自动
    bpy.ops.graph.handle_type(type='AUTO')
```

### 批量设置动画曲线

```python
def batch_set_curve_interpolation(interp_type='LINEAR'):
    """批量设置动画曲线插值类型"""
    # 确保在曲线编辑器中
    bpy.context.area.type = 'GRAPH_EDITOR'
    
    # 获取当前动作
    action = bpy.context.active_object.animation_data.action
    
    for fcurve in action.fcurves:
        # 选择曲线
        bpy.ops.graph.select_all(action='DESELECT')
        fcurve.select = True
        bpy.context.active_object.active_rotation_keyframe = fcurve
        
        # 设置插值
        bpy.ops.graph.interpolation_type(type=interp_type)
```

### 创建循环动画

```python
def setup_looping_animation(obj, loop_frames=30):
    """设置循环动画"""
    # 选中所有曲线
    bpy.context.area.type = 'GRAPH_EDITOR'
    bpy.ops.graph.select_all(action='SELECT')
    
    # 设置循环外推
    bpy.ops.graph.extrapolation_type(type='CYCLIC')
    
    # 设置曲线为循环
    for fcurve in obj.animation_data.action.fcurves:
        # 确保首尾关键帧匹配
        first_key = fcurve.keyframe_points[0]
        last_key = fcurve.keyframe_points[-1]
        
        if first_key.co[0] != 0:
            bpy.ops.graph.keyframe_insert(type='ALL')
```

### 曲线噪声效果

```python
def add_noise_to_curves(obj, noise_strength=0.1, noise_scale=1.0):
    """为曲线添加噪声效果"""
    bpy.context.area.type = 'GRAPH_EDITOR'
    bpy.ops.graph.select_all(action='SELECT')
    
    for fcurve in obj.animation_data.action.fcurves:
        # 添加噪声修饰器
        bpy.ops.graph.modifier_add(type='NOISE')
        
        modifier = fcurve.modifiers[-1]
        modifier.strength = noise_strength
        modifier.scale = noise_scale
        modifier.phase = 0.0
        modifier.depth = 0.0
        
        # 更新视图
        bpy.ops.graph.update()
```

### 简化动画曲线

```python
def simplify_curves(obj, threshold=0.1):
    """简化动画曲线关键帧"""
    bpy.context.area.type = 'GRAPH_EDITOR'
    
    for fcurve in obj.animation_data.action.fcurves:
        # 选择曲线
        bpy.ops.graph.select_all(action='DESELECT')
        fcurve.select = True
        
        # 简化曲线
        bpy.ops.graph.decimate(type='SELECTED', ratio=threshold)
```

## 使用场景

- **动画编辑**：编辑和调整动画曲线
- **曲线清理**：清理多余的关键帧和平滑曲线
- **插值控制**：设置关键帧之间的插值方式
- **循环动画**：创建循环动画曲线
- **曲线特效**：使用修饰器添加噪声等效果
- **动画烘焙**：烘焙动画数据

## 注意事项

- 曲线编辑需要正确的区域类型
- 删除操作不可逆
- 外推设置影响循环动画
- 修饰器会实时影响曲线
- 插值类型影响动画感觉
- 关键帧清洁不会影响动画结果
