# bpy_extras.node_utils - 节点工具模块

bpy_extras.node_utils模块提供了节点编辑、节点连接和节点树操作的实用工具函数。

## 概述

节点工具模块封装了Blender节点编辑器中的常见操作，包括节点输入输出查找、节点连接管理、节点树遍历等功能。适用于开发节点处理工具和材质编辑器插件。

## 核心功能

### 节点插槽查找

```python
import bpy
from bpy_extras.node_utils import (
    find_node_input,
    find_node_output,
    socket_id_to_index,
    socket_index_to_id
)

def get_node_input_socket(node, identifier):
    """查找节点的输入插槽"""
    return find_node_input(node, identifier)

def get_node_output_socket(node, identifier):
    """查找节点的输出插槽"""
    return find_node_output(node, identifier)

def get_socket_index(node, identifier, is_input):
    """将插槽ID转换为索引"""
    return socket_id_to_index(node, identifier, is_input)

def get_socket_id(node, index, is_input):
    """将插槽索引转换为ID"""
    return socket_index_to_id(node, index, is_input)

def list_all_inputs(node):
    """列出所有输入插槽"""
    inputs = []
    for input in node.inputs:
        inputs.append({
            'name': input.name,
            'identifier': input.identifier,
            'type': input.type,
            'default_value': input.default_value if hasattr(input, 'default_value') else None
        })
    return inputs

def list_all_outputs(node):
    """列出所有输出插槽"""
    outputs = []
    for output in node.outputs:
        outputs.append({
            'name': output.name,
            'identifier': output.identifier,
            'type': output.type
        })
    return outputs
```

### 节点查找

```python
def find_node_by_type(node_tree, node_type):
    """按类型查找节点"""
    for node in node_tree.nodes:
        if node.type == node_type:
            return node
    return None

def find_nodes_by_type(node_tree, node_type):
    """按类型查找所有节点"""
    return [node for node in node_tree.nodes if node.type == node_type]

def find_node_by_name(node_tree, name):
    """按名称查找节点"""
    return node_tree.nodes.get(name)

def find_nodes_by_name_pattern(node_tree, pattern):
    """按名称模式查找节点"""
    return [node for node in node_tree.nodes if pattern in node.name]

def find_node_with_input_connected(node_tree, node_type, input_name):
    """查找输入已连接的节点"""
    for node in node_tree.nodes:
        if node.type == node_type:
            input_socket = node.inputs.get(input_name)
            if input_socket and input_socket.is_linked:
                return node
    return None

def find_node_with_output_connected(node_tree, node_type, output_name):
    """查找输出已连接的节点"""
    for node in node_tree.nodes:
        if node.type == node_type:
            output_socket = node.outputs.get(output_name)
            if output_socket and output_socket.is_linked:
                return node
    return None
```

### 节点连接

```python
def get_node_connections(node_tree):
    """获取所有连接"""
    connections = []
    for link in node_tree.links:
        connections.append({
            'from_node': link.from_node.name,
            'from_socket': link.from_socket.name,
            'to_node': link.to_node.name,
            'to_socket': link.to_socket.name
        })
    return connections

def connect_nodes(node_tree, from_node, from_socket, to_node, to_socket):
    """连接两个节点"""
    socket_from = from_node.outputs.get(from_socket)
    socket_to = to_node.inputs.get(to_socket)
    if socket_from and socket_to:
        return node_tree.links.new(socket_from, socket_to)
    return None

def disconnect_node_input(node, input_name):
    """断开节点的输入连接"""
    socket = node.inputs.get(input_name)
    if socket and socket.is_linked:
        link = socket.links[0]
        node_tree = node.id_data
        node_tree.links.remove(link)

def disconnect_node_output(node, output_name):
    """断开节点的输出连接"""
    socket = node.outputs.get(output_name)
    if socket:
        for link in list(socket.links):
            node_tree = node.id_data
            node_tree.links.remove(link)

def remove_all_connections(node):
    """移除节点的所有连接"""
    for input in list(node.inputs):
        for link in list(input.links):
            node.id_data.links.remove(link)
    for output in list(node.outputs):
        for link in list(output.links):
            node.id_data.links.remove(link)
```

## 实用函数

### 节点树遍历

```python
def traverse_node_tree(node_tree, include_hidden=True):
    """遍历节点树"""
    nodes = []
    for node in node_tree.nodes:
        if not include_hidden and node.hide:
            continue
        nodes.append(node)
    return nodes

def find_source_node(node_tree):
    """查找源节点"""
    for node in node_tree.nodes:
        if node.type == 'GROUP':
            return node
        if hasattr(node, 'inputs') and len(node.inputs) == 0:
            return node
    return None

def find_output_node(node_tree):
    """查找输出节点"""
    for node in node_tree.nodes:
        if node.type == 'OUTPUT_MATERIAL':
            return node
        if hasattr(node, 'inputs') and len(node.inputs) > 0 and node.type == 'OUTPUT':
            return node
    return None

def find_dependent_nodes(node_tree, start_node):
    """查找依赖节点"""
    dependent = []
    stack = [start_node]
    while stack:
        current = stack.pop()
        for input in current.inputs:
            if input.is_linked:
                link = input.links[0]
                from_node = link.from_node
                if from_node not in dependent:
                    dependent.append(from_node)
                    stack.append(from_node)
    return dependent

def find_dependency_chain(node_tree, end_node, max_depth=10):
    """查找依赖链"""
    chain = []
    current = end_node
    depth = 0
    while depth < max_depth:
        for input in current.inputs:
            if input.is_linked:
                link = input.links[0]
                chain.append(link.from_node)
                current = link.from_node
                break
        else:
            break
        depth += 1
    return chain
```

### 节点创建

```python
def create_node(node_tree, node_type, name=None, location=(0, 0)):
    """创建节点"""
    node = node_tree.nodes.new(type=node_type)
    if name:
        node.name = name
    node.location = location
    return node

def duplicate_node(node_tree, node):
    """复制节点"""
    new_node = node_tree.nodes.new(type=node.type)
    new_node.name = node.name + '.001'
    new_node.location = (node.location.x + 300, node.location.y)
    new_node.inputs['Strength'].default_value = node.inputs['Strength'].default_value
    return new_node

def create_ principled_bsdf_setup(node_tree, location=(-200, 0)):
    """创建Principled BSDF设置"""
    output = find_node_by_type(node_tree, 'OUTPUT_MATERIAL')
    if not output:
        output = create_node(node_tree, 'ShaderNodeOutputMaterial', location=(400, 0))
    
    principled = create_node(node_tree, 'ShaderNodeBsdfPrincipled', location=(0, 0))
    
    connect_nodes(node_tree, principled, 'BSDF', output, 'Surface')
    return principled

def create_texture_coordinate_chain(node_tree):
    """创建纹理坐标链"""
    coord = create_node(node_tree, 'ShaderNodeTexCoord', location=(-600, 0))
    mapping = create_node(node_tree, 'ShaderNodeMapping', location=(-300, 0))
    image = create_node(node_tree, 'ShaderNodeTexImage', location=(0, 0))
    
    connect_nodes(node_tree, coord, 'Generated', mapping, 'Vector')
    connect_nodes(node_tree, mapping, 'Vector', image, 'Vector')
    return coord, mapping, image
```

### 节点属性

```python
def copy_node_attributes(source, target):
    """复制节点属性"""
    for input in source.inputs:
        if input.is_linked:
            continue
        if hasattr(input, 'default_value'):
            target_input = target.inputs.get(input.name)
            if target_input and hasattr(target_input, 'default_value'):
                target_input.default_value = input.default_value

def get_node_type_description(node_type):
    """获取节点类型描述"""
    descriptions = {
        'TEX_IMAGE': '图像纹理节点',
        'BSDF_PRINCIPLED': 'Principled BSDF节点',
        'OUTPUT_MATERIAL': '材质输出节点',
        'TEX_COORD': '纹理坐标节点',
        'MAPPING': '映射节点'
    }
    return descriptions.get(node_type, '未知节点类型')

def get_socket_type_description(socket_type):
    """获取插槽类型描述"""
    descriptions = {
        'VALUE': '浮点值',
        'RGBA': '颜色',
        'VECTOR': '向量',
        'SHADER': '着色器'
    }
    return descriptions.get(socket_type, '未知类型')
```

## 常见问题排查

### 节点未找到

节点不存在：
- 确认节点类型名称正确
- 检查节点树是否正确
- 使用find_nodes_by_type获取所有匹配节点

### 连接失败

插槽类型不匹配：
- 确认两个插槽类型兼容
- 检查节点是否已存在连接
- 验证节点是否在同一个节点树中

### 属性访问错误

属性不存在：
- 使用hasattr检查属性
- 确认节点类型支持该属性
- 检查输入输出名称是否正确
