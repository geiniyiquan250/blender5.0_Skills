# bmesh.utils 模块

## 模块概述

bmesh.utils 模块提供了一系列用于 BMesh 数据结构的实用工具函数。这些函数补充了 bmesh.ops 和 bmesh.types 的功能，提供了网格验证、法线计算、边方向判断等辅助功能。虽然这些函数不像 bmesh.ops 中的操作那样直接修改网格，但它们在网格处理流程中扮演着重要的角色。

该模块中的函数可以分为几个主要类别：法线计算函数用于获取和设置元素的方向信息，网格验证函数用于检查网格的有效性，几何计算函数用于测量距离和角度，拓扑查询函数用于获取网格的结构信息。这些函数的共同特点是它们都是纯函数，不会修改传入的网格数据。

理解 bmesh.utils 中的工具函数对于编写健壮的网格处理脚本至关重要。这些函数可以帮助检测潜在的网格问题、计算必要的数据用于后续操作、以及验证操作结果的正确性。在复杂的建模流程中，合理使用这些工具函数可以显著提高代码的可靠性和可维护性。

## 法线计算函数

### 计算顶点法线

calc_tangent_edge 函数计算与顶点相连的边的切线方向。这个函数在需要计算顶点切线用于纹理映射或光照计算时非常有用。

```python
import bmesh
from bmesh.utils import calc_tangent_edge
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((0.0, 1.0, 0.0))
f = bme.faces.new((v1, v2, v3))

print("计算顶点切线测试:")
print(f"面 {f.index} 的法线: {f.normal}")

for v in bme.verts:
    print(f"\n顶点 {v.index}:")
    print(f"  坐标: {v.co}")
    print(f"  法线: {v.normal}")

    # 计算关联边的切线
    for e in v.link_edges:
        tangent = calc_tangent_edge(e, v)
        if tangent:
            v1, v2 = e.verts
            print(f"  边 {e.index} ({v1.co} - {v2.co}) 的切线: {tangent}")
```

### 计算循环切线

calc_tangent_loop 函数计算循环的切线方向。循环是 BMesh 中的基本拓扑结构之一，每个循环对应面的一条边。

```python
import bmesh
from bmesh.utils import calc_tangent_loop, calc_tangent_edge
from mathutils import Vector

# 创建更复杂的测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((1.0, 1.0, 0.0))
v4 = bme.verts.new((0.0, 1.0, 0.0))
f = bme.faces.new((v1, v2, v3, v4))

print("计算循环切线测试:")
print(f"面 {f.index} 的法线: {f.normal}")

# 遍历所有循环
for loop in f.loops:
    print(f"\n循环:")
    print(f"  顶点: {loop.vert.co}")
    print(f"  边: {loop.edge.index}")

    # 计算循环切线
    tangent = calc_tangent_loop(loop)
    print(f"  切线: {tangent}")

    # 计算边的切线
    edge_tangent = calc_tangent_edge(loop.edge, loop.vert)
    print(f"  边切线: {edge_tangent}")
```

### 边切线计算

calc_tangent_edge 函数计算特定边在某个顶点处的切线向量。这个函数考虑了边在面中的位置和方向，返回一个单位向量表示切线方向。

```python
import bmesh
from bmesh.utils import calc_tangent_edge
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
# 创建立方体
verts = []
for x in [-1, 1]:
    for y in [-1, 1]:
        for z in [-1, 1]:
            verts.append(bme.verts.new((x, y, z)))
bme.verts.ensure_lookup_table()

face_verts = [
    (0, 1, 3, 2),  # 前面
    (5, 4, 7, 6),  # 后面
    (4, 0, 3, 7),  # 左面
    (1, 5, 6, 2),  # 右面
    (3, 2, 6, 7),  # 顶面
    (4, 5, 1, 0),  # 底面
]
for fv in face_verts:
    bme.faces.new([verts[i] for i in fv])

print("边切线计算测试:")
print(f"顶面法线: {bme.faces[4].normal}")

# 分析顶面的四条边
top_face = bme.faces[4]
for loop in top_face.loops:
    edge = loop.edge
    tangent = calc_tangent_edge(edge, loop.vert)
    print(f"\n边 {edge.index} 在顶点 {loop.vert.index}:")
    print(f"  边的另一个顶点: {edge.other_vert(loop.vert).co}")
    print(f"  切线: {tangent}")
```

## 边方向函数

### 边方向判断

edge_direction 函数返回边的方向向量，从第一个顶点指向第二个顶点。这个函数在需要确定边的方向用于后续操作时非常有用。

```python
import bmesh
from bmesh.utils import edge_direction
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((2.0, 0.0, 0.0))
e = bme.edges.new((v1, v2))

print("边方向测试:")
print(f"顶点1: {v1.co}")
print(f"顶点2: {v2.co}")

# 获取边的方向
direction = edge_direction(e)
print(f"边方向: {direction}")

# 验证方向
expected = v2.co - v1.co
print(f"期望方向: {expected}")
print(f"方向正确: {direction == expected}")

# 测试多条边
print("\n多条边方向测试:")
for i in range(4):
    v1 = bme.verts.new((i, 0, 0))
    v2 = bme.verts.new((i + 1, 0, 0))
    e = bme.edges.new((v1, v2))
    direction = edge_direction(e)
    print(f"  边 {len(bme.edges) - 1}: 方向={direction}")
```

### 共享顶点查找

edge_share_vert 函数检查两条边是否共享顶点，并返回共享的顶点（如果有）。

```python
import bmesh
from bmesh.utils import edge_share_vert

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((1.0, 1.0, 0.0))
v4 = bme.verts.new((0.0, 1.0, 0.0))

e1 = bme.edges.new((v1, v2))
e2 = bme.edges.new((v2, v3))
e3 = bme.edges.new((v1, v3))  # 对角线，不共享顶点

print("边共享顶点测试:")
print(f"边1: {v1.co} - {v2.co}")
print(f"边2: {v2.co} - {v3.co}")
print(f"边3: {v1.co} - {v3.co}")

# 检查边1和边2
shared = edge_share_vert(e1, e2)
print(f"\n边1和边2共享顶点: {shared}")
if shared:
    print(f"  共享顶点: {shared.co}")

# 检查边1和边3
shared = edge_share_vert(e1, e3)
print(f"\n边1和边3共享顶点: {shared}")

# 检查边2和边3
shared = edge_share_vert(e2, e3)
print(f"\n边2和边3共享顶点: {shared}")
if shared:
    print(f"  共享顶点: {shared.co}")
```

## 网格验证函数

### 网格有效性检查

mesh_linked_submesh_check 函数检查网格的连通性，判断网格是否由多个分离的部分组成。

```python
import bmesh
from bmesh.utils import mesh_linked_submesh_check

# 创建分离的网格
bme = bmesh.new()

# 第一个三角形
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((0.5, 1.0, 0.0))
bme.faces.new((v1, v2, v3))

# 第二个三角形（分离）
v4 = bme.verts.new((5.0, 0.0, 0.0))
v5 = bme.verts.new((6.0, 0.0, 0.0))
v6 = bme.verts.new((5.5, 1.0, 0.0))
bme.faces.new((v4, v5, v6))

print("网格连通性测试:")
print(f"面数: {len(bme.faces)}")
print(f"顶点数: {len(bme.verts)}")

# 检查连通性
is_connected = mesh_linked_submesh_check(bme)
print(f"网格是否连通: {is_connected}")

# 创建连通的网格
bme2 = bmesh.new()
for x in range(3):
    for y in range(3):
        bme2.verts.new((x, y, 0))
bme2.verts.ensure_lookup_table()

for y in range(2):
    for x in range(2):
        i = y * 3 + x
        bme2.faces.new([
            bme2.verts[i],
            bme2.verts[i + 1],
            bme2.verts[i + 4],
            bme2.verts[i + 3]
        ])

print("\n连通网格测试:")
print(f"面数: {len(bme2.faces)}")
is_connected = mesh_linked_submesh_check(bme2)
print(f"网格是否连通: {is_connected}")
```

### 顶点有效性检查

vert_separate_by_angle 函数根据角度阈值分离顶点。这个函数常用于复制硬边处的顶点，使它们不再共享。

```python
import bmesh
from bmesh.utils import vert_separate_by_angle

# 创建测试网格（带硬边）
bme = bmesh.new()
# 创建立方体
verts = []
for x in [-1, 1]:
    for y in [-1, 1]:
        for z in [-1, 1]:
            verts.append(bme.verts.new((x, y, z)))
bme.verts.ensure_lookup_table()

face_verts = [
    (0, 1, 3, 2),
    (5, 4, 7, 6),
    (4, 0, 3, 7),
    (1, 5, 6, 2),
    (3, 2, 6, 7),
    (4, 5, 1, 0),
]
for fv in face_verts:
    bme.faces.new([verts[i] for i in fv])

print("顶点分离测试:")
print(f"操作前顶点数: {len(bme.verts)}")

# 选择一个顶点
v = bme.verts[0]
print(f"顶点 {v.index} 的相邻面数: {len(v.link_faces)}")

# 计算相邻面之间的角度
adjacent_normals = []
for f in v.link_faces:
    adjacent_normals.append(f.normal)

print(f"相邻面法线: {[n for n in adjacent_normals]}")

# 分离顶点（基于角度）
result = vert_separate_by_angle(bme, verts=[v], angle=1.0)
print(f"分离后顶点数: {len(bme.verts)}")

# 检查新创建的顶点
new_verts = result['verts']
print(f"新创建的顶点数: {len(new_verts)}")
```

## 几何计算函数

### 边长度计算

edge_calc_length 函数计算边的长度。这个函数提供了直接计算边长度的能力，与通过计算两个端点距离的方式等效。

```python
import bmesh
from bmesh.utils import edge_calc_length

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((3.0, 4.0, 0.0))
e = bme.edges.new((v1, v2))

print("边长度计算测试:")
print(f"顶点1: {v1.co}")
print(f"顶点2: {v2.co}")

# 计算边长度
length = edge_calc_length(e)
print(f"边长度: {length}")

# 验证（3-4-5 三角形）
expected_length = 5.0
print(f"期望长度: {expected_length}")
print(f"计算正确: {abs(length - expected_length) < 0.0001}")

# 测试多条边
print("\n多条边长度测试:")
edges = []
for i in range(5):
    x = i * 2
    v1 = bme.verts.new((x, 0, 0))
    v2 = bme.verts.new((x + 1, 0, 0))
    edges.append(bme.edges.new((v1, v2)))

for i, e in enumerate(edges):
    length = edge_calc_length(e)
    print(f"  边 {i}: 长度={length}")
```

### 距离计算

vertex_distance_to_plane 函数计算顶点到平面的距离。这个函数在需要判断顶点相对于某个平面的位置时非常有用。

```python
import bmesh
from bmesh.utils import vertex_distance_to_plane
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((0.0, 1.0, 0.0))
bme.faces.new((v1, v2, v3))

# 定义平面（使用面的位置和法线）
f = bme.faces[0]
plane_co = f.center_median
plane_no = f.normal

print("顶点到平面距离测试:")
print(f"平面中心: {plane_co}")
print(f"平面法线: {plane_no}")

for v in bme.verts:
    distance = vertex_distance_to_plane(v, plane_co, plane_no)
    print(f"\n顶点 {v.index}:")
    print(f"  坐标: {v.co}")
    print(f"  到平面距离: {distance:.4f}")

    # 验证：面上的顶点距离应该接近0
    if v in f.verts:
        print(f"  验证: 顶点在面上，距离应接近0")
```

## 实践示例

### 网格分析器

这个示例展示了如何使用 bmesh.utils 中的函数创建网格分析工具。

```python
import bmesh
from bmesh.utils import (
    edge_calc_length, edge_direction, edge_share_vert,
    calc_tangent_edge, calc_tangent_loop
)
from mathutils import Vector

class MeshAnalyzer:
    def __init__(self, bme):
        self.bme = bme

    def analyze_edges(self):
        """分析所有边"""
        analysis = {
            'total_edges': len(self.bme.edges),
            'avg_length': 0,
            'min_length': float('inf'),
            'max_length': 0,
            'direction_stats': {'X': 0, 'Y': 0, 'Z': 0, 'DIAGONAL': 0},
            'shared_vert_stats': {0: 0, 1: 0, 2: 0}
        }

        total_length = 0
        for e in self.bme.edges:
            # 长度分析
            length = edge_calc_length(e)
            total_length += length
            analysis['min_length'] = min(analysis['min_length'], length)
            analysis['max_length'] = max(analysis['max_length'], length)

            # 方向分析
            direction = edge_direction(e)
            abs_x, abs_y, abs_z = abs(direction.x), abs(direction.y), abs(direction.z)
            if abs_x > abs_y and abs_x > abs_z:
                analysis['direction_stats']['X'] += 1
            elif abs_y > abs_x and abs_y > abs_z:
                analysis['direction_stats']['Y'] += 1
            elif abs_z > abs_x and abs_z > abs_y:
                analysis['direction_stats']['Z'] += 1
            else:
                analysis['direction_stats']['DIAGONAL'] += 1

        analysis['avg_length'] = total_length / max(1, len(self.bme.edges))

        return analysis

    def analyze_faces(self):
        """分析所有面"""
        analysis = {
            'total_faces': len(self.bme.faces),
            'face_sizes': {},
            'normal_directions': {'X': 0, 'Y': 0, 'Z': 0},
            'total_area': 0
        }

        for f in self.bme.faces:
            # 面大小分析
            size = len(f.verts)
            analysis['face_sizes'][size] = analysis['face_sizes'].get(size, 0) + 1

            # 法线方向分析
            normal = f.normal
            abs_x, abs_y, abs_z = abs(normal.x), abs(normal.y), abs(normal.z)
            if abs_x > abs_y and abs_x > abs_z:
                analysis['normal_directions']['X'] += 1
            elif abs_y > abs_x and abs_y > abs_z:
                analysis['normal_directions']['Y'] += 1
            else:
                analysis['normal_directions']['Z'] += 1

            # 面积分析
            analysis['total_area'] += f.calc_area()

        return analysis

    def analyze_topology(self):
        """分析拓扑结构"""
        analysis = {
            'vertex_connections': {},
            'edge_connections': {},
            'is_manifold': True,
            'boundary_edges': 0
        }

        for v in self.bme.verts:
            conn = len(v.link_edges)
            analysis['vertex_connections'][conn] = analysis['vertex_connections'].get(conn, 0) + 1

        for e in self.bme.edges:
            conn = len(list(e.link_faces))
            analysis['edge_connections'][conn] = analysis['edge_connections'].get(conn, 0) + 1
            if e.is_boundary():
                analysis['boundary_edges'] += 1
                analysis['is_manifold'] = False

        return analysis

    def full_report(self):
        """生成完整报告"""
        edge_analysis = self.analyze_edges()
        face_analysis = self.analyze_faces()
        topology_analysis = self.analyze_topology()

        print("=" * 60)
        print("网格分析报告")
        print("=" * 60)

        print("\n边分析:")
        print(f"  总边数: {edge_analysis['total_edges']}")
        print(f"  平均长度: {edge_analysis['avg_length']:.4f}")
        print(f"  长度范围: {edge_analysis['min_length']:.4f} - {edge_analysis['max_length']:.4f}")
        print(f"  方向分布: {edge_analysis['direction_stats']}")

        print("\n面分析:")
        print(f"  总面数: {face_analysis['total_faces']}")
        print(f"  面大小分布: {face_analysis['face_sizes']}")
        print(f"  法线方向分布: {face_analysis['normal_directions']}")
        print(f"  总面积: {face_analysis['total_area']:.4f}")

        print("\n拓扑分析:")
        print(f"  顶点连接度分布: {topology_analysis['vertex_connections']}")
        print(f"  边连接度分布: {topology_analysis['edge_connections']}")
        print(f"  边界边数: {topology_analysis['boundary_edges']}")
        print(f"  是否为流形: {topology_analysis['is_manifold']}")

# 使用示例
bme = bmesh.new()
for x in range(3):
    for y in range(3):
        bme.verts.new((x, y, 0))
bme.verts.ensure_lookup_table()

for y in range(2):
    for x in range(2):
        i = y * 3 + x
        bme.faces.new([
            bme.verts[i],
            bme.verts[i + 1],
            bme.verts[i + 4],
            bme.verts[i + 3]
        ])

analyzer = MeshAnalyzer(bme)
analyzer.full_report()
```

### 法线验证工具

这个示例展示了如何使用 bmesh.utils 中的函数验证和修正网格法线。

```python
import bmesh
from bmesh.utils import calc_tangent_edge, calc_tangent_loop
from mathutils import Vector

class NormalValidator:
    def __init__(self, bme):
        self.bme = bme

    def validate_face_normals(self):
        """验证面的法线方向"""
        issues = []

        for f in self.bme.faces:
            # 计算法线
            normal = f.normal

            # 检查法线是否有效
            if normal.length < 0.001:
                issues.append({
                    'type': 'zero_normal',
                    'face': f.index,
                    'message': '面法线长度为0'
                })

            # 检查法线是否朝上（假设地面朝上）
            if normal.z < 0:
                issues.append({
                    'type': 'inverted_normal',
                    'face': f.index,
                    'normal': normal,
                    'message': '面法线朝下，可能需要翻转'
                })

        return issues

    def validate_vertex_normals(self):
        """验证顶点法线"""
        issues = []

        for v in self.bme.verts:
            normal = v.normal

            if normal.length < 0.001:
                issues.append({
                    'type': 'zero_normal',
                    'vertex': v.index,
                    'message': '顶点法线长度为0'
                })

        return issues

    def analyze_tangents(self):
        """分析切线方向"""
        tangent_info = []

        for f in self.bme.faces:
            for loop in f.loops:
                tangent = calc_tangent_loop(loop)
                if tangent and tangent.length > 0.001:
                    tangent_info.append({
                        'face': f.index,
                        'vertex': loop.vert.index,
                        'tangent': tangent,
                        'tangent_length': tangent.length
                    })

        return tangent_info

    def flip_face_normals(self, faces=None):
        """翻转面法线"""
        if faces is None:
            faces = list(self.bme.faces)

        for f in faces:
            # 翻转顶点顺序
            verts = list(f.verts)
            verts.reverse()
            f.verts = verts

        return faces

    def print_validation_report(self):
        """打印验证报告"""
        face_issues = self.validate_face_normals()
        vertex_issues = self.validate_vertex_normals()
        tangents = self.analyze_tangents()

        print("=" * 60)
        print("法线验证报告")
        print("=" * 60)

        print(f"\n面法线问题: {len(face_issues)} 个")
        for issue in face_issues[:5]:
            print(f"  - {issue['message']} (面 {issue['face']})")

        print(f"\n顶点法线问题: {len(vertex_issues)} 个")
        for issue in vertex_issues[:5]:
            print(f"  - {issue['message']} (顶点 {issue['vertex']})")

        print(f"\n切线分析: {len(tangents)} 个")
        if tangents:
            avg_length = sum(t['tangent_length'] for t in tangents) / len(tangents)
            print(f"  平均切线长度: {avg_length:.4f}")

# 使用示例
bme = bmesh.new()
# 创建有问题的网格（有些面法线朝下）
verts = []
for x in [-1, 1]:
    for y in [-1, 1]:
        for z in [-1, 1]:
            verts.append(bme.verts.new((x, y, z)))
bme.verts.ensure_lookup_table()

# 创建一个法线朝下的面
bme.faces.new([verts[1], verts[0], verts[2]])  # 顶点顺序导致法线朝下

validator = NormalValidator(bme)
validator.print_validation_report()
```

## 注意事项

### 函数兼容性

bmesh.utils 中的某些函数可能有版本限制或在不同 Blender 版本中行为不同。在使用这些函数时，应该参考当前 Blender 版本的官方文档确认函数的可用性和行为。

### 性能考虑

虽然 bmesh.utils 中的函数本身开销不大，但在处理大规模网格时应该注意调用的频率。如果需要多次计算相同的数据（如法线），应该考虑缓存结果而不是重复计算。

### 返回值处理

某些函数返回字典或特殊类型的值，在使用前应该仔细检查返回值的结构和类型。对于可能返回 None 的函数，应该添加适当的空值检查。