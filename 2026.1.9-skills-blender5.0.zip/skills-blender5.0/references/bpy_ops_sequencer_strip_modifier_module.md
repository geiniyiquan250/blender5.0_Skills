# bpy.ops.sequencer - 条带修改器操作模块

Blender序列器条带修改器操作符，用于管理视频序列条带的修改器。

## 概述

`bpy.ops.sequencer.strip_modifier` 模块提供用于在Blender序列器中对条带应用和修改修改器的功能，包括颜色校正、变换、模糊等效果。

## 核心功能

### 修改器管理

```python
import bpy

# 添加修改器
bpy.ops.sequencer.strip_modifier_add(
    type='COLOR_BALANCE'
)

# 添加颜色平衡修改器
bpy.ops.sequencer.strip_modifier_add(
    type='COLOR_BALANCE'
)

# 添加曲线修改器
bpy.ops.sequencer.strip_modifier_add(
    type='CURVES'
)

# 添加亮度对比度修改器
bpy.ops.sequencer.strip_modifier_add(
    type='BRIGHT_CONTRAST'
)

# 添加色调映射修改器
bpy.ops.sequencer.strip_modifier_add(
    type='TONEMAP'
)

# 添加模糊修改器
bpy.ops.sequencer.strip_modifier_add(
    type='BLUR'
)

# 添加变换修改器
bpy.ops.sequencer.strip_modifier_add(
    type='TRANSFORM'
```

### 修改器选择

```python
# 选择修改器
bpy.ops.sequencer.strip_modifier_select(
    strip='STRIP',
    strip_index=0,
    modifier_index=0,
    extend=False
)

# 扩展选择
bpy.ops.sequencer.strip_modifier_select(
    strip='STRIP',
    strip_index=0,
    modifier_index=1,
    extend=True
)
```

### 修改器移除

```python
# 移除修改器
bpy.ops.sequencer.strip_modifier_remove(
    strip='STRIP',
    strip_index=0,
    modifier_index=0
)

# 移除所有修改器
def remove_all_modifiers(strip):
    while strip.modifiers:
        bpy.context.scene.sequence_editor.active_strip = strip
        bpy.ops.sequencer.strip_modifier_remove(
            strip=strip.name,
            strip_index=0,
            modifier_index=0
        )
```

### 修改器移动

```python
# 上移修改器
bpy.ops.sequencer.strip_modifier_move(
    strip='STRIP',
    strip_index=0,
    modifier_index=1,
    direction='UP'
)

# 下移修改器
bpy.ops.sequencer.strip_modifier_move(
    strip='STRIP',
    strip_index=0,
    modifier_index=0,
    direction='DOWN'
)
```

### 修改器复制

```python
# 复制修改器
bpy.ops.sequencer.strip_modifier_copy(
    strip='STRIP',
    strip_index=0,
    modifier_index=0
)
```

## 实用函数

```python
def add_color_balance(strip):
    """添加颜色平衡修改器"""
    bpy.context.scene.sequence_editor.active_strip = strip
    bpy.ops.sequencer.strip_modifier_add(type='COLOR_BALANCE')
    return strip.modifiers[-1]

def add_brightness_contrast(strip):
    """添加亮度对比度修改器"""
    bpy.context.scene.sequence_editor.active_strip = strip
    bpy.ops.sequencer.strip_modifier_add(type='BRIGHT_CONTRAST')
    return strip.modifiers[-1]

def add_curves(strip):
    """添加曲线修改器"""
    bpy.context.scene.sequence_editor.active_strip = strip
    bpy.ops.sequencer.strip_modifier_add(type='CURVES')
    return strip.modifiers[-1]

def add_blur(strip, size=10, angle=0):
    """添加模糊修改器"""
    bpy.context.scene.sequence_editor.active_strip = strip
    bpy.ops.sequencer.strip_modifier_add(type='BLUR')
    modifier = strip.modifiers[-1]
    modifier.size_x = size
    modifier.size_y = size
    modifier.angle = angle
    return modifier

def add_transform(strip, scale_x=1.0, scale_y=1.0):
    """添加变换修改器"""
    bpy.context.scene.sequence_editor.active_strip = strip
    bpy.ops.sequencer.strip_modifier_add(type='TRANSFORM')
    modifier = strip.modifiers[-1]
    modifier.scale_x = scale_x
    modifier.scale_y = scale_y
    return modifier

def add_crop(strip, left=0, right=0, top=0, bottom=0):
    """添加裁剪修改器"""
    bpy.context.scene.sequence_editor.active_strip = strip
    bpy.ops.sequencer.strip_modifier_add(type='CROP')
    modifier = strip.modifiers[-1]
    modifier.left = left
    modifier.right = right
    modifier.top = top
    modifier.bottom = bottom
    return modifier

def apply_color_grading(strip, lift=(1, 1, 1), gamma=(1, 1, 1), gain=(1, 1, 1)):
    """应用色彩分级"""
    bpy.context.scene.sequence_editor.active_strip = strip
    bpy.ops.sequencer.strip_modifier_add(type='COLOR_BALANCE')
    mod = strip.modifiers[-1]
    mod.color_balance.lift_factor = lift
    mod.color_balance.gamma_factor = gamma
    mod.color_balance.gain_factor = gain
    return mod

def create_vignette(strip, radius=0.5, softness=0.5):
    """创建暗角效果"""
    bpy.context.scene.sequence_editor.active_strip = strip
    bpy.ops.sequencer.strip_modifier_add(type='WIPE')
    mod = strip.modifiers[-1]
    mod.wipe.angle = 0
    mod.wipe.blur = softness
    mod.wipe.edge_radius = radius
    return mod

def add_glow(strip, threshold=0.8, radius=15):
    """添加发光效果"""
    bpy.context.scene.sequence_editor.active_strip = strip
    bpy.ops.sequencer.strip_modifier_add(type='GAUSSIAN_BLUR')
    mod = strip.modifiers[-1]
    mod.blur.radius = radius
    return mod

def duplicate_modifier(strip, modifier_name):
    """复制修改器"""
    for i, mod in enumerate(strip.modifiers):
        if mod.name == modifier_name:
            bpy.context.scene.sequence_editor.active_strip = strip
            bpy.ops.sequencer.strip_modifier_select(
                strip=strip.name,
                strip_index=0,
                modifier_index=i
            )
            bpy.ops.sequencer.strip_modifier_copy(
                strip=strip.name,
                strip_index=0,
                modifier_index=i
            )
            return
```

## 常见问题排查

### 修改器不工作
```python
# 检查活动条带
strip = bpy.context.scene.sequence_editor.active_strip
print(f"活动条带: {strip}")

# 检查修改器
print(f"修改器数: {len(strip.modifiers) if strip else 0}")

if strip and strip.modifiers:
    for mod in strip.modifiers:
        print(f"修改器: {mod.name}, 类型: {mod.type}")
        print(f"  启用: {mod.show_render}")
        print(f"  显示: {mod.show_viewport}")
```

### 修改器顺序问题
```python
# 检查修改器顺序
strip = bpy.context.scene.sequence_editor.active_strip
for i, mod in enumerate(strip.modifiers):
    print(f"{i}: {mod.name} ({mod.type})")

# 上移修改器
bpy.ops.sequencer.strip_modifier_move(
    strip=strip.name,
    strip_index=0,
    modifier_index=1,
    direction='UP'
)

# 下移修改器
bpy.ops.sequencer.strip_modifier_move(
    strip=strip.name,
    strip_index=0,
    modifier_index=0,
    direction='DOWN'
)
```

### 修改器效果不明显
```python
# 检查修改器参数
strip = bpy.context.scene.sequence_editor.active_strip
if strip.modifiers:
    mod = strip.modifiers[0]
    print(f"修改器类型: {mod.type}")
    
    # 打印参数
    for prop in dir(mod):
        if not prop.startswith('_'):
            val = getattr(mod, prop)
            if not callable(val):
                print(f"  {prop}: {val}")

# 增强效果
if mod.type == 'BLUR':
    mod.size_x = 20
    mod.size_y = 20
elif mod.type == 'BRIGHT_CONTRAST':
    mod.contrast = 20
    mod.brightness = 0.1
```

### 修改器冲突
```python
# 检查冲突的修改器
strip = bpy.context.scene.sequence_editor.active_strip
for i, mod in enumerate(strip.modifiers):
    print(f"{i}: {mod.name} ({mod.type})")
    for j, other in enumerate(strip.modifiers):
        if i != j and mod.type == other.type:
            print(f"  冲突: {other.name}")

# 禁用冲突修改器
for mod in strip.modifiers:
    mod.show_render = False

# 重新启用
for mod in strip.modifiers:
    mod.show_render = True
```
