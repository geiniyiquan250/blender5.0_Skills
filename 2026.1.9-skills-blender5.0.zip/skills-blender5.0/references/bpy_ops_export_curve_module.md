# bpy.ops.export_curve - 曲线导出操作模块

Blender曲线导出操作符，用于将曲线数据导出为各种文件格式。

## 概述

`bpy.ops.export_curve` 模块提供用于将Blender中的曲线、路径和矢量图形导出为外部文件格式的功能。

## 核心功能

### SVG导出

```python
import bpy

# 导出为SVG
bpy.ops.export_curve.svg(
    filepath='//output.svg',
    export_selected=True,
    apply_modifiers=True,
    split_curves=False,
    export_hair_curves=False,
    export_particle_systems=False,
    scale=1.0
)

# 导出选中曲线为SVG
bpy.ops.export_curve.svg(
    filepath='//curves.svg',
    export_selected=True
)

# 导出所有曲线为SVG
bpy.ops.export_curve.svg(
    filepath='//all_curves.svg',
    export_selected=False
)

# 分离曲线导出
bpy.ops.export_curve.svg(
    filepath='//separated.svg',
    split_curves=True
)
```

### DXF导出

```python
# 导出为DXF
bpy.ops.export_curve.dxf(
    filepath='//output.dxf',
    export_selected=True,
    apply_modifiers=True,
    scale=1.0,
    version='R12',
    use_mesh_data=False,
    use_line_endings=False
)

# 导出选中对象为DXF
bpy.ops.export_curve.dxf(
    filepath='//selected.dxf',
    export_selected=True
)

# 导出特定版本
bpy.ops.export_curve.dxf(
    filepath='//r14.dxf',
    version='R14'
)

bpy.ops.export_curve.dxf(
    filepath='//r2000.dxf',
    version='R2000'
)
```

### Adobe Illustrator导出

```python
# 导出为AI
bpy.ops.export_curve.ai(
    filepath='//output.ai',
    export_selected=True,
    scale=1.0,
    resolution=12,
    export_hair_curves=False
)

# 高精度导出
bpy.ops.export_curve.ai(
    filepath='//high_res.ai',
    resolution=24
)

# 只导出选中对象
bpy.ops.export_curve.ai(
    filepath='//selected.ai',
    export_selected=True
)
```

### 通用导出选项

```python
# 设置导出比例
bpy.ops.export_curve.svg(
    filepath='//scaled.svg',
    scale=2.0
)

# 应用修改器
bpy.ops.export_curve.svg(
    filepath='//with_modifiers.svg',
    apply_modifiers=True
)

# 导出毛发曲线
bpy.ops.export_curve.svg(
    filepath='//with_hair.svg',
    export_hair_curves=True
)

# 导出粒子系统
bpy.ops.export_curve.svg(
    filepath='//with_particles.svg',
    export_particle_systems=True
)
```

### 批量导出

```python
# 批量导出多个文件
def batch_export_svg(curves, base_path):
    for i, curve in enumerate(curves):
        bpy.ops.object.select_all(action='DESELECT')
        curve.select_set(True)
        bpy.context.view_layer.objects.active = curve
        bpy.ops.export_curve.svg(
            filepath=f'{base_path}_{i}.svg',
            export_selected=True
        )

# 导出所有曲线到目录
def export_all_curves_to_directory(output_dir):
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    curves = [obj for obj in bpy.data.objects if obj.type == 'CURVE']
    for curve in curves:
        bpy.ops.object.select_all(action='DESELECT')
        curve.select_set(True)
        bpy.context.view_layer.objects.active = curve
        filepath = os.path.join(output_dir, f'{curve.name}.svg')
        bpy.ops.export_curve.svg(filepath=filepath, export_selected=True)
```

## 实用函数

```python
def export_selected_as_svg(filepath, scale=1.0):
    """导出选中的曲线为SVG"""
    bpy.ops.export_curve.svg(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=True,
        scale=scale
    )

def export_all_curves_as_svg(filepath):
    """导出所有曲线为SVG"""
    bpy.ops.export_curve.svg(
        filepath=filepath,
        export_selected=False,
        apply_modifiers=True
    )

def export_curves_to_dxf(filepath, selected_only=True, version='R12'):
    """导出曲线为DXF格式"""
    bpy.ops.export_curve.dxf(
        filepath=filepath,
        export_selected=selected_only,
        version=version
    )

def export_to_ai(filepath, resolution=12, selected_only=True):
    """导出为Adobe Illustrator格式"""
    bpy.ops.export_curve.ai(
        filepath=filepath,
        export_selected=selected_only,
        resolution=resolution
    )

def export_curve_with_options(filepath, format='svg', **options):
    """使用自定义选项导出曲线"""
    if format == 'svg':
        bpy.ops.export_curve.svg(filepath=filepath, **options)
    elif format == 'dxf':
        bpy.ops.export_curve.dxf(filepath=filepath, **options)
    elif format == 'ai':
        bpy.ops.export_curve.ai(filepath=filepath, **options)
    else:
        raise ValueError(f'不支持的格式: {format}')

def export_nurbs_to_spline(filepath):
    """将NURBS曲面导出为样条曲线SVG"""
    # 转换为贝塞尔曲线
    for obj in bpy.context.selected_objects:
        if obj.type == 'SURFACE':
            bpy.ops.object.convert(target='CURVE')
    
    bpy.ops.export_curve.svg(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=True
    )
```

## 常见问题排查

### 导出为空
```python
# 检查选中的曲线
curves = [obj for obj in bpy.context.selected_objects if obj.type == 'CURVE']
print(f"选中曲线数: {len(curves)}")

# 检查所有曲线
all_curves = [obj for obj in bpy.data.objects if obj.type == 'CURVE']
print(f"总曲线数: {len(all_curves)}")

# 确保曲线有数据
for curve in all_curves:
    print(f"曲线点数: {sum(len(spline.bezier_points) if spline.type == 'BEZIER' else len(spline.points) for spline in curve.data.splines)}")

# 取消隐藏
for curve in all_curves:
    curve.hide_viewport = False
```

### 导出比例错误
```python
# 检查导出比例
bpy.ops.export_curve.svg(filepath='//test.svg', scale=1.0)

# 检查对象缩放
obj = bpy.context.active_object
print(f"对象缩放: {obj.scale}")

# 应用变换
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

# 重新导出
bpy.ops.export_curve.svg(filepath='//corrected.svg', scale=1.0)
```

### 导出格式不支持
```python
# 检查导出格式
print("支持的格式: SVG, DXF, AI")

# 检查版本兼容性
bpy.ops.export_curve.dxf(filepath='//test.dxf', version='R12')

# 尝试不同版本
for version in ['R12', 'R14', 'R2000', 'R2004', 'R2007', 'R2010', 'R2013', 'R2018']:
    try:
        bpy.ops.export_curve.dxf(filepath=f'//test_{version}.dxf', version=version)
        print(f"版本 {version} 可用")
    except:
        print(f"版本 {version} 不可用")
```
