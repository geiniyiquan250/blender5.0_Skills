# bpy.ops.paint.texture - 纹理绘画操作模块

bpy.ops.paint.texture模块提供了纹理绘制（ texture paint）模式下的操作功能，用于直接在模型上绘制纹理。

## 概述

纹理绘制是Blender中直接在3D模型表面绘制颜色和细节的功能。这个模块提供了笔刷控制、颜色选择和绘制操作。

## 核心功能

### 笔刷设置

```python
import bpy

def set_brush_size(size):
    """设置笔刷大小"""
    bpy.context.tool_settings.image_paint.brush.size = size

def set_brush_strength(strength):
    """设置笔刷强度"""
    bpy.context.tool_settings.image_paint.brush.strength = strength

def set_brush_color(color):
    """设置笔刷颜色"""
    bpy.context.tool_settings.image_paint.brush.color = color

def set_brush_blur(blur):
    """设置笔刷模糊"""
    bpy.context.tool_settings.image_paint.brush.blur = blur
```

### 绘制操作

```python
def paint_brush():
    """绘制笔刷"""
    bpy.ops.paint.texture_paint_toggle()
    bpy.ops.paint.brush_colors_flip()

def sample_color():
    """采样颜色"""
    bpy.ops.paint.sample_brush_color(
        location=bpy.context.region.view2d.region_to_view(
            bpy.context.region.x,
            bpy.context.region.y
        )
    )

def clone_source():
    """设置克隆源"""
    bpy.ops.paint.clone_image_set()
```

### 选择操作

```python
def select_all():
    """全选"""
    bpy.ops.paint.select_all(action='SELECT')

def deselect_all():
    """取消全选"""
    bpy.ops.paint.select_all(action='DESELECT')

def invert_selection():
    """反选"""
    bpy.ops.paint.select_all(action='INVERT')

def select_circle(x, y, radius):
    """圆形选择"""
    bpy.ops.paint.face_select_border(
        x=x,
        y=y,
        radius=radius,
        mode='SET'
    )
```

## 实用函数

### 遮罩操作

```python
def add_mask():
    """添加遮罩"""
    bpy.ops.paint.add_orco_mask()

def clear_mask():
    """清除遮罩"""
    bpy.ops.paint.clear_orco_mask()

def invert_mask():
    """反相遮罩"""
    bpy.ops.paint.invert_orco_mask()
```

### 绘制工具

```python
def grab_tool():
    """抓取工具"""
    bpy.ops.paint.grab_clone()

def smudge_tool():
    """涂抹工具"""
    bpy.context.tool_settings.image_paint.brush.mask_tool = 'SMEAR'

def deformer_tool():
    """变形工具"""
    bpy.context.tool_settings.image_paint.brush.mask_tool = 'DEFORM'
```

## 常见问题排查

### 绘制问题

笔刷无响应：
- 确认纹理可编辑
- 检查UV是否正确
- 验证笔刷设置

### 颜色问题

颜色不准确：
- 检查颜色空间设置
- 确认纹理格式支持
- 验证颜色管理设置
