# bpy.app.icons - Application Icons Module

Blender 图标系统，用于加载和管理自定义图标。

## Overview

`bpy.app.icons` 模块提供了访问 Blender 内置图标和加载自定义图标的功能。这个模块主要用于插件开发中添加自定义 UI 图标。

## 关键概念

### 图标生命周期
- 图标在加载时注册到 Blender
- 需要手动管理图标生命周期避免内存泄漏
- 多个地方可以引用同一个图标

### 图标来源
- Blender 内置图标
- 外部图像文件（支持多种格式）
- 程序生成的图标数据

## 主要功能

### 加载图标

```python
import bpy

# 加载单个图标文件
icon = bpy.app.icons.load(filepath)

# 从图像数据加载图标
import bpy.path
filepath = bpy.path.abspath("//icons/my_icon.png")
icon = bpy.app.icons.load(filepath)

# 加载系列图标（用于动画图标）
def load_icon_series():
    """加载图标序列"""
    icons = []
    for i in range(10):
        filepath = f"//icons/frame_{i:03d}.png"
        try:
            icon = bpy.app.icons.load(filepath)
            icons.append(icon)
            print(f"已加载帧 {i}: {icon.icon_id}")
        except Exception as e:
            print(f"加载帧 {i} 失败: {e}")
    return icons
```

### 批量加载图标

```python
def load_all_icons_from_directory(directory_path):
    """从目录加载所有图标"""
    import os
    from pathlib import Path
    
    icons = {}
    dir_path = Path(directory_path)
    
    if not dir_path.exists():
        print(f"目录不存在: {directory_path}")
        return icons
    
    supported_formats = {'.png', '.jpg', '.jpeg', '.bmp', '.tga'}
    
    for file_path in dir_path.iterdir():
        if file_path.suffix.lower() in supported_formats:
            try:
                icon = bpy.app.icons.load(str(file_path))
                icons[file_path.stem] = icon
                print(f"已加载: {file_path.name} (ID: {icon.icon_id})")
            except Exception as e:
                print(f"加载 {file_path.name} 失败: {e}")
    
    return icons

# 使用示例
# all_icons = load_all_icons_from_directory("//icons")
```

### 清理图标

```python
def clear_icons(icons_dict):
    """清理图标资源"""
    for name, icon in icons_dict.items():
        if icon and hasattr(icon, 'clear'):
            icon.clear()
            print(f"已清理图标: {name}")
    
    icons_dict.clear()

class IconManager:
    """图标管理器"""
    
    def __init__(self):
        self.icons = {}
        self.custom_icons = {}
    
    def load_icon(self, name, filepath):
        """加载并缓存图标"""
        if name in self.icons:
            print(f"图标 {name} 已存在，跳过加载")
            return self.icons[name]
        
        try:
            icon = bpy.app.icons.load(filepath)
            self.icons[name] = icon
            print(f"已加载图标: {name} (ID: {icon.icon_id})")
            return icon
        except Exception as e:
            print(f"加载图标 {name} 失败: {e}")
            return None
    
    def load_icon_series(self, name, start, end, format_str):
        """加载图标序列"""
        if name in self.custom_icons:
            return self.custom_icons[name]
        
        icons = []
        for i in range(start, end + 1):
            filepath = format_str.format(i)
            icon = bpy.app.icons.load(filepath)
            if icon:
                icons.append(icon)
        
        self.custom_icons[name] = icons
        return icons
    
    def get_icon(self, name):
        """获取已加载的图标"""
        return self.icons.get(name)
    
    def clear_all(self):
        """清理所有图标"""
        for icon in self.icons.values():
            if icon and hasattr(icon, 'clear'):
                try:
                    icon.clear()
                except:
                    pass
        
        for icons in self.custom_icons.values():
            for icon in icons:
                if icon and hasattr(icon, 'clear'):
                    try:
                        icon.clear()
                    except:
                        pass
        
        self.icons.clear()
        self.custom_icons.clear()
        print("已清理所有图标")
```

### 在 UI 中使用图标

```python
import bpy
from bpy.props import EnumProperty

class CustomIconsOperator(bpy.types.Operator):
    """自定义图标操作符"""
    bl_idname = "object.custom_icons_demo"
    bl_label = "图标演示"
    
    icon_enum: EnumProperty(
        name="选择图标",
        items=[
            ('ICON1', "图标 1", "第一个自定义图标"),
            ('ICON2', "图标 2", "第二个自定义图标"),
            ('ICON3', "图标 3", "第三个自定义图标"),
        ]
    )
    
    def execute(self, context):
        icon_name = self.icon_enum
        print(f"选择了图标: {icon_name}")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "icon_enum")
        
        # 预览图标
        icon = bpy.app.icons.get(self.icon_enum)
        if icon:
            layout.template_icon(icon_value=icon.icon_id, scale=3.0)

# 注册面板中使用图标
class CustomIconsPanel(bpy.types.Panel):
    """自定义图标面板"""
    bl_label = "图标预览"
    bl_idname = "OBJECT_PT_custom_icons"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '自定义'
    
    def draw(self, context):
        layout = self.layout
        
        # 加载并显示图标
        icon_path = "//icons/custom_icon.png"
        icon = bpy.app.icons.load(icon_path)
        
        if icon:
            layout.template_icon(icon_value=icon.icon_id, scale=5.0)
            layout.label(text=f"图标 ID: {icon.icon_id}")
        else:
            layout.label(text="图标加载失败", icon='ERROR')
        
        # 图标按钮
        layout.operator("object.custom_icons_demo", icon_value=icon.icon_id if icon else 0)
```

## 高级用法

### 动态图标生成

```python
import bpy
import gpu
import bpy.path

def create_dynamic_icon(size=64):
    """创建动态图标"""
    import numpy as np
    from gpu import GPUOffScreen
    
    # 创建离屏渲染
    offscreen = gpu.offscreen_new(width=size, height=size)
    
    with offscreen.bind():
        # 清除背景
        from gpu import state
        state.color_mask_set(True, True, True, True)
        state.clear_color(0.0, 0.0, 0.0, 0.0)
        state.clear(buffers={'COLOR'})
        
        # 绘制简单图形
        # 这里可以添加自定义绘制代码
    
    # 保存到文件
    output_path = bpy.path.abspath("//icons/dynamic_icon.png")
    
    return offscreen, output_path

class DynamicIconGenerator:
    """动态图标生成器"""
    
    def __init__(self, size=64):
        self.size = size
        self.icons = {}
    
    def generate_gradient_icon(self, name, colors, direction='horizontal'):
        """生成渐变图标"""
        import numpy as np
        from PIL import Image
        
        # 创建图像数据
        img_data = np.zeros((self.size, self.size, 4), dtype=np.uint8)
        
        for y in range(self.size):
            for x in range(self.size):
                if direction == 'horizontal':
                    t = x / (self.size - 1)
                else:
                    t = y / (self.size - 1)
                
                r = int(colors[0][0] * (1 - t) + colors[1][0] * t)
                g = int(colors[0][1] * (1 - t) + colors[1][1] * t)
                b = int(colors[0][2] * (1 - t) + colors[1][2] * t)
                
                img_data[y, x] = [r, g, b, 255]
        
        # 保存临时文件
        temp_path = bpy.path.abspath(f"//temp_icon_{name}.png")
        Image.fromarray(img_data).save(temp_path)
        
        # 加载图标
        icon = bpy.app.icons.load(temp_path)
        self.icons[name] = icon
        
        return icon
```

### 图标缓存管理

```python
class IconCache:
    """图标缓存管理器"""
    
    def __init__(self, max_size=100):
        self.cache = {}
        self.access_order = []
        self.max_size = max_size
    
    def get(self, key):
        """获取图标"""
        if key in self.cache:
            # 更新访问顺序
            self.access_order.remove(key)
            self.access_order.append(key)
            return self.cache[key]
        return None
    
    def put(self, key, icon):
        """添加图标到缓存"""
        if len(self.cache) >= self.max_size:
            # 移除最久未使用的图标
            oldest_key = self.access_order.pop(0)
            old_icon = self.cache.pop(oldest_key)
            if old_icon and hasattr(old_icon, 'clear'):
                try:
                    old_icon.clear()
                except:
                    pass
        
        self.cache[key] = icon
        self.access_order.append(key)
    
    def preload_icons(self, icon_list):
        """预加载图标"""
        for name, path in icon_list:
            if name not in self.cache:
                try:
                    icon = bpy.app.icons.load(path)
                    self.put(name, icon)
                    print(f"预加载图标: {name}")
                except Exception as e:
                    print(f"预加载图标 {name} 失败: {e}")
    
    def clear_cache(self):
        """清空缓存"""
        for icon in self.cache.values():
            if icon and hasattr(icon, 'clear'):
                try:
                    icon.clear()
                except:
                    pass
        self.cache.clear()
        self.access_order.clear()
```

## 最佳实践

### 1. 图标文件管理
```python
# 集中管理图标路径
ICON_PATHS = {
    'custom_add': "//icons/custom_add.png",
    'custom_remove': "//icons/custom_remove.png",
    'custom_export': "//icons/custom_export.png",
}

def load_all_plugin_icons():
    """加载插件所有图标"""
    manager = IconManager()
    for name, path in ICON_PATHS.items():
        manager.load_icon(name, path)
    return manager
```

### 2. 错误处理
```python
def safe_load_icon(filepath, fallback=None):
    """安全加载图标"""
    try:
        icon = bpy.app.icons.load(filepath)
        return icon
    except FileNotFoundError:
        print(f"图标文件不存在: {filepath}")
        return fallback
    except Exception as e:
        print(f"加载图标失败: {e}")
        return fallback
```

### 3. 资源清理
```python
# 在插件注销时清理图标
def unregister():
    global icon_manager
    if icon_manager:
        icon_manager.clear_all()
```

## 常见问题

### Q: 图标不显示
A: 检查文件路径是否正确，确认图标文件存在且格式支持。

### Q: 内存使用过高
A: 使用图标缓存管理，避免重复加载相同图标，及时清理不再使用的图标。

### Q: 图标显示模糊
A: 使用足够大的图标尺寸（推荐 64x64 或更大），UI 会自动缩放。

## 性能优化

1. **预加载常用图标**：在插件初始化时预加载
2. **使用图标缓存**：避免重复加载相同图标
3. **及时清理资源**：在不需要时清理图标
4. **选择合适格式**：优先使用 PNG 格式支持透明通道

## 相关模块

- [bpy.app.timers](bpy_app_timers_module.md) - 应用程序定时器
- [bpy.app.handlers](bpy_app_handlers_module.md) - 应用程序事件处理器
- [bpy_extras](bpy_extras_module.md) - 额外工具函数
