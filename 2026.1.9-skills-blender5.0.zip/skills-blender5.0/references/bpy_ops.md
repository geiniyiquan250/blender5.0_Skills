# bpy.ops Operators Reference

Complete reference for all Blender operators organized by category.

## Mesh Operators (bpy.ops.mesh)

### Creation

- `primitive_cube_add()` - Add cube
- `primitive_uv_sphere_add()` - Add UV sphere
- `primitive_ico_sphere_add()` - Add icosphere
- `primitive_cylinder_add()` - Add cylinder
- `primitive_cone_add()` - Add cone
- `primitive_torus_add()` - Add torus
- `primitive_grid_add()` - Add grid
- `primitive_monkey_add()` - Add monkey
- `primitive_plane_add()` - Add plane
- `primitive_circle_add()` - Add circle

### Editing

- `delete()` - Delete selected elements
- `duplicate()` - Duplicate selected elements
- `extrude_region_move()` - Extrude region
- `extrude_manifold()` - Extrude manifold
- `inset()` - Inset faces
- `bevel()` - Bevel edges
- `bisect()` - Bisect mesh
- `knife_project()` - Knife project
- `knife_cut()` - Knife cut
- `rip()` - Rip mesh
- `split()` - Split mesh
- `merge()` - Merge elements
- `separate()` - Separate mesh
- `join()` - Join meshes

### Modification

- `smooth()` - Smooth mesh
- `shrink_fatten()` - Shrink/fatten mesh
- `push_pull()` - Push/pull vertices
- `normals_make_consistent()` - Make normals consistent
- `flip_normals()` - Flip normals
- `recalculate_inside()` - Recalculate inside
- `recalculate_outside()` - Recalculate outside

### UV Mapping

- `uv_reset()` - Reset UV
- `uv_sphere_project()` - Sphere project UV
- `uv_cylinder_project()` - Cylinder project UV
- `uv_cube_project()` - Cube project UV

## Object Operators (bpy.ops.object)

### Creation

- `add()` - Add new object
- `duplicate()` - Duplicate object
- `duplicate_move()` - Duplicate and move
- `duplicate_move_linked()` - Duplicate linked
- `join()` - Join objects
- `separate()` - Separate objects

### Transformation

- `location_clear()` - Clear location
- `rotation_clear()` - Clear rotation
- `scale_clear()` - Clear scale
- `origin_clear()` - Clear origin
- `origin_set()` - Set origin
- `transform_apply()` - Apply transform

### Display

- `hide_view_clear()` - Clear hide view
- `hide_view_set()` - Set hide view
- `hide_render_clear()` - Clear hide render
- `hide_render_set()` - Set hide render
- `show_all()` - Show all objects
- `hide_all()` - Hide all objects

### Selection

- `select_all()` - Select all objects
- `deselect_all()` - Deselect all objects
- `select_by_type()` - Select by type
- `select_by_layer()` - Select by layer
- `select_same()` - Select same

### Parenting

- `parent_set()` - Set parent
- `parent_clear()` - Clear parent

### Collection

- `collection_link()` - Link to collection
- `collection_unlink()` - Unlink from collection
- `collection_objects_link()` - Link objects to collection
- `collection_instance_add()` - Add collection instance

## Material Operators (bpy.ops.material)

### Creation

- `new()` - Create new material
- `copy()` - Copy material
- `paste()` - Paste material

### Assignment

- `assign()` - Assign material to selection
- `select_all()` - Select all materials

### Slot Operations

- `slot_add()` - Add material slot
- `slot_remove()` - Remove material slot
- `slot_copy()` - Copy material slot
- `slot_paste()` - Paste material slot

## Texture Operators (bpy.ops.texture)

### Creation

- `new()` - Create new texture
- `copy()` - Copy texture

### Slot Operations

- `slot_add()` - Add texture slot
- `slot_remove()` - Remove texture slot

## Render Operators (bpy.ops.render)

### Rendering

- `render()` - Render scene
- `render_animation()` - Render animation
- `view_cancel()` - Cancel render
- `play_rendered_anim()` - Play rendered animation

### Settings

- `preset_add()` - Add render preset
- `preset_add_experimental()` - Add experimental preset

### View

- `view_show()` - Show render view
- `view_cancel()` - Cancel render view

## Node Operators (bpy.ops.node)

### Creation

- `add()` - Add node
- `add_search()` - Add node from search
- `link()` - Link nodes
- `link_make()` - Make link
- `link_cut()` - Cut link
- `link_detach()` - Detach link

### Editing

- `delete()` - Delete node
- `duplicate()` - Duplicate node
- `group_make()` - Make group
- `group_ungroup()` - Ungroup
- `group_insert()` - Insert group
- `group_edit()` - Edit group
- `group_exit()` - Exit group edit
- `read_sample()` - Read sample
- `read_viewlayers()` - Read view layers
- `read_fullsampled_layers()` - Read full sampled layers

### Organization

- `attach()` - Attach nodes
- `detach()` - Detach nodes
- `join()` - Join nodes
- `hide()` - Hide node
- `mute_toggle()` - Toggle mute
- `preview_toggle()` - Toggle preview
- `options_toggle()` - Toggle options
- `inputs_show()` - Show inputs
- `outputs_show()` - Show outputs
- `copy_color()` - Copy color
- `paste_color()` - Paste color

## Animation Operators (bpy.ops.anim)

### Keyframing

- `keyframe_insert()` - Insert keyframe
- `keyframe_delete()` - Delete keyframe
- `keyframe_insert_menu()` - Insert keyframe menu
- `keyframe_delete_v3d()` - Delete keyframe in 3D view

### Playback

- `play()` - Play animation
- `stop()` - Stop animation
- `pause()` - Pause animation

### Navigation

- `frame_jump()` - Jump to frame
- `frame_next()` - Next frame
- `frame_prev()` - Previous frame
- `end_frame_set()` - Set end frame
- `start_frame_set()` - Set start frame

## Scene Operators (bpy.ops.scene)

### Management

- `new()` - Create new scene
- `delete()` - Delete scene
- `duplicate()` - Duplicate scene

### Operations

- `add()` - Add scene
- `remove()` - Remove scene
- `link()` - Link scene

## File Operators (bpy.ops.file)

### Import

- `import_scene()` - Import scene
- `import_obj()` - Import OBJ
- `import_fbx()` - Import FBX
- `import_collada()` - Import Collada
- `import_blend()` - Import blend
- `import_svg()` - Import SVG
- `import_stl()` - Import STL
- `import_ply()` - Import PLY

### Export

- `export_scene()` - Export scene
- `export_obj()` - Export OBJ
- `export_fbx()` - Export FBX
- `export_collada()` - Export Collada
- `export_blend()` - Export blend
- `export_svg()` - Export SVG
- `export_stl()` - Export STL
- `export_ply()` - Export PLY

### File Operations

- `open()` - Open file
- `save()` - Save file
- `save_as()` - Save as
- `save_mainfile()` - Save main file
- `save_mainfile_as()` - Save main file as
- `save_incremental()` - Save incremental
- `recover_auto_save()` - Recover auto save
- `recover_last_session()` - Recover last session
- `reload()` - Reload file
- `close()` - Close file
- `quit()` - Quit Blender

## Screen Operators (bpy.ops.screen)

### Management

- `new()` - Create new screen
- `delete()` - Delete screen
- `duplicate()` - Duplicate screen
- `area_join()` - Join areas
- `area_split()` - Split areas
- `area_options()` - Area options
- `region_quadview()` - Quad view
- `region_scale()` - Scale region
- `region_flip()` - Flip region
- `screen_full_area()` - Full area
- `screen_set()` - Set screen
- `screen_set_quadview()` - Set quadview
- `screenshot()` - Screenshot
- `userpref_show()` - Show user preferences
- `spacedata_cleanup()` - Space data cleanup
- `workspace_to_scene()` - Workspace to scene

## UI Operators (bpy.ops.ui)

### Interface

- `reorder_to_front()` - Reorder to front
- `reorder_to_back()` - Reorder to back
- `reorder_to_top()` - Reorder to top
- `reorder_to_bottom()` - Reorder to bottom
- `copy_to_region()` - Copy to region
- `copy_data_path_button()` - Copy data path
- `drop_material()` - Drop material
- `drop_image()` - Drop image
- `drop_world()` - Drop world

### Menus

- `reports_to_textblock()` - Reports to text block
- `view2d_zoom()` - 2D view zoom
- `view2d_pan()` - 2D view pan
- `view2d_scroller_activate()` - Activate 2D scroller

## View2D Operators (bpy.ops.view2d)

### Navigation

- `pan()` - Pan view
- `zoom()` - Zoom view
- `zoom_in()` - Zoom in
- `zoom_out()` - Zoom out
- `zoom_border()` - Zoom border
- `scroll_down()` - Scroll down
- `scroll_up()` - Scroll up
- `scroll_left()` - Scroll left
- `scroll_right()` - Scroll right
- `zoom_ratio()` - Zoom ratio
- `reset()` - Reset view

## View3D Operators (bpy.ops.view3d)

### Navigation

- `rotate()` - Rotate view
- `pan()` - Pan view
- `zoom()` - Zoom view
- `zoom_in()` - Zoom in
- `zoom_out()` - Zoom out
- `dolly()` - Dolly view
- `fly()` - Fly view
- `walk()` - Walk view
- `roll()` - Roll view
- `orbit()` - Orbit view
- `move()` - Move view
- `ndof()` - NDOF navigation
- `view_all()` - View all
- `view_center()` - Center view
- `view_lock()` - Lock view
- `view_lock_clear()` - Clear view lock
- `camera_to_view()` - Camera to view
- `view_to_camera()` - View to camera
- `localview_set()` - Set local view
- `localview_clear()` - Clear local view

### Display

- `view_persportho()` - Perspective/orthographic
- `background_image_add()` - Add background image
- `background_image_remove()` - Remove background image
- `clip_border()` - Clip border
- `render_border()` - Render border
- `clear_render_border()` - Clear render border
- `home()` - Home view
- `smoothview()` - Smooth view
- `properties()` - Properties
- `toolshelf()` - Tool shelf

## Script Operators (bpy.ops.script)

### Execution

- `execute()` - Execute script
- `python_file_run()` - Run Python file
- `text_run()` - Run text block

### Management

- `reload()` - Reload scripts
- `auto_execute_py()` - Auto execute Python

## Console Operators (bpy.ops.console)

### Operations

- `clear()` - Clear console
- `copy()` - Copy console
- `paste()` - Paste to console
- `scrollback_append()` - Append scrollback
- `history_cycle()` - Cycle history
- `indent()` - Indent
- `unindent()` - Unindent

## Text Operators (bpy.ops.text)

### File Operations

- `new()` - New text block
- `open()` - Open text file
- `save()` - Save text
- `save_as()` - Save text as
- `reload()` - Reload text

### Editing

- `cut()` - Cut text
- `copy()` - Copy text
- `paste()` - Paste text
- `duplicate_line()` - Duplicate line
- `delete()` - Delete text
- `join_lines()` - Join lines
- `split_lines()` - Split lines
- `move()` - Move text
- `line_break()` - Line break
- `line_number()` - Line number
- `jump()` - Jump to line
- `find()` - Find text
- `replace()` - Replace text
- `to_3d_object()` - Text to 3D object

## Image Operators (bpy.ops.image)

### File Operations

- `new()` - New image
- `open()` - Open image
- `save()` - Save image
- `save_as()` - Save image as
- `save_sequence()` - Save sequence
- `save_all_modified()` - Save all modified
- `reload()` - Reload image

### Editing

- `invert()` - Invert image
- `flip()` - Flip image
- `resize()` - Resize image
- `scale()` - Scale image
- `crop()` - Crop image
- `clear()` - Clear image
- `fill()` - Fill image

## Sound Operators (bpy.ops.sound)

### File Operations

- `open()` - Open sound
- `open_mono()` - Open mono sound
- `pack()` - Pack sound
- `unpack()` - Unpack sound

## Camera Operators (bpy.ops.camera)

### Creation

- `add()` - Add camera

### Operations

- `presets_add()` - Add camera preset
- `presets_add_experimental()` - Add experimental preset

## Light Operators (bpy.ops.light)

### Creation

- `add()` - Add light
- `add_point()` - Add point light
- `add_sun()` - Add sun light
- `add_spot()` - Add spot light
- `add_area()` - Add area light
- `add_hemi()` - Add hemi light

### Operations

- `presets_add()` - Add light preset

## World Operators (bpy.ops.world)

### Creation

- `new()` - Create new world

### Operations

- `new()` - Create new world

## Collection Operators (bpy.ops.collection)

### Management

- `create()` - Create collection
- `remove()` - Remove collection
- `objects_add()` - Add objects to collection
- `objects_remove()` - Remove objects from collection
- `objects_remove_all()` - Remove all objects from collection
- `objects_move_to_active()` - Move objects to active collection
- `objects_move_to_index()` - Move objects to index
- `objects_move_to_other_collection()` - Move to other collection
- `objects_select_all()` - Select all objects in collection
- `objects_deselect_all()` - Deselect all objects in collection
- `link_to_scene()` - Link to scene
- `unlink_from_scene()` - Unlink from scene

## Outliner Operators (bpy.ops.outliner)

### Operations

- `collection_drop()` - Drop collection
- `object_drop()` - Drop object
- `id_copy()` - Copy ID
- `id_paste()` - Paste ID
- `id_delete()` - Delete ID
- `orphans_purge()` - Purge orphans
- `show_active()` - Show active
- `show_one_level()` - Show one level
- `show_hierarchy()` - Show hierarchy

## Constraint Operators (bpy.ops.constraint)

### Creation

- `add()` - Add constraint
- `add_target()` - Add target

### Operations

- `delete()` - Delete constraint
- `limit_reset()` - Reset limit
- `limit_distance_reset()` - Reset distance limit
- `limit_rotation_reset()` - Reset rotation limit
- `limit_scale_reset()` - Reset scale limit

## Modifier Operators (bpy.ops.modifier)

### Creation

- `add()` - Add modifier
- `copy()` - Copy modifier
- `paste()` - Paste modifier

### Operations

- `move_up()` - Move up
- `move_down()` - Move down
- `apply_as_shapekey()` - Apply as shape key
- `apply()` - Apply modifier
- `copy_to_selected()` - Copy to selected
- `remove()` - Remove modifier

## Pose Operators (bpy.ops.pose)

### Operations

- `hide()` - Hide pose
- `reveal()` - Reveal pose
- `select_all()` - Select all
- `deselect_all()` - Deselect all
- `select_linked()` - Select linked
- `select_hierarchy()` - Select hierarchy
- `select_parent()` - Select parent
- `select_grouped()` - Select grouped

### Transform

- `push()` - Push pose
- `relax()` - Relax pose
- `break_down()` - Break down

### Libraries

- `paste()` - Paste pose
- `blend_to_scene()` - Blend to scene
- `blend_to_scene_selected()` - Blend to scene selected
- `select_prev()` - Select previous
- `select_next()` - Select next

## NLA Operators (bpy.ops.nla)

### Operations

- `action_pushdown()` - Push down action
- `action_unlink()` - Unlink action
- `action_clip_add()` - Add action clip
- `transition_add()` - Add transition
- `soundclip_add()` - Add sound clip
- `meta_add()` - Add meta
- `meta_remove()` - Remove meta
- `tracks_delete()` - Delete tracks
- `selected_action_add()` - Add selected action
- `selected_action_clip_add()` - Add selected action clip
- `selected_action_unlink()` - Unlink selected action
- `tweakmode_enter()` - Enter tweak mode
- `tweakmode_exit()` - Exit tweak mode

## Marker Operators (bpy.ops.marker)

### Operations

- `add()` - Add marker
- `delete()` - Delete marker
- `duplicate()` - Duplicate marker
- `move()` - Move marker
- `rename()` - Rename marker
- `select_all()` - Select all
- `deselect_all()` - Deselect all
- `make_links_scene()` - Make links to scene
- `jump()` - Jump to marker
- `camera_bind()` - Bind to camera

## Mask Operators (bpy.ops.mask)

### Creation

- `new()` - New mask
- `delete()` - Delete mask

### Editing

- `add_feather_vertex()` - Add feather vertex
- `add_feather_vertex_slide()` - Slide feather vertex
- `add_vertex()` - Add vertex
- `add_vertex_slide()` - Slide vertex
- `cyclic_toggle()` - Toggle cyclic
- `duplicate()` - Duplicate mask
- `slide_point()` - Slide point
- `slide_spline_curvature()` - Slide spline curvature
- `switch_direction()` - Switch direction

### Selection

- `select_all()` - Select all
- `deselect_all()` - Deselect all
- `select_less()` - Select less
- `select_more()` - Select more
- `select_next()` - Select next
- `select_prev()` - Select previous

## Paint Operators (bpy.ops.paint)

### Operations

- `weight_from_bones()` - Weight from bones
- `weight_sample()` - Sample weight
- `weight_sample_group()` - Sample weight group
- `weight_set()` - Set weight
- `weight_gradient()` - Weight gradient
- `weight_bone_limit()` - Bone weight limit
- `weight_bone_normalize()` - Normalize bone weight
- `weight_bone_auto_normalize()` - Auto normalize bone weight
- `weight_bone_remove()` - Remove bone weight
- `weight_vgroup_normalize()` - Normalize vertex group weight
- `weight_vgroup_remove()` - Remove vertex group weight
- `weight_vgroup_select()` - Select vertex group
- `weight_vgroup_deselect()` - Deselect vertex group
- `weight_vgroup_lock()` - Lock vertex group
- `weight_vgroup_unlock()` - Unlock vertex group
- `weight_vgroup_assign()` - Assign vertex group
- `weight_vgroup_unassign()` - Unassign vertex group
- `weight_vgroup_select_all()` - Select all vertex groups
- `weight_vgroup_deselect_all()` - Deselect all vertex groups
- `weight_vgroup_lock_all()` - Lock all vertex groups
- `weight_vgroup_unlock_all()` - Unlock all vertex groups
- `weight_clean()` - Clean weight
- `weight_normalize_all()` - Normalize all weights
- `weight_set()` - Set weight
- `weight_bake()` - Bake weight
- `weight_sample()` - Sample weight
- `weight_sample_group()` - Sample weight group

## Sculpt Operators (bpy.ops.sculpt)

### Operations

- `symmetrize()` - Symmetrize
- `optimize()` - Optimize
- `dirty_mask()` - Dirty mask

### Tools

- `brush_stroke()` - Brush stroke
- `set_persistent_base()` - Set persistent base

## Grease Pencil Operators (bpy.ops.gpencil)

### Drawing

- `draw()` - Draw
- `draw_on_back()` - Draw on back

### Editing

- `blank_frame_add()` - Add blank frame
- `active_frames_delete_all()` - Delete all active frames
- `frame_duplicate()` - Duplicate frame
- `frame_delete()` - Delete frame
- `layer_add()` - Add layer
- `layer_remove()` - Remove layer
- `layer_move()` - Move layer
- `layer_merge()` - Merge layer
- `layer_duplicate()` - Duplicate layer
- `layer_isolate()` - Isolate layer
- `layer_reveal()` - Reveal layer
- `layer_hide()` - Hide layer
- `layer_lock_all()` - Lock all layers
- `layer_unlock_all()` - Unlock all layers

### Stroke Editing

- `stroke_apply_width()` - Apply width
- `stroke_apply_strength()` - Apply strength
- `stroke_apply_hardness()` - Apply hardness
- `stroke_apply_randomness()` - Apply randomness
- `stroke_apply_spacing()` - Apply spacing
- `stroke_apply_thickness()` - Apply thickness
- `stroke_apply_uv_rotation()` - Apply UV rotation

### Selection

- `select_all()` - Select all
- `deselect_all()` - Deselect all
- `select_box()` - Box select
- `select_circle()` - Circle select
- `select_lasso()` - Lasso select
- `select_stroke()` - Stroke select

## Dynamic Paint Operators (bpy.ops.dpaint)

### Operations

- `brush_toggle()` - Toggle brush
- `sample_color()` - Sample color
- `new()` - New dynamic paint

## Vertex Paint Operators (bpy.ops.vertex_paint)

### Operations

- `draw()` - Draw
- `sample()` - Sample

## Texture Paint Operators (bpy.ops.texture_paint)

### Operations

- `bucket_fill()` - Bucket fill
- `sample_color()` - Sample color
- `get_color()` - Get color
- `tool_set()` - Set tool

## UV Operators (bpy.ops.uv)

### Mapping

- `reset()` - Reset UV
- `sphere_project()` - Sphere project
- `cylinder_project()` - Cylinder project
- `cube_project()` - Cube project
- `smart_project()` - Smart project
- `lightmap_pack()` - Lightmap pack
- `layout()` - Layout
- `unwrap()` - Unwrap
- `seams_from_islands()` - Seams from islands
- `seams_from_islands_mark()` - Mark seams from islands

### Editing

- `add()` - Add UV
- `remove()` - Remove UV
- `select_all()` - Select all
- `deselect_all()` - Deselect all
- `select_loop()` - Select loop
- `select_edge_ring()` - Select edge ring
- `select_linked()` - Select linked
- `select_pinned()` - Select pinned
- `weld()` - Weld UV
- `snap_cursor()` - Snap cursor
- `cursor_set()` - Set cursor
- `pack_islands()` - Pack islands

## Cloth Operators (bpy.ops.cloth)

### Simulation

- `preset_add()` - Add preset
- `preset_add_experimental()` - Add experimental preset

## Fluid Operators (bpy.ops.fluid)

### Simulation

- `preset_add()` - Add preset
- `preset_add_experimental()` - Add experimental preset

## Smoke Operators (bpy.ops.smoke)

### Simulation

- `preset_add()` - Add preset
- `preset_add_experimental()` - Add experimental preset

## Soft Body Operators (bpy.ops.soft_body)

### Simulation

- `preset_add()` - Add preset
- `preset_add_experimental()` - Add experimental preset

## Rigid Body Operators (bpy.ops.rigidbody)

### Simulation

- `preset_add()` - Add preset
- `preset_add_experimental()` - Add experimental preset

## Particle Operators (bpy.ops.particle)

### Creation

- `new()` - New particle system
- `delete()` - Delete particle system

### Editing

- `preset_add()` - Add preset
- `preset_add_experimental()` - Add experimental preset

## Cycles Operators (bpy.ops.cycles)

### Rendering

- `denoise_toggle()` - Toggle denoise
- `use_shading_nodes()` - Use shading nodes

## Edit Operators (bpy.ops.ed)

### Editing

- `undo()` - Undo
- `redo()` - Redo
- `undo_push()` - Push undo
- `redo_repeat()` - Repeat redo

## Transform Operators (bpy.ops.transform)

### Transformations

- `translate()` - Translate
- `rotate()` - Rotate
- `resize()` - Resize
- `scale()` - Scale
- `mirror()` - Mirror
- `bend()` - Bend
- `shear()` - Shear
- `push_pull()` - Push/pull
- `tosphere()` - To sphere
- `tosphere_gizmo()` - To sphere gizmo
- `skin_resize()` - Skin resize
- `edge_bevel()` - Edge bevel
- `edge_slide()` - Edge slide
- `vertex_slide()` - Vertex slide
- `vertex_random()` - Randomize vertices
- `vertex_smooth()` - Smooth vertices
- `transform()` - Transform
- `create_orientation()` - Create orientation
- `delete_orientation()` - Delete orientation

## Boid Operators (bpy.ops.boid)

### Creation

- `add()` - Add boid system

### Editing

- `preset_add()` - Add preset

## Metaball Operators (bpy.ops.mball)

### Creation

- `add_meta_ball()` - Add metaball

### Editing

- `delete_metaelems()` - Delete meta elements

## Lattice Operators (bpy.ops.lattice)

### Creation

- `add()` - Add lattice

### Editing

- `select_all()` - Select all
- `make_regular()` - Make regular

## Curve Operators (bpy.ops.curve)

### Creation

- `primitive_bezier_curve_add()` - Add bezier curve
- `primitive_bezier_circle_add()` - Add bezier circle
- `primitive_nurbs_curve_add()` - Add NURBS curve
- `primitive_nurbs_circle_add()` - Add NURBS circle
- `primitive_nurbs_path_add()` - Add NURBS path

### Editing

- `delete()` - Delete curve
- `duplicate()` - Duplicate curve
- `separate()` - Separate curve
- `cyclic_toggle()` - Toggle cyclic
- `decimate()` - Decimate curve
- `subdivide()` - Subdivide curve
- `smooth()` - Smooth curve
- `smooth_radius()` - Smooth radius
- `smooth_tilt()` - Smooth tilt
- `bevel()` - Bevel curve
- `extrude()` - Extrude curve
- `draw()` - Draw curve
- `pen()` - Pen curve
- `radius_set()` - Set radius

## Surface Operators (bpy.ops.surface)

### Creation

- `primitive_nurbs_surface_curve_add()` - Add NURBS surface curve
- `primitive_nurbs_surface_torus_add()` - Add NURBS surface torus
- `primitive_nurbs_surface_sphere_add()` - Add NURBS surface sphere
- `primitive_nurbs_surface_cylinder_add()` - Add NURBS surface cylinder
- `primitive_nurbs_surface_cube_add()` - Add NURBS surface cube
- `primitive_nurbs_surface_monkey_add()` - Add NURBS surface monkey

### Editing

- `resolution_set()` - Set resolution

## Font Operators (bpy.ops.font)

### Operations

- `open()` - Open font
- `unload()` - Unload font

## Palette Operators (bpy.ops.palette)

### Operations

- `add()` - Add palette
- `delete()` - Delete palette

## Brush Operators (bpy.ops.brush)

### Operations

- `add()` - Add brush
- `curve_preset_add()` - Add curve preset
- `reset()` - Reset brush

## Buttons Operators (bpy.ops.buttons)

### Operations

- `directed_box()` - Directed box
- `directed_circle()` - Directed circle
- `directed_cone()` - Directed cone
- `directed_cylinder()` - Directed cylinder

## Clip Operators (bpy.ops.clip)

### Editing

- `delete()` - Delete clip
- `select_all()` - Select all
- `select_box()` - Box select
- `select_circle()` - Circle select
- `select_lasso()` - Lasso select

## Action Operators (bpy.ops.action)

### Operations

- `new()` - New action
- `pushdown()` - Push down
- `unlink()` - Unlink
- `clean()` - Clean
- `clean_unused()` - Clean unused
- `layer_add()` - Add layer
- `layer_remove()` - Remove layer
- `layer_next()` - Next layer
- `layer_prev()` - Previous layer
- `layer_activate()` - Activate layer
- `layer_move()` - Move layer

## Pose Library Operators (bpy.ops.poselib)

### Operations

- `browse_interactive()` - Browse interactive
- `apply_pose()` - Apply pose
- `add()` - Add pose
- `unlink()` - Unlink pose

## Graph Operators (bpy.ops.graph)

### Editing

- `delete()` - Delete keyframes
- `duplicate()` - Duplicate keyframes
- `copy()` - Copy keyframes
- `paste()` - Paste keyframes
- `select_all()` - Select all
- `deselect_all()` - Deselect all
- `select_box()` - Box select
- `select_circle()` - Circle select
- `select_lasso()` - Lasso select
- `select_column_markers()` - Select column markers
- `select_leftright()` - Select left/right
- `select_more()` - Select more
- `select_less()` - Select less
- `view_all()` - View all
- `zoom()` - Zoom
- `zoom_in()` - Zoom in
- `zoom_out()` - Zoom out
- `pan()` - Pan

## Info Operators (bpy.ops.info)

### Operations

- `add_directed()` - Add directed
- `report_display()` - Display report

## Preferences Operators (bpy.ops.preferences)

### Operations

- `add()` - Add preferences
- `remove()` - Remove preferences
- `context_toggle()` - Toggle context
- `activate_section()` - Activate section
- `use_experiment_add()` - Add use experiment

## Workspace Operators (bpy.ops.workspace)

### Operations

- `add()` - Add workspace
- `delete()` - Delete workspace
- `duplicate()` - Duplicate workspace
- `append_activate()` - Append activate

## Asset Operators (bpy.ops.asset)

### Operations

- `open()` - Open asset
- `clear()` - Clear asset
- `library_refresh()` - Refresh library

## Gizmo Group Operators (bpy.ops.gizmogroup)

### Operations

- `add()` - Add gizmo group

## Armature Operators (bpy.ops.armature)

### Creation

- `add()` - Add armature

### Editing

- `select_all()` - Select all
- `deselect_all()` - Deselect all
- `select_hierarchy()` - Select hierarchy
- `select_linked()` - Select linked
- `select_less()` - Select less
- `select_more()` - Select more
- `select_parent()` - Select parent
- `select_mirror()` - Select mirror
- `align()` - Align

## Export Animation Operators (bpy.ops.export_anim)

### Export

- `fbx()` - Export FBX animation

## Export Scene Operators (bpy.ops.export_scene)

### Export

- `fbx()` - Export FBX scene
- `obj()` - Export OBJ scene
- `gltf()` - Export glTF scene

## Import Animation Operators (bpy.ops.import_anim)

### Import

- `fbx()` - Import FBX animation

## Import Curve Operators (bpy.ops.import_curve)

### Import

- `svg()` - Import SVG curve

## Import Scene Operators (bpy.ops.import_scene)

### Import

- `fbx()` - Import FBX scene
- `obj()` - Import OBJ scene
- `gltf()` - Import glTF scene
- `collada()` - Import Collada scene

## Point Cache Operators (bpy.ops.ptcache)

### Operations

- `bake()` - Bake point cache
- `bake_all()` - Bake all point caches

## Cache File Operators (bpy.ops.cachefile)

### Operations

- `open()` - Open cache file

## Extensions Operators (bpy.ops.extensions)

### Operations

- `update()` - Update extensions
- `update_all()` - Update all extensions
- `update_ui()` - Update UI extensions
- `repo_sync()` - Sync repository
- `repo_sync_all()` - Sync all repositories
- `install()` - Install extension
- `uninstall()` - Uninstall extension
- `disable()` - Disable extension
- `enable()` - Enable extension
- `show()` - Show extension

## Point Cloud Operators (bpy.ops.pointcloud)

### Operations

- `add()` - Add point cloud

## Spreadsheet Operators (bpy.ops.spreadsheet)

### Operations

- `add()` - Add spreadsheet
- `delete()` - Delete spreadsheet

## Text Editor Operators (bpy.ops.text_editor)

### Operations

- `find()` - Find
- `replace()` - Replace
- `jump()` - Jump
- `line_number()` - Line number

## Sequencer Operators (bpy.ops.sequencer)

### Editing

- `cut()` - Cut
- `copy()` - Copy
- `paste()` - Paste
- `delete()` - Delete
- `duplicate()` - Duplicate
- `split()` - Split
- `gap_insert()` - Insert gap
- `gap_remove()` - Remove gap
- `meta_toggle()` - Toggle meta
- `meta_make()` - Make meta
- `meta_separate()` - Separate meta
- `mute_toggle()` - Toggle mute
- `unmute()` - Unmute
- `lock_toggle()` - Toggle lock
- `unlock()` - Unlock
- `select_all()` - Select all
- `select_handles_all()` - Select all handles
- `select_side_of_frame()` - Select side of frame
- `select_box()` - Box select
- `select_linked_pick()` - Pick linked
- `select_linked_extend()` - Extend linked selection
- `select_more()` - Select more
- `select_less()` - Select less
- `select_active_side()` - Select active side
- `select_grouped()` - Select grouped
- `view_frame()` - View frame
- `view_zoom()` - Zoom view
- `view_all()` - View all
- `refresh_all()` - Refresh all
- `rebuild_proxy()` - Rebuild proxy
- `export_subtitles()` - Export subtitles
- `import_subtitles()` - Import subtitles

## Sculpt Curves Operators (bpy.ops.sculpt_curves)

### Operations

- `brush_stroke()` - Brush stroke

## Paint Curve Operators (bpy.ops.paintcurve)

### Operations

- `new()` - New paint curve
- `add()` - Add paint curve
- `delete()` - Delete paint curve
- `select_all()` - Select all
- `deselect_all()` - Deselect all

## Surface Operators (bpy.ops.surface)

### Operations

- `add()` - Add surface
- `delete()` - Delete surface

## Transform Operators (bpy.ops.transform)

### Operations

- `create_orientation()` - Create orientation
- `delete_orientation()` - Delete orientation
