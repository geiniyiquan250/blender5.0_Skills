# bpy.ops.geometry - 几何操作模块

Blender几何操作符，用于在3D视口中进行几何计算和变换。

## 概述

`bpy.ops.geometry` 模块提供用于执行几何计算、空间变换和几何数据分析的操作功能。这些操作对于程序化建模、几何处理和数学计算非常有用。

## 核心功能

### 距离测量

```python
import bpy
import math

# 计算两点之间的距离
bpy.ops.geometry.distance_measure(
    mode='POINTS',
    source_point=(0, 0, 0),
    target_point=(1, 1, 1)
)

# 测量选中对象之间的距离
bpy.ops.geometry.distance_measure(mode='OBJECTS')

# 测量边长
bpy.ops.geometry.distance_measure(mode='EDGES')

# 测量曲线的长度
bpy.ops.geometry.measure_length(
    target='ACTIVE_OBJECT'
)

# 测量表面积
bpy.ops.geometry.measure_area(
    target='ACTIVE_OBJECT'
)

# 测量体积
bpy.ops.geometry.measure_volume(
    target='ACTIVE_OBJECT'
)

# 测量角度
bpy.ops.geometry.measure_angle(
    vertex=(0, 0, 0),
    point1=(1, 0, 0),
    point2=(0, 1, 0)
)
```

### 空间变换

```python
# 绕任意轴旋转
bpy.ops.geometry.rotate(
    input_vector=(1, 0, 0),
    center=(0, 0, 0),
    axis=(0, 0, 1),
    angle=math.radians(45)
)

# 沿法线方向挤出
bpy.ops.geometry.extrude_along_normal(
    distance=1.0,
    steps=1
)

# 沿曲线挤出
bpy.ops.geometry.extrude_along_curve(
    curve='CurvePath'
)

# 沿路径变形
bpy.ops.geometry.deform_along_path(
    path='CurvePath'
)

# 镜像几何体
bpy.ops.geometry.mirror(
    mirror_axis='X',
    center=(0, 0, 0)
)

# 缩放沿轴
bpy.ops.geometry.scale_along_axis(
    factor=2.0,
    axis='Z'
)

# 投影到平面
bpy.ops.geometry.project_to_plane(
    plane_point=(0, 0, 0),
    plane_normal=(0, 0, 1)
)

# 投影到球面
bpy.ops.geometry.project_to_sphere(
    center=(0, 0, 0),
    radius=1.0
)
```

### 布尔运算

```python
# 几何体交集
bpy.ops.geometry.boolean_intersect(
    solver='FAST',
    tolerance=0.001
)

# 几何体并集
bpy.ops.geometry.boolean_union(
    solver='FAST'
)

# 几何体差集
bpy.ops.geometry.boolean_difference(
    solver='FAST',
    tolerance=0.001
)

# 切片操作
bpy.ops.geometry.slice(
    plane_point=(0, 0, 0),
    plane_normal=(0, 0, 1),
    fill_holes=True
)

# 切割几何体
bpy.ops.geometry.cut(
   切割_object='CutObject',
    use_fill=False
)

# 分离重叠
bpy.ops.geometry.split_overlap(
    precision=0.001
)

# 合并接近的顶点
bpy.ops.geometry.merge_vertices(
    distance=0.001
)
```

### 曲率计算

```python
# 计算平均曲率
bpy.ops.geometry.curvature(
    curvature_type='MEAN'
)

# 计算高斯曲率
bpy.ops.geometry.curvature(
    curvature_type='GAUSS'
)

# 计算主曲率
bpy.ops.geometry.curvature(
    curvature_type='PRINCIPAL'
)

# 计算法线
bpy.ops.geometry.recalculate_normals(
    inside=False,
    sharp_edges=True
)

# 计算切线
bpy.ops.geometry.recalculate_tangents(
    uv_layer='UVMap'
)

# 计算包围盒
bpy.ops.geometry.bounding_box(
    calc_center=True
)
```

### 三角化

```python
# 三角化网格
bpy.ops.geometry.triangulate(
    ngon_method='BEAUTY',
    quad_method='SHORTEST_DIAGONAL'
)

# 转换为三角面
bpy.ops.geometry.quads_convert_to_tris()

# 反三角化
bpy.ops.geometry.tris_to_quads()
```

### 细分曲面

```python
# 细分网格
bpy.ops.geometry.subdivide(
    number_cuts=1,
    smoothness=0.0,
    quadtri=False
)

# 细分边
bpy.ops.geometry.subdivide_edges(
    number_cuts=1,
    edge_percents={}
)

# 连线细分
bpy.ops.geometry.subdivide_edgeloop(
    number_cuts=1
)

# 冠层细分
bpy.ops.geometry.compactness(
    distance=1.0
)
```

### 修复操作

```python

# 移除孤立顶点
bpy.ops.geometry.remove_isolated_vertices()

# 移除零点
bpy.ops.geometry.remove_zero_size()

# 填充孔洞
bpy.ops.geometry.fill_holes(
    sides=4
)

# 修复法线方向
bpy.ops.geometry.fix_normals()

# 修复非流形
bpy.ops.geometry.fix_non_manifold(
    method='DISSOLVE'
)

# 修复自交
bpy.ops.geometry.fix_self_intersections()
```

### 网格分析

```python
# 检查网格质量
bpy.ops.geometry.mesh_quality(
    threshold=0.001
)

# 检查非流形
bpy.ops.geometry.find_non_manifold()

# 检查零点
bpy.ops.geometry.find_zero_size()

# 检查自交
bpy.ops.geometry.find_self_intersections()

# 检查非平面面
bpy.ops.geometry.find_non_planar_faces(
    threshold=0.001
)

# 检查细长面
bpy.ops.geometry.find_thin_faces(
    threshold=0.1
)

# 统计信息
bpy.ops.geometry.mesh_stats()
```

### 顶点组操作

```python
# 根据几何体选择创建顶点组
bpy.ops.geometry.select_to_vertex_group()

# 根据顶点组选择几何体
bpy.ops.geometry.vertex_group_to_select()

# 顶点组反转选择
bpy.ops.geometry.vertex_group_invert()

# 顶点组扩展选择
bpy.ops.geometry.vertex_group_expand(
    factor=1
)

# 顶点组收缩选择
bpy.ops.geometry.vertex_group_shrink(
    factor=1
)

# 顶点组平滑
bpy.ops.geometry.vertex_group_smooth(
    factor=0.5
)

# 顶点组复制
bpy.ops.geometry.vertex_group_copy()

# 顶点组从权重创建
bpy.ops.geometry.vertex_group_from_weights(
    threshold=0.5
)
```

## 实用函数

```python
def get_mesh_center(obj):
    """获取网格中心点"""
    if obj.type == 'MESH':
        return obj.location + obj.data.vertices[0].co
    return obj.location

def get_total_surface_area(obj):
    """计算总表面积"""
    if obj.type == 'MESH':
        return sum(p.area for p in obj.data.polygons)
    return 0.0

def get_total_volume(obj):
    """计算总体积"""
    if obj.type == 'MESH':
        return obj.data.volume
    return 0.0

def get_bounding_box(obj):
    """获取包围盒"""
    return obj.bound_box

def normalize_vector(vec):
    """归一化向量"""
    length = math.sqrt(sum(v**2 for v in vec))
    if length > 0:
        return tuple(v/length for v in vec)
    return (0, 0, 0)

def distance_between_points(p1, p2):
    """计算两点间距离"""
    return math.sqrt(sum((a-b)**2 for a, b in zip(p1, p2)))

def angle_between_vectors(v1, v2):
    """计算两向量夹角"""
    dot = sum(a*b for a, b in zip(v1, v2))
    mag1 = math.sqrt(sum(v**2 for v in v1))
    mag2 = math.sqrt(sum(v**2 for v in v2))
    if mag1 * mag2 > 0:
        return math.acos(dot / (mag1 * mag2))
    return 0.0

def project_point_to_plane(point, plane_point, plane_normal):
    """将点投影到平面"""
    v = tuple(p - pp for p, pp in zip(point, plane_point))
    d = sum(v * n for v, n in zip(v, plane_normal))
    return tuple(p - d * n for p, n in zip(point, plane_normal))
```

## 常见问题排查

### 布尔运算失败
```python
# 检查对象是否有有效几何体
obj = bpy.context.active_object
print(f"顶点数: {len(obj.data.vertices)}")
print(f"面数: {len(obj.data.polygons)}")

# 确保对象是网格类型
print(f"对象类型: {obj.type}")

# 尝试不同的求解器
bpy.ops.geometry.boolean_intersect(solver='EXACT')

# 简化几何体
bpy.ops.geometry.decimate(ratio=0.5)
```

### 曲率计算问题
```python
# 确保网格有足够的细分
print(f"面数: {len(bpy.context.active_object.data.polygons)}")

# 重新计算法线
bpy.ops.geometry.recalculate_normals()

# 检查网格质量
bpy.ops.geometry.mesh_quality(threshold=0.0001)
```

### 测量数据不准确
```python
# 确保单位正确
print(f"场景单位: {bpy.context.scene.unit_settings.system}")

# 使用正确的缩放
obj = bpy.context.active_object
scale = obj.scale
print(f"对象缩放: {scale}")

# 应用变换
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
```
