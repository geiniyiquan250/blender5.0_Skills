# bpy.ops.keying_set - 关键帧设置操作模块

Blender关键帧设置操作符，用于管理和批量设置关键帧。

## 概述

`bpy.ops.keying_set` 模块提供用于创建、编辑和管理关键帧设置的功能。关键帧设置允许您批量为多个属性设置关键帧。

## 核心功能

### 关键帧设置创建

```python
import bpy

# 创建新关键帧设置
bpy.ops.keying_set.new(
    name='MyKeyingSet',
    type='INSERT'
)

# 创建插入关键帧设置
bpy.ops.keying_set.new(
    name='InsertAll',
    type='INSERT'
)

# 创建覆盖关键帧设置
bpy.ops.keying_set.new(
    name='OverrideAll',
    type='OVERRIDE'
)

# 创建清除关键帧设置
bpy.ops.keying_set.new(
    name='ClearAll',
    type='CLEAR'
)
```

### 关键帧设置操作

```python
# 删除关键帧设置
bpy.ops.keying_set.remove()

# 重命名关键帧设置
bpy.ops.keying_set.rename(
    name='NewName'
)

# 复制关键帧设置
bpy.ops.keying_set.duplicate()

# 添加路径到关键帧设置
bpy.ops.keying_set.path_add(
    data_path='location'
)

# 添加路径变体
bpy.ops.keying_set.path_add(
    data_path='rotation_euler',
    index=0
)

# 移除路径
bpy.ops.keying_set.path_remove()

# 移除所有路径
bpy.ops.keying_set.path_remove_all()
```

### 关键帧操作

```python
# 插入关键帧
bpy.ops.keyframe_insert()

# 插入活动对象关键帧
bpy.ops.keyframe_insert(
    type='ACTIVEOBJ'
)

# 插入选择对象关键帧
bpy.ops.keyframe_insert(
    type='SELECTED'
)

# 插入可见对象关键帧
bpy.ops.keyframe_insert(
    type='VISIBLE'
)

# 清除关键帧
bpy.ops.keyframe_delete()

# 清除所有关键帧
bpy.ops.keyframe_delete(
    type='ALL'
)

# 清除插值
bpy.ops.keyframe_clear_viable()
```

### 批量关键帧设置

```python
# 创建完整动画关键帧设置
def create_full_animation_keying_set():
    bpy.ops.keying_set.new(name='FullAnimation', type='INSERT')
    keying_set = bpy.context.scene.keying_sets.active
    
    paths = [
        'location',
        'rotation_euler',
        'scale',
        'rotation_quaternion',
        'delta_location',
        'delta_rotation_euler',
        'delta_scale'
    ]
    
    for path in paths:
        keying_set.paths.add(
            data_path=path,
            index=-1,
            group_method='NONE',
            group_name=''
        )
    
    return keying_set

# 创建材质关键帧设置
def create_material_keying_set():
    bpy.ops.keying_set.new(name='MaterialAnim', type='INSERT')
    keying_set = bpy.context.scene.keying_sets.active
    
    material_paths = [
        'diffuse_color',
        'specular_color',
        'specular_intensity',
        'metallic',
        'roughness',
        'alpha',
        'emission_color',
        'emission_strength'
    ]
    
    for path in material_paths:
        keying_set.paths.add(
            data_path=f'materials[""].{path}',
            index=-1
        )
    
    return keying_set

# 创建约束关键帧设置
def create_constraint_keying_set():
    bpy.ops.keying_set.new(name='ConstraintAnim', type='INSERT')
    keying_set = bpy.context.scene.keying_sets.active
    
    for i in range(32):
        keying_set.paths.add(
            data_path=f'constraints[""].influence',
            index=i
        )
    
    return keying_set

# 创建修改器关键帧设置
def create_modifier_keying_set():
    bpy.ops.keying_set.new(name='ModifierAnim', type='INSERT')
    keying_set = bpy.context.scene.keying_sets.active
    
    for i in range(32):
        keying_set.paths.add(
            data_path=f'modifiers[""].factor',
            index=i
        )
    
    return keying_set
```

## 实用函数

```python
def get_keying_set_paths(keying_set_name):
    """获取关键帧设置的所有路径"""
    keying_set = bpy.context.scene.keying_sets.get(keying_set_name)
    if keying_set:
        return [(p.data_path, p.array_index) for p in keying_set.paths]
    return []

def add_object_properties_to_keying_set(keying_set_name, obj):
    """添加对象属性到关键帧设置"""
    keying_set = bpy.context.scene.keying_sets.get(keying_set_name)
    if keying_set:
        for prop in obj.bl_rna.properties:
            if prop.is_animable:
                keying_set.paths.add(
                    data_path=f'objects["{obj.name}"].{prop.identifier}',
                    index=-1
                )

def batch_keyframe_objects(object_names, frame):
    """批量为对象设置关键帧"""
    bpy.context.scene.frame_set(frame)
    
    for obj_name in object_names:
        obj = bpy.data.objects.get(obj_name)
        if obj:
            bpy.context.view_layer.objects.active = obj
            bpy.ops.keyframe_insert(type='ACTIVEOBJ')

def create_visibility_keying_set():
    """创建可见性关键帧设置"""
    bpy.ops.keying_set.new(name='Visibility', type='INSERT')
    keying_set = bpy.context.scene.keying_sets.active
    
    keying_set.paths.add(
        data_path='hide_viewport',
        index=-1
    )
    keying_set.paths.add(
        data_path='hide_render',
        index=-1
    )
    keying_set.paths.add(
        data_path='hide_select',
        index=-1
    )
    
    return keying_set

def sync_keying_sets_to_action(action_name):
    """同步关键帧设置到动作"""
    action = bpy.data.actions.get(action_name)
    if action:
        for keying_set in bpy.context.scene.keying_sets:
            for path in keying_set.paths:
                if path.id_type == 'OBJECT':
                    path.id = bpy.context.active_object

def export_keying_set(keying_set_name, filepath):
    """导出关键帧设置"""
    import json
    
    keying_set = bpy.context.scene.keying_sets.get(keying_set_name)
    if keying_set:
        data = {
            'name': keying_set.bl_label,
            'type': keying_set.bl_idname,
            'paths': [(p.data_path, p.array_index) for p in keying_set.paths]
        }
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
```

## 常见问题排查

### 关键帧不生效
```python
# 检查关键帧设置
keying_set = bpy.context.scene.keying_sets.active
print(f"关键帧设置: {keying_set}")
print(f"路径数: {len(keying_set.paths) if keying_set else 0}")

# 检查路径
if keying_set:
    for path in keying_set.paths:
        print(f"路径: {path.data_path}, 索引: {path.array_index}")

# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")
print(f"动作: {obj.animation_data.action if obj.animation_data else None}")
```

### 批量关键帧问题
```python
# 检查帧范围
print(f"开始帧: {bpy.context.scene.frame_start}")
print(f"结束帧: {bpy.context.scene.frame_end}")
print(f"当前帧: {bpy.context.scene.frame_current}")

# 设置正确的帧
bpy.context.scene.frame_set(1)

# 检查对象是否被锁定
obj = bpy.context.active_object
print(f"锁定: {obj.lock_location}")
print(f"旋转锁定: {obj.lock_rotation}")
print(f"缩放锁定: {obj.lock_scale}")
```

### 关键帧设置丢失
```python
# 检查所有关键帧设置
print("所有关键帧设置:")
for ks in bpy.context.scene.keying_sets:
    print(f"  {ks.name}: {len(ks.paths)} 路径")

# 重新创建关键帧设置
bpy.ops.keying_set.new(name='Recovery', type='INSERT')

# 从备份恢复
import json
with open('//keying_set_backup.json', 'r') as f:
    data = json.load(f)
    bpy.ops.keying_set.new(name=data['name'], type='INSERT')
    ks = bpy.context.scene.keying_sets.active
    for path_data in data['paths']:
        ks.paths.add(data_path=path_data[0], index=path_data[1])
```
