# gpu.capabilities - GPU能力查询模块

gpu.capabilities模块提供了查询GPU硬件能力和特性支持的函数，用于检查GPU功能和确定可用的渲染特性。

## 概述

GPU能力查询模块允许开发者检查当前GPU的硬件能力和API特性支持。这对于编写适应性代码、根据硬件能力调整渲染策略非常重要。

## 核心功能

### 版本查询

```python
import gpu
from gpu.capabilities import (
    gpu_info_get,
    gpu_shader_info_get,
    gpu_capabilities_get
)

def get_gpu_vendor():
    """获取GPU厂商"""
    return gpu_info_get('VENDOR')

def get_gpu_renderer():
    """获取GPU渲染器"""
    return gpu_info_get('RENDERER')

def get_gpu_version():
    """获取GPU驱动版本"""
    return gpu_info_get('VERSION')

def get_gpu_api_version():
    """获取GPU API版本"""
    return gpu_info_get('API_VERSION')

def get_gpu_shader_version():
    """获取着色器版本"""
    return gpu_shader_info_get('VERSION')
```

### 特性检测

```python
from gpu.capabilities import (
    supports_glsl_compat,
    supports_glsl_es,
    supports_compute_shader,
    supports_geometry_shader,
    supports_tessellation_shader
)

def check_opengl_support():
    """检查OpenGL支持"""
    return {
        'glsl_compat': supports_glsl_compat(),
        'glsl_es': supports_glsl_es(),
        'geometry_shader': supports_geometry_shader(),
        'tessellation': supports_tessellation_shader(),
        'compute': supports_compute_shader()
    }

def check_advanced_features():
    """检查高级特性支持"""
    features = {}
    
    if supports_compute_shader():
        features['compute'] = True
    
    if supports_geometry_shader():
        features['geometry'] = True
    
    if supports_tessellation_shader():
        features['tessellation'] = True
    
    return features

def get_max_texture_size():
    """获取最大纹理尺寸"""
    return gpu_capabilities_get('MAX_TEXTURE_SIZE')

def get_max_uniform_blocks():
    """获取最大Uniform块数量"""
    return gpu_capabilities_get('MAX_UNIFORM_BLOCKS')
```

### 性能指标

```python
def get_gpu_memory_size():
    """获取GPU内存大小"""
    return gpu_capabilities_get('GPU_MEMORY_SIZE')

def get_max_texture_units():
    """获取最大纹理单元数"""
    return gpu_capabilities_get('MAX_TEXTURE_UNITS')

def get_max_vertex_attribs():
    """获取最大顶点属性数"""
    return gpu_capabilities_get('MAX_VERTEX_ATTRIBS')

def get_max_varying_floats():
    """获取最大Varying浮点数"""
    return gpu_capabilities_get('MAX_VARYING_FLOATS')

def get_max_compute_work_group_size():
    """获取最大计算工作组大小"""
    return gpu_capabilities_get('MAX_COMPUTE_WORK_GROUP_SIZE')
```

## 实用函数

### 兼容性检查

```python
def is_opengl_es_compatible():
    """检查OpenGL ES兼容性"""
    return supports_glsl_es()

def requires_fallback():
    """检查是否需要回退"""
    return not supports_glsl_compat()

def check_minimum_requirements():
    """检查最低要求"""
    requirements = {
        'glsl_compat': True,
        'texture_size': 4096,
        'texture_units': 8
    }
    
    if not supports_glsl_compat():
        return False, "GLSL compatibility not supported"
    
    if get_max_texture_size() < requirements['texture_size']:
        return False, "Texture size too small"
    
    if get_max_texture_units() < requirements['texture_units']:
        return False, "Not enough texture units"
    
    return True, "All requirements met"

def get_recommended_settings():
    """获取推荐设置"""
    settings = {}
    
    if supports_compute_shader():
        settings['use_compute'] = True
    else:
        settings['use_compute'] = False
    
    if supports_geometry_shader():
        settings['use_geometry'] = True
    else:
        settings['use_geometry'] = False
    
    texture_size = get_max_texture_size()
    if texture_size >= 16384:
        settings['texture_quality'] = 'HIGH'
    elif texture_size >= 4096:
        settings['texture_quality'] = 'MEDIUM'
    else:
        settings['texture_quality'] = 'LOW'
    
    return settings
```

### 能力报告

```python
def generate_capability_report():
    """生成能力报告"""
    report = {
        'vendor': get_gpu_vendor(),
        'renderer': get_gpu_renderer(),
        'version': get_gpu_version(),
        'api_version': get_gpu_api_version(),
        'shader_version': get_gpu_shader_version(),
        'features': check_opengl_support(),
        'limits': {
            'max_texture_size': get_max_texture_size(),
            'max_texture_units': get_max_texture_units(),
            'max_vertex_attribs': get_max_vertex_attribs(),
            'memory_size': get_gpu_memory_size()
        }
    }
    return report

def print_capability_report():
    """打印能力报告"""
    report = generate_capability_report()
    
    print("GPU Capabilities Report")
    print("=" * 40)
    print(f"Vendor: {report['vendor']}")
    print(f"Renderer: {report['renderer']}")
    print(f"Version: {report['version']}")
    print(f"API Version: {report['api_version']}")
    print(f"Shader Version: {report['shader_version']}")
    print("\nFeatures:")
    for feature, supported in report['features'].items():
        print(f"  {feature}: {'Supported' if supported else 'Not Supported'}")
    print("\nLimits:")
    for limit, value in report['limits'].items():
        print(f"  {limit}: {value}")
```

### 特性比较

```python
def compare_capabilities(other_gpu_info):
    """比较GPU能力"""
    current = generate_capability_report()
    comparison = {}
    
    for key in current:
        if key in other_gpu_info:
            comparison[key] = {
                'current': current[key],
                'other': other_gpu_info[key],
                'match': current[key] == other_gpu_info[key]
            }
    
    return comparison

def has_feature(feature_name):
    """检查特定特性"""
    features = check_opengl_support()
    return features.get(feature_name, False)

def is_feature_better(current_value, feature_name):
    """检查特性是否更好"""
    return current_value > get_capability(feature_name)

def get_capability(capability_name):
    """获取特定能力值"""
    capability_map = {
        'texture_size': get_max_texture_size,
        'texture_units': get_max_texture_units,
        'vertex_attribs': get_max_vertex_attribs,
        'memory': get_gpu_memory_size
    }
    
    if capability_name in capability_map:
        return capability_map[capability_name]()
    return None
```

## 常见问题排查

### 特性不可用

GPU驱动问题：
- 更新GPU驱动程序
- 检查GPU是否支持所需特性
- 使用兼容模式

### 性能不足

硬件限制：
- 降低渲染设置
- 禁用高级特性
- 优化着色器代码

### 报告不准确

API版本问题：
- 确认Blender版本支持
- 检查GPU API初始化
- 重新启动Blender
