# bpy.ops.gizmo - 小工具操作模块

Blender小工具操作符，用于管理变换小工具和自定义小工具。

## 概述

`bpy.ops.gizmo` 模块提供用于操作Blender中各种小工具（Gizmo）的功能，包括选择、移动、配置和自定义小工具。

## 核心功能

### 小工具选择

```python
import bpy

# 选择小工具
bpy.ops.gizmo.select(
    extend=False,
    deselect=False,
    toggle=False,
    deselect_all=True
)

# 全选小工具
bpy.ops.gizmo.select_all(
    action='SELECT'
)

# 取消全选小工具
bpy.ops.gizmo.select_all(
    action='DESELECT'
)

# 反选小工具
bpy.ops.gizmo.select_all(
    action='INVERT'
)
```

### 小工具类型

```python
# 切换到移动小工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.move'
)

# 切换到旋转小工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.rotate'
)

# 切换到缩放小工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.scale'
)

# 切换到智能移动
bpy.ops.wm.tool_set_by_id(
    name='builtin.transform'
)

# 切换到标注小工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.annotate'
)

# 切换到测量小工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.measure'
)
```

### 小工具操作

```python
# 激活小工具
bpy.ops.gizmo.activate(
    type='START'
)

# 拖动小工具
bpy.ops.gizmo.drag(
    type='TRANSLATE'
)

# 点击小工具
bpy.ops.gizmo.click()

# 释放小工具
bpy.ops.gizmo.release()
```

### 小工具配置

```python
# 设置小工具属性
bpy.ops.gizmo.properties(
    op='GIZMO'
)

# 切换小工具显示
bpy.ops.gizmo.toggle()

# 显示小工具
bpy.ops.gizmo.show(
    type='ALL'
)

# 隐藏小工具
bpy.ops.gizmo.hide(
    type='ALL'
)

# 重置小工具
bpy.ops.gizmo.reset()
```

### 自定义小工具

```python
# 添加自定义小工具
bpy.ops.gizmo.add(
    type='CUSTOM'
)

# 删除自定义小工具
bpy.ops.gizmo.remove()

# 编辑自定义小工具
bpy.ops.gizmo.edit(
    type='CUSTOM'
)

# 复制小工具
bpy.ops.gizmo.duplicate()

# 粘贴小工具
bpy.ops.gizmo.paste()
```

### 小工具约束

```python
# 设置约束轴
bpy.ops.transform.constraint(
    constraint_axis=(True, False, False)
)

# 设置约束模式
bpy.ops.transform.constraint(
    mode='OFFSET'
)

# 清除约束
bpy.ops.transform.constraint_clear()
```

## 实用函数

```python
def enable_gizmos():
    """启用小工具"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_gizmo = True

def disable_gizmos():
    """禁用小工具"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_gizmo = False

def toggle_move_gizmo():
    """切换移动小工具"""
    bpy.ops.wm.tool_set_by_id(name='builtin.move')

def toggle_rotate_gizmo():
    """切换旋转小工具"""
    bpy.ops.wm.tool_set_by_id(name='builtin.rotate')

def toggle_scale_gizmo():
    """切换缩放小工具"""
    bpy.ops.wm.tool_set_by_id(name='builtin.scale')

def set_gizmo_opacity(opacity):
    """设置小工具不透明度"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.gizmo_opacity = opacity

def set_gizmo_size(size):
    """设置小工具大小"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.gizmo_size = size

def enable_axis_gizmos():
    """启用轴小工具"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_gizmo_navigate = True
            space.show_gizmo_object_rotate = True
            space.show_gizmo_object_translate = True
            space.show_gizmo_object_scale = True

def disable_axis_gizmos():
    """禁用轴小工具"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_gizmo_navigate = False
            space.show_gizmo_object_rotate = False
            space.show_gizmo_object_translate = False
            space.show_gizmo_object_scale = False
```

## 常见问题排查

### 小工具不显示
```python
# 检查小工具显示设置
space = bpy.context.area.spaces.active
print(f"小工具显示: {space.show_gizmo}")

# 启用小工具
space.show_gizmo = True

# 检查小工具类型
print(f"移动小工具: {space.show_gizmo_object_translate}")
print(f"旋转小工具: {space.show_gizmo_object_rotate}")
print(f"缩放小工具: {space.show_gizmo_object_scale}")

# 启用所有小工具
space.show_gizmo_object_translate = True
space.show_gizmo_object_rotate = True
space.show_gizmo_object_scale = True
```

### 小工具太小
```python
# 检查小工具大小
space = bpy.context.area.spaces.active
print(f"小工具大小: {space.gizmo_size}")

# 设置更大的大小
space.gizmo_size = 60

# 检查不透明度
print(f"不透明度: {space.gizmo_opacity}")
space.gizmo_opacity = 1.0
```

### 小工具无响应
```python
# 检查活动对象
obj = bpy.context.active_object
print(f"活动对象: {obj}")

# 检查对象是否被锁定
print(f"锁定: {obj.lock_location}, {obj.lock_rotation}, {obj.lock_scale}")

# 解锁对象
obj.lock_location = (False, False, False)
obj.lock_rotation = (False, False, False)
obj.lock_scale = (False, False, False)

# 检查模式
print(f"模式: {bpy.context.mode}")
```

### 自定义小工具问题
```python
# 检查自定义小工具
print(f"小工具数: {len(bpy.data.gizmos)}")

# 列出小工具
for gizmo in bpy.data.gizmos:
    print(f"小工具: {gizmo.name}")

# 重置小工具
bpy.ops.gizmo.reset()

# 重新创建小工具
bpy.ops.gizmo.add(type='CUSTOM')
```
