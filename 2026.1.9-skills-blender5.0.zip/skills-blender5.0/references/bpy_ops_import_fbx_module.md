# bpy.ops.import_scene - FBX导入操作模块

Blender FBX文件导入操作符，用于将FBX格式文件导入Blender。

## 概述

`bpy.ops.import_scene.fbx` 模块提供用于将Autodesk FBX格式文件导入Blender的功能，支持几何体、材质、纹理、骨骼和动画的导入。

## 核心功能

### 基础导入

```python
import bpy

# 导入FBX文件
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    directory='//',
    files=[{'name': 'model.fbx'}],
    ui_tab='MAIN',
    use_manual_orientation=False,
    global_scale=1.0,
    bake_space_transform=False,
    use_custom_normals=True,
    use_image_search=True,
    use_alpha_decals=False,
    decal_offset=0.0,
    use_anim=True,
    use_anim_action_all=True,
    use_anim_adaptive_constraints=False,
    use_anim_cache=False,
    use_conical_deform=False,
    use_apply_scale=True,
    use_decal_offset=False,
    axis_forward='-Z',
    axis_up='Y'
)
```

### 坐标轴设置

```python
# Blender默认轴向
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    axis_forward='-Z',
    axis_up='Y'
)

# 传统FBX轴向
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    axis_forward='-Z',
    axis_up='Y'
)

# 其他轴向组合
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    axis_forward='Y',
    axis_up='Z'
)
```

### 缩放设置

```python
# 设置缩放
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    global_scale=1.0
)

# 缩放10倍
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    global_scale=10.0
)

# 应用缩放
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_apply_scale=True
)
```

### 法线设置

```python
# 使用自定义法线
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_custom_normals=True
)

# 不使用自定义法线
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_custom_normals=False
)
```

### 动画设置

```python
# 导入动画
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_anim=True
)

# 不导入动画
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_anim=False
)

# 导入所有动作
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_anim=True,
    use_anim_action_all=True
)

# 自适应约束
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_anim_adaptive_constraints=True
)
```

### 骨骼导入

```python
# 导入骨骼
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_armature_deform=True
)

# 不导入骨骼
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_armature_deform=False
)
```

### 纹理搜索

```python
# 启用纹理搜索
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_image_search=True
)

# 禁用纹理搜索
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_image_search=False
)
```

### 材质设置

```python
# 使用Alpha贴图
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_alpha_decals=True
)

# 设置偏移
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    decal_offset=0.0
)

# 使用蒙皮
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_custom_skinning=True
)
```

## 实用函数

```python
def import_fbx_model(filepath, scale=1.0):
    """导入FBX模型"""
    bpy.ops.import_scene.fbx(
        filepath=filepath,
        global_scale=scale,
        use_custom_normals=True,
        use_anim=False,
        use_armature_deform=True,
        use_image_search=True
    )
    return list(bpy.context.selected_objects)

def import_fbx_with_animations(filepath, scale=1.0):
    """导入FBX带动画"""
    bpy.ops.import_scene.fbx(
        filepath=filepath,
        global_scale=scale,
        use_custom_normals=True,
        use_anim=True,
        use_anim_action_all=True,
        use_armature_deform=True,
        use_image_search=True
    )
    return list(bpy.context.selected_objects)

def import_fbx_for_editing(filepath):
    """导入FBX用于编辑"""
    bpy.ops.import_scene.fbx(
        filepath=filepath,
        global_scale=1.0,
        use_custom_normals=True,
        use_anim=False,
        use_armature_deform=False,
        use_image_search=False
    )
    return list(bpy.context.selected_objects)

def import_fbx_character(filepath):
    """导入FBX角色"""
    bpy.ops.import_scene.fbx(
        filepath=filepath,
        global_scale=1.0,
        use_custom_normals=True,
        use_anim=True,
        use_anim_action_all=True,
        use_armature_deform=True,
        use_image_search=True,
        use_apply_scale=True
    )
    return list(bpy.context.selected_objects)

def batch_import_fbx_files(fbx_files, scale=1.0):
    """批量导入FBX文件"""
    all_objects = []
    for filepath in fbx_files:
        bpy.ops.import_scene.fbx(
            filepath=filepath,
            global_scale=scale
        )
        imported = list(bpy.context.selected_objects)
        all_objects.extend(imported)
    return all_objects

def import_fbx_and_merge(filepath):
    """导入FBX并合并"""
    bpy.ops.import_scene.fbx(
        filepath=filepath,
        global_scale=1.0,
        use_custom_normals=True
    )
    
    objects = list(bpy.context.selected_objects)
    if len(objects) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = objects[0]
        bpy.ops.object.join()
        return [bpy.context.active_object]
    
    return objects
```

## 常见问题排查

### 导入后模型不可见
```python
# 检查选中对象
selected = bpy.context.selected_objects
print(f"导入对象数: {len(selected)}")

# 检查对象类型
for obj in selected:
    print(f"{obj.name}: 类型={obj.type}")

# 检查隐藏状态
for obj in selected:
    print(f"{obj.name}: 隐藏={obj.hide_viewport}")
    obj.hide_viewport = False

# 检查层级关系
for obj in selected:
    print(f"{obj.name}: 父级={obj.parent}")
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 检查骨骼
if obj.type == 'ARMATURE':
    print(f"骨骼数: {len(obj.data.bones)}")

# 检查NLA轨道
if obj.animation_data:
    for track in obj.animation_data.nla_tracks:
        print(f"NLA轨道: {track.name}")

# 重新导入带动画
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_anim=True,
    use_anim_action_all=True
)
```

### 材质丢失
```python
# 检查材质
print(f"材质数: {len(bpy.data.materials)}")

# 检查纹理
print(f"纹理数: {len(bpy.data.textures)}")

# 检查图像
print(f"图像数: {len(bpy.data.images)}")

# 检查纹理搜索
bpy.ops.import_scene.fbx(
    filepath='//model.fbx',
    use_image_search=True
)

# 手动分配材质
obj = bpy.context.active_object
if obj.data.materials:
    for slot in obj.material_slots:
        print(f"材质槽: {slot.material}")
```

### 骨骼问题
```python
# 检查骨骼
armature = None
for obj in bpy.context.selected_objects:
    if obj.type == 'ARMATURE':
        armature = obj
        break

if armature:
    print(f"骨骼数: {len(armature.data.bones)}")
    
    # 检查权重
    for vert in armature.children[0].data.vertices:
        if vert.groups:
            print(f"顶点 {vert.index}: 权重组={len(vert.groups)}")

# 检查父级关系
for obj in bpy.context.selected_objects:
    if obj.parent and obj.parent.type == 'ARMATURE':
        print(f"{obj.name} 父级: {obj.parent.name}")
```
