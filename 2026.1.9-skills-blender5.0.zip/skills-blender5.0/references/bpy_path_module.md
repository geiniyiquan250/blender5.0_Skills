# bpy.path 路径模块

提供与 Blender 路径处理相关的实用工具函数，作用范围与 os.path 类似，专门处理 Blender 中的文件路径操作。

## 函数

### abspath

```python
import bpy

absolute_path = bpy.path.abspath("//textures/wood.png")
print(absolute_path)

absolute_path = bpy.path.abspath("//../assets/model.fbx", start="/project")
print(absolute_path)
```

返回相对于当前 blend 文件的绝对路径，支持使用「//」前缀表示相对于当前文件目录。

**参数：**

- `start` (str | bytes): 相对路径的起始目录，未设置时使用当前文件名所在目录。
- `library` (Library): 路径所属的库文件，当库不为 None 时，其路径会替换 start。

**返回：**

- str: 绝对路径。

**说明：** 「//」前缀是 Blender 特有的相对路径表示方式，表示相对于当前保存的 blend 文件位置。

---

### basename

```python
import bpy
from bpy import path

result = path.basename("/home/user/project/textures/wood.png")
print(result)

result = path.basename("//textures/wood.png")
print(result)
```

等价于 os.path.basename 函数，但会跳过「//」前缀。确保 Windows 平台兼容性。

**返回：**

- str: 给定路径的基本名称（文件名部分）。

---

### clean_name

```python
import bpy

clean = bpy.path.clean_name("My Texture Map 1")
print(clean)

clean = bpy.path.clean_name("Texture@#$%", replace="-")
print(clean)
```

返回经过清理的名称，用于处理可能导致问题的特殊字符。所有除 A-Z、a-z、0-9 之外的字符都会被替换为下划线或指定的替换字符。

**参数：**

- `name` (str | bytes): 需要清理的路径名或文件名。
- `replace` (str): 用于替换非法字符的字符，默认为下划线「_」。

**返回：**

- str: 清理后的安全名称。

**应用场景：** 文件写入、材质命名、对象命名等需要避免特殊字符的场景。

---

### display_name

```python
import bpy

display = bpy.path.display_name("wood_texture.png")
print(display)

display = bpy.path.display_name("wood_texture.png", has_ext=False)
print(display)

display = bpy.path.display_name("wood_texture.png", title_case=False)
print(display)
```

根据名称创建用于菜单和用户界面的显示字符串，专为文件名和模块名设计。

**参数：**

- `name` (str): 用于界面显示的名称。
- `has_ext` (bool): 是否从名称中移除文件扩展名，默认为 True。
- `title_case` (bool): 是否将小写名称转换为标题格式，默认为 True。

**返回：**

- str: 用于界面显示的字符串。

**示例效果：**

- `wood_texture.png` → `Wood Texture`
- `wood_texture.png`（has_ext=False）→ `Wood Texture`
- `wood_texture.png`（title_case=False）→ `wood texture`

---

### display_name_to_filepath

```python
import bpy

filepath = bpy.path.display_name_to_filepath("My File_001")
print(filepath)
```

执行 display_name 的逆操作，将显示名称转换回可用于文件路径的格式，处理文件中不支持的特殊字符的字面量版本。

**参数：**

- `name` (str): 需要转换的显示名称。

**返回：**

- str: 文件路径字符串。

---

### display_name_from_filepath

```python
import bpy

display = bpy.path.display_name_from_filepath("/home/user/textures/wood.png")
print(display)
```

从文件路径中提取文件名（不含目录和扩展名），确保 UTF-8 兼容性。

**参数：**

- `name` (str): 需要转换的文件路径。

**返回：**

- str: 用于显示的名称。

---

### ensure_ext

```python
import bpy

filepath = bpy.path.ensure_ext("/path/to/file", ".png")
print(filepath)

filepath = bpy.path.ensure_ext("/path/to/file.png", ".jpg")
print(filepath)

filepath = bpy.path.ensure_ext("/path/to/file", ".tar.gz")
print(filepath)
```

如果文件路径未包含指定扩展名，则添加该扩展名。

**参数：**

- `filepath` (str): 文件路径。
- `ext` (str): 需要检查的扩展名，可以是复合扩展名（如 .tar.gz），必须以点号开头。
- `case_sensitive` (bool): 比较扩展名时是否区分大小写，默认为 False。

**返回：**

- str: 带有指定扩展名的文件路径。

---

### is_subdir

```python
import bpy

result = bpy.path.is_subdir("/project/assets/textures", "/project/assets")
print(result)

result = bpy.path.is_subdir("/project/assets", "/project/textures")
print(result)
```

检查给定路径是否是指定目录的子目录。两个路径都必须是绝对路径。

**参数：**

- `path` (str | bytes): 需要检查的绝对路径。
- `directory` (str | bytes): 父目录的绝对路径。

**返回：**

- bool: 路径是否为子目录。

---

### module_names

```python
import bpy

modules = bpy.path.module_names("/scripts")
print(modules)

modules = bpy.path.module_names("/scripts", recursive=True)
print(modules)

modules = bpy.path.module_names("/scripts", package="my_package")
print(modules)
```

返回可以从指定路径导入的模块列表。

**参数：**

- `path` (str): 要扫描的目录路径。
- `recursive` (bool): 是否递归返回包的子模块名称，默认为 False。
- `package` (str): 可选字符串，用作模块名称的前缀（不带尾部点号）。

**返回：**

- list[tuple[str, str]]: 模块名称和模块文件路径的字符串对列表。

---

### native_pathsep

```python
import bpy

path = bpy.path.native_pathsep("/home/user/project/file.txt")
print(path)
```

将路径分隔符替换为系统原生的分隔符（os.sep）。

**参数：**

- `path` (str): 需要替换分隔符的路径。

**返回：**

- str: 使用系统原生分隔符的路径。

**示例：** 在 Windows 上会将 `/` 替换为 `\`，在 Linux/macOS 上保持不变。

---

### reduce_dirs

```python
import bpy

dirs = [
    "/project",
    "/project/src",
    "/project/src/utils",
    "/project/src",
    "/project/assets",
    "/project/assets/textures",
]

unique_dirs = bpy.path.reduce_dirs(dirs)
print(unique_dirs)
```

给定一系列目录路径，移除重复项和嵌套在其他路径中的目录。

**参数：**

- `dirs` (Sequence[str]): 目录路径序列。

**返回：**

- list[str]: 去重后的唯一路径列表。

**用途：** 递归路径搜索时避免重复搜索同一目录。

---

### relpath

```python
import bpy

relative = bpy.path.relpath("/project/textures/wood.png")
print(relative)

relative = bpy.path.relpath("/project/textures/wood.png", start="/project")
print(relative)
```

返回相对于当前 blend 文件的路径，使用「//」前缀表示。

**参数：**

- `path` (str | bytes): 绝对路径。
- `start` (str | bytes): 相对路径的起始目录，未设置时使用当前文件名所在目录。

**返回：**

- str: 相对路径。

**说明：** 与 abspath 互为逆操作，abspath 将相对路径转为绝对路径，relpath 将绝对路径转为相对路径。

---

### resolve_ncase

```python
import bpy

path = bpy.path.resolve_ncase("/home/User/Project/file.txt")
print(path)
```

在大小写敏感的系统上解析大小写不敏感的路径，如果找到则返回正确大小写的路径，否则返回原始路径。

**参数：**

- `path` (str | bytes): 需要解析的路径。

**返回：**

- str: 正确大小写的路径或原始路径。

**用途：** 确保在大小写敏感的文件系统上访问 Windows 风格的大小写混合路径时能找到正确文件。

---

## 使用示例

### 文件导出路径处理

```python
import bpy
import os

def export_with_correct_path(obj, export_dir, filename, extension=".obj"):
    clean_filename = bpy.path.clean_name(filename)
    full_filename = bpy.path.ensure_ext(clean_filename, extension)
    full_path = os.path.join(export_dir, full_filename)
    
    abs_path = bpy.path.abspath("//" + os.path.join(export_dir, full_filename))
    
    print(f"导出路径: {abs_path}")
    
    return abs_path

export_path = export_with_correct_path(
    bpy.context.active_object,
    "exported_models",
    "My Model 001"
)
```

### 批量处理纹理路径

```python
import bpy
import os

def batch_fix_texture_paths(material, new_textures_dir):
    for node in material.node_tree.nodes:
        if node.type == 'IMAGE' and node.image:
            old_path = node.image.filepath
            
            display_name = bpy.path.display_name_from_filepath(old_path)
            clean_name = bpy.path.clean_name(display_name)
            
            new_filename = bpy.path.ensure_ext(clean_name, ".png")
            new_path = os.path.join(new_textures_dir, new_filename)
            
            relative_path = bpy.path.relpath("//" + new_path)
            
            print(f"旧路径: {old_path}")
            print(f"新相对路径: {relative_path}")

batch_fix_texture_paths(bpy.context.active_object.active_material, "textures")
```

### 插件模块加载

```python
import bpy
import os

def load_plugin_modules(plugin_dir):
    if not os.path.exists(plugin_dir):
        print(f"目录不存在: {plugin_dir}")
        return []
    
    module_list = bpy.path.module_names(plugin_dir, recursive=True)
    
    valid_modules = []
    for module_name, module_file in module_list:
        if bpy.path.is_subdir(module_file, plugin_dir):
            valid_modules.append((module_name, module_file))
    
    print(f"找到 {len(valid_modules)} 个可用模块:")
    for name, path in valid_modules:
        print(f"  - {name}: {path}")
    
    return valid_modules

modules = load_plugin_modules("//plugins")
```

### 相对路径管理

```python
import bpy
import os

class PathManager:
    def __init__(self, base_path=None):
        self.base_path = base_path or bpy.path.abspath("//")
    
    def to_relative(self, absolute_path):
        rel = bpy.path.relpath(absolute_path, start=self.base_path)
        return f"//{rel}" if not rel.startswith("//") else rel
    
    def to_absolute(self, relative_path):
        if relative_path.startswith("//"):
            return bpy.path.abspath(relative_path)
        return os.path.join(self.base_path, relative_path)
    
    def is_in_project(self, path):
        abs_path = self.to_absolute(path)
        return bpy.path.is_subdir(abs_path, self.base_path)

manager = PathManager("/project/assets")

print(manager.to_relative("/project/textures/wood.png"))
print(manager.to_absolute("//textures/wood.png"))
print(manager.is_in_project("//textures"))
```

### 路径清理和规范化

```python
import bpy
import os

def sanitize_export_paths(export_items):
    cleaned_paths = []
    
    for item in export_items:
        display = bpy.path.display_name(item["name"])
        clean = bpy.path.clean_name(display)
        final = bpy.path.ensure_ext(clean, item.get("ext", ".obj"))
        
        full_path = os.path.join(item["dir"], final)
        native = bpy.path.native_pathsep(full_path)
        
        cleaned_paths.append({
            "original": item["name"],
            "cleaned": final,
            "path": native,
            "relative": bpy.path.relpath(native)
        })
    
    reduced = bpy.path.reduce_dirs([p["path"] for p in cleaned_paths])
    print(f"规范化后目录: {reduced}")
    
    return cleaned_paths
```

---

## 注意事项

1. **「//」前缀：** 在 Blender 中，「//」前缀表示相对于当前 blend 文件的路径，在文件未保存时可能无法正确解析。

2. **路径分隔符：** 建议使用 bpy.path 模块的函数处理路径，而非直接操作字符串，以确保跨平台兼容性。

3. **UTF-8 编码：** display_name_from_filepath 确保返回的字符串是 UTF-8 兼容的，避免编码问题。

4. **大小写敏感性：** 在 Windows 上文件名通常不区分大小写，但在 Linux/macOS 上区分。resolve_ncase 可帮助处理跨平台路径问题。

5. **库文件路径：** abspath 和 relpath 的 library 参数可以正确处理来自外部库文件的相对路径。

6. **模块搜索：** module_names 返回的模块需要位于 Python 的模块搜索路径中才能成功导入。