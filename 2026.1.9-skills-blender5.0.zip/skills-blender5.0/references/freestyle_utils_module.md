# freestyle.utils - 工具函数模块

freestyle.utils模块提供了Freestyle线条渲染框架中的通用工具函数，包括几何计算、视图处理和样式操作等辅助功能。

## 概述

工具函数模块封装了Freestyle系统中常用的辅助功能，涵盖几何计算、线条处理、样式管理等方面。这些函数可以帮助开发者快速实现自定义功能。

## 核心功能

### 几何计算

```python
from freestyle.utils import (
    compute_polygon_smoothness,
    compute_line_smoothness,
    compute_viewedge_density,
    compute_fedge_length
)

def calculate_curvature(points):
    """计算曲率"""
    if len(points) < 3:
        return 0.0
    
    total_curvature = 0.0
    for i in range(1, len(points) - 1):
        v1 = points[i] - points[i-1]
        v2 = points[i+1] - points[i]
        if v1.length > 0 and v2.length > 0:
            v1.normalize()
            v2.normalize()
            dot = max(-1.0, min(1.0, v1.dot(v2)))
            angle = math.acos(dot)
            total_curvature += angle
    
    return total_curvature / max(1, len(points) - 2)

def calculate_total_length(points):
    """计算总长度"""
    total = 0.0
    for i in range(1, len(points)):
        total += (points[i] - points[i-1]).length
    return total

def calculate_polygon_area(points):
    """计算多边形面积"""
    if len(points) < 3:
        return 0.0
    
    area = 0.0
    n = len(points)
    for i in range(n):
        j = (i + 1) % n
        area += points[i].x * points[j].y
        area -= points[j].x * points[i].y
    return abs(area) / 2.0

def calculate_bounding_box(points):
    """计算边界框"""
    if not points:
        return None, None
    
    min_x = min(p.x for p in points)
    min_y = min(p.y for p in points)
    min_z = min(p.z for p in points)
    max_x = max(p.x for p in points)
    max_y = max(p.y for p in points)
    max_z = max(p.z for p in points)
    
    return Vector((min_x, min_y, min_z)), Vector((max_x, max_y, max_z))
```

### 线条处理

```python
def simplify_stroke(points, tolerance=0.1):
    """简化线条"""
    if len(points) < 3:
        return points
    
    simplified = [points[0]]
    last_point = points[0]
    
    for point in points[1:]:
        if (point - last_point).length > tolerance:
            simplified.append(point)
            last_point = point
    
    if simplified[-1] != points[-1]:
        simplified.append(points[-1])
    
    return simplified

def resample_stroke(points, num_points):
    """重采样线条"""
    if len(points) < 2:
        return points
    
    total_length = calculate_total_length(points)
    segment_length = total_length / (num_points - 1)
    
    result = [points[0]]
    current_length = 0
    target_length = segment_length
    
    for i in range(1, len(points)):
        while current_length + (points[i] - points[i-1]).length >= target_length:
            t = (target_length - current_length) / (points[i] - points[i-1]).length
            new_point = points[i-1] + (points[i] - points[i-1]) * t
            result.append(new_point)
            target_length += segment_length
        current_length += (points[i] - points[i-1]).length
    
    while len(result) < num_points:
        result.append(points[-1])
    
    return result[:num_points]

def smooth_stroke(points, strength=0.5, iterations=1):
    """平滑线条"""
    if len(points) < 3:
        return points
    
    for _ in range(iterations):
        new_points = [points[0]]
        for i in range(1, len(points) - 1):
            smoothed = points[i] * (1 - strength) + (points[i-1] + points[i+1]) / 2 * strength
            new_points.append(smoothed)
        new_points.append(points[-1])
        points = new_points
    
    return points
```

### 视图工具

```python
def get_view_edge_density(view_map, region):
    """获取视图边密度"""
    density_map = {}
    for edge in view_map.edges:
        if edge.view2d:
            center = edge.view2d.get_center()
            x, y = int(center.x), int(center.y)
            if 0 <= x < region.width and 0 <= y < region.height:
                density_map[(x, y)] = density_map.get((x, y), 0) + 1
    return density_map

def project_points_to_view(points, view_matrix, projection_matrix):
    """将点投影到视图"""
    projected = []
    for point in points:
        clip = projection_matrix @ (view_matrix @ point)
        ndc = Vector((clip.x / clip.w, clip.y / clip.w))
        screen = Vector((
            (ndc.x + 1) / 2 * region.width,
            (ndc.y + 1) / 2 * region.height
        ))
        projected.append(screen)
    return projected

def calculate_view_coverage(view_map, region):
    """计算视图覆盖率"""
    covered_pixels = set()
    for edge in view_map.edges:
        if edge.view2d:
            for point in edge.view2d.points:
                x, y = int(point.x), int(point.y)
                if 0 <= x < region.width and 0 <= y < region.height:
                    covered_pixels.add((x, y))
    return len(covered_pixels) / (region.width * region.height)
```

## 实用函数

### 样式管理

```python
def load_style_file(filepath):
    """加载样式文件"""
    with open(filepath, 'r') as f:
        return json.load(f)

def save_style_file(style_data, filepath):
    """保存样式文件"""
    with open(filepath, 'w') as f:
        json.dump(style_data, f, indent=2)

def apply_style(stroke, style_config):
    """应用样式配置"""
    if 'color' in style_config:
        stroke.attributes.color = tuple(style_config['color'])
    if 'thickness' in style_config:
        stroke.attributes.thickness = style_config['thickness']
    if 'alpha' in style_config:
        stroke.attributes.alpha = style_config['alpha']

def extract_style(stroke):
    """提取样式配置"""
    return {
        'color': list(stroke.attributes.color),
        'thickness': stroke.attributes.thickness,
        'alpha': stroke.attributes.alpha
    }
```

### 批量处理

```python
def process_strokes(strokes, processor_func):
    """批量处理线条"""
    results = []
    for stroke in strokes:
        result = processor_func(stroke)
        results.append(result)
    return results

def filter_strokes(strokes, filter_func):
    """过滤线条"""
    return [s for s in strokes if filter_func(s)]

def sort_strokes(strokes, key_func, reverse=False):
    """排序线条"""
    return sorted(strokes, key=key_func, reverse=reverse)

def group_strokes(strokes, group_func):
    """分组线条"""
    groups = {}
    for stroke in strokes:
        key = group_func(stroke)
        if key not in groups:
            groups[key] = []
        groups[key].append(stroke)
    return groups
```

### 性能优化

```python
def batch_compute_lengths(strokes):
    """批量计算长度"""
    for stroke in strokes:
        stroke.compute_length()
    return strokes

def optimize_stroke_density(strokes, max_points=100):
    """优化线条密度"""
    for stroke in strokes:
        if len(stroke.vertices) > max_points:
            stroke.vertices = resample_stroke(
                [v.point for v in stroke.vertices],
                max_points
            )

def cull_invisible_strokes(strokes, view_bounds):
    """剔除不可见线条"""
    visible = []
    for stroke in strokes:
        if is_visible(stroke, view_bounds):
            visible.append(stroke)
    return visible

def is_visible(stroke, view_bounds):
    """检查线条是否可见"""
    min_x, min_y, max_x, max_y = view_bounds
    for vertex in stroke.vertices:
        if not (min_x <= vertex.point.x <= max_x and
                min_y <= vertex.point.y <= max_y):
            return False
    return True
```

## 常见问题排查

### 线条处理错误

输入数据问题：
- 确认点列表有效
- 检查点数量是否足够
- 验证坐标范围正确

### 性能问题

处理时间过长：
- 使用批量处理优化
- 减少不必要的计算
- 使用缓存机制

### 样式应用失败

配置格式错误：
- 确认JSON格式正确
- 检查配置参数类型
- 验证属性名称存在
