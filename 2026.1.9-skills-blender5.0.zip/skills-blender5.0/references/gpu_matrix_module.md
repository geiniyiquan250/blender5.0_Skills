# gpu.matrix - GPU矩阵模块

gpu.matrix模块提供了GPU渲染所需的矩阵操作函数，包括模型视图矩阵、投影矩阵和各种矩阵变换。

## 概述

GPU矩阵模块封装了图形渲染中常用的矩阵操作。用于设置渲染管线中的变换矩阵，处理3D到2D的投影转换，以及各种几何变换。

## 核心功能

### 矩阵初始化

```python
import gpu
from gpu.matrix import (
    identity,
    orthographic,
    perspective,
    lookat
)

def reset_matrices():
    """重置所有矩阵"""
    gpu.matrix.load_identity()

def create_identity_matrix():
    """创建单位矩阵"""
    return identity()

def create_orthographic_matrix(
    left, right, bottom, top, near, far
):
    """创建正交投影矩阵"""
    return orthographic(left, right, bottom, top, near, far)

def create_perspective_matrix(
    fovy, aspect, near, far
):
    """创建透视投影矩阵"""
    return perspective(fovy, aspect, near, far)

def create_lookat_matrix(eye, center, up):
    """创建视图矩阵"""
    return lookat(eye, center, up)
```

### 矩阵操作

```python
from gpu.matrix import (
    translate,
    rotate,
    scale,
    multiply,
    inverse,
    transpose
)

def apply_translation(x, y, z):
    """应用平移变换"""
    gpu.matrix.translate((x, y, z))

def apply_rotation(angle, axis):
    """应用旋转变换"""
    gpu.matrix.rotate(angle, axis)

def apply_scale(x, y, z):
    """应用缩放变换"""
    gpu.matrix.scale((x, y, z))

def multiply_matrices(mat1, mat2):
    """矩阵相乘"""
    return multiply(mat1, mat2)

def get_inverse_matrix(mat):
    """获取矩阵的逆"""
    return inverse(mat)

def get_transpose_matrix(mat):
    """获取矩阵的转置"""
    return transpose(mat)
```

### 投影矩阵

```python
def setup_perspective_projection(fov=45, near=0.1, far=1000):
    """设置透视投影"""
    width = bpy.context.region.width
    height = bpy.context.region.height
    aspect = width / height if height > 0 else 1.0
    
    gpu.matrix.perspective(math.radians(fov), aspect, near, far)

def setup_orthographic_projection(
    left=None, right=None, 
    bottom=None, top=None,
    near=-100, far=100
):
    """设置正交投影"""
    if left is None:
        left = -1
    if right is None:
        right = 1
    if bottom is None:
        bottom = -1
    if top is None:
        top = 1
    
    gpu.matrix.orthographic(left, right, bottom, top, near, far)

def setup_view_matrix(eye, center, up):
    """设置视图矩阵"""
    gpu.matrix.lookat(eye, center, up)

def get_current_projection_matrix():
    """获取当前投影矩阵"""
    return gpu.matrix.get_projection_matrix()

def get_current_model_view_matrix():
    """获取当前模型视图矩阵"""
    return gpu.matrix.get_model_view_matrix()
```

## 实用函数

### 模型变换

```python
def push_matrix():
    """保存矩阵状态"""
    gpu.matrix.push()

def pop_matrix():
    """恢复矩阵状态"""
    gpu.matrix.pop()

def load_matrix(mat):
    """加载矩阵"""
    gpu.matrix.load_matrix(mat)

def store_matrix():
    """存储当前矩阵"""
    return gpu.matrix.get_state()

def restore_matrix(state):
    """恢复矩阵状态"""
    gpu.matrix.set_state(state)

def transform_point(point, matrix=None):
    """变换点"""
    if matrix is None:
        matrix = gpu.matrix.get_model_view_matrix()
    homogeneous = Vector((point.x, point.y, point.z, 1.0))
    transformed = matrix @ homogeneous
    return Vector((transformed.x, transformed.y, transformed.z))
```

### 视图控制

```python
def orbit_view(azimuth, elevation, distance):
    """轨道视图"""
    gpu.matrix.load_identity()
    gpu.matrix.translate((0, 0, -distance))
    gpu.matrix.rotate(math.radians(elevation), (1, 0, 0))
    gpu.matrix.rotate(math.radians(azimuth), (0, 0, 1))

def pan_view(dx, dy):
    """平移视图"""
    gpu.matrix.translate((dx, dy, 0))

def zoom_view(factor):
    """缩放视图"""
    gpu.matrix.scale((factor, factor, factor))

def reset_view():
    """重置视图"""
    gpu.matrix.load_identity()
    gpu.matrix.translate((0, 0, -5))
```

### 矩阵计算

```python
def calculate_normal_matrix(model_view):
    """计算法线矩阵"""
    normal_matrix = model_view.to_3x3().inverted().transposed()
    return normal_matrix

def calculate_shadow_matrix(light_dir, plane):
    """计算阴影矩阵"""
    dot = plane.normal.dot(light_dir)
    shadow_matrix = Matrix([
        [dot - light_dir.x * plane.normal.x, -light_dir.x * plane.normal.y, -light_dir.x * plane.normal.z, 0],
        [-light_dir.y * plane.normal.x, dot - light_dir.y * plane.normal.y, -light_dir.y * plane.normal.z, 0],
        [-light_dir.z * plane.normal.x, -light_dir.z * plane.normal.y, dot - light_dir.z * plane.normal.z, 0],
        [-light_dir.x * plane.constant, -light_dir.y * plane.constant, -light_dir.z * plane.constant, dot]
    ])
    return shadow_matrix

def decompose_matrix(matrix):
    """分解矩阵"""
    location = matrix.translation
    rotation = matrix.to_euler()
    scale = matrix.to_scale()
    return location, rotation, scale
```

## 常见问题排查

### 矩阵变换无效

矩阵未更新：
- 确保调用load_matrix加载新矩阵
- 检查矩阵乘顺序
- 验证矩阵有效性

### 投影错误

参数范围问题：
- 检查near和far值是否合理
- 确认aspect比率为正
- 验证fov值在有效范围内

### 坐标系问题

变换顺序错误：
- 理解矩阵乘法的非交换性
- 检查变换顺序是否符合预期
- 使用push/pop管理矩阵状态
