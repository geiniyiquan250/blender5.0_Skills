# bpy.ops.grease_pencil 模块

石墨铅笔动画操作模块，用于创建和管理2D绘画动画。

## 概述

bpy.ops.grease_pencil 模块包含用于创建和编辑石墨铅笔（Grease Pencil）对象的运算符。石墨铅笔是Blender中强大的2D绘图工具，可以用于动画制作、故事板绘制、概念设计等多种场景。

## 常用操作

### 基础操作

```python
import bpy

# 添加石墨铅笔对象
bpy.ops.object.grease_pencil_add(type='EMPTY')

# 添加空白石墨铅笔
bpy.ops.object.grease_pencil_add(type='EMPTY')

# 添加指定类型的石墨铅笔
bpy.ops.object.grease_pencil_add(type='DRAWING')

# 转换为石墨铅笔
bpy.ops.object.convert(target='GPENCIL')
```

### 绘制模式

```python
# 进入绘制模式
bpy.ops.gpencil.draw(mode='DRAW')

# 进入绘制模式
bpy.ops.gpencil.draw(mode='DRAW', stroke=stroke_data)

# 进入线条模式
bpy.ops.gpencil.draw(mode='LINE')

# 进入多边形模式
bpy.ops.gpencil.draw(mode='POLY')

# 进入弧线模式
bpy.ops.gpencil.draw(mode='ARC')

# 进入曲线模式
bpy.ops.gpencil.draw(mode='CURVE')

### 图层操作

```python
# 添加新图层
bpy.ops.gpencil.layer_add()

# 删除图层
bpy.ops.gpencil.layer_remove()

# 重命名图层
bpy.ops.gpencil.layer_rename(name='NewLayer')

# 复制图层
bpy.ops.gpencil.layer_duplicate()

# 移动图层
bpy.ops.gpencil.layer_move(type='UP')

# 隐藏图层
bpy.ops.gpencil.layer_hide()

# 显示图层
bpy.ops.gpencil.layer_reveal()

# 锁定图层
bpy.ops.gpencil.layer_lock()

# 解锁图层
bpy.ops.gpencil.layer_unlock()

# 设置图层透明度
bpy.ops.gpencil.layer_opacity(opacity=0.5)

# 设置图层混合模式
bpy.ops.gpencil.layer_blend(mode='NORMAL')
```

### 帧操作

```python
# 添加新帧
bpy.ops.gpencil.frame_add()

# 删除帧
bpy.ops.gpencil.frame_delete()

# 复制帧
bpy.ops.gpencil.frame_duplicate()

# 移动帧
bpy.ops.gpencil.frame_move(type='NEXT')

# 跳转到帧
bpy.ops.gpencil.frame_jump(frame=10)

# 选择帧
bpy.ops.gpencil.frame_select()

# 设置关键帧
bpy.ops.gpencil.interpolate()
```

### 绘制操作

```python
# 绘制线条
bpy.ops.gpencil.draw()

# 绘制点
bpy.ops.gpencil.draw(mode='DOT')

# 擦除线条
bpy.ops.gpencil.erase()

# 平滑线条
bpy.ops.gpencil.smooth()

# 简化线条
bpy.ops.gpencil.simplify()

# 复制到粘贴板
bpy.ops.gpencil.copy()

# 从粘贴板粘贴
bpy.ops.gpencil.paste()

# 删除选中
bpy.ops.gpencil.delete(type='STROKE')
```

### 选择操作

```python
# 全选
bpy.ops.gpencil.select_all(action='SELECT')

# 取消全选
bpy.ops.gpencil.select_all(action='DESELECT')

# 反选
bpy.ops.gpencil.select_all(action='INVERT')

# 选择同层
bpy.ops.gpencil.select_layer()

# 选择同帧
bpy.ops.gpencil.select_frame()

# 选择相同颜色
bpy.ops.gpencil.select_color()

# 选择相似
bpy.ops.gpencil.select_similar()
```

### 编辑操作

```python
# 进入编辑模式
bpy.ops.gpencil.editmode_toggle()

# 移动选中
bpy.ops.gpencil.move(delta_x=10, delta_y=0)

# 旋转选中
bpy.ops.gpencil.rotate(angle=45)

# 缩放选中
bpy.ops.gpencil.scale(factor=1.5)

# 复制选中
bpy.ops.gpencil.duplicate_move()

# 删除选中
bpy.ops.gpencil.delete(type='POINTS')

# 合并选中
bpy.ops.gpencil.merge(type='LAST')
```

## 实际应用示例

### 创建基本绘图

```python
def create_grease_pencil_drawing():
    """创建石墨铅笔绘图"""
    # 添加石墨铅笔对象
    bpy.ops.object.grease_pencil_add(type='EMPTY')
    gp_obj = bpy.context.active_object
    
    # 创建新图层
    bpy.ops.gpencil.layer_add()
    layer = bpy.context.active_object
    
    # 创建新帧
    bpy.ops.gpencil.frame_add()
    frame = bpy.context.active_object
    
    # 绘制简单线条
    stroke = [
        {"co": (0, 0, 0), "pressure": 1, "time": 0},
        {"co": (1, 1, 0), "pressure": 1, "time": 1},
        {"co": (2, 0, 0), "pressure": 1, "time": 2},
    ]
    
    # 添加笔画
    bpy.ops.gpencil.draw(stroke=stroke, mode='DRAW')
    
    return gp_obj
```

### 创建逐帧动画

```python
def create_frame_by_frame_animation(gp_obj, frame_count=24):
    """创建逐帧动画"""
    # 确保选中石墨铅笔对象
    bpy.context.view_layer.objects.active = gp_obj
    gp_obj.select_set(True)
    
    # 创建图层
    bpy.ops.gpencil.layer_add()
    layer = gp_obj.data.layers[0]
    
    # 为每一帧创建内容
    for i in range(frame_count):
        # 添加新帧
        bpy.ops.gpencil.frame_add()
        
        # 在当前帧绘制
        create_frame_content(i)
        
        # 移动到下一帧
        bpy.ops.gpencil.frame_move(type='NEXT')

def create_frame_content(frame_index):
    """创建帧内容"""
    import math
    
    # 创建圆形动画
    angle = frame_index * (2 * math.pi / 24)
    radius = 2
    
    stroke = []
    for i in range(36):
        theta = i * (2 * math.pi / 36)
        x = radius * math.cos(theta)
        y = radius * math.sin(theta)
        stroke.append({
            "co": (x, y, 0),
            "pressure": 1,
            "time": i
        })
    
    bpy.ops.gpencil.draw(stroke=stroke, mode='DRAW')
```

### 创建动画特效

```python
def create_glow_effect(gp_obj, layer_name):
    """创建发光效果"""
    layer = gp_obj.data.layers.get(layer_name)
    
    if layer:
        # 复制图层
        bpy.ops.gpencil.layer_duplicate()
        glow_layer = gp_obj.data.layers[-1]
        
        # 设置发光属性
        for frame in glow_layer.active_frame.strokes:
            for point in stroke.points:
                point.color = (1, 1, 0, 1)  # 黄色
            
        # 设置混合模式为叠加
        glow_layer.blend_mode = 'ADD'
        
        # 设置透明度
        bpy.ops.gpencil.layer_opacity(opacity=0.5)
```

### 创建洋葱皮效果

```python
def create_onion_skin(gp_obj, layer_name, past_frames=3, future_frames=3):
    """创建洋葱皮效果"""
    layer = gp_obj.data.layers.get(layer_name)
    
    if layer:
        # 启用洋葱皮
        layer.use_onion_skinning = True
        
        # 设置显示帧数
        layer.grease_pencil_onion_user_data.past_frames = past_frames
        layer.grease_pencil_onion_user_data.future_frames = future_frames
        
        # 设置洋葱皮透明度
        layer.grease_pencil_onion_user_data.opacity = 0.3
```

### 创建墨迹效果

```python
def create_ink_effect(gp_obj, layer_name):
    """创建墨迹效果"""
    layer = gp_obj.data.layers.get(layer_name)
    
    if layer:
        # 添加线条平滑修改器
        bpy.ops.gpencil.stroke_smooth()
        
        # 添加线条模糊效果
        for stroke in layer.active_frame.strokes:
            for point in stroke.points:
                point.draw_mode = '3DSPACE'
```

### 创建填充效果

```python
def create_fill_effect(gp_obj, layer_name):
    """创建填充效果"""
    layer = gp_obj.data.layers.get(layer_name)
    
    if layer:
        # 选择封闭区域
        bpy.ops.gpencil.select_all(action='DESELECT')
        
        # 使用填充工具
        for frame in layer.frames:
            for stroke in frame.strokes:
                if stroke.is_closed:
                    stroke.fill_opacity = 1.0
                    stroke.material_index = 1
```

### 创建蒙版效果

```python
def create_mask_layer(gp_obj, mask_layer_name):
    """创建蒙版图层"""
    # 添加新图层
    bpy.ops.gpencil.layer_add()
    mask_layer = bpy.context.active_object
    mask_layer.name = mask_layer_name
    
    # 设置为蒙版
    mask_layer.use_mask_layer = True
    
    # 绘制蒙版区域
    bpy.ops.gpencil.draw()
    
    return mask_layer
```

### 导出为SVG

```python
def export_to_svg(gp_obj, filepath):
    """导出为SVG文件"""
    # 选择石墨铅笔对象
    bpy.context.view_layer.objects.active = gp_obj
    gp_obj.select_set(True)
    
    # 导出为SVG
    bpy.ops.export_scene.gpencil(
        filepath=filepath,
        export_type='SVG'
    )
```

### 导出为PNG序列

```python
def export_to_png_sequence(gp_obj, output_dir, frame_start=1, frame_end=24):
    """导出为PNG序列"""
    # 设置渲染输出路径
    bpy.context.scene.render.filepath = output_dir
    
    # 逐帧渲染
    for frame in range(frame_start, frame_end + 1):
        bpy.context.scene.frame_set(frame)
        
        # 渲染当前帧
        bpy.ops.render.render(
            write_still=True,
            use_viewport=True
        )
```

### 创建故事板

```python
def create_storyboard(gp_obj, panels, frame_duration=8):
    """创建故事板"""
    layer = gp_obj.data.layers[0]
    
    for i, panel_content in enumerate(panels):
        # 计算帧范围
        start_frame = i * frame_duration + 1
        end_frame = (i + 1) * frame_duration
        
        # 跳转到帧
        bpy.ops.gpencil.frame_jump(frame=start_frame)
        
        # 绘制面板内容
        draw_panel_content(panel_content)
        
        # 复制到所有帧
        for frame in range(start_frame + 1, end_frame + 1):
            bpy.ops.gpencil.frame_jump(frame=frame)
            bpy.ops.gpencil.frame_duplicate()

def draw_panel_content(content):
    """绘制面板内容"""
    # 根据内容类型绘制不同图形
    if content['type'] == 'box':
        draw_rectangle(content['position'], content['size'])
    elif content['type'] == 'circle':
        draw_circle(content['position'], content['radius'])
    elif content['type'] == 'text':
        draw_text(content['text'], content['position'])
```

## 使用场景

- **2D动画制作**：创建手绘风格的动画
- **故事板绘制**：快速绘制动画分镜
- **概念设计**：草图和快速设计
- **注释和标记**：在3D场景中添加2D注释
- **动态特效**：创建线条动画和特效
- **角色动画**：2D角色动作设计
- **场景布局**：快速布局和构图
- **教学演示**：创建说明性动画

## 注意事项

- 石墨铅笔绘图需要切换到绘图区域
- 图层管理对于复杂项目很重要
- 帧操作需要确保在正确的图层上
- 绘制操作前需要选择正确的笔刷
- 导出前应检查图层和帧的完整性
- 大型项目需要注意性能优化
- 定期保存工作进度
- 使用蒙版可以创建复杂的叠加效果
- 洋葱皮功能有助于动画参考
- 结合3D场景可以创建独特的视觉效果
