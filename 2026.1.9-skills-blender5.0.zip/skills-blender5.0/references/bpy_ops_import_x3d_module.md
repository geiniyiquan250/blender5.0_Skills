# bpy.ops.import_scene - X3D导入操作模块

Blender X3D文件导入操作符，用于将X3D格式文件导入Blender。

## 概述

`bpy.ops.import_scene.x3d` 模块提供用于将X3D格式文件导入Blender的功能，支持Web3D内容和交互式3D场景的导入。

## 核心功能

### 基础导入

```python
import bpy

# 导入X3D文件
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    directory='//',
    files=[{'name': 'model.x3d'}],
    ui_tab='MAIN',
    use_unit_scale=True,
    use_normals=True,
    use_compression=True,
    import_scale=1.0,
    animation_mode='REPLACE',
   ani_filters=None,
    const_speed=True,
    use_cameras=True,
    use_lamps=True,
    use_glob=True,
    axis_forward='Z',
    axis_up='Y'
)
```

### 单位设置

```python
# 使用单位缩放
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    use_unit_scale=True
)

# 不使用单位缩放
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    use_unit_scale=False
)
```

### 几何体设置

```python
# 导入法线
bpy.ops.import_scene.x3d(
    filepath='//normals.x3d',
    use_normals=True
)

# 不导入法线
bpy.ops.import_scene.x3d(
    filepath='//no_normals.x3d',
    use_normals=False
)
```

### 压缩设置

```python
# 使用压缩
bpy.ops.import_scene.x3d(
    filepath='//compressed.x3d',
    use_compression=True
)

# 不使用压缩
bpy.ops.import_scene.x3d(
    filepath='//uncompressed.x3d',
    use_compression=False
)
```

### 缩放设置

```python
# 设置导入缩放
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    import_scale=1.0
)

# 缩放10倍
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    import_scale=10.0
)

# 缩小10倍
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    import_scale=0.1
)
```

### 动画设置

```python
# 导入动画
bpy.ops.import_scene.x3d(
    filepath='//anim.x3d',
    animation_mode='REPLACE'
)

# 替换动画
bpy.ops.import_scene.x3d(
    filepath='//anim.x3d',
    animation_mode='REPLACE'
)

# 附加动画
bpy.ops.import_scene.x3d(
    filepath='//anim.x3d',
    animation_mode='APPEND'
)

# 常速
bpy.ops.import_scene.x3d(
    filepath='//anim.x3d',
    const_speed=True
)

# 动画过滤器
bpy.ops.import_scene.x3d(
    filepath='//anim.x3d',
    ani_filters=['position', 'rotation']
)
```

### 相机导入

```python
# 导入相机
bpy.ops.import_scene.x3d(
    filepath='//cameras.x3d',
    use_cameras=True
)

# 不导入相机
bpy.ops.import_scene.x3d(
    filepath='//no_cameras.x3d',
    use_cameras=False
)
```

### 灯光导入

```python
# 导入灯光
bpy.ops.import_scene.x3d(
    filepath='//lamps.x3d',
    use_lamps=True
)

# 不导入灯光
bpy.ops.import_scene.x3d(
    filepath='//no_lamps.x3d',
    use_lamps=False
)
```

### 坐标轴设置

```python
# 设置前向轴
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    axis_forward='Z'
)

# 设置上向轴
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    axis_up='Y'
)

# 其他轴向组合
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    axis_forward='-Z',
    axis_up='Y'
)
```

### 球体设置

```python
# 使用全局
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    use_glob=True
)

# 不使用全局
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    use_glob=False
)
```

## 实用函数

```python
def import_x3d_model(filepath, scale=1.0):
    """导入X3D模型"""
    bpy.ops.import_scene.x3d(
        filepath=filepath,
        import_scale=scale,
        use_normals=True,
        use_cameras=True,
        use_lamps=True,
        animation_mode='REPLACE'
    )
    return list(bpy.context.selected_objects)

def import_x3d_with_animations(filepath, scale=1.0):
    """导入X3D带动画"""
    bpy.ops.import_scene.x3d(
        filepath=filepath,
        import_scale=scale,
        use_normals=True,
        use_cameras=True,
        use_lamps=True,
        animation_mode='REPLACE',
        const_speed=True
    )
    return list(bpy.context.selected_objects)

def import_x3d_for_editing(filepath, scale=1.0):
    """导入X3D用于编辑"""
    bpy.ops.import_scene.x3d(
        filepath=filepath,
        import_scale=scale,
        use_normals=True,
        use_cameras=False,
        use_lamps=False,
        animation_mode='REPLACE'
    )
    return list(bpy.context.selected_objects)

def import_x3d_compressed(filepath, scale=1.0):
    """导入压缩X3D"""
    bpy.ops.import_scene.x3d(
        filepath=filepath,
        import_scale=scale,
        use_normals=True,
        use_compression=True,
        use_cameras=True,
        use_lamps=True
    )
    return list(bpy.context.selected_objects)

def import_x3d_character(filepath, scale=1.0):
    """导入X3D角色"""
    bpy.ops.import_scene.x3d(
        filepath=filepath,
        import_scale=scale,
        use_normals=True,
        use_cameras=True,
        use_lamps=True,
        animation_mode='REPLACE',
        const_speed=True
    )
    return list(bpy.context.selected_objects)

def batch_import_x3d_files(x3d_files, scale=1.0):
    """批量导入X3D文件"""
    all_objects = []
    for filepath in x3d_files:
        bpy.ops.import_scene.x3d(
            filepath=filepath,
            import_scale=scale
        )
        imported = list(bpy.context.selected_objects)
        all_objects.extend(imported)
    return all_objects

def import_x3d_and_merge(filepath, scale=1.0):
    """导入X3D并合并"""
    bpy.ops.import_scene.x3d(
        filepath=filepath,
        import_scale=scale,
        use_normals=True,
        use_cameras=False,
        use_lamps=False
    )
    
    objects = list(bpy.context.selected_objects)
    if len(objects) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = objects[0]
        bpy.ops.object.join()
        return [bpy.context.active_object]
    
    return objects
```

## 常见问题排查

### 导入后模型不可见
```python
# 检查选中对象
selected = bpy.context.selected_objects
print(f"导入对象数: {len(selected)}")

# 检查对象类型
for obj in selected:
    print(f"{obj.name}: 类型={obj.type}")

# 检查隐藏状态
for obj in selected:
    print(f"{obj.name}: 隐藏={obj.hide_viewport}")
    obj.hide_viewport = False

# 检查显示类型
for obj in selected:
    obj.display_type = 'SOLID'
```

### 材质丢失
```python
# 检查材质
print(f"材质数: {len(bpy.data.materials)}")

# 检查纹理
print(f"纹理数: {len(bpy.data.textures)}")

# 检查图像
print(f"图像数: {len(bpy.data.images)}")

# 重新导入
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    use_normals=True,
    use_cameras=True,
    use_lamps=True
)
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 检查骨骼动画
if obj.type == 'ARMATURE':
    print(f"骨骼数: {len(obj.data.bones)}")

# 重新导入带动画
bpy.ops.import_scene.x3d(
    filepath='//anim.x3d',
    animation_mode='REPLACE',
    const_speed=True
)
```

### 比例问题
```python
# 检查导入比例
obj = bpy.context.active_object
print(f"尺寸: {obj.dimensions}")

# 检查单位设置
print(f"场景单位: {bpy.context.scene.unit_settings.system}")

# 重新导入带正确比例
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    import_scale=0.01,
    use_unit_scale=True
)
```

### 性能问题
```python
# 检查对象数
print(f"对象数: {len(bpy.context.selected_objects)}")

# 减少导入内容
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    use_cameras=False,
    use_lamps=False,
    animation_mode='REPLACE'
)

# 导入后优化
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.join()
```

### 坐标轴问题
```python
# 检查导入的变换
obj = bpy.context.active_object
print(f"位置: {obj.location}")
print(f"旋转: {obj.rotation_euler}")
print(f"缩放: {obj.scale}")

# 尝试不同轴向
bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    axis_forward='Z',
    axis_up='Y'
)

bpy.ops.import_scene.x3d(
    filepath='//model.x3d',
    axis_forward='-Z',
    axis_up='Y'
)
```

### 压缩问题
```python
# 检查压缩状态
print(f"压缩文件: {filepath.endswith('.x3dz')}")

# 尝试解压
import gzip
with gzip.open(filepath, 'rb') as f:
    content = f.read()
    with open(filepath[:-1], 'wb') as out:
        out.write(content)

# 导入解压后的文件
bpy.ops.import_scene.x3d(
    filepath=filepath[:-1],
    use_compression=False
)
```

### 动画速度问题
```python
# 检查动画速度
obj = bpy.context.active_object
if obj.animation_data:
    print(f"动画长度: {obj.animation_data.action.frame_range}")

# 使用常速
bpy.ops.import_scene.x3d(
    filepath='//anim.x3d',
    animation_mode='REPLACE',
    const_speed=True
)

# 调整速度
if obj.animation_data:
    for fcurve in obj.animation_data.action.fcurves:
        for keyframe in fcurve.keyframe_points:
            keyframe.interpolation = 'LINEAR'
```
