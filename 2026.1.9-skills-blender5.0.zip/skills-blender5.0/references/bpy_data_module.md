# bpy.data 模块

## 模块概述

bpy.data 模块提供对 Blender 当前 .blend 文件中所有数据的全局访问接口，通过该模块可以访问场景、物体、材质、纹理、图像、几何节点树等各种数据。这个模块是 Blender Python API 的核心组成部分，它将 .blend 文件中的所有数据组织成易于访问的集合形式。与 bpy.context 提供运行时上下文信息不同，bpy.data 包含的是文件的持久化数据，这些数据在文件保存和加载时保持不变。

数据访问遵循标准的 Python 集合接口，可以通过索引、名称或键来访问具体的数据项。每个数据项都是 Blender 内部数据结构的 Python 表示，如 Scene、Object、Material、Texture、Image、NodeTree 等。bpy.data 中的数据在脚本运行过程中会被实时更新，例如当用户创建新物体时，bpy.data.objects 集合会自动包含新物体的引用。

该模块还提供了数据管理的常用方法，包括创建新数据项、删除不需要的数据、查找重复项、批量更新属性等。由于 bpy.data 包含整个项目的数据，在编写脚本时应该注意数据操作的影响范围，避免意外修改或删除重要的项目数据。

## 数据集合结构

### 集合属性

bpy.data 中的每个数据集合都继承自 bpy.props.CollectionProperty 和 bpy.types.ID 的组合，具有统一的访问接口。collections 属性返回所有数据集合的字典，可以按名称或索引访问每个集合。所有的集合都支持整数索引、字符串键和迭代操作，这提供了极大的灵活性。

每个数据项都有一些共同的基本属性。name 属性是数据项的显示名称，可以在用户界面中修改。users 属性表示有多少其他数据引用了这个数据项，用于判断是否可以安全删除。use_fake_user 属性设置是否为数据项创建一个虚引用，防止在没有用户引用时被垃圾回收。tag 属性用于在脚本中临时标记数据项。

```python
import bpy

# 访问所有数据集合
print("数据集合列表:")
for name, collection in bpy.data.collections.items():
    print(f"  {name}: {len(collection)} 项")

# 访问常用集合
scenes = bpy.data.scenes
objects = bpy.data.objects
materials = bpy.data.materials
meshes = bpy.data.meshes

print(f"\n场景数量: {len(scenes)}")
print(f"物体数量: {len(objects)}")
print(f"材质数量: {len(materials)}")
print(f"网格数量: {len(meshes)}")

# 通过名称访问数据项
cube = bpy.data.objects.get("Cube")
if cube:
    print(f"\n找到物体: {cube.name}")
    print(f"物体类型: {cube.type}")
    print(f"引用计数: {cube.users}")

# 通过索引访问数据项
if len(objects) > 0:
    first_obj = objects[0]
    print(f"\n第一个物体: {first_obj.name}")
```

### 数据生命周期

理解数据生命周期对于正确管理 Blender 项目数据至关重要。当创建一个新的数据项时，它的 users 计数从 0 开始。如果 users 变为 0 且没有设置 use_fake_user，该数据项会在下一次垃圾回收时从文件中删除。垃圾回收可以通过 bpy.data.remove 函数手动触发，也可以让 Blender 自动处理。

数据项的删除应该使用 bpy.data.remove 函数，而不是直接从集合中弹出或删除。这确保了所有引用和数据关联被正确清理。如果删除的数据项仍被其他数据引用，Blender 会阻止删除操作并抛出异常。

```python
import bpy

def safe_remove_data(data_item):
    """安全地删除数据项"""
    if data_item is None:
        return

    # 检查引用计数
    if data_item.users > 0:
        print(f"警告: {data_item.name} 仍有 {data_item.users} 个引用，无法删除")
        return False

    # 获取数据项类型名称
    data_type = type(data_item).__name__
    data_name = data_item.name

    # 删除数据项
    bpy.data.remove(data_item)
    print(f"已删除 {data_type}: {data_name}")
    return True

def create_fake_user_for_orphans():
    """为所有孤立数据项创建虚引用"""
    removed_count = 0

    for collection_name in ['objects', 'materials', 'meshes', 'textures', 'images']:
        collection = getattr(bpy.data, collection_name)
        for item in collection:
            if item.users == 0:
                item.use_fake_user = True
                removed_count += 1

    print(f"为 {removed_count} 个孤立数据项创建了虚引用")

# 使用示例
# create_fake_user_for_orphans()
```

## 场景数据访问

### 场景集合

scenes 集合包含项目中的所有场景，每个场景是一个完整的场景定义，包含自己的物体集合、渲染设置、时间线等。通过这个集合可以创建新场景、切换活动场景、复制现有场景等操作。活动场景存储在 bpy.context.scene 中，但可以通过 bpy.data.scenes 访问所有场景。

```python
import bpy

# 获取所有场景
for scene in bpy.data.scenes:
    print(f"场景: {scene.name}")

# 创建新场景
new_scene = bpy.data.scenes.new(name="渲染场景")
print(f"创建新场景: {new_scene.name}")

# 复制现有场景
if bpy.data.scenes:
    copied_scene = bpy.data.scenes.new(name="复制场景", from_scene=bpy.data.scenes[0])
    print(f"复制场景: {copied_scene.name}")

# 删除场景（如果有引用则无法删除）
scene_to_delete = bpy.data.scenes.get("删除场景")
if scene_to_delete and scene_to_delete.users == 0:
    bpy.data.scenes.remove(scene_to_delete)

# 设置活动场景
if len(bpy.data.scenes) > 1:
    bpy.context.window.scene = bpy.data.scenes[1]
    print(f"切换到场景: {bpy.context.scene.name}")
```

### 场景属性访问

每个场景对象包含丰富的属性，涵盖了场景的各个方面。objects 集合包含场景中所有物体的引用。view_layers 集合包含视图层的定义，用于组织物体的可见性和渲染。render 属性包含渲染设置，如分辨率、采样、输出格式等。timeline_cursor 表示时间线光标的位置。

```python
import bpy

scene = bpy.context.scene

# 访问场景中的物体
print(f"场景 '{scene.name}' 中的物体:")
for obj in scene.objects:
    print(f"  - {obj.name} ({obj.type})")

# 访问视图层
print(f"\n视图层:")
for layer in scene.view_layers:
    layer_info = {
        'name': layer.name,
        'objects': len(layer.objects),
        'use': layer.use
    }
    print(f"  - {layer_info}")

# 访问渲染设置
render = scene.render
print(f"\n渲染设置:")
print(f"  分辨率: {render.resolution_x} x {render.resolution_y}")
print(f"  帧范围: {render.frame_start} - {render.frame_end}")
print(f"  FPS: {render.fps}")

# 访问节点树
if scene.use_nodes:
    tree = scene.node_tree
    print(f"\n合成节点树:")
    for node in tree.nodes:
        print(f"  - {node.name} ({node.type})")
```

## 物体数据访问

### 物体集合

objects 集合包含项目中所有物体的引用，无论这些物体属于哪个场景。每个物体都有一个唯一的数据块引用，指向其几何数据（如 Mesh、Curve、Surface 等）。物体的位置、旋转、缩放等变换信息存储在物体本身，而几何数据则存储在独立的数据块中。

```python
import bpy

# 遍历所有物体
print("所有物体:")
for obj in bpy.data.objects:
    obj_type = obj.type
    data_block = obj.data

    print(f"  {obj.name}:")
    print(f"    类型: {obj_type}")
    print(f"    数据块: {data_block.name if data_block else '无'}")

    # 获取变换信息
    print(f"    位置: {obj.location.to_tuple()}")
    print(f"    旋转: {obj.rotation_euler.to_tuple()}")
    print(f"    缩放: {obj.scale.to_tuple()}")

    # 获取物体矩阵
    print(f"    世界矩阵:\n{obj.matrix_world}")

# 按类型筛选物体
def get_objects_by_type(obj_type):
    """获取指定类型的所有物体"""
    return [obj for obj in bpy.data.objects if obj.type == obj_type]

mesh_objects = get_objects_by_type('MESH')
light_objects = get_objects_by_type('LIGHT')
camera_objects = get_objects_by_type('CAMERA')

print(f"\n网格物体: {len(mesh_objects)}")
print(f"灯光物体: {len(light_objects)}")
print(f"相机物体: {len(camera_objects)}")
```

### 物体数据块

物体的几何数据存储在独立的数据块中，可以通过物体的 data 属性访问。不同的物体类型对应不同的数据块类型：网格物体对应 Mesh 数据块，曲线物体对应 Curve 数据块，曲面物体对应 Surface 数据块，字体物体对应 Text 数据块等。

```python
import bpy

# 访问网格数据
for obj in bpy.data.objects:
    if obj.type == 'MESH':
        mesh = obj.data
        print(f"\n物体 {obj.name} 的网格数据:")
        print(f"  网格名称: {mesh.name}")
        print(f"  顶点数: {len(mesh.vertices)}")
        print(f"  边数: {len(mesh.edges)}")
        print(f"  面数: {len(mesh.polygons)}")

        # 访问顶点坐标
        if mesh.vertices:
            first_vertex = mesh.vertices[0]
            print(f"  第一个顶点: {first_vertex.co}")

        # 访问面法线
        if mesh.polygons:
            first_poly = mesh.polygons[0]
            print(f"  第一个面法线: {first_poly.normal}")

# 访问曲线数据
for obj in bpy.data.objects:
    if obj.type == 'CURVE':
        curve = obj.data
        print(f"\n物体 {obj.name} 的曲线数据:")
        print(f"  曲线名称: {curve.name}")
        print(f"  样条数量: {len(curve.splines)}")

        for spline in curve.splines:
            spline_type = type(spline).__name__
            points_count = len(spline.points) if hasattr(spline, 'points') else len(spline.bezier_points)
            print(f"    样条类型: {spline_type}, 点数: {points_count}")
```

### 创建和删除物体

通过 bpy.data.objects.new 可以创建新物体，这个方法需要指定物体名称和数据块。数据块可以是 None（创建空物体）或现有的数据块引用。创建物体后，需要将其添加到场景中才能在视图中显示。

```python
import bpy
import math

def create_new_mesh(name, vertices, edges, faces):
    """创建新的网格数据"""
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(vertices, edges, faces)
    mesh.update()

    # 创建物体
    obj = bpy.data.objects.new(name, mesh)
    
    # 添加到当前场景
    bpy.context.scene.collection.objects.link(obj)
    
    return obj

def create_cube(name="新立方体"):
    """创建立方体"""
    # 定义立方体顶点
    vertices = [
        (-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1),
        (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1)
    ]

    # 定义边
    edges = [
        (0, 1), (1, 2), (2, 3), (3, 0),
        (4, 5), (5, 6), (6, 7), (7, 4),
        (0, 4), (1, 5), (2, 6), (3, 7)
    ]

    # 定义面
    faces = [
        (0, 1, 2, 3), (4, 7, 6, 5),
        (0, 4, 5, 1), (1, 5, 6, 2),
        (2, 6, 7, 3), (3, 7, 4, 0)
    ]

    return create_new_mesh(name, vertices, edges, faces)

# 使用示例
# cube = create_cube("我的立方体")
# cube.location = (0, 0, 0)

def duplicate_object(obj, new_name=None):
    """复制物体"""
    if new_name is None:
        new_name = f"{obj.name}_复制"

    # 复制数据块
    new_data = obj.data.copy()
    new_data.name = new_name

    # 创建新物体
    new_obj = bpy.data.objects.new(new_name, new_data)

    # 复制变换属性
    new_obj.location = obj.location.copy()
    new_obj.rotation_euler = obj.rotation_euler.copy()
    new_obj.scale = obj.scale.copy()

    # 复制其他属性
    new_obj.matrix_world = obj.matrix_world.copy()

    # 添加到场景
    bpy.context.scene.collection.objects.link(new_obj)

    return new_obj

# 使用示例
# if bpy.context.active_object:
#     duplicated = duplicate_object(bpy.context.active_object)
```

## 材质数据访问

### 材质集合

materials 集合包含项目中所有材质的引用。每个材质可以应用到多个物体，材质的使用计数（users）表示有多少物体或数据块使用了该材质。材质包含多个属性组，如表面属性、体积属性、置换属性等。

```python
import bpy

# 遍历所有材质
for material in bpy.data.materials:
    print(f"\n材质: {material.name}")
    print(f"  引用计数: {material.users}")

    # 检查是否使用
    is_used = material.users > 0
    print(f"  正在使用: {is_used}")
    print(f"  虚引用: {material.use_fake_user}")

    # 获取材质类型
    material_type = "体积" if material.use_nodes and material.node_tree and any(n.type == 'BSDF_VOLUME' for n in material.node_tree.nodes) else "表面"
    print(f"  类型: {material_type}")

    # 如果使用节点，遍历节点
    if material.use_nodes and material.node_tree:
        print(f"  节点树:")
        for node in material.node_tree.nodes:
            print(f"    - {node.name} ({node.type})")

# 创建新材质
def create_new_material(name, color=(0.5, 0.5, 0.5, 1.0)):
    """创建新的基础材质"""
    material = bpy.data.materials.new(name=name)
    material.diffuse_color = color

    # 禁用节点，使用简单材质
    material.use_nodes = False
    material.diffuse_color = color[:3]

    return material

# 使用示例
# mat = create_new_material("我的材质", (0.8, 0.2, 0.2, 1.0))
# bpy.context.active_object.data.materials.append(mat)
```

### 材质属性访问

材质对象包含丰富的属性，覆盖了表面着色、体积渲染、置换等多个方面。每个属性组都有独立的配置选项，可以通过材质对象的属性直接访问。

```python
import bpy

def analyze_material(material):
    """分析材质的详细信息"""
    info = {
        '名称': material.name,
        '引用计数': material.users,
        '使用节点': material.use_nodes,
        '虚引用': material.use_fake_user
    }

    # 表面属性
    if hasattr(material, 'surface'):
        surface = material.surface
        info['表面着色器'] = surface.shader_type if hasattr(surface, 'shader_type') else "无"

    # 体积属性
    if hasattr(material, 'volume'):
        volume = material.volume
        info['体积着色器'] = volume.shader_type if hasattr(volume, 'shader_type') else "无"

    return info

# 分析所有材质
print("材质分析报告:")
for material in bpy.data.materials:
    info = analyze_material(material)
    print(f"\n{info['名称']}:")
    for key, value in info.items():
        print(f"  {key}: {value}")
```

## 纹理和图像数据访问

### 纹理集合

textures 集合包含项目中所有纹理的引用。纹理可以是图像纹理、程序纹理（如云层、噪波、 Musgrave 等）。每个纹理都有类型属性，标识纹理的种类。Blender 4.0 之后，传统的纹理系统逐渐被节点系统取代，但纹理集合仍然保留用于向后兼容。

```python
import bpy

# 遍历所有纹理
for texture in bpy.data.textures:
    print(f"\n纹理: {texture.name}")
    print(f"  类型: {texture.type}")
    print(f"  引用计数: {texture.users}")

    # 根据类型显示不同信息
    if texture.type == 'CLOUDS':
        print(f"  云层纹理 - 大小: {texture.noise_scale}")
    elif texture.type == 'WOOD':
        print(f"  木纹纹理 - 宽度: {texture.noise_width}")
    elif texture.type == 'MARBLE':
        print(f"  大理石纹理 - 深度: {texture.noise_depth}")
    elif texture.type == 'IMAGE':
        if texture.image:
            print(f"  图像纹理: {texture.image.name}")
            print(f"  图像尺寸: {texture.image.size[0]} x {texture.image.size[1]}")

# 统计纹理类型
texture_counts = {}
for texture in bpy.data.textures:
    texture_type = texture.type
    texture_counts[texture_type] = texture_counts.get(texture_type, 0) + 1

print("\n纹理类型统计:")
for tex_type, count in texture_counts.items():
    print(f"  {tex_type}: {count}")
```

### 图像集合

images 集合包含项目中加载的所有图像。每个图像可以是外部文件引用或嵌入式数据。图像有尺寸、通道数、颜色空间等属性。对于外部文件，可以检查文件是否丢失或需要重新加载。

```python
import bpy
import os

def analyze_image(image):
    """分析图像信息"""
    info = {
        '名称': image.name,
        '尺寸': f"{image.size[0]} x {image.size[1]}",
        '通道数': image.channels if hasattr(image, 'channels') else "未知",
        '深度': f"{image.depth} 位" if hasattr(image, 'depth') else "未知",
        '文件路径': image.filepath if hasattr(image, 'filepath') else "无",
        '已打包': image.packed_file is not None if hasattr(image, 'packed_file') else False,
        '引用计数': image.users,
        '分辨率': f"{image.dpi[0]} DPI" if hasattr(image, 'dpi') else "未知"
    }

    return info

# 分析所有图像
print("图像分析报告:")
for image in bpy.data.images:
    info = analyze_image(image)
    print(f"\n{info['名称']}:")
    for key, value in info.items():
        print(f"  {key}: {value}")

    # 检查文件是否存在（对于未打包的图像）
    if info['文件路径'] and info['文件路径'] != "无" and not info['已打包']:
        filepath = bpy.path.abspath(info['文件路径'])
        if not os.path.exists(filepath):
            print(f"  警告: 文件丢失!")

# 创建新图像
def create_new_image(name, width, height, color=(0, 0, 0, 1)):
    """创建新图像"""
    image = bpy.data.images.new(name=name, width=width, height=height, alpha='A' in image.color_mode if hasattr(image, 'color_mode') else True)

    # 填充颜色
    pixels = [c for c in color for _ in range(width * height)]
    image.pixels = pixels

    return image

# 使用示例
# img = create_new_image("我的纹理", 512, 512, (1, 1, 1, 1))
```

## 节点树数据访问

### 节点树集合

node_trees 集合包含项目中所有节点树的引用，包括材质节点树、合成节点树、几何节点树等。每种节点树都有特定的根节点类型和用途。材质节点树用于定义材质外观，合成节点树用于后期处理，几何节点树用于几何体生成和修改。

```python
import bpy

# 遍历所有节点树
for node_tree in bpy.data.node_groups:
    print(f"\n节点树: {node_tree.name}")
    print(f"  类型: {node_tree.type}")
    print(f"  节点数: {len(node_tree.nodes)}")
    print(f"  链接数: {len(node_tree.links)}")

    # 统计节点类型
    node_counts = {}
    for node in node_tree.nodes:
        node_type = node.type
        node_counts[node_type] = node_counts.get(node_type, 0) + 1

    print(f"  节点类型统计:")
    for ntype, count in node_counts.items():
        print(f"    {ntype}: {count}")

# 按类型筛选节点树
def get_node_trees_by_type(tree_type):
    """获取指定类型的节点树"""
    return [tree for tree in bpy.data.node_groups if tree.type == tree_type]

material_trees = get_node_trees_by_type('SHADER')
geometry_trees = get_node_trees_by_type('GEOMETRY')
compositor_trees = get_node_trees_by_type('COMPOSITE')

print(f"\n材质节点树: {len(material_trees)}")
print(f"几何节点树: {len(geometry_trees)}")
print(f"合成节点树: {len(compositor_trees)}")
```

### 节点和链接访问

每个节点树由多个节点和链接组成。节点是执行特定功能的单元，如 Principled BSDF 节点、混合节点、数学节点等。链接连接节点的输出和输入端口，建立数据流。可以通过遍历 nodes 和 links 集合来访问和修改节点树的结构。

```python
import bpy

def analyze_node_tree(node_tree):
    """分析节点树结构"""
    print(f"\n节点树: {node_tree.name}")
    print(f"  节点数: {len(node_tree.nodes)}")
    print(f"  链接数: {len(node_tree.links)}")

    print("  节点列表:")
    for i, node in enumerate(node_tree.nodes):
        print(f"    [{i}] {node.name} ({node.type})")

        # 显示输入端口
        inputs = [f"{inp.identifier}:{inp.type}" for inp in node.inputs if inp.enabled]
        if inputs:
            print(f"        输入: {', '.join(inputs)}")

        # 显示输出端口
        outputs = [f"{out.identifier}:{out.type}" for out in node.outputs if out.enabled]
        if outputs:
            print(f"        输出: {', '.join(outputs)}")

    print("  链接列表:")
    for link in node_tree.links:
        from_node = link.from_node.name
        from_socket = link.from_socket.identifier
        to_node = link.to_node.name
        to_socket = link.to_socket.identifier
        print(f"    {from_node}.{from_socket} -> {to_node}.{to_socket}")

# 分析当前材质的节点树
if bpy.context.active_object and bpy.context.active_object.active_material:
    material = bpy.context.active_object.active_material
    if material.use_nodes and material.node_tree:
        analyze_node_tree(material.node_tree)
```

### 创建节点和链接

通过 Python API 可以创建新节点并建立连接来构建节点树。这是程序化生成材质和几何节点设置的基础。

```python
import bpy

def create_simple_material(name="程序材质"):
    """创建简单的 Principled BSDF 材质"""
    # 创建材质
    material = bpy.data.materials.new(name=name)
    material.use_nodes = True

    # 获取节点树
    tree = material.node_tree

    # 清除默认节点
    tree.nodes.clear()

    # 创建输出节点
    output = tree.nodes.new('ShaderNodeOutputMaterial')
    output.location = (400, 0)

    # 创建 Principled BSDF 节点
    principled = tree.nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (0, 0)

    # 创建颜色渐变节点（可选）
    gradient = tree.nodes.new('ShaderNodeValToRGB')
    gradient.location = (-400, 0)
    gradient.color_ramp.elements[0].color = (0, 0, 1, 1)
    gradient.color_ramp.elements[1].color = (1, 0, 0, 1)

    # 创建链接
    tree.links.new(principled.outputs['BSDF'], output.inputs['Surface'])

    return material

# 使用示例
# mat = create_simple_material("我的程序材质")

def create_geometry_nodes_tree(name="几何节点"):
    """创建几何节点树"""
    # 创建节点树
    tree = bpy.data.node_groups.new(name=name, type='GEOMETRY')

    # 创建节点
    input_node = tree.nodes.new('NodeGroupInput')
    output_node = tree.nodes.new('NodeGroupOutput')
    cube_node = tree.nodes.new('GeometryNodeMeshCube')

    # 设置位置
    input_node.location = (-200, 0)
    output_node.location = (400, 0)
    cube_node.location = (0, 0)

    # 创建链接
    tree.links.new(cube_node.outputs['Mesh'], output_node.inputs['Geometry'])

    return tree

# 使用示例
# geo_tree = create_geometry_nodes_tree("我的几何节点")
```

## 常用操作方法

### 查找重复数据

项目中经常会产生重复的数据项，如复制物体时连带复制的数据块。使用 find_duplicates 方法可以找出可以合并的数据项，这有助于优化文件大小和减少内存使用。

```python
import bpy

def find_duplicate_meshes():
    """查找重复的网格数据"""
    mesh_dict = {}

    for mesh in bpy.data.meshes:
        key = (len(mesh.vertices), len(mesh.polygons))
        if key not in mesh_dict:
            mesh_dict[key] = []
        mesh_dict[key].append(mesh)

    duplicates = {k: v for k, v in mesh_dict.items() if len(v) > 1}
    return duplicates

def find_similar_materials(threshold=0.9):
    """查找相似的材质"""
    # 基于节点类型和数量比较
    materials = list(bpy.data.materials)
    similar_pairs = []

    for i, mat1 in enumerate(materials):
        for mat2 in materials[i + 1:]:
            if mat1.use_nodes and mat2.use_nodes:
                if mat1.node_tree and mat2.node_tree:
                    nodes1 = len(mat1.node_tree.nodes)
                    nodes2 = len(mat2.node_tree.nodes)
                    if nodes1 == nodes2:
                        similar_pairs.append((mat1, mat2))

    return similar_pairs

# 使用示例
# duplicates = find_duplicate_meshes()
# for key, meshes in duplicates.items():
#     print(f"重复网格 (顶点数: {key[0]}, 面数: {key[1]}):")
#     for mesh in meshes:
#         print(f"  - {mesh.name}")
```

### 批量更新属性

当需要更新多个数据项的共同属性时，可以遍历数据集合进行批量操作。这比逐个处理更高效，也更容易维护。

```python
import bpy

def batch_set_material_color(color, material_names=None):
    """批量设置材质颜色"""
    materials = bpy.data.materials

    if material_names:
        target_materials = [mat for mat in materials if mat.name in material_names]
    else:
        target_materials = list(materials)

    for mat in target_materials:
        if not mat.use_nodes:
            mat.diffuse_color = color

    print(f"已更新 {len(target_materials)} 个材质")

def batch_rename_objects(prefix, obj_type=None):
    """批量重命名物体"""
    objects = bpy.data.objects

    if obj_type:
        target_objects = [obj for obj in objects if obj.type == obj_type]
    else:
        target_objects = list(objects)

    for i, obj in enumerate(target_objects):
        obj.name = f"{prefix}_{i:03d}"

    print(f"已重命名 {len(target_objects)} 个物体")

def batch_set_object_location(location, obj_names=None):
    """批量设置物体位置"""
    objects = bpy.data.objects

    if obj_names:
        target_objects = [obj for obj in objects if obj.name in obj_names]
    else:
        target_objects = list(objects)

    for obj in target_objects:
        obj.location = location

    print(f"已更新 {len(target_objects)} 个物体的位置")

# 使用示例
# batch_set_material_color((0.8, 0.2, 0.2, 1.0))
# batch_rename_objects("Cube", 'MESH')
# batch_set_object_location((0, 0, 0))
```

### 数据验证和清理

定期验证和清理项目数据可以保持文件的整洁和性能。使用各种 API 方法可以检查数据的有效性并清理不需要的项目。

```python
import bpy

def validate_all_data():
    """验证所有数据项的有效性"""
    issues = []

    # 检查孤立物体
    for obj in bpy.data.objects:
        if obj.users == 0:
            issues.append(f"孤立物体: {obj.name}")

    # 检查孤立材质
    for mat in bpy.data.materials:
        if mat.users == 0 and not mat.use_fake_user:
            issues.append(f"孤立材质: {mat.name}")

    # 检查孤立网格
    for mesh in bpy.data.meshes:
        if mesh.users == 0:
            issues.append(f"孤立网格: {mesh.name}")

    # 检查丢失的图像引用
    for image in bpy.data.images:
        if image.packed_file is None and not image.filepath:
            issues.append(f"无源图像: {image.name}")

    return issues

def cleanup_orphaned_data():
    """清理孤立数据项"""
    removed = {'objects': 0, 'materials': 0, 'meshes': 0, 'textures': 0, 'images': 0}

    # 清理孤立物体
    for obj in list(bpy.data.objects):
        if obj.users == 0:
            bpy.data.objects.remove(obj)
            removed['objects'] += 1

    # 清理孤立材质
    for mat in list(bpy.data.materials):
        if mat.users == 0:
            bpy.data.materials.remove(mat)
            removed['materials'] += 1

    # 清理孤立网格
    for mesh in list(bpy.data.meshes):
        if mesh.users == 0:
            bpy.data.meshes.remove(mesh)
            removed['meshes'] += 1

    return removed

# 使用示例
# issues = validate_all_data()
# for issue in issues:
#     print(issue)
```

## 实践示例

### 导出数据报告

这个示例展示了如何生成项目数据的详细报告。

```python
import bpy

def generate_data_report():
    """生成项目数据报告"""
    report = []
    report.append("=" * 60)
    report.append("Blender 项目数据报告")
    report.append("=" * 60)

    # 场景信息
    report.append(f"\n场景数量: {len(bpy.data.scenes)}")
    for scene in bpy.data.scenes:
        report.append(f"  - {scene.name}")

    # 物体统计
    report.append(f"\n物体总数: {len(bpy.data.objects)}")
    obj_counts = {}
    for obj in bpy.data.objects:
        obj_counts[obj.type] = obj_counts.get(obj.type, 0) + 1
    for obj_type, count in sorted(obj_counts.items()):
        report.append(f"  - {obj_type}: {count}")

    # 材质统计
    report.append(f"\n材质总数: {len(bpy.data.materials)}")
    used_materials = sum(1 for m in bpy.data.materials if m.users > 0)
    unused_materials = len(bpy.data.materials) - used_materials
    report.append(f"  - 使用中: {used_materials}")
    report.append(f"  - 未使用: {unused_materials}")

    # 网格统计
    report.append(f"\n网格总数: {len(bpy.data.meshes)}")
    total_vertices = sum(len(m.vertices) for m in bpy.data.meshes)
    total_polygons = sum(len(m.polygons) for m in bpy.data.meshes)
    report.append(f"  - 总顶点数: {total_vertices}")
    report.append(f"  - 总面数: {total_polygons}")

    # 图像统计
    report.append(f"\n图像总数: {len(bpy.data.images)}")
    total_pixels = sum(i.size[0] * i.size[1] for i in bpy.data.images)
    report.append(f"  - 总像素数: {total_pixels}")

    # 节点树统计
    report.append(f"\n节点树总数: {len(bpy.data.node_groups)}")

    return "\n".join(report)

# 使用示例
# report = generate_data_report()
# print(report)
```

### 资源管理器

这个示例展示了一个简单的资源管理器功能，用于查看和管理项目数据。

```python
import bpy

class DataManager:
    def __init__(self):
        self.data_types = [
            ('scenes', '场景', bpy.data.scenes),
            ('objects', '物体', bpy.data.objects),
            ('materials', '材质', bpy.data.materials),
            ('meshes', '网格', bpy.data.meshes),
            ('textures', '纹理', bpy.data.textures),
            ('images', '图像', bpy.data.images),
            ('node_groups', '节点树', bpy.data.node_groups)
        ]

    def list_data_items(self, data_type):
        """列出指定类型的所有数据项"""
        for type_key, type_name, collection in self.data_types:
            if type_key == data_type:
                print(f"\n{type_name} ({len(collection)} 项):")
                for item in collection:
                    users = item.users
                    fake_user = getattr(item, 'use_fake_user', False)
                    status = "使用中" if users > 0 else ("虚引用" if fake_user else "孤立")
                    print(f"  - {item.name} ({status}, 引用: {users})")
                return

    def get_statistics(self):
        """获取数据统计信息"""
        stats = {}
        for type_key, _, collection in self.data_types:
            stats[type_key] = len(collection)
        return stats

    def find_data_by_name(self, name, data_type=None):
        """按名称查找数据项"""
        results = []

        if data_type:
            target_types = [(dt, tn, c) for dt, tn, c in self.data_types if dt == data_type]
        else:
            target_types = self.data_types

        for type_key, _, collection in target_types:
            for item in collection:
                if name.lower() in item.name.lower():
                    results.append((type_key, item))

        return results

    def remove_unused_data(self, data_type=None):
        """删除未使用的数据项"""
        removed_count = 0

        if data_type:
            target_collections = [c for dt, _, c in self.data_types if dt == data_type]
        else:
            target_collections = [c for _, _, c in self.data_types]

        for collection in target_collections:
            collection_name = type(collection).__name__
            for item in list(collection):
                if item.users == 0 and not getattr(item, 'use_fake_user', False):
                    collection.remove(item)
                    removed_count += 1
                    print(f"已删除: {item.name} ({collection_name})")

        return removed_count

# 使用示例
# manager = DataManager()
# manager.list_data_items('materials')
# results = manager.find_data_by_name('Cube')
# removed = manager.remove_unused_data()
```

## 注意事项

### 数据引用管理

在操作 bpy.data 中的数据时，需要特别注意引用关系。当删除一个数据项时，确保没有其他数据引用它，否则会抛出异常。可以使用 users 属性检查引用计数。对于需要保留但暂时未使用的数据，可以设置 use_fake_user 属性来防止被垃圾回收。

### 文件性能影响

bpy.data 中的数据量直接影响文件的加载、保存和内存使用。大型项目应该定期清理未使用的数据项，使用批量操作代替循环操作可以提高性能。在编写处理大量数据的脚本时，应该注意内存使用，避免创建不必要的数据副本。

### 实时更新机制

bpy.data 中的集合是实时更新的，这意味着在遍历集合时如果创建或删除数据项，可能会影响遍历的正确性。如果需要在遍历时修改集合，建议先创建数据项的副本列表。