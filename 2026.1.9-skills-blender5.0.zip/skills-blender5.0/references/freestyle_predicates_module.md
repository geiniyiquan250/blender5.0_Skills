# freestyle.predicates - 线条选择谓词模块

freestyle.predicates模块提供了Freestyle线条渲染中的谓词函数，用于根据几何属性和材质属性选择要渲染的边。

## 概述

谓词是Freestyle样式模块的核心组件之一，它们定义了选择线条的条件。通过组合不同的谓词，可以精确控制哪些边被渲染成线条，实现丰富的艺术效果。

## 核心功能

### 比较谓词

```python
from freestyle.predicates import (
    GT, LT, EQ, NOT, AND, OR,
    GreaterThan, LessThan, EqualTo,
    Not, And, Or
)

def create_length_predicate(threshold, greater=True):
    """创建长度谓词"""
    from freestyle.predicates import Length2DBP1D
    if greater:
        return GT(Length2DBP1D(), threshold)
    else:
        return LT(Length2DBP1D(), threshold)

def create_curvature_predicate(threshold, greater=True):
    """创建曲率谓词"""
    from freestyle.predicates import Curvature2DBP1D
    if greater:
        return GT(Curvature2DBP1D(), threshold)
    else:
        return LT(Curvature2DBP1D(), threshold)

def create_normal_predicate(axis, threshold, greater=True):
    """创建法线谓词"""
    from freestyle.predicates import NormalBP1D
    normal_pred = NormalBP1D()
    if greater:
        return GT(normal_pred, threshold) if axis == 'Z' else None
    return normal_pred
```

### 几何谓词

```python
from freestyle.predicates import (
    Length2DBP1D,
    Curvature2DBP1D,
    NormalBP1D,
    MaterialBP2D,
    BackTesselationBP1D,
    ProjectedX,
    ProjectedY,
    ProjectedZ
)

def create_face_area_predicate(threshold, greater=True):
    """创建面面积谓词"""
    from freestyle.predicates import Face2DAreaBP1D
    if greater:
        return GT(Face2DAreaBP1D(), threshold)
    else:
        return LT(Face2DAreaBP1D(), threshold)

def create_projected_x_predicate(threshold, greater=True):
    """创建投影X谓词"""
    pred = ProjectedX()
    if greater:
        return GT(pred, threshold)
    else:
        return LT(pred, threshold)

def create_projected_y_predicate(threshold, greater=True):
    """创建投影Y谓词"""
    pred = ProjectedY()
    if greater:
        return GT(pred, threshold)
    else:
        return LT(pred, threshold)

def create_projected_z_predicate(threshold, greater=True):
    """创建投影Z谓词"""
    pred = ProjectedZ()
    if greater:
        return GT(pred, threshold)
    else:
        return LT(pred, threshold)
```

### 材质谓词

```python
def create_material_predicate(material_name):
    """创建材质谓词"""
    return MaterialBP2D() == material_name

def create_material_compare_predicate(material_name, operator='=='):
    """创建材质比较谓词"""
    pred = MaterialBP2D()
    if operator == '==':
        return pred == material_name
    elif operator == '!=':
        return pred != material_name
    return None

def create_material_name_contains_predicate(substring):
    """创建材质名称包含谓词"""
    def contains_material():
        pass
    return contains_material
```

### 组合谓词

```python
def combine_predicates(pred1, pred2, operator='AND'):
    """组合谓词"""
    if operator == 'AND':
        return And(pred1, pred2)
    elif operator == 'OR':
        return Or(pred1, pred2)
    elif operator == 'NOT':
        return Not(pred1)
    return None

def create_complex_predicate(length_thresh, curvature_thresh):
    """创建复合谓词"""
    length_pred = GT(Length2DBP1D(), length_thresh)
    curvature_pred = GT(Curvature2DBP1D(), curvature_thresh)
    return And(length_pred, curvature_pred)

def negate_predicate(pred):
    """取反谓词"""
    return Not(pred)
```

## 实用函数

### 谓词构建器

```python
def build_predicate_from_config(config):
    """从配置构建谓词"""
    pred_type = config.get('type')
    if pred_type == 'length':
        return GT(Length2DBP1D(), config['threshold'])
    elif pred_type == 'curvature':
        return GT(Curvature2DBP1D(), config['threshold'])
    elif pred_type == 'normal':
        return GT(NormalBP1D(), config['threshold'])
    elif pred_type == 'compound':
        preds = [build_predicate_from_config(c) for c in config['conditions']]
        if config.get('operator') == 'AND':
            return And(*preds)
        elif config.get('operator') == 'OR':
            return Or(*preds)
    return None

def predicates_to_string(predicate, indent=0):
    """将谓词转换为字符串"""
    prefix = '  ' * indent
    pred_type = type(predicate).__name__
    if hasattr(predicate, 'predicates'):
        children = [predicates_to_string(p, indent + 1) for p in predicate.predicates]
        return f'{prefix}{pred_type}(\n{"".join(children)}\n{prefix})'
    elif hasattr(predicate, 'threshold'):
        return f'{prefix}{pred_type}(threshold={predicate.threshold})'
    return f'{prefix}{pred_type}'
```

### 谓词测试

```python
def test_predicate(predicate, view_map):
    """测试谓词"""
    from freestyle import operators
    
    results = []
    for edge in view_map.edges:
        if predicate(view_map, edge):
            results.append(edge)
    return results

def count_predicate_matches(predicate, view_map):
    """统计谓词匹配数量"""
    count = 0
    for edge in view_map.edges:
        if predicate(view_map, edge):
            count += 1
    return count

def get_predicate_statistics(predicate, view_map):
    """获取谓词统计信息"""
    total = len(view_map.edges)
    matched = count_predicate_matches(predicate, view_map)
    return {
        'total_edges': total,
        'matched_edges': matched,
        'match_ratio': matched / total if total > 0 else 0
    }
```

### 常用谓词组合

```python
def create_silhouette_predicate():
    """创建轮廓线谓词"""
    return Not(BackTesselationBP1D())

def create_contour_predicate():
    """创建轮廓线谓词"""
    pred = Not(BackTesselationBP1D())
    return pred

def create_edge_predicate(threshold=5):
    """创建边缘线谓词"""
    length_pred = GT(Length2DBP1D(), threshold)
    back_pred = Not(BackTesselationBP1D())
    return And(length_pred, back_pred)

def create_skin_ridge_predicate(curvature_threshold=0.5):
    """创建皮肤褶皱谓词"""
    curvature_pred = GT(Curvature2DBP1D(), curvature_threshold)
    back_pred = Not(BackTesselationBP1D())
    return And(curvature_pred, back_pred)

def create_ridge_predicate(angle_threshold=math.radians(45)):
    """创建脊线谓词"""
    crease_pred = ChainCreaseAngleIterator(angle_threshold)
    return crease_pred
```

## 常见问题排查

### 谓词不生效

谓词类型错误：
- 确认谓词类导入正确
- 检查谓词参数类型
- 验证谓词组合逻辑

### 谓词组合复杂

嵌套层级过深：
- 使用具名谓词提高可读性
- 限制组合深度
- 分解复杂谓词为简单谓词

### 性能问题

谓词计算开销大：
- 避免重复计算相同属性
- 使用缓存优化
- 简化谓词逻辑
