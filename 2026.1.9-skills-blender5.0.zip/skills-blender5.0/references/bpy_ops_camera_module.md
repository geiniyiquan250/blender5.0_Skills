# bpy.ops.camera 模块

相机操作模块，用于创建和管理3D场景中的相机。

## 概述

bpy.ops.camera 模块包含用于创建、编辑和配置相机的运算符。这些运算符用于在3D场景中添加相机、设置相机属性和执行相机操作。

## 常用操作

### 相机创建

```python
import bpy

# 创建新相机
bpy.ops.object.camera_add(location=(0, 0, 5))

# 创建相机并设置为活动相机
bpy.ops.object.camera_add(location=(0, -5, 2))
bpy.context.scene.camera = bpy.context.active_object

# 从选中对象创建相机
bpy.ops.object.camera_add_from_view()

# 同步相机到视图
bpy.ops.view3d.object_as_camera()
```

### 相机设置

```python
# 设置相机为正交投影
camera = bpy.context.active_object.data
camera.type = 'ORTHO'

# 设置相机为透视投影
camera.type = 'PERSP'

# 设置相机焦距（毫米）
camera.lens = 50.0

# 设置传感器尺寸
camera.sensor_width = 36.0
camera.sensor_height = 24.0

# 设置相机裁剪范围
camera.clip_start = 0.1
camera.clip_end = 1000.0

# 设置景深
camera.dof.use_dof = True
camera.dof.focus_object = bpy.data.objects['FocusObj']
camera.dof.aperture_fstop = 2.8
```

### 相机视图

```python
# 切换到相机视图
bpy.ops.view3d.view_camera()

# 设置相机为当前视图
bpy.ops.view3d.camera_to_view()

# 将视图对齐到相机
bpy.ops.view3d.camera_to_view_selected()

# 锁定相机到视图
bpy.ops.view3d.lock_camera_to_view()

# 解锁相机
bpy.ops.view3d.unlock_camera_to_view()
```

### 相机动画

```python
# 相机环绕动画
bpy.ops.view3d.camera_add_view_rotation(path='//animation.blend')

# 相机轨道
bpy.ops.view3d.camera_view_frame()

# 平滑相机
bpy.ops.view3d.camera_smooth()
```

## 实际应用示例

### 创建轨道相机动画

```python
import bpy
import math

def create_orbit_camera_animation(target_obj, radius, frames=100):
    """创建相机环绕目标动画"""
    # 创建相机
    bpy.ops.object.camera_add(location=(radius, 0, 2))
    camera = bpy.context.active_object
    camera.name = "OrbitCamera"
    
    # 设置相机目标
    camera.rotation_euler = (math.radians(90), 0, 0)
    
    # 创建动画
    camera.animation_data_create()
    action = camera.animation_data.action = bpy.data.actions.new(name="OrbitAnimation")
    
    for i in range(frames):
        angle = (2 * math.pi * i) / frames
        
        # 设置帧
        bpy.context.scene.frame_set(i)
        
        # 计算新位置
        x = radius * math.cos(angle)
        y = radius * math.sin(angle)
        
        # 设置位置
        camera.location = (x, y, 2)
        camera.keyframe_insert(data_path="location", frame=i)
    
    # 设置相机
    bpy.context.scene.camera = camera
    
    return camera
```

### 创建相机切换动画

```python
def create_camera_switch_animation(camera1, camera2, switch_frame):
    """创建两个相机之间的切换动画"""
    scene = bpy.context.scene
    
    # 设置初始相机
    scene.camera = camera1
    
    # 在切换帧设置相机
    scene.frame_set(switch_frame)
    scene.camera = camera2
    
    # 插入关键帧
    camera2.keyframe_insert(data_path="location", frame=switch_frame)
    camera2.keyframe_insert(data_path="rotation_euler", frame=switch_frame)
    
    # 添加淡入淡出效果
    scene.frame_set(switch_frame - 1)
    camera1.hide_render = False
    camera1.keyframe_insert(data_path="hide_render", frame=switch_frame - 1)
    camera1.hide_render = True
    camera1.keyframe_insert(data_path="hide_render", frame=switch_frame)
```

### 设置相机跟随

```python
def setup_camera_follow(camera_obj, target_obj, offset=(0, -5, 2)):
    """设置相机跟随目标物体"""
    # 创建跟随约束
    constraint = camera_obj.constraints.new(type='TRACK_TO')
    constraint.target = target_obj
    constraint.track_axis = 'TRACK_NEGATIVE_Z'
    constraint.up_axis = 'UP_Y'
    
    # 创建复制位置约束
    loc_constraint = camera_obj.constraints.new(type='COPY_LOCATION')
    loc_constraint.target = target_obj
    loc_constraint.use_offset = True
    loc_constraint.head_tail = 0
    
    # 设置偏移
    camera_obj.location = (
        target_obj.location.x + offset[0],
        target_obj.location.y + offset[1],
        target_obj.location.z + offset[2]
    )
```

## 使用场景

- **场景相机配置**：设置主相机和渲染相机
- **相机动画**：创建相机移动和切换动画
- **相机特效**：设置景深和运动模糊
- **多相机系统**：管理多个相机和视角切换
- **自动化拍摄**：在脚本中控制相机进行自动化渲染

## 注意事项

- 相机操作需要先选中相机对象
- 相机属性更改后需要更新视图
- 多相机切换时注意渲染输出的一致性
