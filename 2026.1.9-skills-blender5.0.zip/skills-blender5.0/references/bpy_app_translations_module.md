# bpy.app.translations - Application Translations Module

Blender 国际化翻译系统，用于多语言支持和本地化。

## Overview

`bpy.app.translations` 模块提供了 Blender 的国际化翻译功能。这个模块允许开发者创建多语言插件，支持文本翻译和语言切换。

## 关键概念

### 翻译上下文
- 翻译域（Translation Domains）
- 消息上下文（Message Context）
- 语言代码（Language Codes）

### 翻译工作流程
- 注册翻译表
- 标记需要翻译的字符串
- 根据当前语言设置返回翻译文本

## 主要功能

### 注册翻译

```python
import bpy

# 注册翻译表
def register_translations():
    """注册翻译表"""
    # 注册中文翻译
    translation_dict = {
        "en_US": {
            "*": {
                "Hello": "Hello",
                "World": "World",
                "Settings": "Settings",
                "Confirm": "Confirm",
                "Cancel": "Cancel",
                "Save": "Save",
                "Load": "Load",
                "Delete": "Delete",
                "Edit": "Edit",
                "Add": "Add",
                "Remove": "Remove",
                "Export": "Export",
                "Import": "Import",
            }
        },
        "zh_CN": {
            "*": {
                "Hello": "你好",
                "World": "世界",
                "Settings": "设置",
                "Confirm": "确认",
                "Cancel": "取消",
                "Save": "保存",
                "Load": "加载",
                "Delete": "删除",
                "Edit": "编辑",
                "Add": "添加",
                "Remove": "移除",
                "Export": "导出",
                "Import": "导入",
            }
        },
        "ja_JP": {
            "*": {
                "Hello": "こんにちは",
                "World": "世界",
                "Settings": "設定",
                "Confirm": "確認",
                "Cancel": "キャンセル",
                "Save": "保存",
                "Load": "読み込み",
                "Delete": "削除",
                "Edit": "編集",
                "Add": "追加",
                "Remove": "削除",
                "Export": "エクスポート",
                "Import": "インポート",
            }
        }
    }
    
    # 注册翻译
    bpy.app.translations.register("my_plugin", translation_dict)
    print("翻译表已注册")

# 注销时取消注册
def unregister_translations():
    """注销翻译"""
    bpy.app.translations.unregister("my_plugin")
    print("翻译表已注销")
```

### 使用翻译函数

```python
import bpy
import bpy.app.translations as trans

class TranslationDemoOperator(bpy.types.Operator):
    """翻译演示操作符"""
    bl_idname = "wm.translation_demo"
    bl_label = "翻译演示"
    bl_description = "展示国际化翻译功能"
    
    def execute(self, context):
        # 获取当前语言
        current_lang = bpy.context.preferences.view.language
        print(f"当前语言: {current_lang}")
        
        # 使用翻译函数
        msg = trans.pgettext("Hello")
        print(f"翻译结果: {msg}")
        
        return {'FINISHED'}

class TranslationPanel(bpy.types.Panel):
    """翻译面板"""
    bl_label = "翻译演示面板"
    bl_idname = "OBJECT_PT_translation_demo"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '翻译演示'
    
    def draw(self, context):
        layout = self.layout
        
        # 使用 pgettext 进行翻译
        col = layout.column()
        col.label(text=trans.pgettext("Hello"))
        col.label(text=trans.pgettext("World"))
        col.label(text=trans.pgettext("Settings"))
        
        col.separator()
        
        # 带上下文的翻译
        col.label(text=trans.pgettext("Save", "File"))
        col.label(text=trans.pgettext("Save", "Object"))
```

### 上下文相关翻译

```python
import bpy

class ContextualTranslation:
    """上下文相关翻译管理器"""
    
    def __init__(self):
        self.translation_dict = {
            "en_US": {
                "*": {
                    "Object": "Object",
                    "Mesh": "Mesh",
                    "Curve": "Curve",
                },
                "Operator": {
                    "Delete": "Delete",
                    "Duplicate": "Duplicate",
                },
                "File": {
                    "Delete": "Delete File",
                    "Save": "Save File",
                }
            },
            "zh_CN": {
                "*": {
                    "Object": "对象",
                    "Mesh": "网格",
                    "Curve": "曲线",
                },
                "Operator": {
                    "Delete": "删除",
                    "Duplicate": "复制",
                },
                "File": {
                    "Delete": "删除文件",
                    "Save": "保存文件",
                }
            }
        }
    
    def register(self, domain="my_plugin"):
        """注册翻译"""
        bpy.app.translations.register(domain, self.translation_dict)
    
    def unregister(self, domain="my_plugin"):
        """注销翻译"""
        bpy.app.translations.unregister(domain)
    
    def translate(self, text, context=None, domain="my_plugin"):
        """翻译文本"""
        try:
            if context:
                return trans.pgettext(text, context)
            else:
                return trans.pgettext(text)
        except:
            return text
    
    def translate_ui(self, text, context=None):
        """翻译 UI 文本"""
        return self.translate(text, context, "my_plugin")

# 使用示例
translator = ContextualTranslation()
translator.register()

# 不同上下文的同一词会有不同翻译
obj_label = translator.translate_ui("Delete", "Operator")  # "删除"
file_label = translator.translate_ui("Delete", "File")     # "删除文件"
```

### 动态语言切换

```python
import bpy
from bpy.app import translations

class LanguageSwitcher:
    """语言切换器"""
    
    SUPPORTED_LANGUAGES = [
        ('en_US', "English"),
        ('zh_CN', "中文"),
        ('ja_JP', "日本語"),
        ('de_DE', "Deutsch"),
        ('fr_FR', "Français"),
        ('es_ES', "Español"),
    ]
    
    def __init__(self):
        self.current_language = 'en_US'
    
    def get_current_language(self):
        """获取当前语言"""
        return bpy.context.preferences.view.language
    
    def set_language(self, language_code):
        """设置语言"""
        bpy.context.preferences.view.language = language_code
        self.current_language = language_code
        print(f"语言已切换至: {language_code}")
    
    def get_language_name(self, language_code):
        """获取语言名称"""
        for code, name in self.SUPPORTED_LANGUAGES:
            if code == language_code:
                return name
        return "Unknown"
    
    def reload_translations(self):
        """重新加载翻译"""
        # 注销并重新注册翻译
        translations.unregister("my_plugin")
        translations.register("my_plugin", self.translation_dict)
        print("翻译已重新加载")

class LanguageSwitchPanel(bpy.types.Panel):
    """语言切换面板"""
    bl_label = "语言设置"
    bl_idname = "OBJECT_PT_language_switch"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '设置'
    
    def draw(self, context):
        layout = self.layout
        prefs = context.preferences
        
        # 语言选择
        col = layout.column()
        col.label(text="选择界面语言:")
        
        # 获取支持的语言列表
        languages = [
            ('en_US', "English"),
            ('zh_CN', "中文"),
            ('ja_JP', "日本語"),
        ]
        
        row = col.row()
        row.prop(prefs.view, "language", text="")
        
        # 显示当前语言
        current_lang = prefs.view.language
        col.label(text=f"当前语言: {current_lang}")
        
        # 翻译测试
        col.separator()
        col.label(text="翻译测试:")
        import bpy.app.translations as trans
        col.label(text=f"Hello -> {trans.pgettext('Hello')}")
        col.label(text=f"Settings -> {trans.pgettext('Settings')}")
```

### 翻译文件管理

```python
import bpy
import json
import os
from pathlib import Path

class TranslationFileManager:
    """翻译文件管理器"""
    
    def __init__(self, plugin_name="my_plugin"):
        self.plugin_name = plugin_name
        self.translation_dir = Path(f"//translations")
        self.languages = ['en_US', 'zh_CN', 'ja_JP']
    
    def create_translation_files(self):
        """创建翻译文件"""
        base_translations = {
            "en_US": {
                "*": {
                    "Hello": "Hello",
                    "World": "World",
                    "Settings": "Settings",
                }
            },
            "zh_CN": {
                "*": {
                    "Hello": "你好",
                    "World": "世界",
                    "Settings": "设置",
                }
            },
            "ja_JP": {
                "*": {
                    "Hello": "こんにちは",
                    "World": "世界",
                    "Settings": "設定",
                }
            }
        }
        
        # 确保目录存在
        self.translation_dir.mkdir(parents=True, exist_ok=True)
        
        # 为每种语言创建文件
        for lang in self.languages:
            file_path = self.translation_dir / f"{lang}.json"
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(base_translations.get(lang, {}), f, 
                         ensure_ascii=False, indent=2)
            print(f"已创建翻译文件: {file_path}")
    
    def load_translation_from_file(self, language):
        """从文件加载翻译"""
        file_path = self.translation_dir / f"{language}.json"
        
        if not file_path.exists():
            print(f"翻译文件不存在: {file_path}")
            return None
        
        with open(file_path, 'r', encoding='utf-8') as f:
            translation_dict = json.load(f)
        
        return translation_dict
    
    def load_all_translations(self):
        """加载所有翻译"""
        all_translations = {}
        
        for lang in self.languages:
            translations = self.load_translation_from_file(lang)
            if translations:
                all_translations[lang] = translations
        
        return all_translations
    
    def register_all(self):
        """注册所有翻译"""
        all_translations = self.load_all_translations()
        
        if all_translations:
            bpy.app.translations.register(self.plugin_name, all_translations)
            print(f"已注册 {len(all_translations)} 个语言的翻译")
    
    def update_translation(self, language, key, value, context=None):
        """更新翻译"""
        translation = self.load_translation_from_file(language)
        
        if context:
            if context not in translation:
                translation[context] = {}
            translation[context][key] = value
        else:
            if "*" not in translation:
                translation["*"] = {}
            translation["*"][key] = value
        
        # 保存更新
        file_path = self.translation_dir / f"{language}.json"
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(translation, f, ensure_ascii=False, indent=2)
        
        # 重新加载翻译
        self.reload()
    
    def reload(self):
        """重新加载翻译"""
        bpy.app.translations.unregister(self.plugin_name)
        self.register_all()
```

### UI 文本翻译助手

```python
import bpy
import bpy.app.translations as trans

class UITextHelper:
    """UI 文本翻译助手"""
    
    def __init__(self, domain="my_plugin"):
        self.domain = domain
        self.cache = {}
    
    def t(self, text, context=None):
        """翻译文本（带缓存）"""
        cache_key = f"{context or ''}|{text}"
        
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        try:
            if context:
                result = trans.pgettext(text, context)
            else:
                result = trans.pgettext(text)
            self.cache[cache_key] = result
            return result
        except Exception as e:
            print(f"翻译错误: {e}")
            return text
    
    def clear_cache(self):
        """清空缓存"""
        self.cache.clear()
    
    def register(self, translation_dict):
        """注册翻译"""
        bpy.app.translations.register(self.domain, translation_dict)
    
    def unregister(self):
        """注销翻译"""
        bpy.app.translations.unregister(self.domain)

# 全局实例
ui_text = UITextHelper("my_plugin")

# 注册翻译
ui_text.register({
    "en_US": {
        "*": {
            "操作完成": "Operation Complete",
            "请选择对象": "Please select an object",
            "确认删除": "Confirm Delete",
        }
    },
    "zh_CN": {
        "*": {
            "操作完成": "操作完成",
            "请选择对象": "请选择对象",
            "确认删除": "确认删除",
        }
    }
})

# 在 UI 中使用
class TranslatedPanel(bpy.types.Panel):
    bl_label = "翻译面板"
    bl_idname = "OBJECT_PT_translated_ui"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '翻译'
    
    def draw(self, context):
        layout = self.layout
        
        # 使用翻译助手
        layout.label(text=ui_text.t("操作完成"))
        layout.label(text=ui_text.t("请选择对象"))
        
        # 带上下文的翻译
        layout.label(text=ui_text.t("Confirm", "删除确认"))
        layout.label(text=ui_text.t("Save", "文件保存"))
```

## 最佳实践

### 1. 翻译域管理
```python
# 使用唯一的翻译域名称
TRANSLATION_DOMAIN = "my_unique_plugin_name"

def register():
    bpy.app.translations.register(TRANSLATION_DOMAIN, translations)

def unregister():
    bpy.app.translations.unregister(TRANSLATION_DOMAIN)
```

### 2. 翻译键命名
```python
# 使用清晰的键名
TRANSLATIONS = {
    "en_US": {
        "*": {
            "my_plugin.panel.title": "Plugin Panel",
            "my_plugin.operator.description": "My Operator Description",
            "my_plugin.error.not_found": "Resource not found",
        }
    }
}
```

### 3. 性能考虑
```python
# 使用缓存减少重复翻译
class CachedTranslator:
    def __init__(self, domain):
        self.domain = domain
        self.cache = {}
    
    def t(self, text):
        if text not in self.cache:
            self.cache[text] = trans.pgettext(text)
        return self.cache[text]
```

## 常见问题

### Q: 翻译不生效
A: 检查是否正确注册翻译域，语言设置是否正确，键名是否完全匹配。

### Q: 上下文翻译冲突
A: 使用不同的上下文区分同名翻译，确保上下文名称唯一。

### Q: 动态字符串翻译
A: 对于动态生成的字符串，可能需要使用占位符或模板翻译。

## 性能优化

1. **使用缓存**：减少重复翻译调用
2. **预加载翻译**：在插件初始化时加载所有翻译
3. **按需加载**：大型翻译表可以使用懒加载
4. **避免过度细分**：合并相似的翻译条目

## 相关模块

- [bpy.app.handlers](bpy_app_handlers_module.md) - 应用程序事件处理器
- [bpy.props](bpy_props_module.md) - 属性定义系统
- [bpy.context](bpy_context_module.md) - 上下文访问
