# bpy.ops.anim - 动画操作模块

Blender动画操作符，用于管理动画数据和关键帧操作。

## 概述

`bpy.ops.anim` 模块提供用于操作Blender动画系统的核心功能，包括关键帧管理、动画数据操作和动画播放控制。

## 核心功能

### 关键帧操作

```python
import bpy

# 插入关键帧
bpy.ops.anim.keyframe_insert(
    type='OBJECT'
)

# 插入所有关键帧
bpy.ops.anim.keyframe_insert(
    type='ALL'
)

# 插入可用关键帧
bpy.ops.anim.keyframe_insert(
    type='AVAILABLE'
)

# 删除关键帧
bpy.ops.anim.keyframe_delete(
    type='OBJECT'
)

# 删除所有关键帧
bpy.ops.anim.keyframe_delete(
    type='ALL'
)

# 删除可用关键帧
bpy.ops.anim.keyframe_delete(
    type='AVAILABLE'
)

# 清除关键帧
bpy.ops.anim.keyframe_clear(
    type='OBJECT'
)
```

### 动画数据操作

```python
# 复制动画数据
bpy.ops.anim.copy_fcurves()

# 粘贴动画数据
bpy.ops.anim.paste_fcurves()

# 清除动画数据
bpy.ops.anim.clear_fcurves()

# 推送动画
bpy.ops.anim.push_down()

# 推送所有到NLA
bpy.ops.anim.push_down(
    type='ALL'
)

# 合并到动作
bpy.ops.anim.merge_to_nla()

# 合并所有到NLA
bpy.ops.anim.merge_to_nla(
    type='ALL'
)
```

### 动作操作

```python
# 新建动作
bpy.ops.anim.action_new(
    name='NewAction'
)

# 删除动作
bpy.ops.anim.action_delete()

# 复制动作
bpy.ops.anim.action_copy()

# 粘贴动作
bpy.ops.anim.action_paste()

# 粘贴到新动作
bpy.ops.anim.action_paste(
    overwrite=True
)

# 清除动作
bpy.ops.anim.action_clear()
```

### 插值设置

```python
# 设置插值类型
bpy.ops.anim.keyframe_insert(
    type='OBJECT',
    confirm_success=False
)

# 设置为常量插值
bpy.ops.graph.interpolation_type(
    type='CONSTANT'
)

# 设置为线性插值
bpy.ops.graph.interpolation_type(
    type='LINEAR'
)

# 设置为贝塞尔插值
bpy.ops.graph.interpolation_type(
    type='BEZIER'
)

# 设置为弹性插值
bpy.ops.graph.extrapolation_type(
    type='MAKE_CYCLIC'
)

# 设置为外推
bpy.ops.graph.extrapolation_type(
    type='CYCLIC'
)
```

### 播放控制

```python
# 播放动画
bpy.ops.anim.play(
    forward=True
)

# 反向播放
bpy.ops.anim.play(
    forward=False
)

# 停止播放
bpy.ops.anim.play(
    speed=0
)

# 跳转到开始
bpy.ops.anim.frame_jump(
    end=False
)

# 跳转到结束
bpy.ops.anim.frame_jump(
    end=True
)

# 步进一帧
bpy.ops.anim.step_frame(
    forward=True
)

# 步退一帧
bpy.ops.anim.step_frame(
    forward=False
)
```

## 实用函数

```python
def create_action_with_keyframes(action_name, obj, keyframes):
    """创建带有关键帧的动作"""
    action = bpy.data.actions.new(name=action_name)
    obj.animation_data.action = action
    
    for frame, transform in keyframes.items():
        bpy.context.scene.frame_set(frame)
        obj.location = transform.get('location', obj.location)
        obj.rotation_euler = transform.get('rotation', obj.rotation_euler)
        obj.scale = transform.get('scale', obj.scale)
        bpy.ops.anim.keyframe_insert(type='OBJECT')
    
    return action

def copy_animation_to_objects(source_obj, target_objs):
    """复制动画到多个对象"""
    if not source_obj.animation_data:
        return
    
    source_action = source_obj.animation_data.action
    if not source_obj.animation_data.action:
        return
    
    for target in target_objs:
        if not target.animation_data:
            target.animation_data_create()
        
        target.animation_data.action = source_action.copy()
        target.animation_data.action.name = f'{source_action.name}_{target.name}'

def batch_keyframe_insert(objects, frame):
    """批量插入关键帧"""
    bpy.context.scene.frame_set(frame)
    
    for obj in objects:
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        bpy.ops.anim.keyframe_insert(type='OBJECT')
        obj.select_set(False)

def get_keyframe_range(action):
    """获取动作的帧范围"""
    if not action:
        return (0, 0)
    
    min_frame = float('inf')
    max_frame = float('-inf')
    
    for fcurve in action.fcurves:
        for keyframe in fcurve.keyframe_points:
            if keyframe.co[0] < min_frame:
                min_frame = keyframe.co[0]
            if keyframe.co[0] > max_frame:
                max_frame = keyframe.co[0]
    
    return (int(min_frame), int(max_frame)) if min_frame != float('inf') else (0, 0)

def offset_action_frames(action, offset):
    """偏移动作帧"""
    for fcurve in action.fcurves:
        for keyframe in fcurve.keyframe_points:
            keyframe.co[0] += offset
            keyframe.handle_left[0] += offset
            keyframe.handle_right[0] += offset

def scale_action_duration(action, scale_factor):
    """缩放动作时长"""
    for fcurve in action.fcurves:
        for keyframe in fcurve.keyframe_points:
            keyframe.co[0] *= scale_factor
            keyframe.handle_left[0] *= scale_factor
            keyframe.handle_right[0] *= scale_factor
```

## 常见问题排查

### 关键帧不生效
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")
print(f"动作: {obj.animation_data.action if obj.animation_data else None}")

# 检查关键帧
if obj.animation_data and obj.animation_data.action:
    print(f"曲线数: {len(obj.animation_data.action.fcurves)}")
    for curve in obj.animation_data.action.fcurves:
        print(f"曲线: {curve.data_path}, 关键帧数: {len(curve.keyframe_points)}")

# 手动插入关键帧
bpy.context.scene.frame_set(1)
bpy.ops.anim.keyframe_insert(type='OBJECT')

# 检查数据路径
print(f"数据路径: {obj.path_from_id()}")
```

### 动画不播放
```python
# 检查播放状态
print(f"正在播放: {bpy.context.scene.is_playing}")

# 检查帧范围
print(f"开始帧: {bpy.context.scene.frame_start}")
print(f"结束帧: {bpy.context.scene.frame_end}")
print(f"当前帧: {bpy.context.scene.frame_current}")

# 设置帧范围
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = 250

# 重新开始播放
bpy.ops.anim.play(forward=True)
```

### 动作丢失
```python
# 检查所有动作
print("所有动作:")
for action in bpy.data.actions:
    print(f"  {action.name}: {len(action.fcurves)} 曲线")

# 检查未使用动作
unused_actions = [a for a in bpy.data.actions if not a.users]
print(f"未使用动作: {len(unused_actions)}")

# 恢复动作
action = bpy.data.actions.get('LostAction')
if action:
    obj.animation_data.action = action
```
