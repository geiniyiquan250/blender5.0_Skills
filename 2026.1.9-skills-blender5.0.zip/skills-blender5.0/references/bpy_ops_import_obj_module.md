# bpy.ops.import_mesh - OBJ导入操作模块

Blender OBJ文件导入操作符，用于将OBJ网格文件导入Blender。

## 概述

`bpy.ops.import_mesh.obj` 模块提供用于将Wavefront OBJ格式网格文件导入Blender的功能，支持几何体、材质和纹理的导入。

## 核心功能

### 基础导入

```python
import bpy

# 导入OBJ文件
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    directory='//',
    files=[{'name': 'model.obj'}],
    ui_tab='MAIN',
    use_smooth_groups=True,
    use_split_objects=True,
    use_split_groups=True,
    use_groups_as_vgroups=False,
    use_image_search=True,
    split_mode='ON',
    global_clamp_size=0,
    axis_forward='-Z',
    axis_up='Y'
)
```

### 网格分组选项

```python
# 分割对象
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_split_objects=True
)

# 分割组
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_split_groups=True
)

# 不分割
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_split_objects=False,
    use_split_groups=False
)

# 使用组作为顶点组
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_groups_as_vgroups=True
)
```

### 光滑组设置

```python
# 使用光滑组
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_smooth_groups=True
)

# 不使用光滑组
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_smooth_groups=False
)
```

### 图像搜索

```python
# 启用图像搜索
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_image_search=True
)

# 禁用图像搜索
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_image_search=False
)
```

### 轴向设置

```python
# Blender默认轴向
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    axis_forward='-Z',
    axis_up='Y'
)

# 传统OBJ轴向
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    axis_forward='-Z',
    axis_up='Y'
)

# 其他轴向组合
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    axis_forward='Y',
    axis_up='Z'
)
```

### 尺寸限制

```python
# 设置尺寸限制
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    global_clamp_size=10.0
)

# 无限制
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    global_clamp_size=0
)
```

## 实用函数

```python
def import_obj_model(filepath, split_objects=True):
    """导入OBJ模型"""
    bpy.ops.import_scene.obj(
        filepath=filepath,
        use_split_objects=split_objects,
        use_smooth_groups=True,
        use_image_search=True
    )
    return list(bpy.context.selected_objects)

def import_obj_with_materials(filepath):
    """导入OBJ带材质"""
    bpy.ops.import_scene.obj(
        filepath=filepath,
        use_split_objects=True,
        use_smooth_groups=True,
        use_image_search=True,
        ui_tab='MATERIALS'
    )
    return list(bpy.context.selected_objects)

def import_obj_and_merge(filepath):
    """导入OBJ并合并"""
    bpy.ops.import_scene.obj(
        filepath=filepath,
        use_split_objects=False,
        use_split_groups=False,
        use_smooth_groups=True
    )
    
    # 合并所有对象
    objects = list(bpy.context.selected_objects)
    if len(objects) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = objects[0]
        bpy.ops.object.join()
        return [bpy.context.active_object]
    
    return objects

def import_obj_scaled(filepath, target_scale=1.0):
    """导入OBJ并缩放"""
    bpy.ops.import_scene.obj(
        filepath=filepath,
        use_split_objects=True,
        global_clamp_size=target_scale
    )
    return list(bpy.context.selected_objects)

def import_obj_for_editing(filepath):
    """导入OBJ用于编辑"""
    bpy.ops.import_scene.obj(
        filepath=filepath,
        use_split_objects=True,
        use_split_groups=False,
        use_groups_as_vgroups=True,
        use_smooth_groups=True,
        use_image_search=False
    )
    return list(bpy.context.selected_objects)

def batch_import_obj_files(obj_files):
    """批量导入OBJ文件"""
    all_objects = []
    
    for filepath in obj_files:
        bpy.ops.import_scene.obj(filepath=filepath)
        imported = list(bpy.context.selected_objects)
        all_objects.extend(imported)
    
    return all_objects

def import_obj_with_transform(filepath, rotation=(0, 0, 0), scale=(1, 1, 1)):
    """导入OBJ并应用变换"""
    bpy.ops.import_scene.obj(filepath=filepath)
    obj = bpy.context.active_object
    
    obj.rotation_euler = [r * (3.14159 / 180) for r in rotation]
    obj.scale = scale
    
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    
    return obj
```

## 常见问题排查

### 导入后材质丢失
```python
# 检查材质
print(f"材质数: {len(bpy.data.materials)}")

# 检查纹理
print(f"纹理数: {len(bpy.data.textures)}")

# 检查图像
print(f"图像数: {len(bpy.data.images)}")

# 搜索材质
mat = bpy.data.materials.get('Material')
if mat:
    print(f"材质: {mat.name}")
    if mat.use_nodes:
        for node in mat.node_tree.nodes:
            print(f"节点: {node.type}")

# 重新导入带材质搜索
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_image_search=True,
    ui_tab='MATERIALS'
)
```

### 对象方向错误
```python
# 检查轴向设置
print(f"前向: {-Z}")
print(f"上向: {Y}")

# 检查对象方向
obj = bpy.context.active_object
print(f"旋转: {obj.rotation_euler}")

# 尝试不同轴向
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    axis_forward='-Z',
    axis_up='Y'
)

# 手动旋转
obj.rotation_euler = (0, 0, math.radians(90))
bpy.ops.object.transform_apply(rotation=True)
```

### 网格分割问题
```python
# 检查导入的对象数
print(f"对象数: {len(bpy.context.selected_objects)}")

# 检查对象名称
for obj in bpy.context.selected_objects:
    print(f"对象: {obj.name}")

# 尝试合并
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.join()

# 重新导入不分割
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_split_objects=False,
    use_split_groups=False
)
```

### 图像找不到
```python
# 检查文件路径
print(f"当前目录: {bpy.path.abspath('//')}")
print(f"纹理目录: {bpy.path.abspath('//textures/')}")

# 列出可用图像
print("可用图像:")
for img in bpy.data.images:
    print(f"  {img.name}: {img.filepath}")

# 手动加载纹理
img = bpy.data.images.load('//textures/texture.png')

# 重新导入带图像搜索
bpy.ops.import_scene.obj(
    filepath='//model.obj',
    use_image_search=True
)
```
