# bmesh.ops 模块

## 模块概述

bmesh.ops 模块提供了在 BMesh 数据结构上进行高级网格操作的函数集合。这些操作涵盖了建模过程中最常用的功能，包括挤出、倒角、循环切割、溶解、桥接等。与直接操作顶点、边、面相比，使用 bmesh.ops 中的函数可以更高效地完成复杂的网格修改任务，同时自动处理拓扑关系的变化。

每个操作函数都接受 BMesh 对象作为第一个参数，并返回操作结果的字典。大多数操作还会返回修改或创建的元素列表，方便后续处理。这些函数设计为可组合使用，可以通过组合多个基础操作来实现复杂的建模效果。bmesh.ops 中的所有函数都是无状态的纯函数，不会修改原始输入参数的值，而是返回包含结果的新数据。

理解 bmesh.ops 的工作原理对于编写高效的网格处理脚本至关重要。每个操作都有其特定的参数和返回值格式，了解这些细节可以帮助开发者更好地控制操作的行为。此外，bmesh.ops 中的一些操作可能比手动遍历和修改元素更高效，因为它们使用了 Blender 内部优化的算法。

## 挤出操作

### 挤出顶点

extrude_vert 函数将选中的顶点沿法线方向挤出，创建新的顶点和边。这个操作常用于从点开始构建网格或在现有网格上添加新结构。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((0.0, 1.0, 0.0))
bme.faces.new((v1, v2, v3))

# 选择一个顶点
v1.select = True

print("挤出顶点测试:")
print(f"操作前顶点数: {len(bme.verts)}")

# 挤出顶点
result = bmesh.ops.extrude_vert_only(bme, verts=[v1])
print(f"操作返回: {list(result.keys())}")

# 获取新创建的顶点
new_verts = result['verts']
print(f"新创建的顶点数: {len(new_verts)}")

for v in new_verts:
    print(f"  新顶点: {v.co}")
    v.select = False

print(f"操作后顶点数: {len(bme.verts)}")
```

### 挤出边

extrude_edge_only 函数将选中的边沿法线方向挤出，创建新的边和面。这个操作常用于在网格边缘添加厚度或创建管道结构。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((0.0, 1.0, 0.0))
v4 = bme.verts.new((1.0, 1.0, 0.0))
bme.faces.new((v1, v2, v4, v3))

# 选择一条边
edge = bme.edges[0]
edge.select = True

print("挤出边测试:")
print(f"操作前: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 挤出边
result = bmesh.ops.extrude_edge_only(bme, edges=[edge])
print(f"操作返回键: {list(result.keys())}")

# 获取新创建的元素
new_edges = result['edges']
new_verts = result['verts']
print(f"新创建的边数: {len(new_edges)}")
print(f"新创建的顶点数: {len(new_verts)}")

print(f"操作后: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")
```

### 挤出面

extrude_face_region 函数是功能最强大的挤出操作，可以同时挤出多个面。这个操作会创建新的面和连接侧面，支持自定义挤出方向和距离。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建立方体作为测试
bme = bmesh.new()
verts = []
for x in [-1, 1]:
    for y in [-1, 1]:
        for z in [-1, 1]:
            verts.append(bme.verts.new((x, y, z)))
bme.verts.ensure_lookup_table()

# 定义六个面
face_verts = [
    (0, 1, 3, 2),  # 前面
    (5, 4, 7, 6),  # 后面
    (4, 0, 3, 7),  # 左面
    (1, 5, 6, 2),  # 右面
    (3, 2, 6, 7),  # 顶面
    (4, 5, 1, 0),  # 底面
]
faces = []
for fv in face_verts:
    faces.append(bme.faces.new([verts[i] for i in fv]))

# 选择顶面
top_face = faces[4]
top_face.select = True

print("挤出面测试:")
print(f"操作前: 顶点数={len(bme.verts)}, 面数={len(bme.faces)}")

# 挤出面
result = bmesh.ops.extrude_face_region(bme, geom=[top_face])
print(f"操作返回键: {list(result.keys())}")

# 获取新创建的元素
new_faces = [elem for elem in result['geom'] if isinstance(elem, bmesh.types.BMFace)]
new_edges = [elem for elem in result['geom'] if isinstance(elem, bmesh.types.BMEdge)]
new_verts = [elem for elem in result['geom'] if isinstance(elem, bmesh.types.BMVert)]

print(f"新创建的面数: {len(new_faces)}")
print(f"新创建的边数: {len(new_edges)}")
print(f"新创建的顶点数: {len(new_verts)}")

# 移动挤出的面
extrusion_height = 1.0
for v in new_verts:
    v.co.z += extrusion_height

print(f"操作后: 顶点数={len(bme.verts)}, 面数={len(bme.faces)}")
```

## 变换操作

### 旋转

rotate 函数对指定的元素进行旋转变换。这个操作支持围绕任意轴旋转任意角度，常用于对齐物体或创建对称结构。

```python
import bmesh
import bpy
from mathutils import Vector, Matrix, Euler

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((1.0, 0.0, 0.0))
v2 = bme.verts.new((2.0, 0.0, 0.0))
v3 = bme.verts.new((1.5, 1.0, 0.0))
bme.faces.new((v1, v2, v3))

print("旋转变换测试:")
print(f"原始坐标: {v1.co}, {v2.co}, {v3.co}")

# 创建旋转矩阵（围绕 Z 轴旋转 90 度）
angle = 1.5708  # 90度弧度
rotation_matrix = Matrix.Rotation(angle, 4, 'Z')

# 旋转所有顶点
verts = list(bme.verts)
result = bmesh.ops.rotate(bme, cent=(0, 0, 0), matrix=rotation_matrix, verts=verts)

print(f"操作返回键: {list(result.keys())}")

print(f"旋转后坐标: {v1.co}, {v2.co}, {v3.co}")

# 围绕特定点旋转
bme2 = bmesh.new()
v1 = bme2.verts.new((1.0, 0.0, 0.0))
v2 = bme2.verts.new((2.0, 0.0, 0.0))
v3 = bme2.verts.new((1.5, 1.0, 0.0))
bme2.faces.new((v1, v2, v3))

print("\n围绕特定点旋转测试:")
print(f"原始坐标: {v1.co}, {v2.co}, {v3.co}")

# 围绕中心点 (1.5, 0.5, 0) 旋转
center = Vector((1.5, 0.5, 0))
result = bmesh.ops.rotate(bme2, cent=center, matrix=rotation_matrix, verts=list(bme2.verts))

print(f"围绕 {center} 旋转后:")
print(f"  {v1.co}, {v2.co}, {v3.co}")
```

### 缩放

scale 函数对指定的元素进行缩放变换。这个操作支持各向异性缩放，可以分别控制 X、Y、Z 轴的缩放因子。

```python
import bmesh
import bpy
from mathutils import Vector, Matrix

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((1.0, 1.0, 1.0))
v2 = bme.verts.new((2.0, 1.0, 1.0))
v3 = bme.verts.new((1.5, 2.0, 1.0))
bme.faces.new((v1, v2, v3))

print("缩放变换测试:")
print(f"原始坐标: {v1.co}, {v2.co}, {v3.co}")

# 创建缩放矩阵（X轴压缩到0.5，Y轴拉伸到2倍）
scale_matrix = Matrix.Diagonal((0.5, 2.0, 1.0, 1.0))

# 缩放所有顶点
verts = list(bme.verts)
result = bmesh.ops.scale(bme, cent=(0, 0, 0), matrix=scale_matrix, verts=verts)

print(f"操作返回键: {list(result.keys())}")

print(f"缩放后坐标: {v1.co}, {v2.co}, {v3.co}")

# 均匀缩放
bme2 = bmesh.new()
for i in range(8):
    x = 1 if i & 1 else -1
    y = 1 if i & 2 else -1
    z = 1 if i & 4 else -1
    bme2.verts.new((x, y, z))
bme2.verts.ensure_lookup_table()

print("\n均匀缩放测试:")
print(f"原始: 顶点数={len(bme2.verts)}")

# 创建均匀缩放矩阵
uniform_scale = 0.5
scale_matrix = Matrix.Diagonal((uniform_scale,) * 4)

result = bmesh.ops.scale(bme2, cent=(0, 0, 0), matrix=scale_matrix, verts=list(bme2.verts))

print(f"均匀缩放 {uniform_scale} 倍后:")
for v in bme2.verts:
    print(f"  {v.co}")
```

### 平移

translate 函数对指定的元素进行平移变换。这个操作将元素移动到新的位置，支持批量移动多个元素。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((0.0, 1.0, 0.0))
bme.faces.new((v1, v2, v3))

print("平移变换测试:")
print(f"原始坐标: {v1.co}, {v2.co}, {v3.co}")

# 平移向量
translation = Vector((2.0, 3.0, 4.0))

# 平移所有顶点
verts = list(bme.verts)
result = bmesh.ops.translate(bme, vec=translation, verts=verts)

print(f"操作返回键: {list(result.keys())}")

print(f"平移后坐标: {v1.co}, {v2.co}, {v3.co}")

# 批量平移测试
bme2 = bmesh.new()
for x in range(3):
    for y in range(3):
        bme2.verts.new((x, y, 0))
bme2.verts.ensure_lookup_table()

print("\n批量平移测试:")
for v in bme2.verts:
    print(f"  平移前: {v.co}")

result = bmesh.ops.translate(bme2, vec=translation, verts=list(bme2.verts))

for v in bme2.verts:
    print(f"  平移后: {v.co}")
```

## 网格修改操作

### 倒角

bevel 函数对边或顶点进行倒角处理，创建平滑的过渡。这个操作在工业设计中非常重要，可以使锐利的边缘变得圆滑。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建立方体
bme = bmesh.new()
verts = []
for x in [-1, 1]:
    for y in [-1, 1]:
        for z in [-1, 1]:
            verts.append(bme.verts.new((x, y, z)))
bme.verts.ensure_lookup_table()

# 定义六个面
face_verts = [
    (0, 1, 3, 2),  # 前面
    (5, 4, 7, 6),  # 后面
    (4, 0, 3, 7),  # 左面
    (1, 5, 6, 2),  # 右面
    (3, 2, 6, 7),  # 顶面
    (4, 5, 1, 0),  # 底面
]
for fv in face_verts:
    bme.faces.new([verts[i] for i in fv])

# 选择所有边
for e in bme.edges:
    e.select = True

print("倒角测试:")
print(f"操作前: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 倒角操作
edges = list(bme.edges)
result = bmesh.ops.bevel(bme, geom=edges, offset=0.2, segments=3, vertex_only=False)

print(f"操作返回键: {list(result.keys())}")

# 获取新创建的元素
new_faces = [e for e in result['faces'] if isinstance(e, bmesh.types.BMFace)]
print(f"新创建的面数: {len(new_faces)}")

print(f"操作后: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 顶点倒角测试
bme2 = bmesh.new()
v1 = bme2.verts.new((0.0, 0.0, 0.0))
v2 = bme2.verts.new((2.0, 0.0, 0.0))
v3 = bme2.verts.new((1.0, 1.0, 0.0))
bme2.faces.new((v1, v2, v3))

print("\n顶点倒角测试:")
v1.select = True
result = bmesh.ops.bevel(bme2, geom=[v1], offset=0.1, segments=2, vertex_only=True)
print(f"顶点倒角后: 顶点数={len(bme2.verts)}, 边数={len(bme2.edges)}, 面数={len(bme2.faces)}")
```

### 内插

inset 函数对面进行内插操作，在保持外轮廓的同时缩小面。这个操作常用于创建边框效果或添加细节。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((2.0, 0.0, 0.0))
v3 = bme.verts.new((2.0, 2.0, 0.0))
v4 = bme.verts.new((0.0, 2.0, 0.0))
f = bme.faces.new((v1, v2, v3, v4))

print("内插测试:")
print(f"操作前: 面数={len(bme.faces)}, 边数={len(bme.edges)}")

# 内插操作
result = bmesh.ops.inset_individual(bme, faces=[f], thickness=0.2, depth=0.0)

print(f"操作返回键: {list(result.keys())}")

# 获取新创建的面
inner_faces = [e for e in result['faces'] if isinstance(e, bmesh.types.BMFace)]
print(f"新创建的内插面数: {len(inner_faces)}")

print(f"操作后: 面数={len(bme.faces)}, 边数={len(bme.edges)}")

# 多面内插测试
bme2 = bmesh.new()
# 创建 2x2 的面网格
faces = []
for y in range(2):
    for x in range(2):
        v1 = bme2.verts.new((x, y, 0))
        v2 = bme2.verts.new((x + 1, y, 0))
        v3 = bme2.verts.new((x + 1, y + 1, 0))
        v4 = bme2.verts.new((x, y + 1, 0))
        faces.append(bme2.faces.new((v1, v2, v3, v4)))

print("\n多面内插测试:")
for f in faces:
    f.select = True

result = bmesh.ops.inset_individual(bme2, faces=faces, thickness=0.1, depth=0.0)
print(f"操作后: 面数={len(bme2.faces)}, 边数={len(bme2.edges)}")
```

### 循环切割

subdivide 函数对边进行细分切割，增加网格密度。这个操作支持多种切割模式，可以精确控制新顶点的位置。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((4.0, 0.0, 0.0))
v3 = bme.verts.new((4.0, 4.0, 0.0))
v4 = bme.verts.new((0.0, 4.0, 0.0))
bme.faces.new((v1, v2, v3, v4))

print("循环切割测试:")
print(f"操作前: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 选择所有边
edges = list(bme.edges)
for e in edges:
    e.select = True

# 细分操作
result = bmesh.ops.subdivide(bme, edges=edges, cuts=2, use_grid_fill=True, smoothness=0.0)

print(f"操作返回键: {list(result.keys())}")

# 获取新创建的顶点
new_verts = result['verts']
print(f"新创建的顶点数: {len(new_verts)}")

print(f"操作后: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 边细分测试
bme2 = bmesh.new()
v1 = bme2.verts.new((0.0, 0.0, 0.0))
v2 = bme2.verts.new((1.0, 0.0, 0.0))
e = bme2.edges.new((v1, v2))

print("\n单边细分测试:")
print(f"操作前: 边数={len(bme2.edges)}")

result = bmesh.ops.subdivide(bme2, edges=[e], cuts=3)
print(f"操作后: 边数={len(bme2.edges)}, 顶点数={len(bme2.verts)}")

for v in bme2.verts:
    print(f"  顶点: {v.co}")
```

## 删除和溶解操作

### 删除元素

delete 函数删除指定的元素及其关联的拓扑结构。根据删除模式的不同，可以只删除元素本身或同时删除与之相连的孤立元素。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((1.0, 1.0, 0.0))
v4 = bme.verts.new((0.0, 1.0, 0.0))
v5 = bme.verts.new((0.5, 0.5, 0.0))  # 中心点
f1 = bme.faces.new((v1, v2, v5))
f2 = bme.faces.new((v2, v3, v5))
f3 = bme.faces.new((v3, v4, v5))
f4 = bme.faces.new((v4, v1, v5))

print("删除测试:")
print(f"操作前: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 删除一个面
result = bmesh.ops.delete(bme, geom=[f1], context='FACES')
print(f"删除面后: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 删除一条边
edges = list(bme.edges)
result = bmesh.ops.delete(bme, geom=[edges[0]], context='EDGES')
print(f"删除边后: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 删除一个顶点
verts = list(bme.verts)
result = bmesh.ops.delete(bme, geom=[verts[-1]], context='VERTS')
print(f"删除顶点后: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 删除模式测试
bme2 = bmesh.new()
v1 = bme2.verts.new((0.0, 0.0, 0.0))
v2 = bme2.verts.new((1.0, 0.0, 0.0))
v3 = bme2.verts.new((0.5, 1.0, 0.0))
f = bme2.faces.new((v1, v2, v3))

print("\n不同删除模式测试:")
print(f"初始: 顶点数={len(bme2.verts)}, 边数={len(bme2.edges)}, 面数={len(bme2.faces)}")

# 仅删除面（保留边和顶点）
result = bmesh.ops.delete(bme2, geom=[f], context='FACES_KEEP_BORDERS')
print(f"仅删除面: 顶点数={len(bme2.verts)}, 边数={len(bme2.edges)}, 面数={len(bme2.faces)}")
```

### 溶解操作

dissolve 函数溶解元素，移除不必要的几何体同时保持网格形状。溶解比普通删除更智能，可以处理边界和相邻元素的关系。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建测试网格
bme = bmesh.new()
# 创建细分平面
for y in range(3):
    for x in range(3):
        bme.verts.new((x, y, 0))
bme.verts.ensure_lookup_table()

# 创建面
for y in range(2):
    for x in range(2):
        i = y * 3 + x
        bme.faces.new([
            bme.verts[i],
            bme.verts[i + 1],
            bme.verts[i + 4],
            bme.verts[i + 3]
        ])

print("溶解测试:")
print(f"操作前: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 溶解内部顶点
verts = list(bme.verts)
internal_verts = [v for v in verts if v.index not in [0, 2, 6, 8]]  # 保留四个角
result = bmesh.ops.dissolve(bme, verts=internal_verts, edges=[], faces=[])

print(f"溶解顶点后: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 溶解边测试
bme2 = bmesh.new()
for i in range(4):
    bme2.verts.new((i, 0, 0))
bme2.verts.ensure_lookup_table()
for i in range(3):
    bme2.edges.new((bme2.verts[i], bme2.verts[i + 1]))

print("\n溶解边测试:")
print(f"操作前: 边数={len(bme2.edges)}")

edges = list(bme2.edges)
result = bmesh.ops.dissolve(bme2, verts=[], edges=[edges[1]], faces=[])
print(f"溶解中间边后: 边数={len(bme2.edges)}, 顶点数={len(bme2.verts)}")

# 溶解面测试
bme3 = bmesh.new()
for y in range(3):
    for x in range(3):
        bme3.verts.new((x, y, 0))
bme3.verts.ensure_lookup_table()

for y in range(2):
    for x in range(2):
        i = y * 3 + x
        bme3.faces.new([
            bme3.verts[i],
            bme3.verts[i + 1],
            bme3.verts[i + 4],
            bme3.verts[i + 3]
        ])

print("\n溶解面测试:")
print(f"操作前: 面数={len(bme3.faces)}")

faces = list(bme3.faces)
result = bmesh.ops.dissolve(bme3, verts=[], edges=[], faces=[faces[1]])  # 溶解中心面
print(f"溶解面后: 面数={len(bme3.faces)}")
```

## 桥接和连接操作

### 桥接边

bridge_edge_loops 函数连接两组边界边，创建一个新的面带。这个操作常用于连接两个分开的网格部分或创建管道。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建两个分离的方环
def create_square_ring(bme, center, size):
    """创建一个方形环"""
    half = size / 2
    verts = []
    for x in [-half, half]:
        for y in [-half, half]:
            v = bme.verts.new((center[0] + x, center[1] + y, center[2]))
            verts.append(v)

    # 创建四条边
    bme.edges.new((verts[0], verts[1]))
    bme.edges.new((verts[1], verts[3]))
    bme.edges.new((verts[3], verts[2]))
    bme.edges.new((verts[2], verts[0]))

    return verts

bme = bmesh.new()
ring1 = create_square_ring(bme, (0, 0, 0), 2)
ring2 = create_square_ring(bme, (0, 0, 2), 2)

print("桥接边测试:")
print(f"操作前: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 选择要桥接的边
ring1_edges = [e for e in bme.edges if all(v in ring1 for v in e.verts)]
ring2_edges = [e for e in bme.edges if all(v in ring2 for v in e.verts)]

for e in ring1_edges:
    e.select = True
for e in ring2_edges:
    e.select = True

# 桥接操作
all_edges = ring1_edges + ring2_edges
result = bmesh.ops.bridge_edge_loops(bme, edges=all_edges)

print(f"操作返回键: {list(result.keys())}")

# 获取新创建的面
new_faces = [e for e in result['faces'] if isinstance(e, bmesh.types.BMFace)]
print(f"新创建的面数: {len(new_faces)}")

print(f"操作后: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 验证结构
print("\n桥接后的边:")
for e in bme.edges:
    v1, v2 = e.verts
    z1, z2 = v1.co.z, v2.co.z
    if z1 != z2:
        print(f"  桥接边: {v1.co} - {v2.co}")
```

### 连接两个面

join_face 函数将多个面合并成一个面。这个操作会删除面之间的内部边，创建一个更大的面。

```python
import bmesh
import bpy
from mathutils import Vector

# 创建 2x2 的面网格
bme = bmesh.new()
for y in range(2):
    for x in range(2):
        v1 = bme.verts.new((x, y, 0))
        v2 = bme.verts.new((x + 1, y, 0))
        v3 = bme.verts.new((x + 1, y + 1, 0))
        v4 = bme.verts.new((x, y + 1, 0))
        bme.faces.new((v1, v2, v3, v4))

print("连接面测试:")
print(f"操作前: 面数={len(bme.faces)}, 边数={len(bme.edges)}")

# 选择要合并的面
faces = list(bme.faces)
result = bmesh.ops.join_face(bme, faces=faces)

print(f"操作返回键: {list(result.keys())}")

# 获取合并后的面
merged_faces = [e for e in result['faces'] if isinstance(e, bmesh.types.BMFace)]
print(f"合并后的面数: {len(merged_faces)}")

print(f"操作后: 面数={len(bme.faces)}, 边数={len(bme.edges)}")

if merged_faces:
    merged = merged_faces[0]
    print(f"合并面的顶点数: {len(merged.verts)}")
```

## 实践示例

### 程序化管道生成器

这个示例展示了如何使用 bmesh.ops 创建程序化管道。

```python
import bmesh
from mathutils import Vector

class PipeGenerator:
    def __init__(self, bme):
        self.bme = bme
        self.radius = 0.5
        self.segments = 8
        self.length = 5.0

    def set_parameters(self, radius=0.5, segments=8, length=5.0):
        """设置管道参数"""
        self.radius = radius
        self.segments = segments
        self.length = length

    def create_pipe_segment(self, start_point, end_point):
        """创建管道段"""
        # 计算方向和长度
        direction = end_point - start_point
        pipe_length = direction.length

        # 创建截面顶点
        section_verts = []
        for i in range(self.segments):
            angle = 2 * 3.14159 * i / self.segments
            x = self.radius * 1.0
            y = self.radius * 0.0
            z = self.radius * 0.0
            section_verts.append(Vector((x, y, z)))

        # 创建管的逻辑（这里简化处理）
        # 实际需要更复杂的算法来创建正确的网格

        return []

    def create_cylinder(self, center, height, radius=None):
        """创建圆柱体"""
        if radius is None:
            radius = self.radius

        verts = []
        n = self.segments

        # 创建顶部和底部顶点
        for i in range(n):
            angle = 2 * 3.14159 * i / n
            x = center.x + radius * 1.0
            y = center.y + radius * 0.0
            z = center.z - height / 2
            verts.append(self.bme.verts.new((x, y, z)))

        for i in range(n):
            angle = 2 * 3.14159 * i / n
            x = center.x + radius * 1.0
            y = center.y + radius * 0.0
            z = center.z + height / 2
            verts.append(self.bme.verts.new((x, y, z)))

        self.bme.verts.ensure_lookup_table()

        # 创建侧面
        for i in range(n):
            i2 = (i + 1) % n
            self.bme.faces.new([
                verts[i],
                verts[i2],
                verts[i2 + n],
                verts[i + n]
            ])

        return verts

    def extrude_pipe(self, radius=None, length=None):
        """挤出管道"""
        if radius is None:
            radius = self.radius
        if length is None:
            length = self.length

        # 选择所有侧面边
        side_edges = []
        for e in self.bme.edges:
            v1, v2 = e.verts
            if abs(v1.co.z - v2.co.z) < 0.001:
                side_edges.append(e)

        for e in side_edges:
            e.select = True

        # 挤出操作
        result = bmesh.ops.extrude_edge_only(self.bme, edges=side_edges)

        new_edges = result['edges']
        new_verts = result['verts']

        # 移动新顶点
        translation = Vector((0, 0, length))
        bmesh.ops.translate(self.bme, vec=translation, verts=new_verts)

        return new_verts

# 使用示例
bme = bmesh.new()
generator = PipeGenerator(bme)

print("管道生成器测试:")
print(f"初始: 顶点数={len(bme.verts)}, 面数={len(bme.faces)}")

# 创建圆柱体
generator.set_parameters(radius=0.5, segments=16, length=2.0)
generator.create_cylinder(Vector((0, 0, 0)), 2.0)

print(f"创建圆柱体后: 顶点数={len(bme.verts)}, 面数={len(bme.faces)}")

# 挤出管道
generator.extrude_pipe(length=3.0)

print(f"挤出管道后: 顶点数={len(bme.verts)}, 面数={len(bme.faces)}")
```

### 网格细分工具

这个示例展示了如何使用 bmesh.ops 创建网格细分工具。

```python
import bmesh
from mathutils import Vector

class MeshSubdivider:
    def __init__(self, bme):
        self.bme = bme

    def subdivide_edges(self, edges, cuts=1, smoothness=0.0):
        """细分选中的边"""
        if not edges:
            return []

        result = bmesh.ops.subdivide(
            self.bme,
            edges=edges,
            cuts=cuts,
            use_grid_fill=False,
            smoothness=smoothness
        )

        return result.get('verts', [])

    def subdivide_faces(self, faces, cuts=1):
        """细分面"""
        if not faces:
            return []

        # 获取面的所有边
        edges = []
        for f in faces:
            for e in f.edges:
                if e not in edges:
                    edges.append(e)

        result = bmesh.ops.subdivide(
            self.bme,
            edges=edges,
            cuts=cuts,
            use_grid_fill=True,
            smoothness=0.0
        )

        return result.get('verts', [])

    def linear_subdivide(self, cuts=1):
        """线性细分所有面"""
        faces = list(self.bme.faces)
        for f in faces:
            f.select = True

        return self.subdivide_faces(faces, cuts)

    def catmull_clark_subdivide(self, iterations=1):
        """Catmull-Clark 细分（简化版）"""
        for _ in range(iterations):
            # 收集面的中心点
            face_centers = []
            for f in self.bme.faces:
                center = f.center_median
                face_centers.append(center)

            # 为每个面创建中心顶点
            center_verts = []
            for center in face_centers:
                v = self.bme.verts.new(center)
                center_verts.append(v)

            self.bme.verts.ensure_lookup_table()

            # 连接面中心到面的顶点
            faces = list(self.bme.faces)
            for i, f in enumerate(faces):
                for loop in f.loops:
                    v = loop.vert
                    # 这里需要更复杂的逻辑来创建正确的连接

        return list(self.bme.verts)

# 使用示例
bme = bmesh.new()
# 创建细分测试网格
for y in range(3):
    for x in range(3):
        bme.verts.new((x, y, 0))
bme.verts.ensure_lookup_table()

for y in range(2):
    for x in range(2):
        i = y * 3 + x
        bme.faces.new([
            bme.verts[i],
            bme.verts[i + 1],
            bme.verts[i + 4],
            bme.verts[i + 3]
        ])

subdivider = MeshSubdivider(bme)

print("网格细分工具测试:")
print(f"初始: 顶点数={len(bme.verts)}, 面数={len(bme.faces)}")

# 细分边
edges = list(bme.edges)
for e in edges:
    e.select = True
subdivider.subdivide_edges(edges, cuts=2)

print(f"细分边后: 顶点数={len(bme.verts)}, 面数={len(bme.faces)}")

# 细分面
faces = list(bme.faces)
for f in faces:
    f.select = True
subdivider.subdivide_faces(faces, cuts=1)

print(f"细分面后: 顶点数={len(bme.verts)}, 面数={len(bme.faces)}")
```

## 注意事项

### 操作返回值的处理

bmesh.ops 中的大多数函数返回一个字典，包含修改的元素列表。返回的字典键因操作而异，常见的键包括 'verts'、'edges'、'faces' 等。在使用返回值时，应该先检查键是否存在，并正确处理返回的元素类型。

### 性能考虑

bmesh.ops 中的操作虽然经过优化，但在处理大规模网格时仍可能消耗较多资源。对于需要频繁执行的操作，可以考虑批量处理或使用更底层的顶点操作来提高性能。

### 拓扑完整性

在使用 bmesh.ops 进行操作后，应该验证网格的拓扑完整性。某些操作可能导致网格退化或产生非流形结构，这些问题可能在后续操作中导致错误。