# bpy.ops.toolshelf - 工具架操作模块

Blender工具架操作符，用于管理工具架面板和工具选择。

## 概述

`bpy.ops.toolshelf` 模块提供用于操作Blender工具架（Tool Shelf）面板的功能，包括面板切换、工具选择和参数调整。

## 核心功能

### 面板操作

```python
import bpy

# 切换到雕刻面板
bpy.ops.toolshelf.tab_change(
    tab='sculpt'
)

# 切换到雕刻面板
bpy.ops.toolshelf.tab_change(
    tab='vertex_paint'
)

# 切换到顶点绘制面板
bpy.ops.toolshelf.tab_change(
    tab='vertex_paint'
)

# 切换到权重绘制面板
bpy.ops.toolshelf.tab_change(
    tab='weight_paint'
)

# 切换到纹理绘制面板
bpy.ops.toolshelf.tab_change(
    tab='texture_paint'
)

# 切换到编辑面板
bpy.ops.toolshelf.tab_change(
    tab='mesh_edit'
)

# 切换到UV编辑面板
bpy.ops.toolshelf.tab_change(
    tab='uv_edit'
)

# 切换到粒子面板
bpy.ops.toolshelf.tab_change(
    tab='particle_edit'
)
```

### 工具架切换

```python
# 打开工具架
bpy.ops.screen.toolbar_prompt(
    tool_name='builtin.move'
)

# 关闭工具架
bpy.ops.screen.toolbar_prompt(
    tool_name='builtin.move'
)

# 展开工具架
bpy.ops.screen.toolbar_prompt(
    tool_name='builtin.move',
    prompt='OPEN'
)

# 收起工具架
bpy.ops.screen.toolbar_prompt(
    tool_name='builtin.move',
    prompt='CLOSE'
)
```

### 工具选择

```python
# 选择移动工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.move'
)

# 选择旋转工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.rotate'
)

# 选择缩放工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.scale'
)

# 选择智能变换工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.transform'
)

# 选择雕刻工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.sculpt'
)

# 选择重新拓扑工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.measure'
)

# 选择注释工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.annotate'
)

# 选择选择工具
bpy.ops.wm.tool_set_by_id(
    name='builtin.select'
)
```

### 笔刷操作

```python
# 选择笔刷
bpy.ops.paint.brush_select(
    sculpt_tool='DRAW'
)

# 选择雕刻笔刷
bpy.ops.paint.brush_select(
    sculpt_tool='DRAW',
    texture_paint_tool='DRAW'
)

# 选择顶点绘制笔刷
bpy.ops.paint.brush_select(
    vertex_paint_tool='MIX'
)

# 选择权重绘制笔刷
bpy.ops.paint.brush_select(
    weight_paint_tool='DRAW'
)

# 选择纹理绘制笔刷
bpy.ops.paint.brush_select(
    texture_paint_tool='DRAW'
)
```

### 模式切换

```python
# 切换到对象模式
bpy.ops.object.mode_set(
    mode='OBJECT'
)

# 切换到编辑模式
bpy.ops.object.mode_set(
    mode='EDIT'
)

# 切换到雕刻模式
bpy.ops.sculpt.sculptmode_toggle()

# 切换到顶点绘制模式
bpy.ops.paint.vertex_paint_toggle()

# 切换到权重绘制模式
bpy.ops.paint.weight_paint_toggle()

# 切换到纹理绘制模式
bpy.ops.paint.texture_paint_toggle()

# 切换到姿势模式
bpy.ops.pose.select_hierarchy(
    direction='PARENT'
)
```

## 实用函数

```python
def show_toolshelf():
    """显示工具架"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = True

def hide_toolshelf():
    """隐藏工具架"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = False

def toggle_toolshelf():
    """切换工具架显示"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = not space.show_region_toolbar

def switch_to_sculpt_mode():
    """切换到雕刻模式"""
    if bpy.context.active_object:
        bpy.ops.sculpt.sculptmode_toggle()

def switch_to_edit_mode():
    """切换到编辑模式"""
    if bpy.context.active_object:
        bpy.ops.object.mode_set(mode='EDIT')

def switch_to_object_mode():
    """切换到对象模式"""
    if bpy.context.active_object:
        bpy.ops.object.mode_set(mode='OBJECT')

def select_brush(brush_name):
    """选择笔刷"""
    brushes = bpy.data.brushes
    if brush_name in brushes:
        bpy.context.tool_settings.sculpt.brush = brushes[brush_name]

def set_brush_size(size):
    """设置笔刷大小"""
    bpy.context.tool_settings.sculpt.brush.size = size

def set_brush_strength(strength):
    """设置笔刷强度"""
    bpy.context.tool_settings.sculpt.brush.strength = strength

def show_ui_panel():
    """显示UI面板"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_ui = True

def hide_ui_panel():
    """隐藏UI面板"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_ui = False
```

## 常见问题排查

### 工具架不显示
```python
# 检查工具架状态
space = bpy.context.area.spaces.active
print(f"工具架: {space.show_region_toolbar}")

# 启用工具架
space.show_region_toolbar = True

# 检查区域
print(f"区域类型: {bpy.context.area.type}")

# 确保在3D视图中
if bpy.context.area.type != 'VIEW_3D':
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            bpy.context.window.screen.areas[0] = area
            break
```

### 工具无法选择
```python
# 检查当前模式
print(f"当前模式: {bpy.context.mode}")

# 检查活动对象
obj = bpy.context.active_object
print(f"活动对象: {obj}")

if obj:
    print(f"对象类型: {obj.type}")

# 确保在正确的模式
if bpy.context.mode == 'OBJECT':
    bpy.ops.object.mode_set(mode='EDIT')

# 检查工具
print(f"当前工具: {bpy.context.workspace.tools.active}")
```

### 笔刷不工作
```python
# 检查笔刷
brush = bpy.context.tool_settings.sculpt.brush
print(f"当前笔刷: {brush}")

# 检查笔刷设置
print(f"笔刷大小: {brush.size}")
print(f"笔刷强度: {brush.strength}")

# 选择正确笔刷
bpy.ops.paint.brush_select(sculpt_tool='DRAW')

# 重置笔刷设置
brush.size = 50
brush.strength = 1.0
```

### 面板切换问题
```python
# 检查当前面板
print(f"当前选项卡: {bpy.context.workspace.tools.active.paint_mode}")

# 切换到雕刻
bpy.ops.toolshelf.tab_change(tab='sculpt')

# 检查笔刷
bpy.ops.paint.brush_select(sculpt_tool='DRAW')

# 重置工具架
bpy.ops.screen.toolbar_prompt(tool_name='builtin.move', prompt='OPEN')
```
