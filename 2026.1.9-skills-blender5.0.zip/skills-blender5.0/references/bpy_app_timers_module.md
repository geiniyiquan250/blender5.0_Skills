# bpy.app.timers 模块

bpy.app.timers 模块提供了注册和管理定时器的功能，用于在 Blender 中执行定时任务和后台操作。

## 定时器概述

定时器模块允许注册在指定时间间隔后执行的回调函数，非常适合实现动画、更新检查和周期性任务。

### 何时使用定时器

- 实现周期性更新
- 创建动画效果
- 延迟执行操作
- 检查外部状态
- 后台数据同步

## 注册定时器

### bpy.app.timers.register

注册一个定时回调函数。

```python
import bpy
import time

# 简单的定时回调
def my_timer_callback():
    print("定时器触发!")
    return 1.0  # 返回下次触发间隔（秒）

# 注册定时器
timer = bpy.app.timers.register(my_timer_callback)

# 取消注册
bpy.app.timers.unregister(timer)
```

### 带参数的定时器

```python
import bpy

def progress_timer(progress_var):
    """带参数的定时器回调"""
    if progress_var['value'] >= 100:
        progress_var['finished'] = True
        print("任务完成!")
        return None  # 返回 None 停止定时器
    
    progress_var['value'] += 5
    print(f"进度: {progress_var['value']}%")
    
    return 0.5  # 每 0.5 秒触发一次

# 使用变量传递状态
task_progress = {'value': 0, 'finished': False}
bpy.app.timers.register(lambda: progress_timer(task_progress))
```

## 实际应用示例

### 进度更新器

```python
import bpy
import time

class ProgressUpdater:
    """进度更新器"""
    
    def __init__(self, name="Task", total_steps=100):
        self.name = name
        self.total_steps = total_steps
        self.current_step = 0
        self.start_time = None
        self.timer = None
        self.finished = False
    
    def start(self, interval=0.1):
        """开始进度更新"""
        self.start_time = time.time()
        self.current_step = 0
        self.finished = False
        
        self.timer = bpy.app.timers.register(
            self._update_callback,
            persistent=True
        )
        
        print(f"{self.name} 开始")
    
    def _update_callback(self):
        """定时回调"""
        if self.finished:
            return None
        
        self.current_step += 1
        
        # 计算进度
        progress = self.current_step / self.total_steps
        elapsed = time.time() - self.start_time
        
        # 估算剩余时间
        if progress > 0:
            total_time = elapsed / progress
            remaining = total_time - elapsed
        else:
            remaining = 0
        
        # 更新进度
        self._update_ui(progress)
        
        if self.current_step >= self.total_steps:
            self.finish()
            return None
        
        return 0.1  # 每 0.1 秒更新
    
    def _update_ui(self, progress):
        """更新用户界面"""
        # 更新标题
        bpy.context.scene.my_addon.progress = progress * 100
        
        # 在控制台输出
        print(f"\r{self.name}: {progress*100:.1f}%", end="")
    
    def finish(self):
        """完成"""
        self.finished = True
        elapsed = time.time() - self.start_time
        print(f"\n{self.name} 完成! 用时: {elapsed:.2f}秒")
        
        if self.timer:
            bpy.app.timers.unregister(self.timer)
            self.timer = None
    
    def cancel(self):
        """取消"""
        self.finished = True
        if self.timer:
            bpy.app.timers.unregister(self.timer)
            self.timer = None
        
        print(f"\n{self.name} 已取消")


def run_long_task():
    """运行长时间任务"""
    updater = ProgressUpdater("数据处理", total_steps=50)
    updater.start(interval=0.1)
```

### 动画系统

```python
import bpy
import math

class AnimationPlayer:
    """动画播放器"""
    
    def __init__(self):
        self.animations = {}
        self.current_time = 0.0
        self.is_playing = False
        self.timer = None
        self.fps = 30.0
        self.frame_interval = 1.0 / self.fps
    
    def add_keyframe_animation(self, obj, path, values, duration):
        """添加关键帧动画"""
        self.animations[path] = {
            'object': obj,
            'property': path,
            'values': values,  # [(time, value), ...]
            'duration': duration
        }
    
    def play(self, animation_name=None):
        """播放动画"""
        self.is_playing = True
        self.current_time = 0.0
        
        if self.timer:
            bpy.app.timers.unregister(self.timer)
        
        self.timer = bpy.app.timers.register(
            self._animation_loop,
            persistent=True
        )
        
        print(f"开始播放动画: {animation_name or '全部'}")
    
    def _animation_loop(self):
        """动画循环"""
        if not self.is_playing:
            return None
        
        # 更新时间
        self.current_time += self.frame_interval
        
        # 更新所有动画
        for name, anim in self.animations.items():
            value = self._evaluate_keyframes(anim, self.current_time)
            self._apply_value(anim['object'], anim['property'], value)
        
        # 检查是否完成
        max_duration = max(anim['duration'] for anim in self.animations.values())
        if self.current_time >= max_duration:
            self.stop()
            return None
        
        return self.frame_interval
    
    def _evaluate_keyframes(self, anim, time):
        """计算关键帧值"""
        values = anim['values']
        
        # 找到当前时间所在的关键帧
        prev_key = None
        next_key = None
        
        for key_time, key_value in values:
            if key_time <= time:
                prev_key = (key_time, key_value)
            if key_time > time and next_key is None:
                next_key = (key_time, key_value)
        
        if prev_key is None:
            return values[0][1] if values else 0.0
        if next_key is None:
            return prev_key[1]
        
        # 插值
        t = (time - prev_key[0]) / (next_key[0] - prev_key[0])
        t = max(0.0, min(1.0, t))
        
        # 线性插值
        return prev_key[1] + (next_key[1] - prev_key[1]) * t
    
    def _apply_value(self, obj, property_path, value):
        """应用值到对象"""
        # 解析属性路径
        parts = property_path.split('.')
        target = obj
        
        for part in parts[:-1]:
            if hasattr(target, part):
                target = getattr(target, part)
        
        final_prop = parts[-1]
        if hasattr(target, final_prop):
            setattr(target, final_prop, value)
    
    def stop(self):
        """停止动画"""
        self.is_playing = False
        if self.timer:
            bpy.app.timers.unregister(self.timer)
            self.timer = None
        
        print("动画播放完成")


def animate_object_rotation():
    """动画对象旋转"""
    player = AnimationPlayer()
    
    obj = bpy.context.active_object
    if not obj:
        print("请先选择一个对象")
        return
    
    # 创建旋转动画
    duration = 2.0  # 2秒
    values = [
        (0.0, 0.0),
        (0.5, math.pi),
        (1.0, 2 * math.pi),
        (1.5, 3 * math.pi),
        (2.0, 4 * math.pi)
    ]
    
    player.add_keyframe_animation(obj, "rotation_euler.z", values, duration)
    player.play()
```

### 自动保存系统

```python
import bpy
import os
import time

class AutoSaver:
    """自动保存器"""
    
    def __init__(self):
        self.last_save_time = 0
        self.save_interval = 300  # 5分钟
        self.backup_count = 3
        self.timer = None
        self.is_active = False
    
    def start(self, interval_minutes=5):
        """启动自动保存"""
        self.save_interval = interval_minutes * 60
        self.is_active = True
        self.last_save_time = time.time()
        
        if self.timer:
            bpy.app.timers.unregister(self.timer)
        
        self.timer = bpy.app.timers.register(
            self._auto_save_check,
            persistent=True
        )
        
        print(f"自动保存已启用，间隔: {interval_minutes} 分钟")
    
    def _auto_save_check(self):
        """自动保存检查"""
        if not self.is_active:
            return None
        
        current_time = time.time()
        
        if current_time - self.last_save_time >= self.save_interval:
            self.save_backup()
            self.last_save_time = current_time
        
        return 30.0  # 每 30 秒检查一次
    
    def save_backup(self):
        """保存备份"""
        if not bpy.data.filepath:
            print("未保存的文件，跳过自动保存")
            return
        
        # 创建备份文件名
        filepath = bpy.data.filepath
        dirname = os.path.dirname(filepath)
        basename = os.path.basename(filepath)
        name, ext = os.path.splitext(basename)
        
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup_name = f"{name}_backup_{timestamp}{ext}"
        backup_path = os.path.join(dirname, backup_name)
        
        try:
            bpy.ops.wm.save_as_mainfile(filepath=backup_path)
            print(f"已保存备份: {backup_name}")
            
            # 清理旧备份
            self._cleanup_old_backups(dirname, name, ext)
            
        except Exception as e:
            print(f"自动保存失败: {e}")
    
    def _cleanup_old_backups(self, dirname, name, ext):
        """清理旧备份"""
        backups = []
        
        for f in os.listdir(dirname):
            if f.startswith(f"{name}_backup_") and f.endswith(ext):
                filepath = os.path.join(dirname, f)
                mtime = os.path.getmtime(filepath)
                backups.append((mtime, filepath))
        
        # 按修改时间排序，保留最新的
        backups.sort(key=lambda x: x[0], reverse=True)
        
        for i, (mtime, filepath) in enumerate(backups):
            if i >= self.backup_count:
                try:
                    os.remove(filepath)
                    print(f"已删除旧备份: {os.path.basename(filepath)}")
                except Exception as e:
                    print(f"删除备份失败: {e}")
    
    def stop(self):
        """停止自动保存"""
        self.is_active = False
        if self.timer:
            bpy.app.timers.unregister(self.timer)
            self.timer = None
        
        print("自动保存已禁用")


# 使用示例
def enable_auto_save():
    """启用自动保存"""
    saver = AutoSaver()
    saver.start(interval_minutes=5)  # 每5分钟保存一次
    
    # 保存引用以保持活动
    bpy.context.scene.auto_saver = saver
```

### 实时数据同步

```python
import bpy
import requests
import json

class RealtimeSync:
    """实时同步器"""
    
    def __init__(self, api_url):
        self.api_url = api_url
        self.last_data = None
        self.sync_interval = 5.0  # 秒
        self.timer = None
        self.is_syncing = False
    
    def start(self, interval=5.0):
        """开始同步"""
        self.sync_interval = interval
        self.is_syncing = True
        
        if self.timer:
            bpy.app.timers.unregister(self.timer)
        
        self.timer = bpy.app.timers.register(
            self._sync_data,
            persistent=True
        )
        
        print(f"开始同步数据: {self.api_url}")
    
    def _sync_data(self):
        """同步数据"""
        if not self.is_syncing:
            return None
        
        try:
            # 模拟 API 请求
            response = requests.get(self.api_url, timeout=2)
            
            if response.status_code == 200:
                data = response.json()
                
                # 检查数据变化
                if data != self.last_data:
                    self._on_data_changed(data)
                    self.last_data = data
                    print(f"数据已更新: {json.dumps(data, indent=2)}")
            
        except requests.RequestException as e:
            print(f"同步请求失败: {e}")
        except Exception as e:
            print(f"数据处理失败: {e}")
        
        return self.sync_interval
    
    def _on_data_changed(self, data):
        """数据变化回调"""
        # 更新场景属性
        scene = bpy.context.scene
        
        if 'camera_position' in data:
            cam_data = data['camera_position']
            cam = scene.camera
            if cam:
                cam.location = cam_data.get('location', cam.location)
                cam.rotation_euler = cam_data.get('rotation', cam.rotation_euler)
        
        if 'object_transforms' in data:
            for name, transform in data['object_transforms'].items():
                obj = bpy.data.objects.get(name)
                if obj:
                    if 'location' in transform:
                        obj.location = transform['location']
                    if 'rotation' in transform:
                        obj.rotation_euler = transform['rotation']
                    if 'scale' in transform:
                        obj.scale = transform['scale']
    
    def stop(self):
        """停止同步"""
        self.is_syncing = False
        if self.timer:
            bpy.app.timers.unregister(self.timer)
            self.timer = None
        
        print("数据同步已停止")
    
    def send_update(self, data):
        """发送数据更新"""
        try:
            requests.post(
                self.api_url,
                json=data,
                timeout=2
            )
        except Exception as e:
            print(f"发送更新失败: {e}")


def setup_realtime_sync():
    """设置实时同步"""
    sync = RealtimeSync("http://localhost:8080/api/data")
    sync.start(interval=10.0)
    
    # 保存引用
    bpy.context.scene.realtime_sync = sync
    
    return sync
```

### 性能监控器

```python
import bpy
import time
import psutil

class PerformanceMonitor:
    """性能监控器"""
    
    def __init__(self):
        self.update_interval = 1.0
        self.history = []
        self.max_history = 60  # 保存60秒的历史
        self.timer = None
        self.is_monitoring = False
    
    def start(self, interval=1.0):
        """开始监控"""
        self.update_interval = interval
        self.is_monitoring = True
        self.history = []
        
        if self.timer:
            bpy.app.timers.unregister(self.timer)
        
        self.timer = bpy.app.timers.register(
            self._monitor_performance,
            persistent=True
        )
        
        print("开始性能监控")
    
    def _monitor_performance(self):
        """监控性能"""
        if not self.is_monitoring:
            return None
        
        # 获取 Blender 进程信息
        process = psutil.Process()
        memory_info = process.memory_info()
        cpu_percent = process.cpu_percent()
        
        # 获取场景信息
        scene = bpy.context.scene
        obj_count = len(bpy.data.objects)
        
        # 收集数据
        data = {
            'timestamp': time.time(),
            'memory_mb': memory_info.rss / 1024 / 1024,
            'cpu_percent': cpu_percent,
            'object_count': obj_count,
            'fps': bpy.context.scene.render.fps
        }
        
        self.history.append(data)
        
        # 限制历史长度
        if len(self.history) > self.max_history:
            self.history.pop(0)
        
        # 更新 UI
        self._update_ui(data)
        
        return self.update_interval
    
    def _update_ui(self, data):
        """更新用户界面"""
        scene = bpy.context.scene
        
        # 存储性能数据
        if not hasattr(scene, 'perf_data'):
            scene.perf_data = {}
        
        scene.perf_data['memory'] = data['memory_mb']
        scene.perf_data['cpu'] = data['cpu_percent']
        scene.perf_data['objects'] = data['object_count']
    
    def get_statistics(self):
        """获取统计信息"""
        if not self.history:
            return None
        
        memories = [d['memory_mb'] for d in self.history]
        cpus = [d['cpu_percent'] for d in self.history]
        
        return {
            'avg_memory': sum(memories) / len(memories),
            'max_memory': max(memories),
            'min_memory': min(memories),
            'avg_cpu': sum(cpus) / len(cpus),
            'max_cpu': max(cpus),
            'sample_count': len(self.history),
            'duration_seconds': self.history[-1]['timestamp'] - self.history[0]['timestamp']
        }
    
    def stop(self):
        """停止监控"""
        self.is_monitoring = False
        if self.timer:
            bpy.app.timers.unregister(self.timer)
            self.timer = None
        
        # 输出统计
        stats = self.get_statistics()
        if stats:
            print("\n=== 性能统计 ===")
            print(f"平均内存: {stats['avg_memory']:.1f} MB")
            print(f"最大内存: {stats['max_memory']:.1f} MB")
            print(f"平均 CPU: {stats['avg_cpu']:.1f}%")
            print(f"最大 CPU: {stats['max_cpu']:.1f}%")
            print(f"监控时长: {stats['duration_seconds']:.1f} 秒")
            print(f"样本数: {stats['sample_count']}")


def start_monitoring():
    """开始监控"""
    monitor = PerformanceMonitor()
    monitor.start(interval=2.0)
    
    # 保存引用
    bpy.context.scene.perf_monitor = monitor
    
    return monitor
```

## 最佳实践

1. **及时注销**：不再需要定时器时及时注销，避免资源浪费
2. **持久化处理**：使用 persistent=True 确保定时器在重绘时保持活动
3. **错误处理**：在定时器回调中添加异常处理，防止定时器崩溃
4. **间隔选择**：根据任务性质选择合适的间隔时间，平衡响应性和性能
5. **状态管理**：使用类或字典管理定时器状态，便于控制和调试
