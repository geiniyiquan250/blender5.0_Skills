# bpy.ops.paint_curve - 笔触曲线操作模块

Blender笔触曲线操作符，用于创建和管理绘画笔触路径。

## 概述

`bpy.ops.paint_curve` 模块提供用于在绘画工具中创建和操作笔触曲线的功能。笔触曲线定义了绘画时的笔触形状和动态效果。

## 核心功能

### 笔触曲线创建

```python
import bpy

# 添加笔触曲线点
bpy.ops.paintcurve.add(
    location=(0, 0, 0)
)

# 添加多个点
for i in range(10):
    bpy.ops.paintcurve.add(
        location=(i * 0.1, 0, 0)
    )

# 关闭笔触曲线
bpy.ops.paintcurve.close()

# 完成笔触曲线
bpy.ops.paintcurve.record()

# 取消笔触曲线
bpy.ops.paintcurve.cancel()
```

### 笔触曲线选择

```python
# 选择所有点
bpy.ops.paintcurve.select_all(
    action='SELECT'
)

# 取消选择所有点
bpy.ops.paintcurve.select_all(
    action='DESELECT'
)

# 反选
bpy.ops.paintcurve.select_all(
    action='INVERT'
)

# 选择相似的点
bpy.ops.paintcurve.select_similar(
    type='DISTANCE',
    threshold=0.1
)

# 选择区域内的点
bpy.ops.paintcurve.select_box(
    xmin=100,
    ymin=100,
    xmax=200,
    ymax=200
)

# 选择圆内的点
bpy.ops.paintcurve.select_circle(
    x=150,
    y=150,
    radius=50
)

# 套索选择
bpy.ops.paintcurve.select_lasso(
    path=[(x, y) for x, y in [(100, 100), (200, 100), (200, 200), (100, 200)]]
)
```

### 笔触曲线编辑

```python
# 删除选中点
bpy.ops.paintcurve.delete()

# 移除点
bpy.ops.paintcurve.remove()

# 分离点
bpy.ops.paintcurve.separate()

# 连接点
bpy.ops.paintcurve.make_segment()

# 断开连接
bpy.ops.paintcurve.break_segment()

# 滑动点
bpy.ops.paintcurve.slide(
    factor=0.5
)

# 平滑点
bpy.ops.paintcurve.smooth()

# 简化曲线
bpy.ops.paintcurve.simplify(
    factor=0.1
)
```

### 笔触曲线变换

```python
# 移动选中点
bpy.ops.paintcurve.move(
    delta=(1.0, 0.0, 0.0)
)

# 旋转
bpy.ops.paintcurve.rotate(
    angle=45
)

# 缩放
bpy.ops.paintcurve.scale(
    factor=1.5
)

# 应用变换
bpy.ops.paintcurve.transform_apply()

# 重置变换
bpy.ops.paintcurve.transform_reset()
```

### 笔触曲线属性

```python
# 设置点权重
bpy.ops.paintcurve.set_weight(
    value=1.0
)

# 设置点半径
bpy.ops.paintcurve.set_radius(
    radius=10
)

# 设置点颜色
bpy.ops.paintcurve.set_color(
    color=(1.0, 0.0, 0.0, 1.0)
)

# 设置点硬度
bpy.ops.paintcurve.set_hardness(
    hardness=0.8
)

# 设置点时间
bpy.ops.paintcurve.set_time(
    time=0.0
)

# 随机化点属性
bpy.ops.paintcurve.randomize(
    factor=0.1
)
```

### 笔触曲线工具

```python
# 插值点
bpy.ops.paintcurve.subdivide(
    cuts=1
)

# 细分曲线
bpy.ops.paintcurve.subdivide_curve(
    number_cuts=2
)

# 倒角点
bpy.ops.paintcurve.bevel_point(
    radius=0.1
)

# 倒角曲线
bpy.ops.paintcurve.bevel_curve(
    radius=0.1
)

# 转换点类型
bpy.ops.paintcurve.convert_point_type(
    type='AUTO'
)

# 切换切线
bpy.ops.paintcurve.toggle_handle_type()
```

## 实用函数

```python
def create_brush_stroke_curve(name, points):
    """创建笔触曲线"""
    bpy.ops.paintcurve.new(name=name)
    curve = bpy.context.active_object
    
    for point in points:
        bpy.ops.paintcurve.add(location=point)
    
    bpy.ops.paintcurve.close()
    
    return curve

def add_noise_to_curve(curve, amount=0.1):
    """为曲线添加噪点"""
    import random
    
    for i, point in enumerate(curve.data.points):
        if point.select:
            point.location += (
                random.uniform(-amount, amount),
                random.uniform(-amount, amount),
                random.uniform(-amount, amount)
            )

def smooth_curve_points(curve, iterations=3):
    """平滑曲线点"""
    for _ in range(iterations):
        points = curve.data.points
        for i in range(len(points)):
            if i > 0 and i < len(points) - 1:
                prev_point = points[i - 1]
                next_point = points[i + 1]
                
                avg_location = (
                    (prev_point.location.x + next_point.location.x) / 2,
                    (prev_point.location.y + next_point.location.y) / 2,
                    (prev_point.location.z + next_point.location.z) / 2
                )
                
                points[i].location = avg_location

def sample_curve_to_keyframes(curve, num_samples=10):
    """将曲线采样为关键帧"""
    points = curve.data.points
    step = max(1, len(points) // num_samples)
    
    for i in range(0, len(points), step):
        point = points[i]
        bpy.context.scene.frame_set(i)
        point.select_set(True)
    
    return [i for i in range(0, len(points), step)]

def create_radial_stroke(name, center, radius, num_points=12):
    """创建放射状笔触曲线"""
    import math
    
    bpy.ops.paintcurve.new(name=name)
    curve = bpy.context.active_object
    
    for i in range(num_points):
        angle = (2 * math.pi * i) / num_points
        x = center[0] + radius * math.cos(angle)
        y = center[1] + radius * math.sin(angle)
        z = center[2]
        
        bpy.ops.paintcurve.add(location=(x, y, z))
    
    bpy.ops.paintcurve.close()
    
    return curve

def create_spiral_stroke(name, center, max_radius, turns, points_per_turn):
    """创建螺旋笔触曲线"""
    import math
    
    bpy.ops.paintcurve.new(name=name)
    curve = bpy.context.active_object
    
    total_points = turns * points_per_turn
    
    for i in range(total_points):
        angle = (2 * math.pi * i) / points_per_turn
        radius = (max_radius * i) / total_points
        
        x = center[0] + radius * math.cos(angle)
        y = center[1] + radius * math.sin(angle)
        z = center[2]
        
        bpy.ops.paintcurve.add(location=(x, y, z))
    
    bpy.ops.paintcurve.close()
    
    return curve
```

## 常见问题排查

### 笔触曲线不可见
```python
# 检查曲线是否存在
print(f"笔触曲线数: {len(bpy.data.paint_curves)}")

# 检查活动曲线
print(f"活动曲线: {bpy.context.active_object}")

# 检查显示设置
curve = bpy.context.active_object
print(f"显示: {curve.show_viewport}")
print(f"渲染: {curve.show_render}")

# 启用显示
curve.show_viewport = True
curve.show_render = True

# 检查点数量
print(f"点数: {len(curve.data.points)}")
```

### 点无法选择
```python
# 检查选择模式
print(f"选择模式: {bpy.context.tool_settings.select_mode}")

# 重置选择
bpy.ops.paintcurve.select_all(action='DESELECT')

# 切换到点选择模式
bpy.ops.paintcurve.select_mode(type='POINT')

# 检查点是否被锁定
for point in curve.data.points:
    print(f"锁定: {point.lock}")
```

### 曲线编辑无效果
```python
# 检查曲线数据
curve = bpy.context.active_object
print(f"点数: {len(curve.data.points)}")
print(f"段数: {len(curve.data.splines)}")

# 重新创建曲线
bpy.ops.paintcurve.new(name='NewCurve')

# 清除历史
bpy.ops.paintcurve.clear()

# 检查曲线类型
print(f"曲线类型: {curve.data.splines[0].type if curve.data.splines else 'N/A'}")
```
