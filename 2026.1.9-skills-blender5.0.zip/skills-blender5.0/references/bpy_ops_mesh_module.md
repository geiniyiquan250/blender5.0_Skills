# bpy.ops.mesh - Mesh Operations Module

Blender 网格操作符，用于在编辑模式下进行网格顶点的创建、编辑、变换和管理。

## Overview

`bpy.ops.mesh` 模块包含网格编辑器中的所有操作命令，涵盖顶点、边、面的选择、创建、删除、变换等核心功能。这个模块主要用于编辑模式下的网格建模操作。

## 核心功能

### 网格选择操作

```python
import bpy

# 全选
bpy.ops.mesh.select_all(action='SELECT')

# 全不选
bpy.ops.mesh.select_all(action='DESELECT')

# 反选
bpy.ops.mesh.select_all(action='INVERT')

# 选择更多
bpy.ops.mesh.select_more(use_face_step=True)

# 选择更少
bpy.ops.mesh.select_less(use_face_step=True)

# 选择相似
bpy.ops.mesh.select_similar(type='COPLANAR', threshold=0.01)
bpy.ops.mesh.select_similar(type='NORMAL', threshold=0.01)
bpy.ops.mesh.select_similar(type='MATERIAL', threshold=0.01)
bpy.ops.mesh.select_similar(type='FACE', threshold=0.01)
bpy.ops.mesh.select_similar(type='VIRTUAL', threshold=0.01)

# 选择循环边
bpy.ops.mesh.loop_multi_select(ring=False)
bpy.ops.mesh.loop_multi_select(ring=True)

# 选择边循环
bpy.ops.mesh.edge_loop_select()
bpy.ops.mesh.select_vertex_path()

# 选择面循环
bpy.ops.mesh.faces_select_linked()

# 选择连接面
bpy.ops.mesh.select_linked()

# 边框选择
bpy.ops.mesh.select_border(gesture_mode=0, xmin=100, xmax=300, ymin=100, ymax=300)

# 圆形选择
bpy.ops.mesh.select_circle(x=200, y=200, radius=50, mode='ADD')

# 套索选择
bpy.ops.mesh.select_lasso(path=[(100, 100), (200, 100), (200, 200), (100, 200)])

# 切变选择
bpy.ops.mesh.select_mode(type='VERT')
bpy.ops.mesh.select_mode(type='EDGE')
bpy.ops.mesh.select_mode(type='FACE')

def select_all_vertices():
    """选择所有顶点"""
    bpy.ops.mesh.select_mode(type='VERT')
    bpy.ops.mesh.select_all(action='SELECT')
    return [v for v in bpy.context.active_object.data.vertices if v.select]

def select_all_edges():
    """选择所有边"""
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.select_all(action='SELECT')
    return [e for e in bpy.context.active_object.data.edges if e.select]

def select_all_faces():
    """选择所有面"""
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    return [f for f in bpy.context.active_object.data.polygons if f.select]

def deselect_all():
    """取消所有选择"""
    bpy.ops.mesh.select_all(action='DESELECT')
```

### 顶点操作

```python
# 创建顶点
bpy.ops.mesh.duplicates_extrude()

# 删除顶点
bpy.ops.mesh.delete(type='VERT')

# 合并顶点
bpy.ops.mesh.merge(type='CENTER', uvs=False)
bpy.ops.mesh.merge(type='CURSOR', uvs=False)
bpy.ops.mesh.merge(type='COLLAPSE', uvs=False)
bpy.ops.mesh.merge(type='AT_CURSOR', uvs=False)

# 细分顶点
bpy.ops.mesh.subdivide(number_cuts=1)
bpy.ops.mesh.subdivide(number_cuts=2)

# 细分边
bpy.ops.mesh.subdivide_edgeloop(number_cuts=1)

# 倒角顶点
bpy.ops.mesh.bevel_vertex(offset=0.1, segments=3)

# 极点切变
bpy.ops.mesh.poke()

# 分离顶点
bpy.ops.mesh.separate(type='SELECTED')
bpy.ops.mesh.separate(type='MATERIAL')
bpy.ops.mesh.separate(type='LOOSE')

def create_vertex(location):
    """创建顶点"""
    bpy.ops.mesh.primitive_plane_add(size=0, location=location)
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.merge(type='CENTER')

def delete_selected_vertices():
    """删除选中的顶点"""
    bpy.ops.mesh.select_mode(type='VERT')
    bpy.ops.mesh.delete(type='VERT')

def merge_vertices_to_center():
    """合并顶点到中心"""
    bpy.ops.mesh.select_mode(type='VERT')
    bpy.ops.mesh.merge(type='CENTER')

def subdivide_edges(iterations=1):
    """细分边"""
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.select_all(action='SELECT')
    for _ in range(iterations):
        bpy.ops.mesh.subdivide(number_cuts=1)

def bevel_vertex(obj, offset=0.05, segments=3):
    """倒角顶点"""
    bpy.ops.mesh.select_mode(type='VERT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.bevel_vertex(offset=offset, segments=segments)
```

### 边操作

```python
# 创建边
bpy.ops.mesh.edge_vert_add()

# 删除边
bpy.ops.mesh.delete(type='EDGE')

# 旋转边
bpy.ops.mesh.rotate_edges(edge_mode='ADJ')

# 折叠边
bpy.ops.mesh.edge_collapse()

# 细分边
bpy.ops.mesh.subdivide(number_cuts=1)

# 倒角边
bpy.ops.mesh.bevel(offset=0.02, segments=3, affect='EDGES')

# 切变边
bpy.ops.mesh.shear(angle=math.radians(45))

# 创建边环
bpy.ops.mesh.insert_loop()

# 延伸边
bpy.ops.mesh.extrude_region_move()

# 旋转边
bpy.ops.mesh.rotate()

# 标记接缝
bpy.ops.mesh.mark_seam(clear=False)
bpy.ops.mesh.mark_seam(clear=True)

# 标记锐边
bpy.ops.mesh.mark_sharp(clear=False)
bpy.ops.mesh.mark_sharp(clear=True)

# 平滑边
bpy.ops.mesh.set_edges_visible()

def create_edge_from_verts(vert1, vert2):
    """从两个顶点创建边"""
    bpy.ops.mesh.select_all(action='DESELECT')
    vert1.select = True
    vert2.select = True
    bpy.ops.mesh.edge_vert_add()

def delete_selected_edges():
    """删除选中的边"""
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.delete(type='EDGE')

def rotate_selected_edges():
    """旋转选中的边"""
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.rotate_edges(edge_mode='ADJ')

def bevel_selected_edges(offset=0.02, segments=3):
    """倒角选中的边"""
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.bevel(offset=offset, segments=segments, affect='EDGES')

def add_edge_loop(count=1):
    """添加边循环"""
    bpy.ops.mesh.select_all(action='SELECT')
    for _ in range(count):
        bpy.ops.mesh.insert_loop()

def mark_seam_selected():
    """标记接缝"""
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.mark_seam(clear=False)

def clear_seam_selected():
    """清除接缝"""
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.mark_seam(clear=True)

def mark_sharp_selected():
    """标记锐边"""
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.mark_sharp(clear=False)

def clear_sharp_selected():
    """清除锐边"""
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.mark_sharp(clear=True)
```

### 面操作

```python
# 创建面
bpy.ops.mesh.fill()

# 删除面
bpy.ops.mesh.delete(type='FACE')

# 三角化面
bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')

# 三角面转四边面
bpy.ops.mesh.tris_convert_to_quads(limit_mode='ANGLE', angle_limit=math.radians(40))

# 重新三角化
bpy.ops.mesh.recalc_face_normals()

# 翻转法线
bpy.ops.mesh.flip_normals()

# 分离面
bpy.ops.mesh.split()

# 填充孔洞
bpy.ops.mesh.fill_holes(sides=4)

# 凸包
bpy.ops.mesh.convex_hull()

# 内部面
bpy.ops.mesh.select_non_manifold(extend=True)

# 溶解面
bpy.ops.mesh.dissolve_faces(use_verts=True, use_face_split=True)

# 三角化
bpy.ops.mesh.primitive_triangulate()

def create_face_from_vertices(vertices):
    """从顶点创建面"""
    bpy.ops.mesh.select_all(action='DESELECT')
    for v in vertices:
        v.select = True
    bpy.ops.mesh.fill()

def delete_selected_faces():
    """删除选中的面"""
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.delete(type='FACE')

def triangulate_faces():
    """三角化所有面"""
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.quads_convert_to_tris()

def quads_convert_from_tris():
    """三角面转四边面"""
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.tris_convert_to_quads()

def flip_normals_selected():
    """翻转选中面的法线"""
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.flip_normals()

def fill_holes(max_sides=4):
    """填充孔洞"""
    bpy.ops.mesh.fill_holes(sides=max_sides)

def dissolve_selected_faces():
    """溶解选中的面"""
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.dissolve_faces()

def select_non_manifold():
    """选择非流形几何"""
    bpy.ops.mesh.select_non_manifold(extend=True)
```

### 网格变换操作

```python
# 挤出
bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": (0, 0, 1)})
bpy.ops.mesh.extrude_region_shrink_fatten(
    TRANSFORM_OT_shrink_fatten={"value": 0.1, "use_even_offset": True}
)

# 挤出个别
bpy.ops.mesh.extrude_vertex_move()
bpy.ops.mesh.extrude_edge_move()
bpy.ops.mesh.extrude_face_move()

# 旋转
bpy.ops.mesh.rotate(angle=math.radians(45))

# 缩放
bpy.ops.mesh.scale(scale_factor=0.5)

# 切变
bpy.ops.mesh.shear(angle=math.radians(45))

# 弯曲
bpy.ops.mesh.bend(angle=math.radians(90))

# 推拉
bpy.ops.mesh.push_pull(value=0.5)

# 球形化
bpy.ops.mesh.spherize(factor=1.0)

# 变形
bpy.ops.mesh.deform(calc_length=True)

# 平滑
bpy.ops.mesh.vertices_smooth(factor=0.5, repeat=1)
bpy.ops.mesh.laplacian_smooth(factor=0.5, repeat=1)

def extrude_region(axis='Z', distance=1.0):
    """挤出区域"""
    if axis == 'X':
        bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": (distance, 0, 0)})
    elif axis == 'Y':
        bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": (0, distance, 0)})
    elif axis == 'Z':
        bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": (0, 0, distance)})

def extrude_individual():
    """挤出个别面"""
    bpy.ops.mesh.extrude_face_move()

def scale_selected(factor):
    """缩放选中的元素"""
    bpy.ops.transform.resize(value=(factor, factor, factor))

def rotate_selected(angle, axis='Z'):
    """旋转选中的元素"""
    bpy.ops.transform.rotate(value=angle, orient_axis=axis)

def smooth_vertices(iterations=1, factor=0.5):
    """平滑顶点"""
    for _ in range(iterations):
        bpy.ops.mesh.vertices_smooth(factor=factor)

def spherize(factor=1.0):
    """球形化"""
    bpy.ops.mesh.spherize(factor=factor)

def push_pull(value=0.5):
    """推拉"""
    bpy.ops.mesh.push_pull(value=value)

def shear_mesh(angle=math.radians(45), direction=(1, 0, 0)):
    """切变网格"""
    bpy.ops.mesh.shear(angle=angle)
```

### 网格编辑操作

```python
# 细分
bpy.ops.mesh.subdivide(number_cuts=1, use_grid_fill=True)

# 切割
bpy.ops.mesh.knife_tool(confirm=True)
bpy.ops.mesh.knife_select(extend=False, deselect=False, select=True)

# 循环切割
bpy.ops.mesh.loopcut_slide(
    TRANSFORM_OT_edge_slide={"value": 0},
    MESH_OT_loopcut={"number_cuts": 1, "smoothness": 0, "falloff": 'INVERSE_SQUARE', "object_index": 0, "edge_index": 0}
)

# 滑移边
bpy.ops.mesh.edge_slide(TRANSFORM_OT_edge_slide={"value": 0})

# 滑移顶点
bpy.ops.mesh.vert_slide(TRANSFORM_OT_vert_slide={"value": 0})

# 对称
bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')

# 移除三角形
bpy.ops.mesh.dissolve_degenerate(threshold=0.001)

# 移除边线
bpy.ops.mesh.dissolve_limited(angle_limit=math.radians(5))

# 有限溶解
bpy.ops.mesh.dissolve_limit(angle_limit=math.radians(5), use_dissolve_boundaries=False)

# 溶解顶点
bpy.ops.mesh.dissolve_verts(use_verts=True, use_face_split=True)

def subdivide_mesh(levels=1):
    """细分网格"""
    bpy.ops.mesh.select_all(action='SELECT')
    for _ in range(levels):
        bpy.ops.mesh.subdivide(number_cuts=1)

def cut_mesh(start, end, direction=(0, 0, 1)):
    """切割网格"""
    bpy.ops.mesh.knife_tool(confirm=True)

def add_loop_cuts(count=1):
    """添加循环切割"""
    bpy.ops.mesh.loopcut_slide(
        MESH_OT_loopcut={"number_cuts": count, "smoothness": 0}
    )

def slide_edge(value=0.5):
    """滑移边"""
    bpy.ops.mesh.edge_slide(TRANSFORM_OT_edge_slide={"value": value})

def symmetrize_mesh(direction='NEGATIVE_X'):
    """对称网格"""
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.symmetrize(direction=direction)

def dissolve_degenerate(threshold=0.001):
    """溶解退化几何"""
    bpy.ops.mesh.dissolve_degenerate(threshold=threshold)

def dissolve_limited(angle_limit=math.radians(5)):
    """有限溶解"""
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.dissolve_limited(angle_limit=angle_limit)
```

### 网格清理操作

```python
# 填充三角面
bpy.ops.mesh.fill_triangles()

# 移除双面
bpy.ops.mesh.decimate(ratio=0.5)

# 重投影
bpy.ops.mesh.project_paint(stroke=None)

# 重新映射 UV
bpy.ops.mesh.uvs_resize()

# 重新计算法线
bpy.ops.mesh.normals_make_consistent(inside=False)

def decimate_mesh(ratio=0.5):
    """精简网格"""
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.decimate(ratio=ratio)

def recalculate_normals():
    """重新计算法线"""
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.normals_make_consistent(inside=False)

def make_normals_consistent(inside=False):
    """使法线一致"""
    bpy.ops.mesh.normals_make_consistent(inside=inside)

def remove_doubles(threshold=0.0001):
    """移除重复顶点"""
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles(threshold=threshold)

def intersect_faces():
    """相交面"""
    bpy.ops.mesh.intersect(mode='SELECT_UNSELECT')

def intersect_faces_selected():
    """相交选中面"""
    bpy.ops.mesh.intersect(mode='SELECT')

def boolean_operation(operation='DIFFERENCE'):
    """布尔运算"""
    bpy.ops.mesh.boolean(operation=operation)
```

## 实用网格操作

### 网格创建工具

```python
import bpy
import math

def create_grid(x_subdivisions=10, y_subdivisions=10, size=2):
    """创建网格"""
    bpy.ops.mesh.primitive_grid_add(x_subdivisions=x_subdivisions, y_subdivisions=y_subdivisions, size=size)
    return bpy.context.active_object

def create_circle(vertices=32, radius=1, fill_type='NOTHING'):
    """创建圆环"""
    bpy.ops.mesh.primitive_circle_add(vertices=vertices, radius=radius, fill_type=fill_type)
    return bpy.context.active_object

def create_cone(vertices=32, radius1=1, radius2=0, depth=2):
    """创建圆锥"""
    bpy.ops.mesh.primitive_cone_add(vertices=vertices, radius1=radius1, radius2=radius2, depth=depth)
    return bpy.context.active_object

def create_torus(major_segments=48, minor_segments=12, major_radius=1, minor_radius=0.25):
    """创建圆环"""
    bpy.ops.mesh.primitive_torus_add(major_segments=major_segments, minor_segments=minor_segments, 
                                     major_radius=major_radius, minor_radius=minor_radius)
    return bpy.context.active_object

def create_ico_sphere(subdivisions=2, radius=1):
    """创建二十面球体"""
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=subdivisions, radius=radius)
    return bpy.context.active_object

def create_suzanne():
    """创建猴子"""
    bpy.ops.mesh.primitive_monkey_add()
    return bpy.context.active_object
```

### 网格变换工具

```python
def extrude_mesh(obj, direction=(0, 0, 1), distance=1.0, steps=1):
    """挤出网格"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    
    bpy.ops.mesh.select_all(action='SELECT')
    for i in range(steps):
        offset = (direction[0] * distance / steps, direction[1] * distance / steps, direction[2] * distance / steps)
        bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": offset})
    
    bpy.ops.object.mode_set(mode='OBJECT')

def create_array(obj, count=5, offset=(1, 0, 0), axis='X'):
    """创建阵列"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    objects = [obj]
    for i in range(1, count):
        bpy.ops.object.duplicate()
        new_obj = bpy.context.active_object
        
        if axis == 'X':
            new_obj.location.x = obj.location.x + offset[0] * i
        elif axis == 'Y':
            new_obj.location.y = obj.location.y + offset[1] * i
        elif axis == 'Z':
            new_obj.location.z = obj.location.z + offset[2] * i
        
        objects.append(new_obj)
    
    return objects

def create_radial_array(obj, count=8, angle=360):
    """创建环形阵列"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    objects = [obj]
    angle_step = math.radians(angle / count)
    
    for i in range(1, count):
        bpy.ops.object.duplicate()
        new_obj = bpy.context.active_object
        new_obj.rotation_euler.z += angle_step * i
        objects.append(new_obj)
    
    return objects

def create_staircase(obj, steps=10, rise=0.2, tread=0.3):
    """创建楼梯"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    
    for i in range(steps):
        offset = (tread * i, 0, rise * i)
        bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value": offset})
    
    bpy.ops.object.mode_set(mode='OBJECT')
```

### 网格修饰器应用

```python
def apply_subdivision(obj, levels=2):
    """应用细分修饰器"""
    modifier = obj.modifiers.new(name="Subdivision", type='SUBSURF')
    modifier.levels = levels
    modifier.render_levels = levels
    bpy.ops.object.modifier_apply(modifier="Subdivision")

def apply_array(obj, offset=(1, 0, 0)):
    """应用数组修饰器"""
    modifier = obj.modifiers.new(name="Array", type='ARRAY')
    modifier.count = 5
    modifier.relative_offset_displace = (offset[0], offset[1], offset[2])
    bpy.ops.object.modifier_apply(modifier="Array")

def apply_bevel(obj, width=0.1):
    """应用倒角修饰器"""
    modifier = obj.modifiers.new(name="Bevel", type='BEVEL')
    modifier.width = width
    modifier.segments = 3
    bpy.ops.object.modifier_apply(modifier="Bevel")

def apply_solidify(obj, thickness=0.1):
    """应用实体化修饰器"""
    modifier = obj.modifiers.new(name="Solidify", type='SOLIDIFY')
    modifier.thickness = thickness
    bpy.ops.object.modifier_apply(modifier="Solidify")

def apply_decimate(obj, ratio=0.5):
    """应用精简修饰器"""
    modifier = obj.modifiers.new(name="Decimate", type='DECIMATE')
    modifier.ratio = ratio
    bpy.ops.object.modifier_apply(modifier="Decimate")
```

## 网格工程面板

```python
class MeshEngineeringPanel(bpy.types.Panel):
    """网格工程面板"""
    bl_label = "网格工具"
    bl_idname = "MESH_PT_engineering_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '网格'
    
    def draw(self, context):
        layout = self.layout
        obj = context.object
        
        if not obj or obj.type != 'MESH':
            layout.label(text="请选择网格对象")
            return
        
        layout.label(text="选择:")
        
        row = layout.row(align=True)
        row.operator("mesh.select_all", text="全选").action='SELECT'
        row.operator("mesh.select_all", text="反选").action='INVERT'
        
        row = layout.row()
        row.operator("mesh.select_more", text="更多")
        row.operator("mesh.select_less", text="更少")
        
        row = layout.row()
        row.operator("mesh.select_similar", text="相似").type='NORMAL'
        
        layout.separator()
        layout.label(text="编辑:")
        
        row = layout.row(align=True)
        row.operator("mesh.subdivide", text="细分").number_cuts=1
        row.operator("mesh.merge", text="合并").type='CENTER'
        
        row = layout.row()
        row.operator("mesh.delete", text="删除顶点").type='VERT'
        row.operator("mesh.delete", text="删除边").type='EDGE'
        row.operator("mesh.delete", text="删除面").type='FACE'
        
        row = layout.row()
        row.operator("mesh.bevel", text="倒角").offset=0.02
        row.operator("mesh.bevel_vertex", text="顶点倒角").offset=0.02
        
        layout.separator()
        layout.label(text="变换:")
        
        row = layout.row()
        row.operator("mesh.extrude_region_move", text="挤出")
        row.operator("mesh.inset", text="内缩")
        
        row = layout.row()
        row.operator("mesh.loopcut_slide", text="循环切割")
        row.operator("mesh.knife_tool", text="切割")
        
        layout.separator()
        layout.label(text="清理:")
        
        row = layout.row()
        row.operator("mesh.tris_convert_to_quads", text="转四边")
        row.operator("mesh.quads_convert_to_tris", text="转三角")
        
        row = layout.row()
        row.operator("mesh.dissolve_degenerate", text="清除退化")
        row.operator("mesh.remove_doubles", text="移除重复")
        
        row = layout.row()
        row.operator("mesh.normals_make_consistent", text="法线一致")
        row.operator("mesh.fill_holes", text="填充孔洞")
```

## 最佳实践

### 1. 网格优化

```python
def optimize_mesh(obj, threshold=0.0001):
    """优化网格"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles(threshold=threshold)
    
    bpy.ops.mesh.dissolve_degenerate(threshold=threshold)
    
    bpy.ops.object.mode_set(mode='OBJECT')

def triangulate_all():
    """三角化所有面"""
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.quads_convert_to_tris()

def quadrize_all():
    """四边化所有面"""
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.tris_convert_to_quads()

def clean_non_manifold():
    """清理非流形几何"""
    bpy.ops.mesh.select_non_manifold(extend=True)
    bpy.ops.mesh.delete(type='VERT')
```

### 2. 网格验证

```python
def validate_mesh(obj):
    """验证网格"""
    issues = []
    mesh = obj.data
    
    # 检查孤立顶点
    for v in mesh.vertices:
        if not v.select:
            continue
        connected = False
        for edge in mesh.edges:
            if v.index in edge.vertices:
                connected = True
                break
        if not connected:
            issues.append(f"顶点 {v.index} 是孤立的")
    
    # 检查双面
    for poly in mesh.polygons:
        if len(poly.vertices) < 3:
            issues.append(f"面 {poly.index} 顶点数不足")
    
    # 检查法线
    for poly in mesh.polygons:
        if poly.normal.length < 0.001:
            issues.append(f"面 {poly.index} 法线异常")
    
    return issues

def check_topology():
    """检查拓扑"""
    obj = bpy.context.active_object
    if not obj or obj.type != 'MESH':
        return
    
    mesh = obj.data
    
    # 计算统计数据
    vertex_count = len(mesh.vertices)
    edge_count = len(mesh.edges)
    face_count = len(mesh.polygons)
    
    print(f"顶点数: {vertex_count}")
    print(f"边数: {edge_count}")
    print(f"面数: {face_count}")
    
    # 检查拓扑是否合理
    expected_edges = vertex_count * 3 - 3
    if edge_count > expected_edges * 1.5:
        print("警告: 边数可能过多")
```

### 3. 网格备份

```python
def backup_mesh(obj):
    """备份网格数据"""
    return obj.data.copy()

def restore_mesh(obj, backup):
    """恢复网格数据"""
    obj.data = backup
```

## 常见问题

### Q: 无法选择顶点
A: 确保在编辑模式下，选择模式设置为顶点。

### Q: 细分后网格变形
A: 检查法线方向，确保网格是封闭的。

### Q: 布尔运算失败
A: 确保网格是有效的，尝试修复法线和移除重复顶点。

### Q: 网格有破面
A: 使用修复非流形几何功能，检查网格连通性。

## 相关模块

- [bpy.ops.object](bpy_ops_object_module.md) - 对象操作
- [bpy.ops.curve](bpy_ops_curve_module.md) - 曲线操作
- [bmesh.types](bmesh_types_detailed_module.md) - BMesh 类型
- [bpy.types](bpy_types_detailed_module.md) - 数据类型
