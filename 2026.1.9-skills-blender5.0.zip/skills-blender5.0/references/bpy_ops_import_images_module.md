# bpy.ops.import_images - 图像导入操作模块

Blender图像导入操作符，用于将图像和图像序列导入到Blender中。

## 概述

`bpy.ops.import_images` 模块提供用于将图像文件导入Blender的功能，支持单个图像、图像序列和图像平面创建。

## 核心功能

### 基础图像导入

```python
import bpy

# 导入单个图像
bpy.ops.import_images.as_planes(
    filepath='//texture.png',
    files=[{'name': 'texture.png'}],
    directory='//',
    filter_blender=False,
    filter_image=True,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    align='CURSOR'
)

# 导入图像序列
bpy.ops.import_images.as_planes(
    filepath='//frame_',
    files=[{'name': 'frame_001.png'}, {'name': 'frame_002.png'}],
    directory='//',
    filter_blender=False,
    filter_image=True,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    align='CURSOR',
    sequence=True
)
```

### 图像平面设置

```python
# 创建图像平面
bpy.ops.import_images.as_planes(
    filepath='//image.png',
    files=[{'name': 'image.png'}],
    directory='//',
    filter_blender=False,
    filter_image=True,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    align='WORLD',
    scale=1.0,
    height=1.0
)

# 设置平面大小
bpy.ops.import_images.as_planes(
    filepath='//image.png',
    height=2.0
)

# 设置平面缩放
bpy.ops.import_images.as_planes(
    filepath='//image.png',
    scale=0.5
)
```

### 对齐方式

```python
# 光标对齐
bpy.ops.import_images.as_planes(
    filepath='//image.png',
    align='CURSOR'
)

# 世界中心对齐
bpy.ops.import_images.as_planes(
    filepath='//image.png',
    align='WORLD'
)

# 不对齐
bpy.ops.import_images.as_planes(
    filepath='//image.png',
    align='NONE'
)
```

### 序列帧导入

```python
# 启用序列
bpy.ops.import_images.as_planes(
    filepath='//frame_',
    files=[{'name': 'frame_001.png'}],
    directory='//',
    sequence=True
)

# 禁用序列
bpy.ops.import_images.as_planes(
    filepath='//image.png',
    sequence=False
)

# 批量导入序列
bpy.ops.import_images.as_planes(
    filepath='//render_',
    files=[{'name': f'render_{i:04d}.png' for i in range(1, 101)}],
    directory='//render/',
    sequence=True
)
```

### 图像序列播放器

```python
# 打开图像序列
bpy.ops.sequencer.images(
    filepath='//frame_',
    files=[{'name': 'frame_001.png'}],
    directory='//',
    filter_blender=False,
    filter_image=True,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False
)

# 导入到VSE
bpy.ops.sequencer.images(
    filepath='//animation_',
    files=[{'name': f'frame_{i:04d}.png' for i in range(1, 251)}],
    directory='//',
    filter_blender=False,
    filter_image=True,
    use_placeholders=True
)
```

## 实用函数

```python
def import_image_plane(image_path, height=1.0, scale=1.0):
    """导入图像为平面"""
    bpy.ops.import_images.as_planes(
        filepath=image_path,
        files=[{'name': bpy.path.basename(image_path)}],
        directory=bpy.path.dirname(image_path),
        align='WORLD',
        height=height,
        scale=scale
    )
    return bpy.context.active_object

def import_image_sequence(base_path, start_frame, end_frame, height=1.0):
    """导入图像序列"""
    files = [{'name': f'{base_path}{i:04d}.png'} for i in range(start_frame, end_frame + 1)]
    directory = bpy.path.dirname(base_path)
    
    bpy.ops.import_images.as_planes(
        filepath=base_path,
        files=files,
        directory=directory,
        align='WORLD',
        height=height,
        sequence=True
    )
    return list(bpy.context.selected_objects)

def import_all_images_from_directory(directory, height=1.0):
    """导入目录下所有图像"""
    import os
    
    image_files = [f for f in os.listdir(directory) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tif', '.tiff', '.exr'))]
    image_files.sort()
    
    if image_files:
        bpy.ops.import_images.as_planes(
            filepath=os.path.join(directory, image_files[0]),
            files=[{'name': f} for f in image_files],
            directory=directory,
            align='WORLD',
            height=height
        )
    
    return list(bpy.context.selected_objects)

def create_background_plate(image_path, location=(0, 0, 0)):
    """创建背景板"""
    plane = import_image_plane(image_path, height=10.0)
    plane.location = location
    plane.rotation_euler = (0, 0, 0)
    return plane

def create_reference_image(image_path, scale_factor=1.0):
    """创建参考图像"""
    bpy.ops.import_images.as_planes(
        filepath=image_path,
        files=[{'name': bpy.path.basename(image_path)}],
        directory=bpy.path.dirname(image_path),
        align='WORLD',
        scale=scale_factor
    )
    ref = bpy.context.active_object
    ref.name = 'Reference'
    ref.display_type = 'WIRE'
    return ref

def batch_import_planes(image_paths, spacing=1.5):
    """批量导入为平面"""
    planes = []
    for i, path in enumerate(image_paths):
        plane = import_image_plane(path, height=1.0)
        plane.location.x = i * spacing
        planes.append(plane)
    return planes

def import_skybox_images(base_path, ext='.png'):
    """导入天空盒图像"""
    faces = ['px', 'nx', 'py', 'ny', 'pz', 'nz']
    planes = []
    
    for face in faces:
        image_path = f'{base_path}_{face}{ext}'
        if bpy.path.exists(image_path):
            plane = import_image_plane(image_path, height=10.0)
            planes.append(plane)
    
    return planes
```

## 常见问题排查

### 图像不显示
```python
# 检查文件路径
filepath = '//texture.png'
print(f"文件存在: {bpy.path.exists(filepath)}")

# 检查目录
directory = '//'
print(f"目录存在: {bpy.path.exists(directory)}")

# 检查图像数据
print(f"图像数: {len(bpy.data.images)}")

# 重新加载图像
img = bpy.data.images.get('texture.png')
if img:
    img.reload()
```

### 平面大小不对
```python
# 检查导入的平面
plane = bpy.context.active_object
print(f"平面大小: {plane.dimensions}")

# 设置正确大小
bpy.ops.transform.resize(value=(1, 1, 1))
plane.scale = (1, 1, 1)

# 重新导入
bpy.ops.import_images.as_planes(
    filepath='//image.png',
    height=1.0,
    scale=1.0
)
```

### 图像序列不对齐
```python
# 检查序列设置
print(f"帧范围: {bpy.context.scene.frame_start} - {bpy.context.scene.frame_end}")

# 设置正确的帧范围
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = 100

# 检查帧速率
print(f"帧速率: {bpy.context.scene.render.fps}")

# 重新排列序列
for strip in bpy.context.scene.sequence_editor.sequences:
    if strip.type == 'IMAGE':
        print(f"条带: {strip.name}, 帧偏移: {strip.frame_offset}")
```

### 颜色空间问题
```python
# 检查颜色空间
img = bpy.data.images.get('image.png')
if img:
    print(f"颜色空间: {img.colorspace_settings.name}")

# 设置颜色空间
img.colorspace_settings.name = 'sRGB'
img.colorspace_settings.name = 'Linear'

# 对于线性工作流
img.colorspace_settings.name = 'Linear'
```
