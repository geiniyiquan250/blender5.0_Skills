# bpy.ops.font - Font Operations Module

Blender 字体操作符，用于创建和编辑文本对象。

## Overview

`bpy.ops.font` 模块包含文本对象（Text Object）的所有操作命令，涵盖文本的创建、编辑、样式设置等功能。这个模块主要用于处理 Blender 中的 3D 文字对象。

## 核心功能

### 文本对象创建

```python
import bpy

# 创建文本对象
bpy.ops.object.text_add(location=(0, 0, 0))
text_obj = bpy.context.active_object
text_obj.data.body = "Hello World"

# 创建内联文本对象
bpy.ops.font.text_add(text="New Text", cursor=0)

# 在光标处插入文本
bpy.ops.font.insert(text=" inserted text")

# 打开文本文件
bpy.ops.font.open(filepath="C:/fonts/text.txt")

# 替换选中的文本
bpy.ops.font.replace(replace="replacement text")
```

### 文本编辑操作

```python
# 选择所有文本
bpy.ops.font.select_all(select='SELECT')

# 全不选
bpy.ops.font.select_all(select='DESELECT')

# 移动光标
bpy.ops.font.move(type='LINE_BEGIN')
bpy.ops.font.move(type='LINE_END')
bpy.ops.font.move(type='PREVIOUS_CHARACTER')
bpy.ops.font.move(type='NEXT_CHARACTER')
bpy.ops.font.move(type='PREVIOUS_WORD')
bpy.ops.font.move(type='NEXT_WORD')
bpy.ops.font.move(type='PREVIOUS_LINE')
bpy.ops.font.move(type='NEXT_LINE')

# 删除
bpy.ops.font.delete(type='DELETE')
bpy.ops.font.delete(type='BACKSPACE')
bpy.ops.font.delete(type='WORD_DELETE')

# 剪切/复制/粘贴
bpy.ops.font.cut()
bpy.ops.font.copy()
bpy.ops.font.paste()
```

### 文本样式设置

```python
# 设置字体
bpy.ops.font.font_select.invoke()

# 设置字体大小
text_obj.data.size = 1.0

# 设置行距
text_obj.data.line_height = 1.5

# 设置字间距
text_obj.data.space_character = 0.2

# 设置单词间距
text_obj.data.space_word = 0.5

# 设置段落缩进
text_obj.data.tab_width = 1.0

# 设置对齐方式
text_obj.data.align_x = 'LEFT'  # LEFT, CENTER, RIGHT, JUSTIFY, FLUSH
text_obj.data.align_y = 'TOP'   # TOP, MIDDLE, BOTTOM

# 设置自动换行
text_obj.data.wrap_width = 0.0  # 0 为禁用

# 设置粗体
text_obj.data.font = bold_font
text_obj.data.bold_font = bold_font

# 设置斜体
text_obj.data.italic_font = italic_font
text_obj.data.shear = 0.2

# 设置下划线
text_obj.data.underline_position = -0.1
text_obj.data.underline_height = 0.02
```

### 文本效果

```python
# 设置阴影
text_obj.data.shadow = True
text_obj.data.shadow_offset_x = 0.05
text_obj.data.shadow_offset_y = -0.05
text_obj.data.shadow_color = (0, 0, 0, 0.5)

# 设置轮廓
text_obj.data.outline = True
text_obj.data.outline_width = 0.02
text_obj.data.outline_color = (1, 1, 1, 1)

# 设置模糊
text_obj.data.blur_radius = 0.0
```

## 实际应用示例

### 文本生成器

```python
import bpy
import os

class TextGenerator:
    """文本生成器"""
    
    def __init__(self):
        self.default_size = 1.0
        self.default_depth = 0.0
        self.default_resolution = 12
    
    def create_text(self, text, location=(0, 0, 0), size=1.0, depth=0.0):
        """创建 3D 文本"""
        bpy.ops.object.text_add(location=location)
        text_obj = bpy.context.active_object
        
        # 设置文本内容
        text_obj.data.body = text
        
        # 设置大小
        text_obj.data.size = size
        
        # 设置挤出深度
        text_obj.data.extrude = depth
        
        # 设置分辨率
        text_obj.data.resolution_u = self.default_resolution
        text_obj.data.bevel_resolution = self.default_resolution
        
        return text_obj
    
    def create_3d_title(self, text, location=(0, 0, 0)):
        """创建 3D 标题"""
        title = self.create_text(text, location=location, size=1.0, depth=0.1)
        title.name = "Title"
        return title
    
    def create_subtitle(self, text, location=(0, -1, 0)):
        """创建副标题"""
        subtitle = self.create_text(text, location=location, size=0.5, depth=0.05)
        subtitle.name = "Subtitle"
        return subtitle
    
    def create_styled_text(self, text, location=(0, 0, 0), 
                           size=1.0, depth=0.1,
                           bold=False, italic=False,
                           shadow=True, outline=False):
        """创建样式化文本"""
        text_obj = self.create_text(text, location=location, size=size, depth=depth)
        
        # 设置阴影
        if shadow:
            text_obj.data.shadow = True
            text_obj.data.shadow_offset_x = 0.02
            text_obj.data.shadow_offset_y = -0.02
            text_obj.data.shadow_color = (0, 0, 0, 0.8)
        
        # 设置轮廓
        if outline:
            text_obj.data.outline = True
            text_obj.data.outline_width = 0.01
            text_obj.data.outline_color = (1, 1, 1, 1)
        
        return text_obj
    
    def create_multiline_text(self, lines, location=(0, 0, 0), size=1.0):
        """创建多行文本"""
        text = '\n'.join(lines)
        text_obj = self.create_text(text, location=location, size=size)
        text_obj.data.align_x = 'CENTER'
        return text_obj


def create_styled_title_scene(title, subtitle):
    """创建标题场景"""
    generator = TextGenerator()
    
    # 主标题
    main_title = generator.create_3d_title(
        title,
        location=(0, 0, 0)
    )
    
    # 副标题
    sub = generator.create_subtitle(
        subtitle,
        location=(0, -1.2, 0)
    )
    
    # 添加材质
    for obj in [main_title, sub]:
        if obj.data.materials:
            mat = obj.data.materials[0]
        else:
            mat = bpy.data.materials.new(name=f"{obj.name}_Material")
            obj.data.materials.append(mat)
        
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        principled = nodes.get('Principled BSDF')
        if principled:
            principled.inputs['Base Color'].default_value = (1, 1, 1, 1)
            principled.inputs['Metallic'].default_value = 0.3
            principled.inputs['Roughness'].default_value = 0.4
    
    return main_title, sub
```

### 标题动画系统

```python
import bpy

class TitleAnimationSystem:
    """标题动画系统"""
    
    def __init__(self):
        self.frame_rate = bpy.context.scene.render.fps
    
    def animate_text_appearance(self, text_obj, start_frame, duration=30):
        """动画：文字出现效果"""
        # 缩放动画
        text_obj.scale = (0, 0, 0)
        text_obj.keyframe_insert(data_path='scale', frame=start_frame)
        
        text_obj.scale = (1, 1, 1)
        text_obj.keyframe_insert(data_path='scale', frame=start_frame + duration)
        
        # 旋转动画
        text_obj.rotation_euler = (0, 0, -0.5)
        text_obj.keyframe_insert(data_path='rotation_euler', frame=start_frame)
        
        text_obj.rotation_euler = (0, 0, 0)
        text_obj.keyframe_insert(data_path='rotation_euler', frame=start_frame + duration)
    
    def animate_text_wave(self, text_obj, start_frame, duration=60):
        """动画：波浪效果"""
        for i in range(len(text_obj.data.body)):
            char_index = text_obj.data.body.index(text_obj.data.body[i]) if i > 0 else 0
            # 注意：逐字符动画需要更复杂的实现
            pass
    
    def animate_letter_by_letter(self, text_obj, start_frame, letter_duration=5):
        """动画：逐字显示"""
        text_obj.data.body = ""
        total_duration = len(text_obj.data.body) * letter_duration
        
        for i in range(total_duration):
            frame = start_frame + i * letter_duration
            # 设置可见字符数
            # 注意：此功能需要使用表达式或驱动实现
    
    def create_typewriter_effect(self, text_obj, start_frame, char_delay=3):
        """打字机效果"""
        original_text = text_obj.data.body
        text_obj.data.body = ""
        
        for i, char in enumerate(original_text):
            text_obj.data.body += char
            text_obj.data.body_eval = text_obj.data.body  # 强制更新
            text_obj.keyframe_insert(data_path='[""]', frame=start_frame + i * char_delay)
        
        # 恢复完整文本
        text_obj.data.body = original_text
    
    def create_fade_in_out(self, text_obj, fade_in_frames=15, fade_out_frames=15, 
                          hold_frames=60, start_frame=1):
        """淡入淡出效果"""
        mat = text_obj.data.materials[0] if text_obj.data.materials else None
        if not mat or not mat.use_nodes:
            return
        
        nodes = mat.node_tree.nodes
        principled = nodes.get('Principled BSDF')
        if not principled:
            return
        
        alpha_input = principled.inputs.get('Alpha')
        if not alpha_input:
            return
        
        # 淡入
        alpha_input.default_value = 0
        alpha_input.keyframe_insert(data_path='default_value', frame=start_frame)
        alpha_input.default_value = 1
        alpha_input.keyframe_insert(data_path='default_value', frame=start_frame + fade_in_frames)
        
        # 保持
        alpha_input.default_value = 1
        alpha_input.keyframe_insert(data_path='default_value', frame=start_frame + fade_in_frames + hold_frames)
        
        # 淡出
        alpha_input.default_value = 0
        alpha_input.keyframe_insert(data_path='default_value', frame=start_frame + fade_in_frames + hold_frames + fade_out_frames)
    
    def setup_title_sequence(self, text_objects, start_frame=1):
        """设置标题序列动画"""
        current_frame = start_frame
        
        for obj in text_objects:
            duration = 30
            self.animate_text_appearance(obj, current_frame, duration=duration)
            self.create_fade_in_out(obj, start_frame=current_frame, hold_frames=30)
            current_frame += duration + 60
        
        return current_frame


def create_animated_title(title_text, subtitle_text):
    """创建带动画的标题"""
    system = TitleAnimationSystem()
    generator = TextGenerator()
    
    # 创建文本对象
    title = generator.create_styled_text(
        title_text,
        location=(0, 0, 0),
        size=1.5,
        depth=0.1,
        shadow=True
    )
    title.name = "AnimatedTitle"
    
    subtitle = generator.create_styled_text(
        subtitle_text,
        location=(0, -2, 0),
        size=0.8,
        depth=0.05,
        shadow=True
    )
    subtitle.name = "AnimatedSubtitle"
    
    # 设置动画
    system.animate_text_appearance(title, start_frame=1, duration=30)
    system.create_fade_in_out(title, start_frame=1, hold_frames=60)
    
    system.animate_text_appearance(subtitle, start_frame=60, duration=20)
    system.create_fade_in_out(subtitle, start_frame=60, hold_frames=60)
    
    return title, subtitle
```

### 文本路径工具

```python
import bpy
import math

class TextOnPathTool:
    """文本沿路径工具"""
    
    def create_text_on_curve(self, text_obj, curve_obj):
        """创建沿曲线分布的文本"""
        # 将文本添加到曲线
        text_obj.data.align_x = 'CENTER'
        
        # 创建路径约束
        constraint = text_obj.constraints.new(type='FOLLOW_PATH')
        constraint.target = curve_obj
        constraint.offset = 0
        constraint.use_curve_follow = True
        constraint.use_curve_radius = True
        
        return constraint
    
    def create_circular_text(self, text, radius=3, location=(0, 0, 0)):
        """创建圆形文本"""
        # 创建圆形曲线
        bpy.ops.mesh.primitive_circle_add(
            vertices=64,
            radius=radius,
            fill_type='NOTHING',
            location=location
        )
        curve = bpy.context.active_object
        curve.name = "TextPath"
        
        # 转换为曲线
        bpy.ops.object.convert(target='CURVE')
        
        # 创建文本
        bpy.ops.object.text_add(location=(radius, 0, 0))
        text_obj = bpy.context.active_object
        text_obj.data.body = text
        text_obj.data.size = 0.5
        text_obj.data.align_x = 'CENTER'
        
        # 设置沿路径
        constraint = text_obj.constraints.new(type='FOLLOW_PATH')
        constraint.target = curve
        constraint.use_curve_follow = True
        constraint.use_curve_radius = False
        
        # 调整方向
        text_obj.rotation_euler = (0, math.pi / 2, 0)
        
        return text_obj, curve
    
    def create_spiral_text(self, text, loops=3, height=2, radius=1):
        """创建螺旋文本"""
        # 创建螺旋曲线
        bpy.ops.curve.primitive_nurbs_path_add(radius1=radius)
        curve = bpy.context.active_object
        curve.name = "SpiralPath"
        
        curve_data = curve.data
        points = []
        
        for i in range(64):
            t = i / 63
            angle = t * loops * 2 * math.pi
            x = radius - t * radius * 0.8
            y = math.cos(angle) * x * 0.1
            z = t * height
            points.append((x, y, z))
        
        # 设置曲线点
        curve_data.splines[0].points.foreach_set('co', 
            [coord for point in points for coord in point + (1,)])
        
        # 创建文本
        bpy.ops.object.text_add(location=(0, 0, 0))
        text_obj = bpy.context.active_object
        text_obj.data.body = text
        text_obj.data.size = 0.3
        text_obj.data.align_x = 'CENTER'
        
        # 设置沿路径
        constraint = text_obj.constraints.new(type='FOLLOW_PATH')
        constraint.target = curve
        constraint.use_curve_follow = True
        constraint.offset_factor = -0.5
        
        return text_obj, curve


def create_text_scene():
    """创建文本场景"""
    tool = TextOnPathTool()
    generator = TextGenerator()
    
    # 直线标题
    title = generator.create_3d_title(
        "Blender Python",
        location=(0, 2, 0)
    )
    
    # 圆形文本
    circular_text, path = tool.create_circular_text(
        "SCRIPTING",
        radius=4,
        location=(0, 0, 0)
    )
    
    return title, circular_text, path
```

### 文本材质系统

```python
import bpy

class TextMaterialSystem:
    """文本材质系统"""
    
    materials = {}
    
    @classmethod
    def create_neon_material(cls, name, color=(0, 1, 1, 1), glow_strength=2.0):
        """创建霓虹材质"""
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        # 清除默认节点
        nodes.clear()
        
        # 创建节点
        output = nodes.new(type='ShaderNodeOutputMaterial')
        output.location = (400, 0)
        
        emission = nodes.new(type='ShaderNodeEmission')
        emission.location = (0, 0)
        emission.inputs['Color'].default_value = color
        emission.inputs['Strength'].default_value = glow_strength
        
        links.new(emission.outputs['Emission'], output.inputs['Surface'])
        
        cls.materials[name] = mat
        return mat
    
    @classmethod
    def create_metal_material(cls, name, color=(0.8, 0.8, 0.8, 1), roughness=0.3, metallic=1.0):
        """创建金属材质"""
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        
        principled = nodes.get('Principled BSDF')
        if principled:
            principled.inputs['Base Color'].default_value = color
            principled.inputs['Roughness'].default_value = roughness
            principled.inputs['Metallic'].default_value = metallic
        
        cls.materials[name] = mat
        return mat
    
    @classmethod
    def create_glass_material(cls, name, color=(1, 1, 1, 1), transmission=1.0):
        """创建玻璃材质"""
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        mat.blend_method = 'BLEND'
        nodes = mat.node_tree.nodes
        
        principled = nodes.get('Principled BSDF')
        if principled:
            principled.inputs['Base Color'].default_value = color
            principled.inputs['Transmission'].default_value = transmission
            principled.inputs['Roughness'].default_value = 0.0
            principled.inputs['IOR'].default_value = 1.45
        
        cls.materials[name] = mat
        return mat
    
    @classmethod
    def create_wood_material(cls, name, color=(0.4, 0.25, 0.1, 1)):
        """创建木质材质"""
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        principled = nodes.get('Principled BSDF')
        if principled:
            principled.inputs['Base Color'].default_value = color
            principled.inputs['Roughness'].default_value = 0.7
        
        cls.materials[name] = mat
        return mat
    
    @classmethod
    def apply_material(cls, text_obj, material_name):
        """应用材质到文本"""
        mat = cls.materials.get(material_name)
        if not mat:
            return False
        
        if not text_obj.data.materials:
            text_obj.data.materials.append(mat)
        else:
            text_obj.data.materials[0] = mat
        
        return True
    
    @classmethod
    def list_materials(cls):
        """列出所有创建的材质"""
        return list(cls.materials.keys())


def setup_text_materials():
    """设置文本材质"""
    system = TextMaterialSystem()
    
    system.create_neon_material("NeonCyan", color=(0, 1, 1, 1), glow_strength=3.0)
    system.create_neon_material("NeonPink", color=(1, 0, 1, 1), glow_strength=3.0)
    system.create_metal_material("Gold", color=(1.0, 0.8, 0.2, 1))
    system.create_metal_material("Silver", color=(0.9, 0.9, 0.9, 1))
    system.create_glass_material("Glass", color=(1, 1, 1, 0.3))
    system.create_wood_material("Wood", color=(0.4, 0.25, 0.1, 1))
    
    print("材质已创建:")
    print(system.list_materials())
    
    return system
```
