# bpy.types Reference

bpy.types 模块定义了 Blender 中所有数据类型及其属性。

## ID 基类

所有 Blender 数据块都继承自 ID 基类。

### 通用属性

```python
# 数据块名称
name = data_block.name

# 用户数量
users = data_block.users

# 是否使用假用户
use_fake_user = data_block.use_fake_user

# 数据块标签
tag = data_block.tag

# 库引用
library = data_block.library

# 是否是本地数据块
is_local = data_block.library is None

# 是否是链接数据块
is_library_indirect = data_block.library is not None
```

## Scene (场景)

场景包含所有场景数据。

```python
# 获取当前场景
scene = bpy.context.scene

# 场景属性
scene.name  # 场景名称
scene.frame_start  # 起始帧
scene.frame_end  # 结束帧
scene.frame_current  # 当前帧
scene.render  # 渲染设置
scene.camera  # 活动相机
scene.world  # 世界设置
scene.collection  # 主集合

# 遍历场景中的对象
for obj in scene.objects:
    print(obj.name)

# 获取活动对象
active_obj = scene.active_object

# 设置活动对象
scene.active_object = obj

# 更新场景
scene.update()
```

## Object (对象)

对象是 Blender 中的 3D 实体。

```python
# 获取对象
obj = bpy.context.active_object

# 对象属性
obj.name  # 对象名称
obj.type  # 对象类型 ('MESH', 'CURVE', 'ARMATURE', 等)
obj.location  # 位置
obj.rotation_euler  # 欧拉旋转
obj.rotation_quaternion  # 四元数旋转
obj.scale  # 缩放
obj.matrix_world  # 世界矩阵
obj.matrix_local  # 本地矩阵
obj.parent  # 父对象
obj.parent_type  # 父类型
obj.lock_location  # 锁定位置
obj.lock_rotation  # 锁定旋转
obj.lock_scale  # 锁定缩放
obj.hide_viewport  # 在视口中隐藏
obj.hide_render  # 在渲染中隐藏
obj.select  # 选择状态
obj.active_material  # 活动材质
obj.active_material_index  # 活动材质索引

# 对象操作
# 设置位置
obj.location = (1.0, 2.0, 3.0)

# 设置旋转
obj.rotation_euler = (0.0, 0.0, math.radians(45))

# 设置缩放
obj.scale = (2.0, 2.0, 2.0)

# 应用变换
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

# 设置父对象
obj.parent = parent_obj
obj.parent_type = 'OBJECT'

# 清除父对象
obj.parent = None

# 复制对象
new_obj = obj.copy()
bpy.context.collection.objects.link(new_obj)

# 删除对象
bpy.data.objects.remove(obj, do_unlink=True)
```

## Mesh (网格)

网格定义了对象的几何形状。

```python
# 获取网格
mesh = obj.data

# 网格属性
mesh.name  # 网格名称
mesh.vertices  # 顶点列表
mesh.edges  # 边列表
mesh.polygons  # 面列表
mesh.materials  # 材质列表
mesh.uv_layers  # UV 层
mesh.vertex_colors  # 顶点颜色
mesh.vertex_groups  # 顶点组
mesh.shape_keys  # 形状键
mesh.modifiers  # 修改器

# 遍历顶点
for vert in mesh.vertices:
    print(f"Vertex {vert.index}: {vert.co}")

# 遍历边
for edge in mesh.edges:
    print(f"Edge {edge.index}: {edge.vertices}")

# 遍历面
for poly in mesh.polygons:
    print(f"Face {poly.index}: {poly.vertices}")

# 访问顶点坐标
for vert in mesh.vertices:
    x, y, z = vert.co

# 访问面法线
for poly in mesh.polygons:
    normal = poly.normal

# 访问 UV 坐标
if mesh.uv_layers.active:
    uv_layer = mesh.uv_layers.active.data
    for poly in mesh.polygons:
        for loop_idx in poly.loop_indices:
            uv = uv_layer[loop_idx].uv
            print(f"UV: {uv.x}, {uv.y}")

# 更新网格
mesh.update()

# 重新计算法线
mesh.calc_normals()

# 重新计算切线
mesh.calc_tangents()
```

## Material (材质)

材质定义了对象的表面属性。

```python
# 创建材质
mat = bpy.data.materials.new(name="MyMaterial")

# 材质属性
mat.name  # 材质名称
mat.use_nodes  # 是否使用节点
mat.node_tree  # 节点树
mat.diffuse_color  # 漫反射颜色
mat.metallic  # 金属度
mat.roughness  # 粗糙度
mat.specular_intensity  # 镜面强度
mat.alpha  # 透明度
mat.blend_method  # 混合方法

# 使用节点
mat.use_nodes = True
nodes = mat.node_tree.nodes
links = mat.node_tree.links

# 获取输出节点
output = nodes.get("Material Output")

# 获取 BSDF 节点
bsdf = nodes.get("Principled BSDF")

# 设置颜色
bsdf.inputs['Base Color'].default_value = (1.0, 0.0, 0.0, 1.0)

# 设置金属度
bsdf.inputs['Metallic'].default_value = 1.0

# 设置粗糙度
bsdf.inputs['Roughness'].default_value = 0.5

# 将材质分配给对象
obj = bpy.context.active_object
if obj.material_slots:
    obj.material_slots[0].material = mat
else:
    obj.data.materials.append(mat)
```

## Texture (纹理)

纹理定义了图像或程序纹理。

```python
# 创建纹理
tex = bpy.data.textures.new(name="MyTexture", type='IMAGE')

# 纹理属性
tex.name  # 纹理名称
tex.type  # 纹理类型
tex.image  # 图像
tex.use_interpolation  # 使用插值
tex.use_mipmap  # 使用 mipmap
tex.extension  # 扩展方式

# 加载图像
tex.image = bpy.data.images.load(filepath="path/to/image.png")
```

## Image (图像)

图像用于纹理和渲染。

```python
# 加载图像
img = bpy.data.images.load(filepath="path/to/image.png")

# 图像属性
img.name  # 图像名称
img.filepath  # 文件路径
img.size  # 图像尺寸
img.pixels  # 像素数据
img.channels  # 通道数
img.alpha_mode  # Alpha 模式
img.colorspace_settings  # 色彩空间设置

# 创建新图像
img = bpy.data.images.new(
    name="NewImage",
    width=512,
    height=512,
    alpha=True,
    float_buffer=False
)

# 访问像素数据
pixels = img.pixels
for i in range(0, len(pixels), 4):
    r = pixels[i]
    g = pixels[i + 1]
    b = pixels[i + 2]
    a = pixels[i + 3]

# 保存图像
img.save()
```

## Camera (相机)

相机定义了视图和渲染视角。

```python
# 创建相机
cam = bpy.data.cameras.new(name="MyCamera")

# 相机属性
cam.name  # 相机名称
cam.type  # 相机类型 ('PERSP', 'ORTHO')
cam.lens  # 焦距
cam.sensor_width  # 传感器宽度
cam.sensor_height  # 传感器高度
cam.ortho_scale  # 正交缩放
cam.clip_start  # 近裁剪距离
cam.clip_end  # 远裁剪距离
cam.dof  # 景深设置

# 创建相机对象
cam_obj = bpy.data.objects.new(name="Camera", object_data=cam)
bpy.context.collection.objects.link(cam_obj)
bpy.context.scene.camera = cam_obj

# 设置相机位置
cam_obj.location = (0.0, -10.0, 2.0)
cam_obj.rotation_euler = (math.radians(90), 0.0, 0.0)
```

## Light (灯光)

灯光定义了场景中的光源。

```python
# 创建灯光
light = bpy.data.lights.new(name="MyLight", type='POINT')

# 灯光属性
light.name  # 灯光名称
light.type  # 灯光类型 ('POINT', 'SUN', 'SPOT', 'AREA')
light.color  # 灯光颜色
light.energy  # 灯光强度
light.distance  # 灯光距离
light.specular_factor  # 镜面因子
light.shadow_soft_size  # 阴影软大小

# 创建灯光对象
light_obj = bpy.data.objects.new(name="Light", object_data=light)
bpy.context.collection.objects.link(light_obj)

# 设置灯光位置
light_obj.location = (0.0, 0.0, 5.0)
```

## World (世界)

世界定义了场景的背景和环境。

```python
# 获取世界
world = bpy.context.scene.world

# 创建世界
world = bpy.data.worlds.new(name="MyWorld")
bpy.context.scene.world = world

# 世界属性
world.name  # 世界名称
world.use_nodes  # 是否使用节点
world.node_tree  # 节点树
world.color  # 背景颜色

# 使用节点
world.use_nodes = True
nodes = world.node_tree.nodes
bg_node = nodes.get("Background")
bg_node.inputs['Color'].default_value = (0.1, 0.1, 0.2, 1.0)
bg_node.inputs['Strength'].default_value = 1.0
```

## Armature (骨架)

骨架用于角色动画。

```python
# 创建骨架
arm = bpy.data.armatures.new(name="MyArmature")

# 骨架属性
arm.name  # 骨架名称
arm.display_type  # 显示类型
arm.show_names  # 显示名称

# 创建骨架对象
arm_obj = bpy.data.objects.new(name="Armature", object_data=arm)
bpy.context.collection.objects.link(arm_obj)
```

## Bone (骨骼)

骨骼是骨架的组成部分。

```python
# 获取骨骼
arm = bpy.context.active_object.data
bone = arm.bones.get("Bone")

# 骨骼属性
bone.name  # 骨骼名称
bone.head  # 头部位置
bone.tail  # 尾部位置
bone.roll  # 滚动角度
bone.parent  # 父骨骼
bone.use_connect  # 连接到父骨骼
bone.use_deform  # 是否变形
bone.hide  # 隐藏
bone.select  # 选择
bone.select_head  # 选择头部
bone.select_tail  # 选择尾部

# 设置骨骼位置
bone.head = (0.0, 0.0, 0.0)
bone.tail = (0.0, 0.0, 1.0)
```

## Curve (曲线)

曲线用于创建 2D 和 3D 曲线。

```python
# 创建曲线
curve = bpy.data.curves.new(name="MyCurve", type='CURVE')

# 曲线属性
curve.name  # 曲线名称
curve.dimensions  # 维度 ('2D', '3D')
curve.resolution_u  # U 分辨率
curve.resolution_v  # V 分辨率
curve.bevel_depth  # 倒角深度
curve.bevel_resolution  # 倒角分辨率
curve.extrude  # 挤出深度
curve.taper_radius  # 锥化半径

# 添加样条
spline = curve.splines.new(type='BEZIER')
spline.bezier_points.add(1)

# 设置点位置
spline.bezier_points[0].co = (0.0, 0.0, 0.0)
spline.bezier_points[0].handle_left = (-1.0, 0.0, 0.0)
spline.bezier_points[0].handle_right = (1.0, 0.0, 0.0)
spline.bezier_points[1].co = (2.0, 0.0, 0.0)
spline.bezier_points[1].handle_left = (1.0, 0.0, 0.0)
spline.bezier_points[1].handle_right = (3.0, 0.0, 0.0)

# 创建曲线对象
curve_obj = bpy.data.objects.new(name="Curve", object_data=curve)
bpy.context.collection.objects.link(curve_obj)
```

## Modifier (修改器)

修改器用于修改对象的几何形状。

```python
# 获取修改器
obj = bpy.context.active_object
modifier = obj.modifiers.get("MyModifier")

# 创建修改器
modifier = obj.modifiers.new(name="Subsurf", type='SUBSURF')

# 修改器类型
modifier.type  # 修改器类型

# 细分表面修改器
modifier.levels  # 细分级别
modifier.render_levels  # 渲染细分级别

# 镜像修改器
modifier.use_mirror_x  # 镜像 X 轴
modifier.use_mirror_y  # 镜像 Y 轴
modifier.use_mirror_z  # 镜像 Z 轴
modifier.use_clip  # 裁剪

# 阵列修改器
modifier.count  # 数量
modifier.relative_offset_displace  # 相对偏移
modifier.constant_offset_displace  # 常量偏移

# 倒角修改器
modifier.width  # 宽度
modifier.segments  # 段数
modifier.profile  # 轮廓

# 实体化修改器
modifier.thickness  # 厚度
modifier.offset  # 偏移

# 应用修改器
bpy.ops.object.modifier_apply(modifier=modifier.name)

# 删除修改器
obj.modifiers.remove(modifier)
```

## NodeTree (节点树)

节点树用于着色器、合成和纹理。

```python
# 获取节点树
mat = bpy.data.materials.get("MyMaterial")
node_tree = mat.node_tree

# 节点树属性
node_tree.name  # 节点树名称
node_tree.nodes  # 节点列表
node_tree.links  # 连接列表

# 创建节点
node = node_tree.nodes.new(type='ShaderNodeBsdfPrincipled')
node.location = (200, 200)

# 获取节点
node = node_tree.nodes.get("Principled BSDF")

# 节点属性
node.name  # 节点名称
node.type  # 节点类型
node.location  # 位置
node.width  # 宽度
node.height  # 高度
node.inputs  # 输入列表
node.outputs  # 输出列表

# 访问输入
input = node.inputs['Base Color']
input.default_value = (1.0, 0.0, 0.0, 1.0)

# 访问输出
output = node.outputs['BSDF']

# 连接节点
node1 = node_tree.nodes.new(type='ShaderNodeBsdfPrincipled')
node2 = node_tree.nodes.new(type='ShaderNodeOutputMaterial')
node_tree.links.new(node1.outputs['BSDF'], node2.inputs['Surface'])

# 删除节点
node_tree.nodes.remove(node)
```

## Collection (集合)

集合用于组织对象。

```python
# 创建集合
collection = bpy.data.collections.new(name="MyCollection")
bpy.context.scene.collection.children.link(collection)

# 集合属性
collection.name  # 集合名称
collection.objects  # 对象列表
collection.children  # 子集合列表
collection.hide_viewport  # 在视口中隐藏
collection.hide_render  # 在渲染中隐藏

# 添加对象到集合
collection.objects.link(obj)

# 从集合移除对象
collection.objects.unlink(obj)

# 遍历集合中的对象
for obj in collection.objects:
    print(obj.name)

# 遍历子集合
for child in collection.children:
    print(child.name)
```

## RenderSettings (渲染设置)

渲染设置控制场景的渲染。

```python
# 获取渲染设置
render = bpy.context.scene.render

# 渲染属性
render.engine  # 渲染引擎 ('BLENDER_EEVEE', 'CYCLES')
render.resolution_x  # 宽度
render.resolution_y  # 高度
render.resolution_percentage  # 分辨率百分比
render.fps  # 帧率
render.filepath  # 输出路径
render.image_settings.file_format  # 文件格式
render.image_settings.color_mode  # 颜色模式
render.image_settings.color_depth  # 颜色深度
render.film_transparent  # 透明背景
render.use_compositing  # 使用合成
render.use_sequencer  # 使用序列编辑器
```

## SpaceView3D (3D 视图空间)

3D 视图空间控制 3D 视图的显示。

```python
# 获取 3D 视图空间
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        space = area.spaces.active
        break

# 3D 视图属性
space.shading.type  # 着色类型 ('WIREFRAME', 'SOLID', 'MATERIAL', 'RENDERED')
space.shading.show_xray  # 显示 X 射线
space.shading.xray_alpha  # X 射线透明度
space.overlay.show_overlays  # 显示覆盖层
space.overlay.show_floor  # 显示地面
space.overlay.show_axis  # 显示轴
space.region_3d.view_location  # 视图位置
space.region_3d.view_rotation  # 视图旋转
space.region_3d.view_distance  # 视图距离
```

## WindowManager (窗口管理器)

窗口管理器控制 Blender 窗口。

```python
# 获取窗口管理器
wm = bpy.context.window_manager

# 窗口管理器属性
wm.windows  # 窗口列表
wm.keyconfigs  # 键配置
wm.operators  # 操作符

# 添加操作符
wm.operators.add(op_name="my.operator")

# 移除操作符
wm.operators.remove(op_name="my.operator")
```
