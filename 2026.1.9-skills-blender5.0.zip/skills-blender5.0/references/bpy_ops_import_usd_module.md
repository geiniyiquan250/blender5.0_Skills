# bpy.ops.import_scene - USD导入操作模块

Blender USD文件导入操作符，用于将USD（Universal Scene Description）格式文件导入Blender。

## 概述

`bpy.ops.import_scene.usd` 模块提供用于将USD格式文件导入Blender的功能，支持几何体、材质、动画和高级渲染设置的导入。

## 核心功能

### 基础导入

```python
import bpy

# 导入USD文件
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    directory='//',
    files=[{'name': 'model.usd'}],
    ui_tab='MAIN',
    usd_format='USD',
    import_cameras=True,
    import_lights=True,
    import_materials=True,
    import_curves=True,
    import_particles=True,
    import_procedural='NONE',
    import_subdiv=False,
    import_anim=True,
    import_anim_use_default=True,
    import_anim_range=True,
    import_assets=True,
    scale=1.0,
    import_scale=1.0,
    import_transformation_type='壹致',
    apply_unit_scale=True,
    usd_conversion='NONE',
    export_transformation_type='壹致',
    use_euler_filter=True,
    import_guide=False,
    uv_format='NONE',
    normal_format='NONE',
    light_intensity_match=False
)
```

### USD格式选择

```python
# 导入USD格式
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    usd_format='USD'
)

# 导入USDZ格式
bpy.ops.import_scene.usd(
    filepath='//model.usdz',
    usd_format='USDZ'
)

# 导入USDA格式
bpy.ops.import_scene.usd(
    filepath='//model.usda',
    usd_format='USDA'
)
```

### 几何体导入

```python
# 导入网格
bpy.ops.import_scene.usd(
    filepath='//meshes.usd',
    import_meshes=True
)

# 不导入网格
bpy.ops.import_scene.usd(
    filepath='//no_meshes.usd',
    import_meshes=False
)
```

### 相机导入

```python
# 导入相机
bpy.ops.import_scene.usd(
    filepath='//cameras.usd',
    import_cameras=True
)

# 不导入相机
bpy.ops.import_scene.usd(
    filepath='//no_cameras.usd',
    import_cameras=False
)
```

### 灯光导入

```python
# 导入灯光
bpy.ops.import_scene.usd(
    filepath='//lights.usd',
    import_lights=True
)

# 不导入灯光
bpy.ops.import_scene.usd(
    filepath='//no_lights.usd',
    import_lights=False
)

# 灯光强度匹配
bpy.ops.import_scene.usd(
    filepath='//lights.usd',
    import_lights=True,
    light_intensity_match=True
)
```

### 材质导入

```python
# 导入材质
bpy.ops.import_scene.usd(
    filepath='//materials.usd',
    import_materials=True
)

# 不导入材质
bpy.ops.import_scene.usd(
    filepath='//no_materials.usd',
    import_materials=False
)
```

### 曲线导入

```python
# 导入曲线
bpy.ops.import_scene.usd(
    filepath='//curves.usd',
    import_curves=True
)

# 不导入曲线
bpy.ops.import_scene.usd(
    filepath='//no_curves.usd',
    import_curves=False
)
```

### 粒子导入

```python
# 导入粒子
bpy.ops.import_scene.usd(
    filepath='//particles.usd',
    import_particles=True
)

# 不导入粒子
bpy.ops.import_scene.usd(
    filepath='//no_particles.usd',
    import_particles=False
)
```

### 程序化导入

```python
# 不导入程序化
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_procedural='NONE'
)

# 导入为程序化
bpy.ops.import_scene.usd(
    filepath='//procedural.usd',
    import_procedural='CREATE'
)
```

### 细分导入

```python
# 导入细分
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_subdiv=True
)

# 不导入细分
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_subdiv=False
)
```

### 动画导入

```python
# 导入动画
bpy.ops.import_scene.usd(
    filepath='//anim.usd',
    import_anim=True
)

# 不导入动画
bpy.ops.import_scene.usd(
    filepath='//static.usd',
    import_anim=False
)

# 使用默认动画
bpy.ops.import_scene.usd(
    filepath='//anim.usd',
    import_anim=True,
    import_anim_use_default=True
)

# 使用帧范围
bpy.ops.import_scene.usd(
    filepath='//anim.usd',
    import_anim=True,
    import_anim_range=True
)
```

### 资源导入

```python
# 导入资源
bpy.ops.import_scene.usd(
    filepath='//assets.usd',
    import_assets=True
)

# 不导入资源
bpy.ops.import_scene.usd(
    filepath='//no_assets.usd',
    import_assets=False
)
```

### 缩放设置

```python
# 设置缩放
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    scale=1.0
)

# 设置导入缩放
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_scale=1.0
)

# 应用单位缩放
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    apply_unit_scale=True
)
```

### 变换类型

```python
# 一致变换
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_transformation_type='壹致'
)

# 矩阵变换
bpy.ops.import_scene.usd(
    filepath='//matrix.usd',
    import_transformation_type='矩阵'
)
```

### USD转换

```python
# 无转换
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    usd_conversion='NONE'
)

# 使用导出变换类型
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    usd_conversion='NONE',
    export_transformation_type='壹致'
)
```

### 欧拉滤波

```python
# 使用欧拉滤波
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    use_euler_filter=True
)

# 不使用欧拉滤波
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    use_euler_filter=False
)
```

### 引导导入

```python
# 导入引导
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_guide=True
)

# 不导入引导
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_guide=False
)
```

### UV格式

```python
# 无UV
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    uv_format='NONE'
)

# 导入UV
bpy.ops.import_scene.usd(
    filepath='//uv.usd',
    uv_format='IMPORT'
)
```

### 法线格式

```python
# 无法线
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    normal_format='NONE'
)

# 导入法线
bpy.ops.import_scene.usd(
    filepath='//normals.usd',
    normal_format='IMPORT'
)
```

## 实用函数

```python
def import_usd_model(filepath, scale=1.0):
    """导入USD模型"""
    bpy.ops.import_scene.usd(
        filepath=filepath,
        scale=scale,
        import_cameras=True,
        import_lights=True,
        import_materials=True,
        import_anim=False
    )
    return list(bpy.context.selected_objects)

def import_usd_with_animations(filepath, scale=1.0):
    """导入USD带动画"""
    bpy.ops.import_scene.usd(
        filepath=filepath,
        scale=scale,
        import_cameras=True,
        import_lights=True,
        import_materials=True,
        import_anim=True,
        import_anim_use_default=True
    )
    return list(bpy.context.selected_objects)

def import_usd_for_editing(filepath):
    """导入USD用于编辑"""
    bpy.ops.import_scene.usd(
        filepath=filepath,
        scale=1.0,
        import_cameras=False,
        import_lights=False,
        import_materials=False,
        import_anim=False
    )
    return list(bpy.context.selected_objects)

def import_usd_character(filepath):
    """导入USD角色"""
    bpy.ops.import_scene.usd(
        filepath=filepath,
        scale=1.0,
        import_cameras=True,
        import_lights=True,
        import_materials=True,
        import_curves=True,
        import_anim=True,
        import_anim_use_default=True,
        import_anim_range=True
    )
    return list(bpy.context.selected_objects)

def import_usdz_for_ar(filepath, scale=1.0):
    """导入USDZ用于AR"""
    bpy.ops.import_scene.usd(
        filepath=filepath,
        scale=scale,
        usd_format='USDZ',
        import_cameras=True,
        import_lights=True,
        import_materials=True,
        import_anim=False
    )
    return list(bpy.context.selected_objects)

def batch_import_usd_files(usd_files, scale=1.0):
    """批量导入USD文件"""
    all_objects = []
    for filepath in usd_files:
        bpy.ops.import_scene.usd(
            filepath=filepath,
            scale=scale
        )
        imported = list(bpy.context.selected_objects)
        all_objects.extend(imported)
    return all_objects

def import_usd_and_merge(filepath, scale=1.0):
    """导入USD并合并"""
    bpy.ops.import_scene.usd(
        filepath=filepath,
        scale=scale,
        import_cameras=False,
        import_lights=False,
        import_materials=False
    )
    
    objects = list(bpy.context.selected_objects)
    if len(objects) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = objects[0]
        bpy.ops.object.join()
        return [bpy.context.active_object]
    
    return objects
```

## 常见问题排查

### 导入后模型不可见
```python
# 检查选中对象
selected = bpy.context.selected_objects
print(f"导入对象数: {len(selected)}")

# 检查对象类型
for obj in selected:
    print(f"{obj.name}: 类型={obj.type}")

# 检查隐藏状态
for obj in selected:
    print(f"{obj.name}: 隐藏={obj.hide_viewport}")
    obj.hide_viewport = False

# 检查显示类型
for obj in selected:
    obj.display_type = 'SOLID'
```

### 材质丢失
```python
# 检查材质
print(f"材质数: {len(bpy.data.materials)}")

# 检查纹理
print(f"纹理数: {len(bpy.data.textures)}")

# 重新导入带材质
bpy.ops.import_scene.usd(
    filepath='//mat.usd',
    import_materials=True
)
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 重新导入带动画
bpy.ops.import_scene.usd(
    filepath='//anim.usd',
    import_anim=True,
    import_anim_use_default=True
)
```

### 比例问题
```python
# 检查导入比例
obj = bpy.context.active_object
print(f"尺寸: {obj.dimensions}")

# 检查单位设置
print(f"场景单位: {bpy.context.scene.unit_settings.system}")

# 重新导入带正确比例
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    scale=0.01,
    apply_unit_scale=True
)
```

### 性能问题
```python
# 检查对象数
print(f"对象数: {len(bpy.context.selected_objects)}")

# 减少导入内容
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_cameras=False,
    import_lights=False,
    import_materials=False,
    import_curves=False,
    import_particles=False,
    import_anim=False
)

# 导入后优化
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.join()
```

### 灯光强度问题
```python
# 检查灯光强度
for obj in bpy.context.selected_objects:
    if obj.type == 'LIGHT':
        print(f"{obj.name}: 强度={obj.data.energy}")

# 使用强度匹配
bpy.ops.import_scene.usd(
    filepath='//lights.usd',
    import_lights=True,
    light_intensity_match=True
)

# 手动调整强度
for obj in bpy.context.selected_objects:
    if obj.type == 'LIGHT':
        obj.data.energy *= 100  # 根据需要调整
```

### 坐标轴问题
```python
# 检查导入的变换
obj = bpy.context.active_object
print(f"位置: {obj.location}")
print(f"旋转: {obj.rotation_euler}")
print(f"缩放: {obj.scale}")

# 尝试不同的变换类型
bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_transformation_type='壹致'
)

bpy.ops.import_scene.usd(
    filepath='//model.usd',
    import_transformation_type='矩阵'
)
```
