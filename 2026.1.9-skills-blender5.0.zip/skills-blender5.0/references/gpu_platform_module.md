# gpu.platform - GPU平台模块

gpu.platform模块提供了查询GPU平台信息和跨平台抽象的功能，用于处理不同GPU后端的兼容性问题。

## 概述

GPU平台模块封装了GPU后端的底层细节，提供统一的接口来查询当前使用的图形API和平台相关信息。这对于编写可移植的GPU代码非常重要。

## 核心功能

### 平台信息

```python
import gpu
from gpu.platform import (
    get_os_type,
    get_gpu_type,
    get_backend_type,
    BACKEND_OPENGL,
    BACKEND_VULKAN,
    BACKEND_CYCLES,
    OS_WINDOWS,
    OS_MACOS,
    OS_LINUX
)

def get_current_os():
    """获取当前操作系统"""
    return get_os_type()

def get_gpu_backend():
    """获取GPU后端"""
    return get_backend_type()

def is_opengl_backend():
    """检查是否为OpenGL后端"""
    return get_gpu_backend() == BACKEND_OPENGL

def is_vulkan_backend():
    """检查是否为Vulkan后端"""
    return get_gpu_backend() == BACKEND_VULKAN

def is_cycles_backend():
    """检查是否为Cycles后端"""
    return get_gpu_backend() == BACKEND_CYCLES
```

### 驱动信息

```python
from gpu.platform import (
    get_driver_version,
    get_driver_info,
    is_driver_supported
)

def get_current_driver_version():
    """获取当前驱动版本"""
    return get_driver_version()

def get_driver_details():
    """获取驱动详情"""
    return get_driver_info()

def check_driver_support():
    """检查驱动支持"""
    info = get_driver_info()
    return {
        'version': info.get('version'),
        'renderer': info.get('renderer'),
        'vendor': info.get('vendor'),
        'supported': is_driver_supported()
    }
```

### 设备信息

```python
from gpu.platform import (
    get_device_info,
    get_device_count,
    get_active_device
)

def get_all_gpu_devices():
    """获取所有GPU设备"""
    return get_device_info()

def get_gpu_device_count():
    """获取GPU设备数量"""
    return get_device_count()

def get_current_device():
    """获取当前设备"""
    return get_active_device()

def select_device(device_id):
    """选择设备"""
    gpu.platform.set_active_device(device_id)
```

## 实用函数

### 兼容性检查

```python
def requires_compatibility_mode():
    """检查是否需要兼容模式"""
    return gpu.platform.requires_compatibility()

def is_feature_supported(feature):
    """检查特性支持"""
    supported_features = [
        'compute_shader',
        'geometry_shader',
        'tessellation_shader',
        'texture_float',
        'texture_half_float',
        'draw_instanced',
        'viewport_array',
        'debug_output'
    ]
    return feature in supported_features

def get_minimum_supported_version():
    """获取最低支持版本"""
    backend = get_gpu_backend()
    if backend == BACKEND_OPENGL:
        return '3.3'
    elif backend == BACKEND_VULKAN:
        return '1.2'
    return None
```

### 平台适配

```python
def get_platform_specific_code(platform):
    """获取平台特定代码"""
    platform_codes = {
        'windows': '''
            #ifdef _WIN32
            // Windows specific code
            #endif
        ''',
        'macos': '''
            #ifdef __APPLE__
            // macOS specific code
            #endif
        ''',
        'linux': '''
            #ifdef __linux__
            // Linux specific code
            #endif
        '''
    }
    return platform_codes.get(platform, '')

def adapt_shader_for_platform(source):
    """适配着色器到平台"""
    backend = get_gpu_backend()
    if backend == BACKEND_OPENGL:
        return adapt_opengl_shader(source)
    elif backend == BACKEND_VULKAN:
        return adapt_vulkan_shader(source)
    return source

def get_platform_limits():
    """获取平台限制"""
    return {
        'max_texture_size': gpu.capabilities_get('MAX_TEXTURE_SIZE'),
        'max_uniform_vectors': gpu.capabilities_get('MAX_UNIFORM_VECTORS'),
        'max_vertex_attribs': gpu.capabilities_get('MAX_VERTEX_ATTRIBS'),
        'max_texture_units': gpu.capabilities_get('MAX_TEXTURE_UNITS')
    }
```

### 错误处理

```python
from gpu.platform import (
    get_error_code,
    get_error_string,
    GPUError
)

def check_gpu_errors():
    """检查GPU错误"""
    error_code = get_error_code()
    if error_code != 0:
        error_msg = get_error_string(error_code)
        raise GPUError(f"GPU Error {error_code}: {error_msg}")

def handle_gpu_exception(exception):
    """处理GPU异常"""
    error_info = {
        'type': type(exception).__name__,
        'message': str(exception),
        'backend': get_gpu_backend(),
        'driver': get_driver_version()
    }
    return error_info

def is_gpu_responsive():
    """检查GPU响应"""
    try:
        check_gpu_errors()
        return True
    except GPUError:
        return False
```

## 常见问题排查

### 平台不支持

后端不可用：
- 检查GPU驱动是否正确安装
- 确认Blender支持该后端
- 尝试切换到其他后端

### 特性不可用

API版本问题：
- 检查GPU能力支持
- 使用兼容模式
- 更新GPU驱动

### 性能问题

后端选择：
- 根据GPU类型选择合适后端
- 考虑使用OpenGL进行兼容性
- 使用Vulkan获得更好性能
