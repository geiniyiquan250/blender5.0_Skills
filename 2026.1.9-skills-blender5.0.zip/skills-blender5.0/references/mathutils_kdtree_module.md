# mathutils.kdtree - KDTree Utilities Module

KDTree模块提供了K维树（K-Dimensional Tree）的创建和最近邻搜索功能，用于高效的空间点查询。

## 概述

KDTree是一种空间分割数据结构，将k维空间分成嵌套的超矩形区域。它特别适合在大量点中进行最近邻搜索、范围查询和聚类分析。

## 核心功能

### KDTree创建

```python
import bpy
import mathutils
from mathutils.kdtree import KDTree

def create_kdtree_from_vertices(mesh):
    """从网格顶点创建KDTree"""
    verts = [v.co for v in mesh.vertices]
    tree = KDTree(len(verts))
    for i, v in enumerate(verts):
        tree.insert(v, i)
    tree.balance()
    return tree

def create_kdtree_from_points(points):
    """从点列表创建KDTree"""
    tree = KDTree(len(points))
    for i, p in enumerate(points):
        tree.insert(p, i)
    tree.balance()
    return tree

def create_kdtree_with_data(points, data_list):
    """创建带数据的KDTree"""
    tree = KDTree(len(points))
    for i, (p, d) in enumerate(zip(points, data_list)):
        tree.insert(p, i, data=d)
    tree.balance()
    return tree
```

### 最近邻搜索

```python
def find_nearest(tree, point):
    """查找最近的点"""
    co, index, dist = tree.find(point)
    return {
        'coordinate': co,
        'index': index,
        'distance': dist
    }

def find_n_nearest(tree, point, n):
    """查找最近的N个点"""
    return [(tree.find_nearest(point, n=i)) for i in range(n)]

def find_nearest_in_range(tree, point, radius):
    """查找半径内的所有点"""
    return [ (co, index, dist) for co, index, dist in tree.find_range(point, radius) ]

def find_all_nearest(tree, point, num):
    """获取最近的多个点"""
    results = []
    for co, index, dist in tree.find_nearest(point, num):
        results.append({
            'coordinate': co,
            'index': index,
            'distance': dist
        })
    return results
```

### 范围查询

```python
def find_points_in_sphere(tree, center, radius):
    """查找球体内的所有点"""
    return list(tree.find_range(center, radius))

def find_points_in_box(tree, center, half_size):
    """查找立方体内的所有点"""
    from mathutils import Vector
    min_point = center - Vector(half_size)
    max_point = center + Vector(half_size)
    return list(tree.find_range_aabb(min_point, max_point))

def count_points_in_sphere(tree, center, radius):
    """统计球体内的点数"""
    return len(list(tree.find_range(center, radius)))
```

### 数据关联

```python
def find_nearest_with_data(tree, point):
    """查找最近的点及其关联数据"""
    co, index, dist, data = tree.find(point)
    return {
        'coordinate': co,
        'index': index,
        'distance': dist,
        'data': data
    }

def create_kdtree_with_vertex_data(mesh):
    """创建带顶点索引的KDTree"""
    verts = [v.co for v in mesh.vertices]
    tree = KDTree(len(verts))
    for i, v in enumerate(verts):
        tree.insert(v, i)
    tree.balance()
    return tree

def find_nearest_vertex(tree, mesh, point):
    """在网格中查找最近的顶点"""
    co, index, dist = tree.find(point)
    if index < len(mesh.vertices):
        return {
            'vertex': mesh.vertices[index],
            'coordinate': co,
            'distance': dist
        }
    return None
```

## 实用函数

### 批量操作

```python
def build_scene_kdtree():
    """构建场景中所有对象顶点的KDTree"""
    all_verts = []
    vert_map = []
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            for v in obj.data.vertices:
                world_co = obj.matrix_world @ v.co
                all_verts.append(world_co)
                vert_map.append((obj.name, v.index))
    tree = KDTree(len(all_verts))
    for i, v in enumerate(all_verts):
        tree.insert(v, i)
    tree.balance()
    return tree, vert_map

def find_nearest_vertex_in_scene(point):
    """在场景中查找最近的顶点"""
    tree, vert_map = build_scene_kdtree()
    co, index, dist = tree.find(point)
    if index < len(vert_map):
        obj_name, vert_index = vert_map[index]
        return {
            'object': bpy.data.objects[obj_name],
            'vertex_index': vert_index,
            'coordinate': co,
            'distance': dist
        }
    return None
```

### 高级功能

```python
def find_k_nearest_neighbors(tree, point, k):
    """查找K个最近邻"""
    results = []
    for co, index, dist in tree.find_nearest(point, k):
        results.append({
            'coordinate': co,
            'index': index,
            'distance': dist
        })
    return results

def cluster_points_kdtree(points, radius):
    """使用KDTree进行点云聚类"""
    tree = create_kdtree_from_points(points)
    visited = set()
    clusters = []
    for i, point in enumerate(points):
        if i not in visited:
            cluster = [point]
            visited.add(i)
            nearby = tree.find_range(point, radius)
            for co, idx, dist in nearby:
                if idx not in visited:
                    cluster.append(points[idx])
                    visited.add(idx)
            clusters.append(cluster)
    return clusters

def find_duplicates(points, threshold):
    """查找重复点"""
    tree = create_kdtree_from_points(points)
    duplicates = []
    for i, point in enumerate(points):
        for co, idx, dist in tree.find_range(point, threshold):
            if idx > i:
                duplicates.append((i, idx, dist))
    return duplicates
```

## 常见问题排查

### 树未平衡

搜索结果不准确：
- 创建KDTree后必须调用balance()方法
- 如果点分布不均匀，可能需要多次平衡

### 搜索性能问题

搜索速度慢：
- 确保树已平衡
- 避免在循环中重复创建树
- 使用find_nearest代替多次find调用

### 索引越界

index超出范围：
- 确保插入时的索引有效
- 插入后不要修改原始数据列表
- 使用find_range时检查返回的索引

### 内存使用

内存占用过高：
- 对于非常大的点云，考虑分块创建多个KDTree
- 及时释放不再使用的树对象
- 使用生成器表达式处理结果
