# bpy.ops.asset - Asset Operations Module

资产操作模块，用于创建、管理和发布Blender资产。

## 概述

`bpy.ops.asset` 模块提供了Blender资产系统的操作功能，包括资产的标记、清除、目录管理、资源包安装、标签管理等。资产系统是Blender用于管理和复用资源的核心功能，支持材质、模型、场景等各类资源的Asset Browser管理。

## 核心功能

### 资产标记操作

```python
import bpy

# 标记为资产
bpy.ops.asset.mark()

# 标记单个对象为资产
bpy.ops.asset.mark_single()

# 清除资产标记
bpy.ops.asset.clear(set_fake_user=False)

# 清除单个资产标记
bpy.ops.asset.clear_single(set_fake_user=False)

# 分配动作到资产
bpy.ops.asset.assign_action()
```

### 目录管理操作

```python
# 新建目录
bpy.ops.asset.catalog_new(parent_path='')

# 删除目录
bpy.ops.asset.catalog_delete(catalog_id='')

# 撤销目录操作
bpy.ops.asset.catalog_undo()

# 重做目录操作
bpy.ops.asset.catalog_redo()

# 推入目录操作到撤销栈
bpy.ops.asset.catalog_undo_push()

# 保存所有目录
bpy.ops.asset.catalogs_save()
```

### 资源包操作

```python
# 安装资源包
bpy.ops.asset.bundle_install(
    asset_library_reference='',
    filepath='',
    hide_props_region=True,
    check_existing=True
)

# 刷新资产库
bpy.ops.asset.library_refresh()

# 打开包含的blend文件
bpy.ops.asset.open_containing_blend_file()
```

### 标签管理

```python
# 添加标签
bpy.ops.asset.tag_add()

# 移除标签
bpy.ops.asset.tag_remove()
```

### 预览操作

```python
# 截图预览
bpy.ops.asset.screenshot_preview(
    p1=(0, 0),
    p2=(0, 0),
    force_square=True
)
```

## 实用函数

```python
# 批量标记选中对象为资产
def mark_selected_assets():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.asset.mark()

# 清除场景中所有资产标记
def clear_all_assets(set_fake_user=True):
    for obj in bpy.data.objects:
        if obj.asset_data:
            obj.asset_clear(set_fake_user=set_fake_user)

# 为资产添加多个标签
def add_asset_tags(tag_names):
    for tag_name in tag_names:
        bpy.ops.asset.tag_add()
        # 设置标签名称
        # 注意：需要在Asset Browser中手动设置标签名称
```

## 常见问题排查

**问题：资产标记后不在Asset Browser中显示**

- 确保对象有有效的数据（网格、材质等）
- 尝试刷新资产库：`bpy.ops.asset.library_refresh()`

**问题：资源包安装失败**

- 检查文件路径是否正确
- 确认资源包格式是否有效（.blend或.zip）
- 验证资产库路径是否可写

**问题：目录操作无响应**

- 检查是否在编辑模式下操作
- 确认有足够的权限修改目录结构

**问题：标签无法添加**

- 确保当前有选中的资产
- 某些资产类型不支持标签

**问题：预览截图失败**

- 确保对象在视图中可见
- 检查渲染设置是否正确
