# bpy.props 属性定义模块

定义用于扩展 Blender 内部数据的属性。这些函数的返回值用于给 Blender 注册的类分配属性，不能直接在其他上下文中使用。

**重要提示：** 所有参数必须作为关键字参数传递。

## 数值属性

### FloatProperty

```python
import bpy

bpy.types.Material.custom_float = bpy.props.FloatProperty(
    name="浮点属性",
    description="这是一个浮点数值属性",
    default=0.5,
    min=0.0,
    max=1.0,
    step=1,
    precision=2,
    unit='LENGTH',
    update=None,
    get=None,
    set=None
)
```

定义浮点类型属性。

**参数：**

- `name` (str): 属性显示名称。
- `description` (str): 属性描述信息。
- `default` (float): 默认值。
- `min` (float): 最小值。
- `max` (float): 最大值。
- `soft_min` (float): 软限制最小值。
- `soft_max` (float): 软限制最大值。
- `step` (int): 步进值。
- `precision` (int): 小数位数。
- `unit` (str): 单位类型，可选 'LENGTH'、'AREA'、'VOLUME'、'ROTATION'、'TIME'、'VELOCITY'、'ACCELERATION'。
- `update` (Callable): 值更新时的回调函数。
- `get` (Callable): 获取属性值的函数。
- `set` (Callable): 设置属性值的函数。

---

### IntProperty

```python
import bpy

bpy.types.Object.custom_int = bpy.props.IntProperty(
    name="整型属性",
    description="这是一个整型数值属性",
    default=10,
    min=0,
    max=100,
    step=1,
    update=None
)
```

定义整型属性。

**参数：**

- `name` (str): 属性显示名称。
- `description` (str): 属性描述信息。
- `default` (int): 默认值。
- `min` (int): 最小值。
- `max` (int): 最大值。
- `soft_min` (int): 软限制最小值。
- `soft_max` (int): 软限制最大值。
- `step` (int): 步进值。
- `update` (Callable): 值更新时的回调函数。

---

### BoolProperty

```python
import bpy

bpy.types.Object.custom_bool = bpy.props.BoolProperty(
    name="布尔属性",
    description="这是一个布尔类型属性",
    default=True,
    update=None
)
```

定义布尔类型属性（复选框形式）。

**参数：**

- `name` (str): 属性显示名称。
- `description` (str): 属性描述信息。
- `default` (bool): 默认值。
- `update` (Callable): 值更新时的回调函数。

---

## 字符串属性

### StringProperty

```python
import bpy

bpy.types.Object.custom_string = bpy.props.StringProperty(
    name="字符串属性",
    description="这是一个字符串属性",
    default="默认值",
    maxlen=255,
    subtype='FILE_PATH',
    update=None
)
```

定义字符串类型属性。

**参数：**

- `name` (str): 属性显示名称。
- `description` (str): 属性描述信息。
- `default` (str): 默认值。
- `maxlen` (int): 最大长度限制。
- `subtype` (str): 子类型，可选 'NONE'、'FILE_PATH'、'DIR_PATH'、'FILE_NAME'、'BYTE_STRING'、'PASSWORD'。
- `update` (Callable): 值更新时的回调函数。

---

## 枚举属性

### EnumProperty

```python
import bpy

items = [
    ("OPTION_A", "选项A", "这是选项A的描述"),
    ("OPTION_B", "选项B", "这是选项B的描述"),
    ("OPTION_C", "选项C", "这是选项C的描述"),
]

bpy.types.Object.custom_enum = bpy.props.EnumProperty(
    name="枚举属性",
    description="这是一个枚举选择属性",
    items=items,
    default="OPTION_A",
    update=None
)
```

定义枚举类型属性（下拉菜单形式）。

**参数：**

- `name` (str): 属性显示名称。
- `description` (str): 属性描述信息。
- `items` (Sequence): 枚举项列表，每项为元组 (identifier, name, description, icon, number)。
- `default` (str | int | Sequence): 默认值。
- `update` (Callable): 值更新时的回调函数。

**items 格式说明：**

- `identifier` (str): 枚举项的唯一标识符。
- `name` (str): 显示名称。
- `description` (str): 描述信息。
- `icon` (str | int): 图标名称或图标常量。
- `number` (int): 枚举值（通常与 identifier 相同）。

---

## 指针属性

### PointerProperty

```python
import bpy

class MaterialSettings(bpy.types.PropertyGroup):
    my_float: bpy.props.FloatProperty(name="浮点值", default=0.5)
    my_string: bpy.props.StringProperty(name="字符串", default="")

bpy.utils.register_class(MaterialSettings)

bpy.types.Material.custom_settings = bpy.props.PointerProperty(
    name="设置组",
    description="指向自定义设置组的指针",
    type=MaterialSettings
)
```

定义指向其他类型的指针属性。

**参数：**

- `name` (str): 属性显示名称。
- `description` (str): 属性描述信息。
- `type` (type): 指向的类型，必须是 PropertyGroup 或其他 bpy_struct 子类。

---

### CollectionProperty

```python
import bpy

class SceneItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="名称", default="")
    value: bpy.props.IntProperty(name="值", default=0)

bpy.utils.register_class(SceneItem)

bpy.types.Scene.custom_collection = bpy.props.CollectionProperty(
    name="集合",
    description="自定义项目集合",
    type=SceneItem
)
```

定义项目集合属性。

**参数：**

- `name` (str): 属性显示名称。
- `description` (str): 属性描述信息。
- `type` (type): 集合元素的类型，必须是 PropertyGroup 子类。

---

## 浮点向量属性

### FloatVectorProperty

```python
import bpy

bpy.types.Object.custom_vector = bpy.props.FloatVectorProperty(
    name="向量属性",
    description="这是一个三维向量属性",
    size=3,
    default=(0.0, 0.0, 0.0),
    min=0.0,
    max=1.0,
    step=1,
    precision=2,
    unit='LENGTH',
    update=None
)
```

定义浮点向量属性。

**参数：**

- `name` (str): 属性显示名称。
- `description` (str): 属性描述信息。
- `size` (int): 向量维度（2、3 或 4）。
- `default` (Sequence[float]): 默认值。
- `min` (float): 最小值。
- `max` (float): 最大值。
- `soft_min` (float): 软限制最小值。
- `soft_max` (float): 软限制最大值。
- `step` (int): 步进值。
- `precision` (int): 小数位数。
- `unit` (str): 单位类型。
- `update` (Callable): 值更新时的回调函数。

---

### IntVectorProperty

```python
import bpy

bpy.types.Object.custom_int_vector = bpy.props.IntVectorProperty(
    name="整型向量",
    description="这是整型向量属性",
    size=3,
    default=(0, 0, 0),
    min=0,
    max=255
)
```

定义整型向量属性。

**参数：**

- `name` (str): 属性显示名称。
- `description` (str): 属性描述信息。
- `size` (int): 向量维度。
- `default` (Sequence[int]): 默认值。
- `min` (int): 最小值。
- `max` (int): 最大值。
- `soft_min` (int): 软限制最小值。
- `soft_max` (int): 软限制最大值。

---

## 使用示例

### 操作符属性定义

```python
import bpy

class OBJECT_OT_custom_operator(bpy.types.Operator):
    bl_idname = "object.custom_operator"
    bl_label = "自定义操作符"
    bl_options = {'REGISTER', 'UNDO'}

    my_float: bpy.props.FloatProperty(
        name="浮点值",
        default=0.5,
        min=0.0,
        max=1.0
    )
    
    my_bool: bpy.props.BoolProperty(
        name="启用选项",
        default=True
    )
    
    my_string: bpy.props.StringProperty(
        name="字符串",
        default="文本"
    )
    
    my_enum: bpy.props.EnumProperty(
        name="选择模式",
        items=[
            ('MODE_A', "模式A", "模式A描述"),
            ('MODE_B', "模式B", "模式B描述"),
            ('MODE_C', "模式C", "模式C描述"),
        ],
        default='MODE_A'
    )

    def execute(self, context):
        print(f"浮点值: {self.my_float}")
        print(f"布尔值: {self.my_bool}")
        print(f"字符串: {self.my_string}")
        print(f"枚举值: {self.my_enum}")
        return {'FINISHED'}

    def invoke(self, context, event):
        return self.execute(context)

bpy.utils.register_class(OBJECT_OT_custom_operator)

bpy.ops.object.custom_operator(
    my_float=0.8,
    my_bool=False,
    my_string="测试文本",
    my_enum='MODE_B'
)
```

### 属性组定义

```python
import bpy

class ToolSettings(bpy.types.PropertyGroup):
    strength: bpy.props.FloatProperty(
        name="强度",
        default=0.5,
        min=0.0,
        max=1.0
    )
    
    radius: bpy.props.IntProperty(
        name="半径",
        default=20,
        min=1,
        max=100
    )
    
    enabled: bpy.props.BoolProperty(
        name="启用",
        default=True
    )

bpy.utils.register_class(ToolSettings)

bpy.types.Object.tool_settings = bpy.props.PointerProperty(
    name="工具设置",
    type=ToolSettings
)

mat = bpy.data.materials[0]
mat.tool_settings.strength = 0.75
mat.tool_settings.radius = 50
mat.tool_settings.enabled = False
```

### 集合属性定义

```python
import bpy

class ConfigItem(bpy.types.PropertyGroup):
    key: bpy.props.StringProperty(name="键", default="")
    value: bpy.props.FloatProperty(name="值", default=0.0)
    enabled: bpy.props.BoolProperty(name="启用", default=True)

bpy.utils.register_class(ConfigItem)

bpy.types.Scene.config = bpy.props.CollectionProperty(
    name="配置项",
    type=ConfigItem
)

scene = bpy.context.scene

item = scene.config.add()
item.key = "渲染质量"
item.value = 1.0
item.enabled = True

item = scene.config.add()
item.key = "采样数"
item.value = 128.0
item.enabled = True

for idx, item in enumerate(scene.config):
    print(f"[{idx}] {item.key} = {item.value} (启用: {item.enabled})")

scene.config.remove(0)
```

### 动态枚举

```python
import bpy

def get_object_names(self):
    return [(obj.name, obj.name, f"选择{obj.name}")
            for obj in bpy.data.objects]

def update_object_selection(self, context):
    if self.selected_object:
        obj = bpy.data.objects.get(self.selected_object)
        if obj:
            print(f"选中对象: {obj.name}")
            print(f"位置: {obj.location}")

class ObjectSelector(bpy.types.PropertyGroup):
    selected_object: bpy.props.EnumProperty(
        name="选择对象",
        description="从场景中选择一个对象",
        items=get_object_names,
        update=update_object_selection
    )

bpy.utils.register_class(ObjectSelector)

bpy.types.Scene.selector = bpy.props.PointerProperty(
    name="对象选择器",
    type=ObjectSelector
)
```

### 更新回调

```python
import bpy

def update_length(self, context):
    old_value = getattr(self, "length", 0)
    new_value = self.length
    
    self.volume = new_value ** 3
    
    print(f"长度从 {old_value} 变为 {new_value}")
    print(f"计算体积: {self.volume}")

def update_width(self, context):
    self.length = self.width * 2

class BoxSettings(bpy.types.PropertyGroup):
    length: bpy.props.FloatProperty(
        name="长度",
        default=1.0,
        min=0.1,
        update=update_length
    )
    
    width: bpy.props.FloatProperty(
        name="宽度",
        default=1.0,
        min=0.1,
        update=update_width
    )
    
    volume: bpy.props.FloatProperty(
        name="体积",
        default=1.0,
        min=0.0,
        precision=3
    )

bpy.utils.register_class(BoxSettings)

bpy.types.Object.box = bpy.props.PointerProperty(
    name="盒子设置",
    type=BoxSettings
)

obj = bpy.context.active_object
obj.box.length = 2.0
```

### 属性动画支持

```python
import bpy

class AnimatedProperty(bpy.types.PropertyGroup):
    value: bpy.props.FloatProperty(
        name="动画值",
        default=0.0,
        min=-10.0,
        max=10.0
    )
    
    @property
    def animated_value(self):
        return self.value

bpy.utils.register_class(AnimatedProperty)

bpy.types.Object.animated = bpy.props.PointerProperty(
    name="动画属性",
    type=AnimatedProperty
)

obj = bpy.context.active_object

obj.animated.value = 0.0

if not obj.animation_data:
    obj.animation_data_create()

obj.animated.value = 10.0
obj.keyframe_insert(data_path='animated.value', frame=10)

obj.animated.value = -10.0
obj.keyframe_insert(data_path='animated.value', frame=50)
```

---

## 注意事项

1. **参数传递：** 所有属性函数的参数必须使用关键字参数传递。

2. **注册顺序：** PropertyGroup 必须先注册才能用于 PointerProperty 或 CollectionProperty。

3. **线程安全：** 更新回调可能在多线程环境中执行，不应修改其他数据块或非线程安全的数据。

4. **操作符中的特殊处理：** 如果属性属于 Operator，update 回调的第一个参数是 OperatorProperties 实例，而非操作符实例本身。

5. **属性动画：** 自定义属性可以被动画系统驱动，支持关键帧插入和驱动程序。

6. **ID 类型限制：** 自定义属性可以添加到 ID、Bone 和 PoseBone 的子类中。

7. **访问方式：** 自定义属性可以通过用户界面、Python 代码访问，也可以被动画系统驱动。