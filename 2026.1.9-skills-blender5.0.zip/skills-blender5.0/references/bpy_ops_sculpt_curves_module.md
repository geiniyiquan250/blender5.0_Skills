# bpy.ops.sculpt_curves - 雕刻曲线操作模块

Blender雕刻曲线操作符，用于在雕刻模式下创建和编辑曲线。

## 概述

`bpy.ops.sculpt_curves` 模块提供用于在Blender雕刻工作区中创建、编辑和操作曲线的功能。这是Blender 4.0+版本中新增的曲线雕刻系统。

## 核心功能

### 曲线选择操作

```python
import bpy

# 全选曲线
bpy.ops.sculpt_curves.select_all(action='SELECT')

# 全不选
bpy.ops.sculpt_curves.select_all(action='DESELECT')

# 反选
bpy.ops.sculpt_curves.select_all(action='INVERT')

# 选择更多
bpy.ops.sculpt_curves.select_more()

# 选择更少
bpy.ops.sculpt_curves.select_less()

# 选择相似曲线
bpy.ops.sculpt_curves.select_similar(type='LENGTH')

# 选择连接的曲线
bpy.ops.sculpt_curves.select_linked()

# 边框选择
bpy.ops.sculpt_curves.select_border(gesture_mode=0, xmin=100, xmax=300, ymin=100, ymax=300)

# 圆形选择
bpy.ops.sculpt_curves.select_circle(x=200, y=200, radius=50, mode='ADD')

# 套索选择
bpy.ops.sculpt_curves.select_lasso(path=[(100, 100), (200, 100), (200, 200), (100, 200)])

# 根据长度选择
bpy.ops.sculpt_curves.select_by_length(min_length=0.1, max_length=10.0)

# 根据方向选择
bpy.ops.sculpt_curves.select_by_direction(direction='UP', threshold=0.5)
```

### 曲线创建

```python
# 从点创建曲线
bpy.ops.sculpt_curves.create_curve_from_points()

# 创建新曲线
bpy.ops.sculpt_curves.primitive_curve_add()

# 从现有几何体创建曲线
bpy.ops.sculpt_curves.duplicate_curves()

# 从网格边创建曲线
bpy.ops.sculpt_curves.create_from_edges()

# 从选中点创建曲线
bpy.ops.sculpt_curves.create_curve_from_selection()

# 添加曲线点
bpy.ops.sculpt_curves.add_point(location=(0, 0, 0))

# 添加多个点
bpy.ops.sculpt_curves.add_point_chain(count=10)

# 闭合曲线
bpy.ops.sculpt_curves.close_curve()

# 断开曲线
bpy.ops.sculpt_curves.split_curve()
```

### 曲线编辑

```python
# 删除选中曲线
bpy.ops.sculpt_curves.delete(type='SELECTED')

# 删除点
bpy.ops.sculpt_curves.delete_points()

# 删除曲线段
bpy.ops.sculpt_curves.delete_segment()

# 细分曲线
bpy.ops.sculpt_curves.subdivide(number_cuts=1)

# 简化曲线
bpy.ops.sculpt_curves.simplify(threshold=0.01)

# 合并曲线
bpy.ops.sculpt_curves.merge()

# 合并到点
bpy.ops.sculpt_curves.merge_at_cursor()

# 倒角曲线点
bpy.ops.sculpt_curves.bevel_point(radius=0.1)

# 改变曲线类型
bpy.ops.sculpt_curves.change_curve_type(type='POLY')

# 平滑曲线
bpy.ops.sculpt_curves.smooth(iterations=5)

# 重插值曲线
bpy.ops.sculpt_curves.resample(number_points=20)
```

### 曲线变换

```python
# 移动曲线
bpy.ops.sculpt_curves.translate(value=(1.0, 0.0, 0.0))

# 旋转曲线
bpy.ops.sculpt_curves.rotate(angle=45.0, axis='Z')

# 缩放曲线
bpy.ops.sculpt_curves.scale(value=(1.5, 1.5, 1.5))

# 变换曲线
bpy.ops.sculpt_curves.transform(mode='TRANSLATION')

# 吸附到网格
bpy.ops.sculpt_curves.snap_to_grid()

# 吸附到原点
bpy.ops.sculpt_curves.snap_to_origin()

# 吸附到选中对象
bpy.ops.sculpt_curves.snap_to_selected()

# 应用变换
bpy.ops.sculpt_curves.apply_transform()

# 重置变换
bpy.ops.sculpt_curves.reset_transform()

# 复制曲线
bpy.ops.sculpt_curves.duplicate()

# 对称曲线
bpy.ops.sculpt_curves.symmetry(axis='X')
```

### 曲线雕刻工具

```python
# 使用雕刻笔刷
bpy.ops.sculpt_curves.brush_stroke()

# 拉伸手柄
bpy.ops.sculpt_curves.grow_shrink(handle='LEFT', factor=0.1)

# 调整曲线粗细
bpy.ops.sculpt_curves.change_radius(factor=1.5)

# 调整所有曲线粗细
bpy.ops.sculpt_curves.change_radius_all(factor=1.5)

# 曲线吸附
bpy.ops.sculpt_curves.sculpt_stroke()

# 曲线推挤
bpy.ops.sculpt_curves.push_stroke()

# 曲线平滑
bpy.ops.sculpt_curves.smooth_stroke()

# 曲线添加点
bpy.ops.sculpt_curves.add_points_stroke()

# 曲线抽吸
bpy.ops.sculpt_curves.suck_stroke()
```

### 曲线样式设置

```python
# 设置曲线颜色
bpy.ops.sculpt_curves.set_color(color=(1.0, 0.0, 0.0, 1.0))

# 设置曲线材质
bpy.ops.sculpt_curves.set_material(material_name='CurveMaterial')

# 设置曲线粗细
bpy.ops.sculpt_curves.set_radius(radius=0.05)

# 设置点大小
bpy.ops.sculpt_curves.set_point_size(size=0.1)

# 设置曲线插值
bpy.ops.sculpt_curves.set_interpolation(type='BSPLINE')

# 应用材质到所有曲线
bpy.ops.sculpt_curves.set_material_all(material_name='CurveMaterial')

# 清除材质
bpy.ops.sculpt_curves.clear_material()
```

### 曲线UV和纹理

```python
# 设置曲线UV
bpy.ops.sculpt_curves.uv_set(uv_layer='UVMap')

# 应用UV
bpy.ops.sculpt_curves.uv_apply()

# 设置曲线纹理
bpy.ops.sculpt_curves.texture_set(texture_name='CurveTexture')

# 应用纹理到所有曲线
bpy.ops.sculpt_curves.texture_set_all(texture_name='CurveTexture')

# 清除纹理
bpy.ops.sculpt_curves.texture_clear()
```

### 曲线动画

```python
# 插入关键帧
bpy.ops.sculpt_curves.insert_keyframe()

# 删除关键帧
bpy.ops.sculpt_curves.delete_keyframe()

# 清除动画
bpy.ops.sculpt_curves.clear_keyframe()

# 设置曲线驱动的形状键
bpy.ops.sculpt_curves.shape_key_add()

# 移除形状键
bpy.ops.sculpt_curves.shape_key_remove()
```

### 曲线数据操作

```python
# 转换为网格
bpy.ops.sculpt_curves.convert_to_mesh()

# 转换为曲面
bpy.ops.sculpt_curves.convert_to_surface()

# 导出曲线数据
bpy.ops.sculpt_curves.export_data(filepath='//curves.json')

# 导入曲线数据
bpy.ops.sculpt_curves.import_data(filepath='//curves.json')

# 重新计算法线
bpy.ops.sculpt_curves.recalculate_normals()

# 重新计算切线
bpy.ops.sculpt_curves.recalculate_tangents()
```

## 实用函数

```python
def get_selected_curves():
    """获取所有选中的曲线"""
    return [c for c in bpy.context.active_object.data.curves if c.select]

def get_curve_points(curve):
    """获取曲线上的所有点"""
    return list(curve.points)

def get_curve_length(curve):
    """计算曲线长度"""
    return sum(p.co.distance_to(p_next.co) 
               for p, p_next in zip(curve.points[:-1], curve.points[1:]))

def create_curve_from_points(points, name='NewCurve'):
    """从点列表创建曲线"""
    obj = bpy.context.active_object
    curve_data = obj.data
    curve_data.curves[0].points.foreach_set('co', [c for p in points for c in p])
    curve_data.curves[0].name = name
    return curve_data.curves[0]

def batch_apply_material(mat_name):
    """批量应用材质到所有曲线"""
    for curve in bpy.context.active_object.data.curves:
        curve.material_index = bpy.data.materials.find(mat_name)

def select_curves_by_length(min_len, max_len):
    """按长度选择曲线"""
    for curve in bpy.context.active_object.data.curves:
        length = get_curve_length(curve)
        curve.select = (min_len <= length <= max_len)

def normalize_curve(curve):
    """归一化曲线"""
    center = get_curve_center(curve)
    for point in curve.points:
        point.co -= center
```

## 常见问题排查

### 曲线不显示
```python
# 检查曲线数据是否存在
print(f"曲线数量: {len(bpy.context.active_object.data.curves)}")

# 检查渲染属性
obj = bpy.context.active_object
print(f"渲染: {obj.display.rendered_type}")

# 检查视口显示
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        for space in area.spaces:
            if space.type == 'VIEW_3D':
                print(f"显示曲线: {space.show_curves}")
```

### 选择问题
```python
# 重置选择
bpy.ops.sculpt_curves.select_all(action='DESELECT')

# 手动选择曲线
for curve in bpy.context.active_object.data.curves:
    curve.select = True

# 检查选择模式
print(f"选择模式: {bpy.context.scene.tool_settings.sculpt_curves_select_mode}")
```

### 性能问题
```python
# 减少曲线点数量
for curve in bpy.context.active_object.data.curves:
    bpy.ops.sculpt_curves.simplify(threshold=0.1)

# 降低显示精度
import bpy
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        for space in area.spaces:
            if space.type == 'VIEW_3D':
                space.curves_resolution = 8
```
