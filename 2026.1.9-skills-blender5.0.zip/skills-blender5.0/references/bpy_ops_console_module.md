# bpy.ops.console - Console Operations Module

控制台操作模块，用于控制Blender Python控制台。

## 概述

`bpy.ops.console` 模块提供了Blender Python控制台（Text Editor中的Python Console）的操作功能，包括代码执行、自动补全、历史记录管理、文本编辑等。该模块主要用于交互式编程和调试。

## 核心功能

### 代码执行

```python
import bpy

# 执行代码
bpy.ops.console.execute(interactive=False)
```

### 自动补全

```python
# 自动补全
bpy.ops.console.autocomplete()

# 缩进或自动补全
bpy.ops.console.indent_or_autocomplete()
```

### 文本编辑

```python
# 插入文本
bpy.ops.console.insert(text='')

# 删除
bpy.ops.console.delete(type='NEXT_CHARACTER')

# 移动光标
bpy.ops.console.move(type='LINE_BEGIN', select=False)

# 缩进
bpy.ops.console.indent()

# 取消缩进
bpy.ops.console.unindent()

# 清除行
bpy.ops.console.clear_line()

# 清除
bpy.ops.console.clear(scrollback=True, history=False)
```

### 选择操作

```python
# 全选
bpy.ops.console.select_all()

# 选择设置
bpy.ops.console.select_set()

# 选择单词
bpy.ops.console.select_word()
```

### 剪贴板操作

```python
# 复制
bpy.ops.console.copy(delete=False)

# 复制为脚本
bpy.ops.console.copy_as_script()

# 粘贴
bpy.ops.console.paste(selection=False)
```

### 历史记录

```python
# 添加历史
bpy.ops.console.history_append(text='', current_character=0, remove_duplicates=False)

# 历史循环
bpy.ops.console.history_cycle(reverse=False)
```

### 输出控制

```python
# 添加回滚内容
bpy.ops.console.scrollback_append(text='', type='OUTPUT')
```

### 语言设置

```python
# 设置语言
bpy.ops.console.language(language='')
```

### 其他操作

```python
# 显示横幅
bpy.ops.console.banner()
```

## 实用函数

```python
# 在控制台执行代码并获取输出
def execute_console_code(code):
    # 插入代码
    bpy.ops.console.insert(text=code)
    # 执行
    bpy.ops.console.execute()
    # 获取输出
    # 注意：需要从控制台区域获取输出内容

# 清空控制台
def clear_console(keep_history=True):
    bpy.ops.console.clear(scrollback=True, history=not keep_history)

# 添加自定义输出
def console_output(text, output_type='OUTPUT'):
    bpy.ops.console.scrollback_append(text=text, type=output_type)

# 快速测试代码片段
def test_code_snippet(code):
    # 清理当前行
    bpy.ops.console.clear_line()
    # 插入代码
    bpy.ops.console.insert(text=code)
    # 执行
    bpy.ops.console.execute()
```

## 常见问题排查

**问题：自动补全不工作**

- 检查控制台是否处于编辑模式
- 确认Python环境正常
- 尝试手动调用`autocomplete()`

**问题：代码执行无响应**

- 检查语法错误
- 确认代码完整
- 尝试分步执行

**问题：历史记录丢失**

- 检查是否调用了`clear(history=True)`
- 确认Blender未异常退出
- 尝试使用`history_append()`保存重要命令

**问题：输出内容混乱**

- 使用`clear()`清理控制台
- 检查是否有多个输出语句
- 尝试重定向输出到文件

**问题：控制台卡顿**

- 减少输出内容
- 清理历史记录
- 避免大量循环输出
