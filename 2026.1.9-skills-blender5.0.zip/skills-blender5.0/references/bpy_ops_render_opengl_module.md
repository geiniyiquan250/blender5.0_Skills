# bpy.ops.render - OpenGL渲染操作模块

Blender OpenGL渲染操作符，用于使用OpenGL引擎进行快速渲染。

## 概述

`bpy.ops.render.opengl` 模块提供用于使用OpenGL引擎进行快速渲染的功能，支持图像和动画的快速输出。

## 核心功能

### 基础OpenGL渲染

```python
import bpy

# 渲染当前帧
bpy.ops.render.opengl(
    filepath='//render.png',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    view_context=True,
    write_still=False,
    bake=False,
    use_antialiasing=True,
    use_compositing=False,
    use_sequencer=False,
    use_viewer=False,
    show_full_view=False
)
```

### 渲染设置

```python
# 渲染并保存
bpy.ops.render.opengl(
    filepath='//render.png',
    write_still=True
)

# 不保存
bpy.ops.render.opengl(
    filepath='//render.png',
    write_still=False
)

# 使用抗锯齿
bpy.ops.render.opengl(
    filepath='//render.png',
    use_antialiasing=True
)

# 不使用抗锯齿
bpy.ops.render.opengl(
    filepath='//render.png',
    use_antialiasing=False
)
```

### 合成设置

```python
# 使用合成
bpy.ops.render.opengl(
    filepath='//composited.png',
    use_compositing=True
)

# 不使用合成
bpy.ops.render.opengl(
    filepath='//render.png',
    use_compositing=False
)
```

### 序列器设置

```python
# 使用序列器
bpy.ops.render.opengl(
    filepath='//with_sequencer.png',
    use_sequencer=True
)

# 不使用序列器
bpy.ops.render.opengl(
    filepath='//render.png',
    use_sequencer=False
)
```

### 视图器设置

```python
# 使用视图器
bpy.ops.render.opengl(
    filepath='//viewer.png',
    use_viewer=True
)

# 不使用视图器
bpy.ops.render.opengl(
    filepath='//render.png',
    use_viewer=False
)
```

### 全视图

```python
# 使用全视图
bpy.ops.render.opengl(
    filepath='//full_view.png',
    show_full_view=True
)

# 不使用全视图
bpy.ops.render.opengl(
    filepath='//render.png',
    show_full_view=False
)
```

### 烘焙设置

```python
# 启用烘焙
bpy.ops.render.opengl(
    filepath='//baked.png',
    bake=True
)

# 禁用烘焙
bpy.ops.render.opengl(
    filepath='//render.png',
    bake=False
)
```

### 视图上下文

```python
# 使用当前视图
bpy.ops.render.opengl(
    filepath='//render.png',
    view_context=True
)

# 不使用当前视图
bpy.ops.render.opengl(
    filepath='//render.png',
    view_context=False
)
```

## 实用函数

```python
def opengl_render_frame(filepath, resolution=1.0):
    """OpenGL渲染单帧"""
    bpy.context.scene.render.resolution_percentage = int(resolution * 100)
    bpy.ops.render.opengl(
        filepath=filepath,
        write_still=True,
        use_antialiasing=True,
        use_compositing=True,
        use_sequencer=False
    )

def opengl_render_quick(filepath):
    """快速OpenGL渲染"""
    bpy.ops.render.opengl(
        filepath=filepath,
        write_still=True,
        use_antialiasing=False,
        use_compositing=False,
        use_sequencer=False
    )

def opengl_render_composited(filepath):
    """OpenGL渲染带合成"""
    bpy.ops.render.opengl(
        filepath=filepath,
        write_still=True,
        use_antialiasing=True,
        use_compositing=True,
        use_sequencer=False
    )

def opengl_render_sequencer(filepath):
    """OpenGL渲染带序列器"""
    bpy.ops.render.opengl(
        filepath=filepath,
        write_still=True,
        use_antialiasing=True,
        use_compositing=False,
        use_sequencer=True
    )

def opengl_render_high_quality(filepath):
    """高质量OpenGL渲染"""
    bpy.ops.render.opengl(
        filepath=filepath,
        write_still=True,
        use_antialiasing=True,
        use_compositing=True,
        use_sequencer=False,
        view_context=True
    )

def opengl_render_animation(start, end, output_dir):
    """OpenGL渲染动画"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    scene = bpy.context.scene
    original_frame = scene.frame_current
    
    for frame in range(start, end + 1):
        scene.frame_set(frame)
        filepath = os.path.join(output_dir, f'frame_{frame:04d}.png')
        bpy.ops.render.opengl(
            filepath=filepath,
            write_still=True,
            use_antialiasing=True
        )
    
    scene.frame_set(original_frame)
```

## 常见问题排查

### 渲染空白
```python
# 检查渲染设置
print(f"渲染引擎: {bpy.context.scene.render.engine}")
print(f"分辨率: {bpy.context.scene.render.resolution_x} x {bpy.context.scene.render.resolution_y}")

# 设置正确的引擎
bpy.context.scene.render.engine = 'BLENDER_EEVEE'

# 检查渲染层
print(f"活跃场景: {bpy.context.scene.name}")

# 确保视图可见
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        space = area.spaces.active
        space.shading.type = 'SOLID'
```

### 抗锯齿问题
```python
# 检查抗锯齿设置
print(f"抗锯齿: {bpy.context.scene.render.use_antialiasing}")

# 启用抗锯齿
bpy.context.scene.render.use_antialiasing = True

# 设置采样数
bpy.context.scene.eevee.taa_render_samples = 16

# 重新渲染
bpy.ops.render.opengl(
    filepath='//aa_render.png',
    use_antialiasing=True
)
```

### 合成不工作
```python
# 检查合成节点
print(f"合成节点: {bpy.context.scene.node_tree}")

if bpy.context.scene.node_tree:
    for node in bpy.context.scene.node_tree.nodes:
        print(f"节点: {node.type}, 名称: {node.name}")

# 检查合成使用
print(f"使用合成: {bpy.context.scene.render.use_compositing}")

# 启用合成
bpy.context.scene.render.use_compositing = True

# 重新渲染
bpy.ops.render.opengl(
    filepath='//composite.png',
    use_compositing=True
)
```

### 序列器问题
```python
# 检查序列器
print(f"序列器: {bpy.context.scene.sequence_editor}")

if bpy.context.scene.sequence_editor:
    for strip in bpy.context.scene.sequence_editor.sequences:
        print(f"条带: {strip.name}, 类型: {strip.type}")

# 检查序列器使用
print(f"使用序列器: {bpy.context.scene.render.use_sequencer}")

# 启用序列器
bpy.context.scene.render.use_sequencer = True

# 重新渲染
bpy.ops.render.opengl(
    filepath='//sequencer.png',
    use_sequencer=True
)
```

### 性能问题
```python
# 检查性能设置
print(f"分辨率百分比: {bpy.context.scene.render.resolution_percentage}")

# 降低分辨率
bpy.context.scene.render.resolution_percentage = 50

# 禁用抗锯齿
bpy.ops.render.opengl(
    filepath='//fast.png',
    use_antialiasing=False,
    use_compositing=False,
    use_sequencer=False
)

# 重新渲染
print("降低质量设置后重新渲染")
```
