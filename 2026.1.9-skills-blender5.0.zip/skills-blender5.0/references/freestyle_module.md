# freestyle 线条渲染模块

freestyle 模块提供了 Freestyle 非真实感渲染引擎的数据类型和工具，用于创建风格化的线条渲染效果。

```python
import freestyle
```

## 模块概述

Freestyle 模块包含以下子模块：

- `freestyle.types`：视图映射组件的数据类型（0D 和 1D 元素）
- `freestyle.predicates`：线条选择谓词
- `freestyle.functions`：线条处理函数
- `freestyle.chainingiterators`：线条链化迭代器
- `freestyle.shaders`：线条着色器
- `freestyle.utils`：样式模块编写辅助函数

## 核心概念

### 线条渲染工作流

```python
import freestyle

# 创建样式模块
def create_style_module():
    from freestyle.predicates import (
        NOT, GT, INTERSECTS, PROJECTED_X, PROJECTED_Y,
        TrueBP1D, BackTesselationBP1D, Face2DAreaBP1D,
        Length2DBP1D, MaterialBP2D, NormalBP1D, Quantity1DPredicate,
        TrueBP1D, UV2DCoordBP1D
    )
    from freestyle.functions import (
        Curvature2DF0D, Curvature2DGradientF0D, Normal2DF0D,
        ObjectAndFaceIdF0D, SquareRootGradientF0D
    )
    from freestyle.chainingiterators import (
        ChainSilhouetteIterator, ChainBoundaryIterator,
        ChainContourIterator, ChainCreaseAngleIterator
    )
    from freestyle.shaders import (
        ConstantColorShader, ConstantThicknessShader,
        PolygonalizationShader, SamplingShader,
        StrokeShader, ThicknessShader, ColorShader
    )
```

### 谓词（Predicates）

谓词用于选择要渲染的线条，基于几何属性和材质属性进行过滤。

```python
from freestyle.predicates import (
    GT, LT, EQ, NOT, AND, OR,
    INTERSECTS, ProjectedX, ProjectedY, ProjectedZ,
    NormalBP1D, Curvature2DBP1D, MaterialBP2D,
    Length2DBP1D, BackTesselationBP1D, TrueBP1D
)

# 选择长度大于 100 的线条
length_predicate = GT(Length2DBP1D(), 100)

# 选择法线向上的面
normal_predicate = GT(NormalBP1D(), 0.0)

# 组合谓词
combined = AND(length_predicate, normal_predicate)
```

### 函数（Functions）

函数用于计算线条的各种属性值，供着色器使用。

```python
from freestyle.functions import (
    Curvature2DF0D, Curvature2DGradientF0D,
    Normal2DF0D, ObjectAndFaceIdF0D,
    SquareRootGradientF0D, DistanceToCameraF0D
)

# 获取曲率值
curvature_func = Curvature2DF0D()

# 获取法线
normal_func = Normal2DF0D()
```

### 链化迭代器（Chaining Iterators）

链化迭代器决定如何将相邻的边连接成连续的线条。

```python
from freestyle.chainingiterators import (
    ChainSilhouetteIterator, ChainBoundaryIterator,
    ChainContourIterator, ChainCreaseAngleIterator
)

# 创建轮廓链化迭代器
silhouette = ChainSilhouetteIterator()

# 创建边界链化迭代器
boundary = ChainBoundaryIterator()

# 创建折痕角度链化迭代器
crease = ChainCreaseAngleIterator(angle_threshold=1.0)
```

### 着色器（Shaders）

着色器定义线条的外观，包括颜色、厚度、样式等。

```python
from freestyle.shaders import (
    ConstantColorShader, ConstantThicknessShader,
    PolygonalizationShader, SamplingShader,
    StrokeShader, ThicknessShader, ColorShader,
    SmoothingShader, GuidingLinesShader
)

# 创建常量颜色着色器
color_shader = ConstantColorShader((0.0, 0.0, 0.0, 1.0))

# 创建常量厚度着色器
thickness_shader = ConstantThicknessShader(2.0)
```

## 样式模块示例

### 简单轮廓线

```python
from freestyle.predicates import (
    NOT, GT, INTERSECTS, TrueBP1D, BackTesselationBP1D
)
from freestyle.chainingiterators import ChainSilhouetteIterator
from freestyle.shaders import (
    ConstantColorShader, ConstantThicknessShader,
    StrokeShader
)

def create_silhouette_style():
    # 选择背对观察者的边
    predicate = NOT(BackTesselationBP1D())
    
    # 使用轮廓链化
    chaining = ChainSilhouetteIterator()
    
    # 定义着色器
    shaders = [
        ConstantColorShader((0.0, 0.0, 0.0, 1.0)),
        ConstantThicknessShader(1.5),
        StrokeShader()
    ]
    
    return predicate, chaining, shaders
```

### 艺术风格线条

```python
from freestyle.predicates import (
    GT, NormalBP1D, Length2DBP1D, MaterialBP2D
)
from freestyle.chainingiterators import ChainContourIterator
from freestyle.shaders import (
    ConstantColorShader, ThicknessShader,
    PolygonalizationShader, SmoothingShader
)

def create_artistic_style():
    # 根据法线和长度选择线条
    predicate = AND(
        GT(NormalBP1D(), 0.2),
        GT(Length2DBP1D(), 50.0)
    )
    
    # 使用轮廓链化
    chaining = ChainContourIterator()
    
    # 定义着色器序列
    shaders = [
        ConstantColorShader((0.1, 0.1, 0.1, 1.0)),
        ThicknessShader(3.0, 1.0),
        PolygonalizationShader(10.0),
        SmoothingShader(3)
    ]
    
    return predicate, chaining, shaders
```

### 手绘风格线条

```python
from freestyle.predicates import GT, Length2DBP1D
from freestyle.chainingiterators import ChainCreaseAngleIterator
from freestyle.shaders import (
    ConstantColorShader, ThicknessShader,
    SamplingShader, GuidingLinesShader
)

def create_sketch_style():
    predicate = GT(Length2DBP1D(), 30.0)
    
    chaining = ChainCreaseAngleIterator(angle_threshold=0.5)
    
    shaders = [
        ConstantColorShader((0.0, 0.0, 0.0, 1.0)),
        ThicknessShader(4.0, 0.5),
        SamplingShader(5.0),
        GuidingLinesShader(5.0)
    ]
    
    return predicate, chaining, shaders
```

## freestyle.utils 工具函数

```python
import freestyle.utils as utils

# 加载样式模块
style_module = utils.LoadStyleModule("//styles/my_style.py")

# 获取当前场景的视图映射
view_map = utils.GetViewMap()

# 获取 0D 元素
svertices = view_map.svertices

# 获取 1D 元素
edges = view_map.edges

# 获取线条
strokes = view_map.strokes
```

### 常用工具函数

```python
import freestyle.utils as utils

# 获取当前渲染的图像尺寸
width, height = utils.GetRenderSize()

# 获取像素比例
pixel_ratio = utils.GetPixelSize()

# 获取线条颜色
color = utils.GetStrokeColor()

# 设置线条颜色
utils.SetStrokeColor((1.0, 0.0, 0.0, 1.0))
```

## 高级应用

### 多层线条效果

```python
from freestyle.predicates import GT, LT, AND, NormalBP1D, Length2DBP1D
from freestyle.chainingiterators import ChainSilhouetteIterator, ChainContourIterator
from freestyle.shaders import ConstantColorShader, ConstantThicknessShader

def create_layered_style():
    layers = []
    
    # 粗轮廓层
    layer1_predicate = GT(Length2DBP1D(), 200.0)
    layer1_chaining = ChainSilhouetteIterator()
    layer1_shaders = [
        ConstantColorShader((0.0, 0.0, 0.0, 1.0)),
        ConstantThicknessShader(4.0)
    ]
    layers.append((layer1_predicate, layer1_chaining, layer1_shaders))
    
    # 细轮廓层
    layer2_predicate = AND(
        GT(Length2DBP1D(), 50.0),
        LT(Length2DBP1D(), 200.0)
    )
    layer2_chaining = ChainContourIterator()
    layer2_shaders = [
        ConstantColorShader((0.2, 0.2, 0.2, 1.0)),
        ConstantThicknessShader(2.0)
    ]
    layers.append((layer2_predicate, layer2_chaining, layer2_shaders))
    
    return layers
```

### 基于材质的线条样式

```python
from freestyle.predicates import MaterialBP2D, GT
from freestyle.chainingiterators import ChainContourIterator
from freestyle.shaders import ConstantColorShader, ConstantThicknessShader

def create_material_style():
    layers = []
    
    # 金属材质层
    metal_predicate = MaterialBP2D("Metal")
    metal_chaining = ChainContourIterator()
    metal_shaders = [
        ConstantColorShader((0.7, 0.7, 0.8, 1.0)),
        ConstantThicknessShader(2.5)
    ]
    layers.append((metal_predicate, metal_chaining, metal_shaders))
    
    # 塑料材质层
    plastic_predicate = MaterialBP2D("Plastic")
    plastic_chaining = ChainContourIterator()
    plastic_shaders = [
        ConstantColorShader((0.3, 0.3, 0.3, 1.0)),
        ConstantThicknessShader(1.5)
    ]
    layers.append((plastic_predicate, plastic_chaining, plastic_shaders))
    
    return layers
```

### 动态线条效果

```python
from freestyle.predicates import GT, NormalBP1D
from freestyle.chainingiterators import ChainSilhouetteIterator
from freestyle.shaders import ConstantColorShader, ThicknessShader

def create_dyanmic_style(time_factor):
    predicate = GT(NormalBP1D(), 0.0)
    
    chaining = ChainSilhouetteIterator()
    
    # 根据时间动态调整厚度
    thickness = 1.0 + 0.5 * time_factor
    
    shaders = [
        ConstantColorShader((0.0, 0.0, 0.0, 1.0)),
        ThicknessShader(thickness, thickness * 0.5)
    ]
    
    return predicate, chaining, shaders
```

## 调试技巧

```python
import freestyle.utils as utils

# 打印视图映射信息
view_map = utils.GetViewMap()
print(f"0D 元素数量: {len(view_map.svertices)}")
print(f"1D 元素数量: {len(view_map.edges)}")
print(f"线条数量: {len(view_map.strokes)}")

# 遍历所有线条
for stroke in view_map.strokes:
    print(f"线条点数: {len(stroke)}")
    print(f"线条长度: {stroke.length}")
    
    # 遍历线条上的点
    for vertex in stroke:
        print(f"位置: {vertex.point}")
        print(f"法线: {vertex.normal}")
```

## 性能优化建议

1. **使用适当的谓词**：精确的谓词可以减少处理的线条数量
2. **合理设置链化参数**：如折痕角度阈值
3. **优化着色器序列**：避免不必要的计算
4. **使用采样**：对于复杂线条，适当采样可以提高性能

```python
# 采样示例
from freestyle.shaders import SamplingShader

# 减少线条上的点数
sampling_shader = SamplingShader(5.0)  # 最小点间距

# 在着色器列表中使用
shaders = [
    sampling_shader,
    ConstantColorShader((0.0, 0.0, 0.0, 1.0))
]
```
