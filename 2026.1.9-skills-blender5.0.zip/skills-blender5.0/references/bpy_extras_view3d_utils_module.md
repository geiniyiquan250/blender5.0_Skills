# bpy_extras.view3d_utils - 3D视图工具模块

bpy_extras.view3d_utils模块提供了3D视图坐标转换、射线投射和视图投影的实用工具函数。

## 概述

3D视图工具模块封装了3D视图中常用的坐标操作，包括屏幕坐标与3D坐标的相互转换、射线投射、视图向量计算等功能。适用于开发交互式工具和3D视口插件。

## 核心功能

### 坐标转换

```python
import bpy
import bpy_extras
from mathutils import Vector, Matrix
from bpy_extras.view3d_utils import (
    location_3d_to_region_2d,
    location_3d_to_region_2d_multiple,
    region_2d_to_location_3d,
    region_2d_to_origin_3d,
    region_2d_to_vector_3d
)

def world_to_screen(co, region=None, rv3d=None):
    """将3D坐标转换为屏幕坐标"""
    if region is None:
        region = bpy.context.region
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    return location_3d_to_region_2d(co, region, rv3d)

def screen_to_world_3d(x, y, depth=0, region=None, rv3d=None):
    """将屏幕坐标转换为3D坐标"""
    if region is None:
        region = bpy.context.region
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    return region_2d_to_location_3d(x, y, depth, region, rv3d)

def screen_to_world_origin(x, y, region=None, rv3d=None):
    """将屏幕坐标转换为世界原点射线"""
    if region is None:
        region = bpy.context.region
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    origin = region_2d_to_origin_3d(x, y, region, rv3d)
    direction = region_2d_to_vector_3d(x, y, region, rv3d)
    return origin, direction

def get_viewport_center(region=None, rv3d=None):
    """获取视口中心"""
    if region is None:
        region = bpy.context.region
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    
    center_x = region.width / 2
    center_y = region.height / 2
    return (center_x, center_y)

def convert_3d_point_to_view(point, matrix=None, region=None, rv3d=None):
    """转换3D点到视图空间"""
    if matrix is None:
        matrix = bpy.context.space_data.region_3d.view_matrix
    return matrix @ point
```

### 射线投射

```python
def cast_ray_from_mouse(region=None, rv3d=None, mouse_coords=None):
    """从鼠标位置发射射线"""
    if region is None:
        region = bpy.context.region
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    if mouse_coords is None:
        mouse_coords = bpy.context.region_data.mouse
    
    origin = region_2d_to_origin_3d(
        mouse_coords.x, 
        mouse_coords.y, 
        region, 
        rv3d
    )
    direction = region_2d_to_vector_3d(
        mouse_coords.x, 
        mouse_coords.y, 
        region, 
        rv3d
    )
    
    return origin, direction

def ray_cast_scene(origin, direction, distance=1000):
    """在场景中投射射线"""
    result = bpy.context.scene.ray_cast(
        bpy.context.evaluated_depsgraph_get(),
        origin,
        direction,
        distance=distance
    )
    return result

def ray_cast_objects(objects, origin, direction, distance=1000):
    """在指定对象上投射射线"""
    results = []
    for obj in objects:
        if obj.type != 'MESH':
            continue
        depsgraph = bpy.context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh()
        try:
            from mathutils.bvhtree import BVHTree
            bvh = BVHTree.FromPolygons(
                [v.co for v in mesh.vertices],
                [p.vertices for p in mesh.polygons]
            )
            location, normal, index, dist = bvh.ray_cast(origin, direction, distance)
            if location is not None:
                results.append({
                    'object': obj,
                    'location': location,
                    'normal': normal,
                    'face_index': index,
                    'distance': dist
                })
        finally:
            eval_obj.to_mesh_clear()
    return results

def get_point_under_mouse(region=None, rv3d=None, mouse_coords=None):
    """获取鼠标下的点"""
    origin, direction = cast_ray_from_mouse(region, rv3d, mouse_coords)
    hit, location, normal, index, obj, matrix = ray_cast_scene(origin, direction)
    if hit:
        return {
            'location': location,
            'normal': normal,
            'face_index': index,
            'object': obj
        }
    return None
```

### 视图操作

```python
def get_view_distance(region=None, rv3d=None):
    """获取视图距离"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    return rv3d.view_distance

def set_view_distance(distance, region=None, rv3d=None):
    """设置视图距离"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    rv3d.view_distance = distance

def get_view_rotation(region=None, rv3d=None):
    """获取视图旋转"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    return rv3d.view_rotation

def set_view_rotation(rotation, region=None, rv3d=None):
    """设置视图旋转"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    rv3d.view_rotation = rotation

def get_view_perspective(region=None, rv3d=None):
    """获取视图投影类型"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    return rv3d.view_perspective

def set_view_perspective(perspective, region=None, rv3d=None):
    """设置视图投影类型"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    rv3d.view_perspective = perspective
```

## 实用函数

### 视口坐标

```python
def get_viewport_bounds(region=None, rv3d=None):
    """获取视口边界"""
    if region is None:
        region = bpy.context.region
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    
    corners = [
        Vector((0, 0, 0)),
        Vector((region.width, 0, 0)),
        Vector((region.width, region.height, 0)),
        Vector((0, region.height, 0))
    ]
    
    world_corners = []
    view_matrix_inv = rv3d.view_matrix.inverted()
    for corner in corners:
        screen_co = location_3d_to_region_2d(corner, region, rv3d)
        world_corners.append(screen_co)
    
    return world_corners

def point_in_viewport(point, region=None, rv3d=None):
    """检查点是否在视口内"""
    screen = world_to_screen(point, region, rv3d)
    if screen is None:
        return False
    
    if region is None:
        region = bpy.context.region
    
    return (0 <= screen.x <= region.width and 
            0 <= screen.y <= region.height)

def get_mouse_distance_from_view_center(mouse_coords, region=None):
    """计算鼠标到视图中心的距离"""
    if region is None:
        region = bpy.context.region
    center_x, center_y = get_viewport_center(region)
    dx = mouse_coords.x - center_x
    dy = mouse_coords.y - center_y
    return (dx * dx + dy * dy) ** 0.5
```

### 视图对齐

```python
def align_view_to_object(obj, align_axis='Z', region=None, rv3d=None):
    """对齐视图到对象"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    
    bpy.ops.view3d.view_axis(
        type=align_axis,
        align_active=True
    )

def center_view_on_object(obj, region=None, rv3d=None):
    """将视图中心对准对象"""
    bpy.ops.view3d.view_selected(use_all_regions=False)

def view_from_direction(direction, region=None, rv3d=None):
    """从指定方向查看"""
    rot_quat = direction.to_track_quat('-Z', 'Y').to_euler()
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    rv3d.view_rotation = rot_quat.to_quaternion()

def set_orbit_target(point, region=None, rv3d=None):
    """设置旋转目标点"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    bpy.ops.view3d.view_orbit(pivot_point=point)
```

### 投影计算

```python
def project_world_to_view_matrix(region=None, rv3d=None):
    """获取世界到视图的投影矩阵"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    return rv3d.view_matrix

def get_projection_matrix(region=None, rv3d=None):
    """获取投影矩阵"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    return rv3d.perspective_matrix

def get_view_matrix_inverted(region=None, rv3d=None):
    """获取视图矩阵的逆矩阵"""
    if rv3d is None:
        rv3d = bpy.context.space_data.region_3d
    return rv3d.view_matrix.inverted()

def calculate_screen_aspect(region=None):
    """计算屏幕宽高比"""
    if region is None:
        region = bpy.context.region
    return region.width / region.height
```

## 常见问题排查

### 坐标转换失败

视口数据无效：
- 确保在3D视图中运行
- 检查region和rv3d是否有效
- 确认视图已正确初始化

### 射线投射无结果

距离或方向问题：
- 增加射线投射距离
- 检查射线方向是否正确
- 确认对象在场景中可见

### 视图操作无响应

视口类型不支持：
- 确认当前是3D视图
- 检查视图是否被锁定
- 尝试切换视图类型
