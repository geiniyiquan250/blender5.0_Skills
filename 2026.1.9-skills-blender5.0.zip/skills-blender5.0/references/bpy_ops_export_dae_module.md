# bpy.ops.export_scene - COLLADA导出操作模块

Blender COLLADA（DAE）文件导出操作符，用于将场景导出为COLLADA格式。

## 概述

`bpy.ops.export_scene.dae` 模块提供用于将Blender场景导出为COLLADA（DAE）格式的功能，支持几何体、材质、纹理、骨骼和动画的导出。

## 核心功能

### 基础导出

```python
import bpy

# 导出DAE文件
bpy.ops.export_scene.dae(
    filepath='//model.dae',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    export_selected=False,
    use_triangles=False,
    use_cameras=True,
    use_lights=True,
    use_selection=False,
    use_visible=True,
    use_active_objects=False,
    use_export_nurbs=True,
    use_mesh_modifiers=True,
    use_yup=True,
    apply_modifiers=True,
    export_uv=True,
    export_normals=True,
    export_cameras=True,
    export_lights=True,
    export_materials=True,
    export_textures=True,
    export_cubes_as_cubes=False,
    bake_space_transform=False,
    max_file_size=0.0,
    export_frame_range=True,
    export_frame_step=1,
    export_anim=True,
    export_anim_action_only=False,
    export_anim_action_name='',
    export_animation_type='ANIMATION',
    export_baked_animations=True,
    export_baked_matrix=True,
    export_embedded=False,
    export_apply_scale='FBX_SCALE_ALL',
    export_metallic_roughness=True,
    export_original_specular=True,
    export_node_name_from_object=True,
    export_extra_images=False
)
```

### 导出范围

```python
# 只导出选中对象
bpy.ops.export_scene.dae(
    filepath='//selected.dae',
    export_selected=True
)

# 导出所有对象
bpy.ops.export_scene.dae(
    filepath='//all.dae',
    export_selected=False
)
```

### 几何体导出

```python
# 三角化
bpy.ops.export_scene.dae(
    filepath='//triangulated.dae',
    use_triangles=True
)

# 不三角化
bpy.ops.export_scene.dae(
    filepath='//model.dae',
    use_triangles=False
)

# 导出UV
bpy.ops.export_scene.dae(
    filepath='//uv.dae',
    export_uv=True
)

# 不导出UV
bpy.ops.export_scene.dae(
    filepath='//no_uv.dae',
    export_uv=False
)

# 导出法线
bpy.ops.export_scene.dae(
    filepath='//normals.dae',
    export_normals=True
)

# 不导出法线
bpy.ops.export_scene.dae(
    filepath='//no_normals.dae',
    export_normals=False
)
```

### 修改器设置

```python
# 应用修改器
bpy.ops.export_scene.dae(
    filepath='//applied.dae',
    use_mesh_modifiers=True
)

# 不应用修改器
bpy.ops.export_scene.dae(
    filepath='//not_applied.dae',
    use_mesh_modifiers=False
)

# 应用修改器变换
bpy.ops.export_scene.dae(
    filepath='//modifiers.dae',
    apply_modifiers=True
)
```

### 坐标轴设置

```python
# Y轴向上
bpy.ops.export_scene.dae(
    filepath='//model.dae',
    use_yup=True
)

# Z轴向上
bpy.ops.export_scene.dae(
    filepath='//model.dae',
    use_yup=False
)
```

### 相机和灯光

```python
# 导出相机
bpy.ops.export_scene.dae(
    filepath='//cameras.dae',
    export_cameras=True
)

# 不导出相机
bpy.ops.export_scene.dae(
    filepath='//no_cameras.dae',
    export_cameras=False
)

# 导出灯光
bpy.ops.export_scene.dae(
    filepath='//lights.dae',
    export_lights=True
)

# 不导出灯光
bpy.ops.export_scene.dae(
    filepath='//no_lights.dae',
    export_lights=False
)
```

### 材质和纹理

```python
# 导出材质
bpy.ops.export_scene.dae(
    filepath='//materials.dae',
    export_materials=True
)

# 不导出材质
bpy.ops.export_scene.dae(
    filepath='//no_materials.dae',
    export_materials=False
)

# 导出纹理
bpy.ops.export_scene.dae(
    filepath='//textures.dae',
    export_textures=True
)

# 不导出纹理
bpy.ops.export_scene.dae(
    filepath='//no_textures.dae',
    export_textures=False
)
```

### 可见性设置

```python
# 导出可见对象
bpy.ops.export_scene.dae(
    filepath='//visible.dae',
    use_visible=True
)

# 导出活动对象
bpy.ops.export_scene.dae(
    filepath='//active.dae',
    use_active_objects=True
)
```

### 曲线导出

```python
# 导出NURBS
bpy.ops.export_scene.dae(
    filepath='//nurbs.dae',
    use_export_nurbs=True
)

# 不导出NURBS
bpy.ops.export_scene.dae(
    filepath='//no_nurbs.dae',
    use_export_nurbs=False
)
```

### 立方体导出

```python
# 立方体导出为立方体
bpy.ops.export_scene.dae(
    filepath='//cubes.dae',
    export_cubes_as_cubes=True
)

# 立方体导出为其他
bpy.ops.export_scene.dae(
    filepath='//no_cubes.dae',
    export_cubes_as_cubes=False
)
```

### 空间变换

```python
# 烘焙空间变换
bpy.ops.export_scene.dae(
    filepath='//baked.dae',
    bake_space_transform=True
)

# 不烘焙空间变换
bpy.ops.export_scene.dae(
    filepath='//no_baked.dae',
    bake_space_transform=False
)
```

### 文件大小限制

```python
# 无限制
bpy.ops.export_scene.dae(
    filepath='//model.dae',
    max_file_size=0.0
)

# 设置最大文件大小
bpy.ops.export_scene.dae(
    filepath='//model.dae',
    max_file_size=100.0
)
```

### 动画设置

```python
# 导出动画
bpy.ops.export_scene.dae(
    filepath='//anim.dae',
    export_anim=True
)

# 不导出动画
bpy.ops.export_scene.dae(
    filepath='//static.dae',
    export_anim=False
)

# 只导出动作
bpy.ops.export_scene.dae(
    filepath='//action.dae',
    export_anim=True,
    export_anim_action_only=True
)

# 指定动作名称
bpy.ops.export_scene.dae(
    filepath='//named.dae',
    export_anim=True,
    export_anim_action_name='WalkCycle'
)

# 动画类型
bpy.ops.export_scene.dae(
    filepath='//animation.dae',
    export_animation_type='ANIMATION'
)

# 烘焙动画
bpy.ops.export_scene.dae(
    filepath='//baked.dae',
    export_anim=True,
    export_baked_animations=True
)

# 烘焙矩阵
bpy.ops.export_scene.dae(
    filepath='//matrix.dae',
    export_anim=True,
    export_baked_matrix=True
)
```

### 帧范围

```python
# 使用帧范围
bpy.ops.export_scene.dae(
    filepath='//range.dae',
    export_frame_range=True
)

# 设置帧步长
bpy.ops.export_scene.dae(
    filepath='//step.dae',
    export_frame_step=1
)
```

### 嵌入选项

```python
# 不嵌入
bpy.ops.export_scene.dae(
    filepath='//model.dae',
    export_embedded=False
)
```

### 缩放应用

```python
# 应用所有缩放
bpy.ops.export_scene.dae(
    filepath='//scaled.dae',
    export_apply_scale='FBX_SCALE_ALL'
)

# 不应用缩放
bpy.ops.export_scene.dae(
    filepath='//no_scale.dae',
    export_apply_scale='FBX_SCALE_NONE'
)
```

### 材质属性

```python
# 导出金属度粗糙度
bpy.ops.export_scene.dae(
    filepath='//mr.dae',
    export_metallic_roughness=True
)

# 导出原始高光
bpy.ops.export_scene.dae(
    filepath='//specular.dae',
    export_original_specular=True
)
```

### 节点名称

```python
# 从对象名导出节点名
bpy.ops.export_scene.dae(
    filepath='//named.dae',
    export_node_name_from_object=True
)

# 不从对象名导出
bpy.ops.export_scene.dae(
    filepath='//no_name.dae',
    export_node_name_from_object=False
)
```

### 额外图像

```python
# 导出额外图像
bpy.ops.export_scene.dae(
    filepath='//extra.dae',
    export_extra_images=True
)

# 不导出额外图像
bpy.ops.export_scene.dae(
    filepath='//no_extra.dae',
    export_extra_images=False
)
```

## 实用函数

```python
def export_dae_model(filepath, apply_modifiers=True):
    """导出DAE模型"""
    bpy.ops.export_scene.dae(
        filepath=filepath,
        export_selected=True,
        use_mesh_modifiers=apply_modifiers,
        use_yup=True,
        export_uv=True,
        export_normals=True,
        export_materials=True,
        export_textures=True,
        export_anim=False
    )

def export_dae_with_animations(filepath):
    """导出DAE带动画"""
    bpy.ops.export_scene.dae(
        filepath=filepath,
        export_selected=True,
        use_mesh_modifiers=True,
        use_yup=True,
        export_uv=True,
        export_normals=True,
        export_materials=True,
        export_textures=True,
        export_anim=True,
        export_baked_animations=True
    )

def export_dae_for_sketchfab(filepath):
    """导出DAE用于Sketchfab"""
    bpy.ops.export_scene.dae(
        filepath=filepath,
        export_selected=True,
        use_mesh_modifiers=True,
        use_yup=True,
        export_uv=True,
        export_normals=True,
        export_materials=True,
        export_textures=True,
        export_anim=True,
        export_baked_animations=True,
        export_cameras=True,
        export_lights=True
    )

def export_dae_for_web(filepath):
    """导出DAE用于Web"""
    bpy.ops.export_scene.dae(
        filepath=filepath,
        export_selected=True,
        use_mesh_modifiers=True,
        use_yup=True,
        export_uv=True,
        export_normals=True,
        export_materials=True,
        export_textures=True,
        export_anim=False,
        use_triangles=True
    )

def batch_export_dae_by_collection(output_dir):
    """按集合批量导出DAE"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for collection in bpy.data.collections:
        bpy.ops.object.select_all(action='DESELECT')
        
        for obj in collection.objects:
            obj.select_set(True)
        
        if bpy.context.selected_objects:
            bpy.context.view_layer.active_layer_collection = bpy.context.layer_collection.children[collection.name]
            filepath = os.path.join(output_dir, f'{collection.name}.dae')
            bpy.ops.export_scene.dae(
                filepath=filepath,
                export_selected=True,
                use_mesh_modifiers=True,
                use_yup=True,
                export_uv=True,
                export_normals=True,
                export_materials=True
            )
```

## 常见问题排查

### 导出文件无法打开
```python
# 检查文件路径
filepath = '//model.dae'
print(f"文件存在: {bpy.path.exists(filepath)}")

# 检查文件大小
import os
file_size = os.path.getsize(bpy.path.abspath(filepath))
print(f"文件大小: {file_size} 字节")

# 尝试不同的导出选项
bpy.ops.export_scene.dae(
    filepath='//model.dae',
    use_yup=True,
    export_embedded=False
)
```

### 材质丢失
```python
# 检查材质
obj = bpy.context.active_object
print(f"材质数: {len(obj.data.materials) if obj.data else 0}")

# 确保导出材质和纹理
bpy.ops.export_scene.dae(
    filepath='//mat.dae',
    export_selected=True,
    export_materials=True,
    export_textures=True
)

# 检查纹理路径
print(f"纹理目录: {bpy.path.abspath('//textures/')}")
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 确保导出动画
bpy.ops.export_scene.dae(
    filepath='//anim.dae',
    export_selected=True,
    export_anim=True,
    export_baked_animations=True
)

# 检查骨骼动画
if obj.type == 'ARMATURE':
    print(f"骨骼数: {len(obj.data.bones)}")
```

### 骨骼问题
```python
# 检查骨骼
armature = None
for obj in bpy.context.selected_objects:
    if obj.type == 'ARMATURE':
        armature = obj
        break

if armature:
    print(f"骨骼数: {len(armature.data.bones)}")
    
    # 检查绑定
    for child in armature.children:
        if child.type == 'MESH':
            print(f"子对象: {child.name}")
            for mod in child.modifiers:
                if mod.type == 'ARMATURE':
                    print(f"绑定到: {mod.object}")

# 确保导出骨骼
bpy.ops.export_scene.dae(
    filepath='//armature.dae',
    export_selected=True,
    use_mesh_modifiers=True,
    export_anim=True,
    export_baked_animations=True
)
```

### 坐标轴问题
```python
# 检查轴向
print(f"Y轴向上: {bpy.context.scene.unit_settings.system}")

# 尝试不同轴向
bpy.ops.export_scene.dae(
    filepath='//yup.dae',
    use_yup=True
)

bpy.ops.export_scene.dae(
    filepath='//zup.dae',
    use_yup=False
)

# 在导入软件中检查方向
```

### 性能问题
```python
# 检查对象数
print(f"对象数: {len(bpy.context.selected_objects)}")

# 减少导出内容
bpy.ops.export_scene.dae(
    filepath='//optimized.dae',
    export_selected=True,
    use_mesh_modifiers=True,
    use_triangles=True,
    export_uv=True,
    export_normals=True,
    export_materials=True,
    export_anim=False,
    export_cameras=False,
    export_lights=False
)

# 设置文件大小限制
bpy.ops.export_scene.dae(
    filepath='//limited.dae',
    export_selected=True,
    max_file_size=50.0
)
```
