# bpy.ops.object - Object Operations Module

Blender 对象操作符，用于创建、选择、变换、复制和管理 3D 对象。

## Overview

`bpy.ops.object` 模块是 Blender Python API 中最核心的操作符模块之一，包含了场景中对象的所有基本操作命令。这个模块涵盖了对象的创建、选择、变换、复制、删除、分组、对齐等常用功能。

## 核心功能

### 对象选择操作

```python
import bpy

# 全选
bpy.ops.object.select_all(action='SELECT')

# 全不选
bpy.ops.object.select_all(action='DESELECT')

# 反选
bpy.ops.object.select_all(action='INVERT')

# 选择活动对象
bpy.ops.object.select_active(type='MESH')

# 选择边框
bpy.ops.object.select_border(gesture_mode=0, xmin=100, xmax=300, ymin=100, ymax=300)

# 选择圆形
bpy.ops.object.select_circle(x=200, y=200, radius=50)

# 选择多边形
bpy.ops.object.select_lasso(path=[(100, 100), (200, 100), (200, 200), (100, 200)])

# 选择更多
bpy.ops.object.select_more(use_face_step=True, use_connected=False)

# 选择更少
bpy.ops.object.select_less(use_face_step=True)

# 选择相似
bpy.ops.object.select_hierarchy(direction='CHILD', extend=True)
bpy.ops.object.select_hierarchy(direction='PARENT', extend=True)

# 选择类型
bpy.ops.object.select_by_type(type='MESH')
bpy.ops.object.select_by_type(type='CURVE')
bpy.ops.object.select_by_type(type='ARMATURE')
bpy.ops.object.select_by_type(type='CAMERA')
bpy.ops.object.select_by_type(type='LIGHT')

def select_all_objects():
    """选择所有对象"""
    bpy.ops.object.select_all(action='SELECT')
    return bpy.context.selected_objects

def deselect_all():
    """取消所有选择"""
    bpy.ops.object.select_all(action='DESELECT')

def select_by_name(name):
    """按名称选择对象"""
    deselect_all()
    if name in bpy.data.objects:
        obj = bpy.data.objects[name]
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj

def select_by_prefix(prefix):
    """按前缀选择对象"""
    deselect_all()
    for obj in bpy.data.objects:
        if obj.name.startswith(prefix):
            obj.select_set(True)
```

### 对象变换操作

```python
# 变换模式
bpy.ops.object.mode_set(mode='OBJECT')
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.object.mode_set(mode='POSE')
bpy.ops.object.mode_set(mode='SCULPT')
bpy.ops.object.mode_set(mode='VERTEX_PAINT')
bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
bpy.ops.object.mode_set(mode='TEXTURE_PAINT')

# 应用变换
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
bpy.ops.object.transform_apply(location=True, rotation=False, scale=False)
bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

# 重置变换
bpy.ops.object.location_clear(clear_delta=False)
bpy.ops.object.rotation_clear(clear_delta=False)
bpy.ops.object.scale_clear(clear_delta=False)
bpy.ops.object.transform_clear(type='ALL')

# 变换到原点
bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')
bpy.ops.object.origin_set(type='ORIGIN_3D_CURSOR', center='MEDIAN')

# 父级设置
bpy.ops.object.parent_set(type='OBJECT')
bpy.ops.object.parent_set(type='BONE_RELATIVE')
bpy.ops.object.parent_set(type='BONE_SELECTED')
bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
bpy.ops.object.parent_clear(type='CLEAR_INVERSE')

# 约束添加
bpy.ops.object.constraint_add(type='COPY_LOCATION')
bpy.ops.object.constraint_add(type='COPY_ROTATION')
bpy.ops.object.constraint_add(type='COPY_SCALE')
bpy.ops.object.constraint_add(type='TRACK_TO')
bpy.ops.object.constraint_add(type='LOOK_AT')
bpy.ops.object.constraint_add(type='IK')
bpy.ops.object.constraint_add(type='FOLLOW_PATH')

def apply_all_transforms():
    """应用所有变换"""
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

def reset_to_origin(obj):
    """重置对象到原点"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.location_clear()
    bpy.ops.object.rotation_clear()
    bpy.ops.object.scale_clear()

def set_parent(child, parent):
    """设置父级"""
    bpy.ops.object.select_all(action='DESELECT')
    child.select_set(True)
    parent.select_set(True)
    bpy.context.view_layer.objects.active = child
    bpy.ops.object.parent_set(type='OBJECT')
```

### 对象创建操作

```python
import bpy
import math

# 添加空对象
bpy.ops.object.empty_add(type='PLAIN_AXES')
bpy.ops.object.empty_add(type='ARROWS')
bpy.ops.object.empty_add(type='SINGLE_ARROW')
bpy.ops.object.empty_add(type='CIRCLE')
bpy.ops.object.empty_add(type='CUBE')
bpy.ops.object.empty_add(type='SPHERE')
bpy.ops.object.empty_add(type='CONE')

# 添加摄像机
bpy.ops.object.camera_add(location=(0, 0, 5))
bpy.ops.object.camera_add(rotation=(math.radians(90), 0, 0))

# 添加灯光
bpy.ops.object.light_add(type='POINT')
bpy.ops.object.light_add(type='SUN')
bpy.ops.object.light_add(type='SPOT')
bpy.ops.object.light_add(type='AREA')

# 添加网格
bpy.ops.object.mesh_add()
bpy.ops.object.primitive_cube_add()
bpy.ops.object.primitive_uv_sphere_add()
bpy.ops.object.primitive_ico_sphere_add()
bpy.ops.object.primitive_cylinder_add()
bpy.ops.object.primitive_cone_add()
bpy.ops.object.primitive_torus_add()
bpy.ops.object.primitive_circle_add()
bpy.ops.object.primitive_cube_add(size=2, location=(0, 0, 0))
bpy.ops.object.primitive_grid_add(x_subdivisions=10, y_subdivisions=10)
bpy.ops.object.primitive_monkey_add()

# 添加曲线
bpy.ops.object.curve_add()
bpy.ops.object.primitive_bezier_curve_add()
bpy.ops.object.primitive_bezier_circle_add()
bpy.ops.object.primitive_nurbs_path_add()
bpy.ops.object.primitive_nurbs_circle_add()

# 添加曲面
bpy.ops.object.surface_add()
bpy.ops.object.primitive_nurbs_surface_circle_add()
bpy.ops.object.primitive_nurbs_surface_path_add()

# 添加文字
bpy.ops.object.text_add()
bpy.ops.object.text_add(enter_editmode=True)

# 添加骨骼
bpy.ops.object.armature_add()
bpy.ops.object.armature_add(enter_editmode=True)

# 添加粒子系统
bpy.ops.object.particle_system_add()

# 添加毛发
bpy.ops.object.hair_add()

# 添加 Metaball
bpy.ops.object.metaball_add(type='BALL')
bpy.ops.object.metaball_add(type='CAPSULE')
bpy.ops.object.metaball_add(type='PLANE')
bpy.ops.object.metaball_add(type='ELLIPSOID')

def create_cube(name="Cube", size=1.0, location=(0, 0, 0)):
    """创建立方体"""
    bpy.ops.mesh.primitive_cube_add(size=size, location=location)
    obj = bpy.context.active_object
    obj.name = name
    return obj

def create_sphere(name="Sphere", radius=1.0, segments=32, rings=16, location=(0, 0, 0)):
    """创建球体"""
    bpy.ops.mesh.primitive_uv_sphere_add(radius=radius, segments=segments, ring_count=rings, location=location)
    obj = bpy.context.active_object
    obj.name = name
    return obj

def create_cylinder(name="Cylinder", radius=1.0, depth=2.0, vertices=32, location=(0, 0, 0)):
    """创建圆柱体"""
    bpy.ops.mesh.primitive_cylinder_add(radius=radius, depth=depth, vertices=vertices, location=location)
    obj = bpy.context.active_object
    obj.name = name
    return obj

def create_light(name="Light", type='POINT', energy=100, location=(0, 0, 5)):
    """创建灯光"""
    bpy.ops.object.light_add(type=type, location=location)
    obj = bpy.context.active_object
    obj.name = name
    obj.data.energy = energy
    return obj

def create_camera(name="Camera", location=(0, 0, 5), rotation=(0, 0, 0)):
    """创建摄像机"""
    bpy.ops.object.camera_add(location=location, rotation=rotation)
    obj = bpy.context.active_object
    obj.name = name
    bpy.context.scene.camera = obj
    return obj
```

### 对象复制操作

```python
# 复制
bpy.ops.object.duplicate(linked=False, mode='TRANSLATION')
bpy.ops.object.duplicate(linked=True, mode='TRANSLATION')

# 复制并移动
bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked": False, "mode": 'TRANSLATION'}, TRANSFORM_OT_translate={"value": (1, 0, 0)})

# 实例化
bpy.ops.object.duplicates_make_real()

# 实例化集合
bpy.ops.object.duplicates_upstream()

# 复制层级
bpy.ops.object.duplicate_hierarchy(mode='CHILD')

# 浅复制
bpy.ops.object.shade_flat()
bpy.ops.object.shade_smooth()

def duplicate_object(obj, offset=(1, 0, 0)):
    """复制对象"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.duplicate()
    new_obj = bpy.context.active_object
    new_obj.location = (obj.location[0] + offset[0], obj.location[1] + offset[1], obj.location[2] + offset[2])
    return new_obj

def duplicate_linked(obj):
    """浅复制对象"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.duplicate(linked=True)
    return bpy.context.active_object

def create_array(obj, count=5, offset=(1, 0, 0)):
    """创建线性阵列"""
    objects = []
    for i in range(count):
        new_obj = duplicate_object(obj, (offset[0] * i, offset[1] * i, offset[2] * i))
        objects.append(new_obj)
    return objects
```

### 对象删除操作

```python
# 删除
bpy.ops.object.delete(use_global=False)
bpy.ops.object.delete(use_global=True)

# 删除未使用的数据
bpy.ops.object.data_objects_delete()

# 清除未使用的数据块
bpy.ops.object.data_gpencil_delete()

def delete_object(obj, use_global=False):
    """删除对象"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.delete(use_global=use_global)

def delete_selected():
    """删除选中的对象"""
    bpy.ops.object.delete(use_global=False)

def delete_all_objects():
    """删除所有对象"""
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)

def delete_by_type(obj_type):
    """按类型删除对象"""
    for obj in bpy.data.objects:
        if obj.type == obj_type:
            bpy.data.objects.remove(obj)
```

### 对象分组操作

```python
# 添加到集合
bpy.ops.object.collection_link(collection="Collection")

# 从集合取消链接
bpy.ops.object.collection_unlink(collection="Collection")

# 添加新集合
bpy.ops.object.collection_add()

# 移出主集合
bpy.ops.object.move_to_collection(collection_index=0, is_new=True, new_collection_name="New Collection")

def add_to_collection(obj, collection_name):
    """添加对象到集合"""
    if collection_name not in bpy.data.collections:
        bpy.ops.object.collection_add()
        bpy.context.scene.active_collection.name = collection_name
    
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.collection_link(collection=collection_name)

def move_to_collection(obj, collection_name):
    """移动对象到集合"""
    if collection_name not in bpy.data.collections:
        bpy.ops.object.collection_add()
    
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    for i, coll in enumerate(bpy.data.collections):
        if coll.name == collection_name:
            bpy.ops.object.move_to_collection(collection_index=i)
            break

def create_collection(name, objects=None):
    """创建集合并添加对象"""
    bpy.ops.object.collection_add()
    new_collection = bpy.context.scene.active_collection
    new_collection.name = name
    
    if objects:
        for obj in objects:
            move_to_collection(obj, name)
    
    return new_collection
```

## 对象变换操作

### 移动操作

```python
import bpy
import math

# 移动
bpy.ops.transform.translate(value=(1, 0, 0))

# 移动到原点
bpy.ops.object.location_clear()

# 设置位置
def set_location(obj, x, y, z):
    """设置对象位置"""
    obj.location = (x, y, z)
    obj.keyframe_insert(data_path="location")

def move_object(obj, dx, dy, dz):
    """移动对象"""
    obj.location.x += dx
    obj.location.y += dy
    obj.location.z += dz

def move_to_origin(obj):
    """移动对象到原点"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.location_clear()

def animate_move(obj, start_pos, end_pos, start_frame=1, end_frame=30):
    """创建移动动画"""
    obj.location = start_pos
    obj.keyframe_insert(data_path="location", frame=start_frame)
    
    obj.location = end_pos
    obj.keyframe_insert(data_path="location", frame=end_frame)

def move_along_path(obj, path_points, frames_per_point=10):
    """沿路径移动对象"""
    for i, point in enumerate(path_points):
        frame = i * frames_per_point + 1
        obj.location = point
        obj.keyframe_insert(data_path="location", frame=frame)
```

### 旋转操作

```python
# 旋转
bpy.ops.transform.rotate(value=math.radians(45), orient_axis='Z')

# 旋转模式
bpy.ops.object.rotation_clear(clear_delta=False)

# 设置旋转
def set_rotation(obj, euler=None, quaternion=None):
    """设置对象旋转"""
    if euler:
        obj.rotation_euler = euler
    elif quaternion:
        obj.rotation_quaternion = quaternion

def rotate_object(obj, angle, axis='Z'):
    """旋转对象"""
    if axis == 'X':
        obj.rotation_euler.x += math.radians(angle)
    elif axis == 'Y':
        obj.rotation_euler.y += math.radians(angle)
    elif axis == 'Z':
        obj.rotation_euler.z += math.radians(angle)

def reset_rotation(obj):
    """重置旋转"""
    obj.rotation_euler = (0, 0, 0)

def animate_rotation(obj, start_angle, end_angle, axis='Z', start_frame=1, end_frame=30):
    """创建旋转动画"""
    if axis == 'X':
        obj.rotation_euler.x = math.radians(start_angle)
        obj.keyframe_insert(data_path="rotation_euler", frame=start_frame)
        obj.rotation_euler.x = math.radians(end_angle)
        obj.keyframe_insert(data_path="rotation_euler", frame=end_frame)
    elif axis == 'Y':
        obj.rotation_euler.y = math.radians(start_angle)
        obj.keyframe_insert(data_path="rotation_euler", frame=start_frame)
        obj.rotation_euler.y = math.radians(end_angle)
        obj.keyframe_insert(data_path="rotation_euler", frame=end_frame)
    elif axis == 'Z':
        obj.rotation_euler.z = math.radians(start_angle)
        obj.keyframe_insert(data_path="rotation_euler", frame=start_frame)
        obj.rotation_euler.z = math.radians(end_angle)
        obj.keyframe_insert(data_path="rotation_euler", frame=end_frame)

def spin_object(obj, angle, axis='Z', steps=36):
    """旋转扫描创建几何体"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    for i in range(1, steps):
        bpy.ops.object.duplicate()
        bpy.ops.transform.rotate(value=angle / steps, orient_axis=axis)
    
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.join()
```

### 缩放操作

```python
# 缩放
bpy.ops.transform.resize(value=(2, 2, 2))

# 缩放重置
bpy.ops.object.scale_clear(clear_delta=False)

# 设置缩放
def set_scale(obj, x, y, z):
    """设置对象缩放"""
    obj.scale = (x, y, z)

def scale_object(obj, factor):
    """缩放对象"""
    obj.scale.x *= factor
    obj.scale.y *= factor
    obj.scale.z *= factor

def reset_scale(obj):
    """重置缩放"""
    obj.scale = (1, 1, 1)

def animate_scale(obj, start_scale, end_scale, start_frame=1, end_frame=30):
    """创建缩放动画"""
    obj.scale = start_scale
    obj.keyframe_insert(data_path="scale", frame=start_frame)
    obj.scale = end_scale
    obj.keyframe_insert(data_path="scale", frame=end_frame)

def scale_along_axis(obj, factor, axis='Z'):
    """沿轴缩放"""
    if axis == 'X':
        obj.scale.x *= factor
    elif axis == 'Y':
        obj.scale.y *= factor
    elif axis == 'Z':
        obj.scale.z *= factor
    elif axis == 'ALL':
        scale_object(obj, factor)
```

## 对象对齐和分布

```python
# 对齐视图
bpy.ops.object.align(bb_quality=True, align_mode='OPT_2', relative_to='OPT_1')

# 对齐到活动对象
bpy.ops.object.align(align_mode='OPT_1', relative_to='OPT_3')

# 分布
bpy.ops.object.distribute()

# 收集到光标
bpy.ops.object.cursor_on_selected()

def align_objects(objects, alignment='CENTER'):
    """对齐多个对象"""
    if not objects:
        return
    
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = objects[0]
    
    if alignment == 'CENTER':
        bpy.ops.object.align(align_mode='OPT_1', relative_to='OPT_4')
    elif alignment == 'MIN':
        bpy.ops.object.align(align_mode='OPT_4', relative_to='OPT_4')
    elif alignment == 'MAX':
        bpy.ops.object.align(align_mode='OPT_3', relative_to='OPT_4')

def distribute_horizontally(objects):
    """水平分布对象"""
    if not objects:
        return
    
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = objects[0]
    
    bpy.ops.object.distribute()

def center_objects(objects):
    """将对象居中"""
    for obj in objects:
        obj.location = (0, 0, 0)
```

## 对象可见性和显示

```python
# 隐藏
bpy.ops.object.hide_view_clear()
bpy.ops.object.hide_view_set(unselected=False)

# 选择可见性
bpy.ops.object.select大明王朝

# 可渲染性
bpy.ops.object.render_deny_clear()
bpy.ops.object.render_deny_set()

# 显示类型
bpy.ops.object.shade_flat()
bpy.ops.object.shade_smooth()

# 线框显示
bpy.ops.object.display_type_set(type='WIRE')
bpy.ops.object.display_type_set(type='SOLID')
bpy.ops.object.display_type_set(type='BOUNDS')

def hide_selected():
    """隐藏选中的对象"""
    bpy.ops.object.hide_view_set(unselected=False)

def hide_unselected():
    """隐藏未选中的对象"""
    bpy.ops.object.hide_view_set(unselected=True)

def show_all_hidden():
    """显示所有隐藏的对象"""
    bpy.ops.object.hide_view_clear()

def set_display_type(obj, display_type='SOLID'):
    """设置显示类型"""
    obj.display_type = display_type

def set_shading(obj, smooth=True):
    """设置平滑着色"""
    if smooth:
        bpy.ops.object.shade_smooth()
    else:
        bpy.ops.object.shade_flat()
```

## 高级对象操作

### 骨骼操作

```python
import bpy

# 进入编辑模式
bpy.ops.object.mode_set(mode='EDIT')

# 进入姿态模式
bpy.ops.object.mode_set(mode='POSE')

# 选择骨骼
bpy.ops.pose.select_all(action='SELECT')
bpy.ops.pose.select_all(action='DESELECT')
bpy.ops.pose.select_hierarchy(direction='PARENT', extend=True)
bpy.ops.pose.select_hierarchy(direction='CHILD', extend=True)

# 应用姿态
bpy.ops.pose.armature_apply()
bpy.ops.pose.apply_pose_use_current()

# 复制姿态
bpy.ops.pose.copy()

# 粘贴姿态
bpy.ops.pose.paste()

# 镜像姿态
bpy.ops.pose.flip(left_side=True, right_side=True)

# 重置姿态
bpy.ops.pose.rot_clear()
bpy.ops.pose.loc_clear()
bpy.ops.pose.scale_clear()

# 关键帧
bpy.ops.pose.keyframe_insert()
bpy.ops.pose.keyframe_delete()

def select_all_bones():
    """选择所有骨骼"""
    bpy.ops.pose.select_all(action='SELECT')

def deselect_all_bones():
    """取消选择所有骨骼"""
    bpy.ops.pose.select_all(action='DESELECT')

def select_bone_chain(start_bone, direction='CHILD'):
    """选择骨骼链"""
    bpy.ops.pose.select_all(action='DESELECT')
    bpy.context.active_pose_bone = start_bone
    bpy.ops.pose.select_hierarchy(direction=direction, extend=True)

def copy_pose(source_pose_obj, target_pose_obj):
    """复制姿态"""
    bpy.ops.object.select_all(action='DESELECT')
    source_pose_obj.select_set(True)
    bpy.context.view_layer.objects.active = source_pose_obj
    bpy.ops.pose.copy()
    
    bpy.ops.object.select_all(action='DESELECT')
    target_pose_obj.select_set(True)
    bpy.context.view_layer.objects.active = target_pose_obj
    bpy.ops.pose.paste()

def mirror_pose(pose_obj):
    """镜像姿态"""
    bpy.ops.object.select_all(action='DESELECT')
    pose_obj.select_set(True)
    bpy.context.view_layer.objects.active = pose_obj
    bpy.ops.pose.flip()
```

### 约束操作

```python
import bpy

def add_constraint(obj, constraint_type, name="Constraint"):
    """添加约束"""
    constraint = obj.constraints.new(type=constraint_type)
    constraint.name = name
    return constraint

def add_copy_location(obj, target, name="CopyLocation"):
    """添加位置复制约束"""
    constraint = add_constraint(obj, 'COPY_LOCATION', name)
    constraint.target = target
    constraint.influence = 1.0
    return constraint

def add_copy_rotation(obj, target, name="CopyRotation"):
    """添加旋转复制约束"""
    constraint = add_constraint(obj, 'COPY_ROTATION', name)
    constraint.target = target
    constraint.influence = 1.0
    return constraint

def add_copy_scale(obj, target, name="CopyScale"):
    """添加缩放复制约束"""
    constraint = add_constraint(obj, 'COPY_SCALE', name)
    constraint.target = target
    constraint.influence = 1.0
    return constraint

def add_track_to(obj, target, name="TrackTo"):
    """添加朝向约束"""
    constraint = add_constraint(obj, 'TRACK_TO', name)
    constraint.target = target
    constraint.track = 'Z'
    constraint.up = 'Y'
    return constraint

def add_look_at(obj, target, name="LookAt"):
    """添加注视约束"""
    constraint = add_constraint(obj, 'LOOK_AT', name)
    constraint.target = target
    constraint.track_axis = 'TRACK_Z'
    constraint.up_axis = 'UP_Y'
    return constraint

def add_follow_path(obj, path, name="FollowPath"):
    """添加路径跟随约束"""
    constraint = add_constraint(obj, 'FOLLOW_PATH', name)
    constraint.target = path
    constraint.use_curve_follow = True
    constraint.use_curve_radius = True
    return constraint

def add_ik(obj, target, name="IK", chain_count=2):
    """添加反向动力学约束"""
    constraint = add_constraint(obj, 'IK', name)
    constraint.target = target
    constraint.chain_count = chain_count
    constraint.use_tail = False
    return constraint

def remove_constraint(obj, constraint_name):
    """移除约束"""
    for constraint in obj.constraints:
        if constraint.name == constraint_name:
            obj.constraints.remove(constraint)
            return True
    return False

def list_constraints(obj):
    """列出所有约束"""
    for constraint in obj.constraints:
        print(f"约束: {constraint.name}, 类型: {constraint.type}")
```

## 修饰器操作

```python
import bpy

def add_modifier(obj, modifier_type, name="Modifier"):
    """添加修饰器"""
    modifier = obj.modifiers.new(name=name, type=modifier_type)
    return modifier

def add_subdivision(obj, name="Subdivision", levels=1):
    """添加细分表面修饰器"""
    modifier = add_modifier(obj, 'SUBSURF', name)
    modifier.levels = levels
    modifier.render_levels = levels
    return modifier

def add_array(obj, name="Array", count=5):
    """添加数组修饰器"""
    modifier = add_modifier(obj, 'ARRAY', name)
    modifier.count = count
    return modifier

def add_bevel(obj, name="Bevel", width=0.1):
    """添加倒角修饰器"""
    modifier = add_modifier(obj, 'BEVEL', name)
    modifier.width = width
    return modifier

def add_solidify(obj, name="Solidify", thickness=0.1):
    """添加实体化修饰器"""
    modifier = add_modifier(obj, 'SOLIDIFY', name)
    modifier.thickness = thickness
    return modifier

def add_screw(obj, name="Screw", angle=360):
    """添加螺旋修饰器"""
    modifier = add_modifier(obj, 'SCREW', name)
    modifier.angle = math.radians(angle)
    return modifier

def add_skin(obj, name="Skin"):
    """添加皮肤修饰器"""
    modifier = add_modifier(obj, 'SKIN', name)
    return modifier

def add_decimate(obj, name="Decimate", ratio=0.5):
    """添加三角面精简修饰器"""
    modifier = add_modifier(obj, 'DECIMATE', name)
    modifier.ratio = ratio
    return modifier

def add_cast(obj, name="Cast", factor=1.0):
    """添加投射修饰器"""
    modifier = add_modifier(obj, 'CAST', name)
    modifier.factor = factor
    return modifier

def add_simple_deform(obj, name="SimpleDeform", angle=math.radians(45)):
    """添加简单变形修饰器"""
    modifier = add_modifier(obj, 'SIMPLE_DEFORM', name)
    modifier.angle = angle
    return modifier

def add_displace(obj, texture=None, name="Displace", strength=0.5):
    """添加置换修饰器"""
    modifier = add_modifier(obj, 'DISPLACE', name)
    modifier.texture = texture
    modifier.strength = strength
    return modifier

def add_wireframe(obj, name="Wireframe", thickness=0.05):
    """添加线框修饰器"""
    modifier = add_modifier(obj, 'WIREFRAME', name)
    modifier.thickness = thickness
    return modifier

def apply_modifiers(obj):
    """应用所有修饰器"""
    mesh = obj.to_mesh()
    obj.data = mesh

def remove_modifier(obj, modifier_name):
    """移除修饰器"""
    for modifier in obj.modifiers:
        if modifier.name == modifier_name:
            obj.modifiers.remove(modifier)
            return True
    return False

def list_modifiers(obj):
    """列出所有修饰器"""
    for modifier in obj.modifiers:
        print(f"修饰器: {modifier.name}, 类型: {modifier.type}")
```

## 对象工程面板

```python
class ObjectEngineeringPanel(bpy.types.Panel):
    """对象工程面板"""
    bl_label = "对象工具"
    bl_idname = "OBJECT_PT_engineering_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '对象'
    
    def draw(self, context):
        layout = self.layout
        obj = context.object
        
        if not obj:
            layout.label(text="请选择对象")
            return
        
        layout.label(text=f"对象: {obj.name}")
        layout.label(text=f"类型: {obj.type}")
        layout.label(f"位置: ({obj.location.x:.2f}, {obj.location.y:.2f}, {obj.location.z:.2f})")
        
        layout.separator()
        layout.label(text="选择:")
        
        row = layout.row(align=True)
        row.operator("object.select_all", text="全选").action='SELECT'
        row.operator("object.select_all", text="反选").action='INVERT'
        
        row = layout.row()
        row.operator("object.select_more", text="更多")
        row.operator("object.select_less", text="更少")
        
        layout.separator()
        layout.label(text="变换:")
        
        row = layout.row(align=True)
        row.operator("object.transform_apply", text="应用").location=True
        row.operator("object.location_clear", text="清除位置")
        
        row = layout.row()
        row.operator("object.rotation_clear", text="清除旋转")
        row.operator("object.scale_clear", text="清除缩放")
        
        layout.separator()
        layout.label(text="显示:")
        
        row = layout.row()
        row.operator("object.shade_smooth", text="平滑")
        row.operator("object.shade_flat", text="平滑")
        
        layout.separator()
        layout.label(text="删除:")
        
        row = layout.row()
        row.operator("object.delete", text="删除").use_global=False
        row.operator("object.delete", text="全局删除").use_global=True

class ObjectCollectionPanel(bpy.types.Panel):
    """对象集合面板"""
    bl_label = "集合管理"
    bl_idname = "OBJECT_PT_collection_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '对象'
    
    def draw(self, context):
        layout = self.layout
        obj = context.object
        
        if not obj:
            layout.label(text="请选择对象")
            return
        
        layout.label(text=f"当前集合: {context.scene.active_collection.name}")
        
        layout.separator()
        layout.label(text="集合操作:")
        
        row = layout.row()
        row.operator("object.collection_add", text="添加集合")
        row.operator("object.move_to_collection", text="移动到")
```

## 最佳实践

### 1. 对象命名规范

```python
def apply_object_naming(prefix, objects):
    """应用命名规范"""
    for i, obj in enumerate(objects):
        obj.name = f"{prefix}_{i:03d}"

def get_object_by_name(name):
    """按名称获取对象"""
    return bpy.data.objects.get(name)

def get_objects_by_type(obj_type):
    """按类型获取对象"""
    return [obj for obj in bpy.data.objects if obj.type == obj_type]

def get_selected_objects():
    """获取选中的对象"""
    return bpy.context.selected_objects

def get_active_object():
    """获取活动对象"""
    return bpy.context.active_object
```

### 2. 对象选择优化

```python
def batch_select(objects):
    """批量选择对象"""
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        obj.select_set(True)
    if objects:
        bpy.context.view_layer.objects.active = objects[0]

def select_objects_in_viewport():
    """选择视口中的对象"""
    visible_objects = []
    for obj in bpy.data.objects:
        if obj.visible_get():
            visible_objects.append(obj)
    batch_select(visible_objects)
```

### 3. 对象变换优化

```python
def transform_objects(objects, location=None, rotation=None, scale=None):
    """批量变换对象"""
    for obj in objects:
        if location:
            obj.location = location
        if rotation:
            obj.rotation_euler = rotation
        if scale:
            obj.scale = scale

def keyframe_objects(objects, data_path, frame):
    """批量关键帧"""
    for obj in objects:
        obj.keyframe_insert(data_path=data_path, frame=frame)
```

## 常见问题

### Q: 对象无法选择
A: 检查对象是否被隐藏或排除于视口，确保在正确的集合中。

### Q: 变换不生效
A: 检查对象是否有父级约束或修饰器影响，尝试应用变换。

### Q: 修饰器不显示
A: 检查修饰器是否被禁用，切换到正确模式查看效果。

### Q: 约束不工作
A: 检查约束目标是否存在且正确设置，确保约束未被禁用。

## 相关模块

- [bpy.ops.mesh](bpy_ops_detailed_module.md) - 网格操作
- [bpy.ops.armature](bpy_ops_armature_module.md) - 骨骼操作
- [bpy.ops.curve](bpy_ops_curve_module.md) - 曲线操作
- [bpy.ops.pose](bpy_ops_pose_module.md) - 姿态操作
- [bpy.types](bpy_types_detailed_module.md) - 数据类型
