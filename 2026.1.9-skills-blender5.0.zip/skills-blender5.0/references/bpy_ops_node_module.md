# bpy.ops.node 模块

节点操作模块，用于在节点编辑器中创建和管理节点。

## 概述

bpy.ops.node 模块包含用于在各种节点编辑器（材质、合成、几何节点）中操作节点的运算符。这些运算符控制节点的创建、连接、编辑和布局。

## 常用操作

### 节点创建

```python
import bpy

# 添加节点
bpy.ops.node.add_node(type='ShaderNodeBsdfDiffuse', use_transform=True)

# 添加图像节点
bpy.ops.node.add_node(type='ShaderNodeTexImage', use_transform=True)

# 添加混合节点
bpy.ops.node.add_node(type='ShaderNodeMixShader', use_transform=True)

# 添加输出节点
bpy.ops.node.add_node(type='ShaderNodeOutputMaterial', use_transform=True)

# 添加组
bpy.ops.node.group_make()

# 添加组输入
bpy.ops.node.group_input_add()

# 添加组输出
bpy.ops.node.group_output_add()
```

### 节点选择

```python
# 全选
bpy.ops.node.select_all(action='SELECT')
bpy.ops.node.select_all(action='DESELECT')
bpy.ops.node.select_all(action='INVERT')

# 选择节点
bpy.ops.node.select(extend=False)

# 取消选择
bpy.ops.node.select(extend=False, deselect_all=True)

# 选择同类型
bpy.ops.node.select_same_type()

# 选择连接
bpy.ops.node.select_linked()

# 选择输入输出
bpy.ops.node.select_inactive()
bpy.ops.node.select_active()

# 边界框选择
bpy.ops.node.select_border(gesture_mode=0, extend=False)

# 套索选择
bpy.ops.node.select_lasso(path=None, mode='SET')
```

### 节点操作

```python
# 删除节点
bpy.ops.node.delete()

# 剪切节点
bpy.ops.node.cut(linked=False)

# 复制节点
bpy.ops.node.duplicate(linked=False)

# 移动节点
bpy.ops.node.move(type='CHECK_LINKS')

# 粘贴节点
bpy.ops.node.paste()
```

### 链接操作

```python
# 链接节点
bpy.ops.node.link(
    from_node='Diffuse',
    from_socket='BSDF',
    to_node='Mix',
    to_socket='Fac'
)

# 断开链接
bpy.ops.node.link(
    from_node='Diffuse',
    from_socket='BSDF',
    to_node='Mix',
    to_socket='Fac'
)

# 断开所有链接
bpy.ops.node.links_cut(path=None)

# 重新链接
bpy.ops.node.reconnect_all()
```

### 节点编辑

```python
# 重命名节点
bpy.ops.node.rename(name='NewName')

# 隐藏节点
bpy.ops.node.hide_toggle()

# 展开节点
bpy.ops.node.node_preview()

# 缩放节点
bpy.ops.node.resize()
```

### 视图操作

```python
# 框选缩放
bpy.ops.node.view_selected()

# 查看全部
bpy.ops.node.view_all()

# 放大
bpy.ops.node.zoom_in()

# 缩小
bpy.ops.node.zoom_out()

# 背景选择
bpy.ops.node.backimage_add(filepath='//image.png')

# 清除背景
bpy.ops.node.backimage_remove()
```

### 侧边栏

```python
# 切换侧边栏
bpy.ops.node.sidebar_toggle()

# 显示属性
bpy.ops.node.properties()

# 显示节点颜色
bpy.ops.node.options_toggle()
```

### 搜索

```python
# 搜索节点
bpy.ops.node.search(

# 添加到收藏
bpy.ops.node.add_favorites()
```

## 实际应用示例

### 创建材质节点设置

```python
def create_material_nodes(material_name='NewMaterial'):
    """创建新材质的节点"""
    # 创建材质
    mat = bpy.data.materials.new(name=material_name)
    mat.use_nodes = True
    tree = mat.node_tree
    
    # 清理默认节点
    for node in tree.nodes:
        tree.nodes.remove(node)
    
    # 创建Principled BSDF
    principled = tree.nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (0, 0)
    
    # 创建输出
    output = tree.nodes.new('ShaderNodeOutputMaterial')
    output.location = (300, 0)
    
    # 连接节点
    tree.links.new(principled.outputs['BSDF'], output.inputs['Surface'])
    
    return mat
```

### 创建程序化纹理

```python
def create_procedural_texture():
    """创建程序化纹理节点"""
    # 获取活动材质
    mat = bpy.context.active_object.active_material
    tree = mat.node_tree
    
    # 创建坐标
    tex_coord = tree.nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (-600, 0)
    
    # 创建映射
    mapping = tree.nodes.new('ShaderNodeMapping')
    mapping.location = (-400, 0)
    
    # 创建噪声
    noise = tree.nodes.new('ShaderNodeTexNoise')
    noise.location = (-200, 0)
    noise.noise_scale = 5.0
    
    # 创建颜色渐变
    gradient = tree.nodes.new('ShaderNodeValToRGB')
    gradient.location = (0, 0)
    
    # 创建Principled BSDF
    principled = tree.nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (200, 0)
    
    # 创建输出
    output = tree.nodes.new('ShaderNodeOutputMaterial')
    output.location = (400, 0)
    
    # 连接节点
    tree.links.new(tex_coord.outputs['Generated'], mapping.inputs['Vector'])
    tree.links.new(mapping.outputs['Vector'], noise.inputs['Vector'])
    tree.links.new(noise.outputs['Fac'], gradient.inputs['Fac'])
    tree.links.new(gradient.outputs['Color'], principled.inputs['Base Color'])
    tree.links.new(principled.outputs['BSDF'], output.inputs['Surface'])
    
    return tree
```

### 创建混合材质

```python
def create_blended_material(mat_a, mat_b, mix_factor=0.5):
    """创建两种材质的混合"""
    # 获取第一个材质的节点树
    tree = mat_a.node_tree
    
    # 创建混合节点
    mix = tree.nodes.new('ShaderNodeMixShader')
    mix.location = (300, 0)
    mix.inputs['Fac'].default_value = mix_factor
    
    # 清理节点并重新连接
    output = tree.nodes.get('Material Output')
    
    # 假设两个材质已存在
    bsdf_a = tree.nodes.get('Principled BSDF')
    bsdf_b = mat_b.node_tree.nodes.get('Principled BSDF')
    
    if bsdf_b:
        bsdf_b_copy = tree.nodes.new('ShaderNodeBsdfPrincipled')
        bsdf_b_copy.location = (-200, 200)
        bsdf_b_copy.inputs['Base Color'].default_value = bsdf_b.inputs['Base Color'].default_value
        
        tree.links.new(bsdf_b_copy.outputs['BSDF'], mix.inputs[2])
    
    tree.links.new(bsdf_a.outputs['BSDF'], mix.inputs[1])
    tree.links.new(mix.outputs['Shader'], output.inputs['Surface'])
    
    return mix
```

### 创建几何节点设置

```python
def setup_geometry_nodes():
    """设置几何节点"""
    # 添加几何节点修改器
    obj = bpy.context.active_object
    geo_mod = obj.modifiers.new(name='GeometryNodes', type='NODES')
    
    # 获取节点组
    node_group = geo_mod.node_group
    
    # 清理默认节点
    for node in node_group.nodes:
        node_group.nodes.remove(node)
    
    # 创建组输入
    group_input = node_group.nodes.new('NodeGroupInput')
    group_input.location = (-200, 0)
    
    # 创建组输出
    group_output = node_group.nodes.new('NodeGroupOutput')
    group_output.location = (400, 0)
    
    # 创建几何节点
    set_position = node_group.nodes.new('GeometryNodeSetPosition')
    set_position.location = (100, 0)
    
    # 创建输入属性
    position_in = node_group.interface.new_socket(name='Position', in_out='INPUT')
    position_in.socket_type = 'NodeSocketVector')
    
    # 连接节点
    node_group.links.new(group_input.outputs['Position'], set_position.inputs['Position'])
    node_group.links.new(set_position.outputs['Geometry'], group_output.inputs['Geometry'])
    
    return node_group
```

### 批量更新节点颜色

```python
def batch_update_node_colors(material, color_map):
    """批量更新节点颜色"""
    tree = material.node_tree
    
    for node in tree.nodes:
        if node.name in color_map:
            node.color = color_map[node.name]
```

### 创建节点组

```python
def create_node_group():
    """创建可复用节点组"""
    # 创建新节点组
    group = bpy.data.node_groups.new(name='CustomGroup', type='SHADER')
    tree = group.nodes
    
    # 清理默认节点
    for node in tree.nodes:
        tree.nodes.remove(node)
    
    # 创建输入
    group_input = tree.nodes.new('NodeGroupInput')
    group_input.location = (-200, 0)
    
    # 创建输出
    group_output = tree.nodes.new('NodeGroupOutput')
    group_output.location = (300, 0)
    
    # 添加自定义输入
    group.interface.new_socket(name='Color', in_out='INPUT', socket_type='NodeSocketColor')
    group.interface.new_socket(name='Fac', in_out='INPUT', socket_type='NodeSocketFloat')
    
    # 添加自定义输出
    group.interface.new_socket(name='Shader', in_out='OUTPUT', socket_type='NodeSocketShader')
    
    # 创建节点
    principled = tree.nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (0, 0)
    
    # 连接节点
    tree.links.new(group_input.outputs['Color'], principled.inputs['Base Color'])
    tree.links.new(principled.outputs['BSDF'], group_output.inputs['Shader'])
    
    return group
```

## 使用场景

- **材质创建**：使用节点创建复杂材质
- **程序化纹理**：创建可调节的纹理效果
- **几何节点**：程序化修改几何体
- **合成设置**：创建后期处理效果
- **节点复用**：创建自定义节点组
- **批处理**：自动化节点操作

## 注意事项

- 节点操作需要正确的节点类型名称
- 链接操作需要指定正确的Socket
- 节点编辑器有多种类型（材质、合成、几何）
- 节点组可以跨材质复用
- 大量节点影响性能
- 搜索功能可以帮助快速找到节点
