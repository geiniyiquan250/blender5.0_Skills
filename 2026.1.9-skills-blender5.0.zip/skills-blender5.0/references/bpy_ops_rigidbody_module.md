# bpy.ops.rigidbody 模块

刚体物理模拟操作模块，用于配置和管理刚体物理模拟。

## 概述

bpy.ops.rigidbody 模块包含用于配置刚体物理模拟的运算符。刚体模拟可以创建真实的物理交互效果，如碰撞、重力、摩擦等。

## 常用操作

### 刚体添加

```python
import bpy

# 添加活动刚体
bpy.ops.object.rigidbody_add(type='ACTIVE')

# 添加被动刚体
bpy.ops.object.rigidbody_add(type='PASSIVE')

# 删除刚体
bpy.ops.object.rigidbody_remove()
```

### 刚体类型

```python
# 设置为活动刚体
bpy.ops.rigidbody.object_settings_set(type='ACTIVE')

# 设置为被动刚体
bpy.ops.rigidbody.object_settings_set(type='PASSIVE')

# 复制刚体设置
bpy.ops.rigidbody.copy()
```

### 质量设置

```python
# 设置质量
bpy.ops.rigidbody.mass_set(mass=1.0)

# 设置碰撞形状
bpy.ops.rigidbody.collision_shape_set(type='MESH')

# 设置为凸包
bpy.ops.rigidbody.collision_shape_set(type='CONVEX_HULL')

# 设置为包围盒
bpy.ops.rigidbody.collision_shape_set(type='BOX')

# 设置为球体
bpy.ops.rigidbody.collision_shape_set(type='SPHERE')

# 设置为胶囊体
bpy.ops.rigidbody.collision_shape_set(type='CAPSULE')
```

### 物理属性

```python
# 设置摩擦力
bpy.ops.rigidbody.friction_set(friction=0.5)

# 设置弹性
bpy.ops.rigidbody.restitution_set(restitution=0.5)

# 设置线性阻尼
bpy.ops.rigidbody.linear_damping_set(damping=0.04)

# 设置角度阻尼
bpy.ops.rigidbody.angular_damping_set(damping=0.04)

# 设置源起始帧
bpy.ops.rigidbody.source_start_set(start=1)

# 设置源结束帧
bpy.ops.rigidbody.source_end_set(end=250)
```

### 约束操作

```python
# 添加约束
bpy.ops.rigidbody.constraint_add()

# 添加点约束
bpy.ops.rigidbody.constraint_add(type='POINT')

# 添加铰链约束
bpy.ops.rigidbody.constraint_add(type='HINGE')

# 添加滑块约束
bpy.ops.rigidbody.constraint_add(type='SLIDER')

# 添加活塞约束
bpy.ops.rigidbody.constraint_add(type='PISTON')

# 添加通用约束
bpy.ops.rigidbody.constraint_add(type='GENERIC')

# 添加通用铰链约束
bpy.ops.rigidbody.constraint_add(type='GENERIC_HINGE')

# 添加通用滑块约束
bpy.ops.rigidbody.constraint_add(type='GENERIC_SLIDER')

# 删除约束
bpy.ops.rigidbody.constraint_remove()
```

### 约束设置

```python
# 设置禁用碰撞
bpy.ops.rigidbody.constraint_disable_collisions_set(disable=True)

# 设置运动学
bpy.ops.rigidbody.constraint_set('type', motion_type='KINEMATIC')
```

### 缓存操作

```python
# 创建缓存
bpy.ops.rigidbody.cache_create()

# 删除缓存
bpy.ops.rigidbody.cache_delete()

# 清除缓存
bpy.ops.rigidbody.cache_clear()
```

### 模拟控制

```python
# 开始模拟
bpy.ops.rigidbody.simulate()

# 停止模拟
bpy.ops.rigidbody.stop_simulation()

# 重置模拟
bpy.ops.rigidbody.reset_simulation()

# 烘焙模拟
bpy.ops.rigidbody.bake()

# 烘焙到关键帧
bpy.ops.rigidbody.bake_to_keyframes()
```

## 实际应用示例

### 创建物理场景

```python
def setup_physics_scene():
    """设置物理场景"""
    # 创建地面
    bpy.ops.mesh.primitive_plane_add(size=20)
    ground = bpy.context.active_object
    ground.name = 'Ground'
    
    # 地面设为被动刚体
    bpy.ops.object.rigidbody_add(type='PASSIVE')
    ground.rigid_body.collision_shape = 'BOX'
    ground.rigid_body.friction = 0.5
    ground.rigid_body.restitution = 0.2
    
    # 创建立方体
    bpy.ops.mesh.primitive_cube_add(size=1)
    cube = bpy.context.active_object
    cube.name = 'Cube'
    cube.location = (0, 0, 5)
    
    # 立方体设为活动刚体
    bpy.ops.object.rigidbody_add(type='ACTIVE')
    cube.rigid_body.mass = 1.0
    cube.rigid_body.collision_shape = 'BOX'
    cube.rigid_body.friction = 0.5
    cube.rigid_body.restitution = 0.3
    
    return ground, cube
```

### 创建堆叠物体

```python
def create_stack(object_count=10):
    """创建堆叠物体"""
    objects = []
    
    for i in range(object_count):
        bpy.ops.mesh.primitive_cube_add(size=1)
        obj = bpy.context.active_object
        obj.name = f'StackCube_{i}'
        obj.location = (0, 0, 0.5 + i * 1.05)
        
        bpy.ops.object.rigidbody_add(type='ACTIVE')
        obj.rigid_body.mass = 1.0
        obj.rigid_body.friction = 0.8
        obj.rigid_body.restitution = 0.1
        
        objects.append(obj)
    
    return objects
```

### 创建球体下落

```python
def create_falling_balls(ball_count=20, area_size=10):
    """创建球体下落动画"""
    import random
    
    balls = []
    
    for i in range(ball_count):
        bpy.ops.mesh.primitive_uv_sphere_add(radius=0.3)
        ball = bpy.context.active_object
        ball.name = f'Ball_{i}'
        
        x = random.uniform(-area_size/2, area_size/2)
        y = random.uniform(-area_size/2, area_size/2)
        z = random.uniform(5, 20)
        
        ball.location = (x, y, z)
        
        bpy.ops.object.rigidbody_add(type='ACTIVE')
        ball.rigid_body.mass = 0.5
        ball.rigid_body.collision_shape = 'SPHERE'
        ball.rigid_body.friction = 0.3
        ball.rigid_body.restitution = 0.6
        
        balls.append(ball)
    
    return balls
```

### 创建摆锤

```python
def create_pendulum(pivot_obj, bob_obj, length=2.0):
    """创建摆锤"""
    # 设置枢轴
    bpy.ops.object.rigidbody_add(type='PASSIVE')
    pivot_obj.rigid_body.collision_shape = 'SPHERE'
    pivot_obj.rigid_body.kinematic = True
    pivot_obj.location = (0, 0, 5)
    
    # 设置摆锤
    bpy.ops.object.rigidbody_add(type='ACTIVE')
    bob_obj.rigid_body.mass = 1.0
    bob_obj.collision_shape = 'SPHERE'
    bob_obj.location = (0, -length, 5)
    
    # 添加铰链约束
    bpy.ops.rigidbody.constraint_add(type='HINGE')
    constraint = bpy.context.active_object
    
    # 设置约束
    constraint.rigid_body_constraint.type = 'HINGE'
    constraint.rigid_body_constraint.object1 = pivot_obj
    constraint.rigid_body_constraint.object2 = bob_obj
    
    return constraint
```

### 创建碰撞场景

```python
def create_collision_scene(obj1, obj2):
    """创建碰撞场景"""
    # 设置物体1
    obj1.location = (-3, 0, 2)
    bpy.ops.object.rigidbody_add(type='ACTIVE')
    obj1.rigid_body.mass = 2.0
    obj1.rigid_body.collision_shape = 'BOX'
    obj1.rigid_body.friction = 0.3
    obj1.rigid_body.restitution = 0.8
    
    # 设置物体2
    obj2.location = (3, 0, 2)
    bpy.ops.object.rigidbody_add(type='ACTIVE')
    obj2.rigid_body.mass = 2.0
    obj2.rigid_body.collision_shape = 'BOX'
    obj2.rigid_body.friction = 0.3
    obj2.rigid_body.restitution = 0.8
    
    return obj1, obj2
```

### 创建滑梯

```python
def create_slide(start_height=5, slope_length=10, slope_angle=30):
    """创建滑梯"""
    import math
    
    # 创建斜坡
    bpy.ops.mesh.primitive_plane_add(size=slope_length)
    slide = bpy.context.active_object
    slide.name = 'Slide'
    
    # 旋转斜坡
    slope_rad = math.radians(slope_angle)
    slide.rotation_euler = (slope_rad, 0, 0)
    slide.location = (0, -slope_length/2 * math.cos(slope_rad), start_height - slope_length/2 * math.sin(slope_rad))
    
    # 设为被动刚体
    bpy.ops.object.rigidbody_add(type='PASSIVE')
    slide.rigid_body.collision_shape = 'MESH'
    slide.rigid_body.friction = 0.1
    slide.rigid_body.restitution = 0.1
    
    # 创建滑动物体
    bpy.ops.mesh.primitive_sphere_add(radius=0.2)
    slider = bpy.context.active_object
    slider.name = 'Slider'
    slider.location = (0, 0, start_height + 1)
    
    # 设为活动刚体
    bpy.ops.object.rigidbody_add(type='ACTIVE')
    slider.rigid_body.mass = 0.5
    slider.rigid_body.collision_shape = 'SPHERE'
    slider.rigid_body.friction = 0.1
    slider.rigid_body.restitution = 0.3
    
    return slide, slider
```

### 创建多米诺骨牌

```python
def create_domino_chain(start_pos=(0, 0, 0.5), count=20, spacing=0.8):
    """创建多米诺骨牌"""
    dominoes = []
    
    for i in range(count):
        bpy.ops.mesh.primitive_cube_add(size=1)
        domino = bpy.context.active_object
        domino.name = f'Domino_{i}'
        
        x = start_pos[0] + i * spacing
        y = start_pos[1]
        z = start_pos[2]
        
        domino.location = (x, y, z)
        
        # 缩放为骨牌形状
        domino.scale = (0.1, 0.5, 1.0)
        
        # 设为活动刚体
        bpy.ops.object.rigidbody_add(type='ACTIVE')
        domino.rigid_body.mass = 0.5
        domino.rigid_body.collision_shape = 'BOX'
        domino.rigid_body.friction = 0.3
        domino.rigid_body.restitution = 0.2
        
        dominoes.append(domino)
    
    return dominoes
```

## 使用场景

- **物理碰撞**：创建真实的物体碰撞效果
- **堆叠场景**：创建稳定的堆叠结构
- **下落动画**：创建物体下落和弹跳
- **机械系统**：创建连杆、摆锤等机械结构
- **游戏物理**：游戏中的物理交互效果
- **破坏效果**：创建物理破坏模拟
- **动画辅助**：为动画提供物理基础

## 注意事项

- 刚体模拟需要仔细设置碰撞形状
- 质量影响物体的运动行为
- 摩擦力和弹性影响碰撞效果
- 约束可以连接多个物体
- 缓存管理对于长模拟很重要
- 被动刚体不会移动但可以碰撞
- 活动刚体受物理影响
- 运动学刚体可以手动控制
- 烘焙可以加速最终渲染
