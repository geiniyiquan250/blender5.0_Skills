# bpy.ops.export_scene - Alembic导出操作模块

Blender Alembic文件导出操作符，用于将场景导出为Alembic（.abc）格式。

## 概述

`bpy.ops.export_scene.abc` 模块提供用于将Blender场景导出为Alembic格式的功能，支持几何体、动画和材质的高保真导出。

## 核心功能

### 基础导出

```python
import bpy

# 导出Alembic文件
bpy.ops.export_scene.abc(
    filepath='//model.abc',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    export_selected=False,
    export_uv=True,
    export_normals=True,
    export_children=True,
    export_parent_curves=True,
    use_instancing=True,
    export_global_scale=1.0,
    axis_forward='Z',
    axis_up='Y',
    apply_subdiv=False,
    export_anim=True,
    export_anim_named_stashes=False,
    export_anim_only=False,
    export_anim_use_frame_range=True,
    export_anim_use_nla_strips=True,
    export_anim_free_image_path=False,
    export_visibility=True,
    export_cameras=True,
    export_lights=True,
    export_materials=True,
    export_packed_images=True,
    export_texture_compaction=True,
    custom_props=True,
    export_gps_shader=True
)
```

### 导出范围

```python
# 只导出选中对象
bpy.ops.export_scene.abc(
    filepath='//selected.abc',
    export_selected=True
)

# 导出所有对象
bpy.ops.export_scene.abc(
    filepath='//all.abc',
    export_selected=False
)
```

### 几何体导出

```python
# 导出UV
bpy.ops.export_scene.abc(
    filepath='//uv.abc',
    export_uv=True
)

# 不导出UV
bpy.ops.export_scene.abc(
    filepath='//no_uv.abc',
    export_uv=False
)

# 导出法线
bpy.ops.export_scene.abc(
    filepath='//normals.abc',
    export_normals=True
)

# 不导出法线
bpy.ops.export_scene.abc(
    filepath='//no_normals.abc',
    export_normals=False
)

# 导出子对象
bpy.ops.export_scene.abc(
    filepath='//children.abc',
    export_children=True
)

# 不导出子对象
bpy.ops.export_scene.abc(
    filepath='//no_children.abc',
    export_children=False
)
```

### 曲线导出

```python
# 导出父级曲线
bpy.ops.export_scene.abc(
    filepath='//curves.abc',
    export_parent_curves=True
)

# 不导出父级曲线
bpy.ops.export_scene.abc(
    filepath='//no_curves.abc',
    export_parent_curves=False
)
```

### 实例导出

```python
# 使用实例
bpy.ops.export_scene.abc(
    filepath='//instanced.abc',
    use_instancing=True
)

# 不使用实例
bpy.ops.export_scene.abc(
    filepath='//no_instanced.abc',
    use_instancing=False
)
```

### 缩放设置

```python
# 设置全局缩放
bpy.ops.export_scene.abc(
    filepath='//scaled.abc',
    export_global_scale=1.0
)

# 缩放10倍
bpy.ops.export_scene.abc(
    filepath='//scaled.abc',
    export_global_scale=10.0
)
```

### 坐标轴设置

```python
# Blender默认轴向
bpy.ops.export_scene.abc(
    filepath='//model.abc',
    axis_forward='Z',
    axis_up='Y'
)

# 其他轴向组合
bpy.ops.export_scene.abc(
    filepath='//model.abc',
    axis_forward='-Z',
    axis_up='Y'
)
```

### 细分设置

```python
# 应用细分
bpy.ops.export_scene.abc(
    filepath='//subdiv.abc',
    apply_subdiv=True
)

# 不应用细分
bpy.ops.export_scene.abc(
    filepath='//no_subdiv.abc',
    apply_subdiv=False
)
```

### 动画设置

```python
# 导出动画
bpy.ops.export_scene.abc(
    filepath='//anim.abc',
    export_anim=True
)

# 不导出动画
bpy.ops.export_scene.abc(
    filepath='//static.abc',
    export_anim=False
)

# 只导出动画
bpy.ops.export_scene.abc(
    filepath='//anim_only.abc',
    export_anim=True,
    export_anim_only=True
)

# 导出NLA轨道
bpy.ops.export_scene.abc(
    filepath='//nla.abc',
    export_anim=True,
    export_anim_use_nla_strips=True
)

# 导出命名缓存
bpy.ops.export_scene.abc(
    filepath='//stashes.abc',
    export_anim=True,
    export_anim_named_stashes=True
)
```

### 帧范围

```python
# 使用帧范围
bpy.ops.export_scene.abc(
    filepath='//range.abc',
    export_anim=True,
    export_anim_use_frame_range=True
)

# 设置自定义帧范围
# 通过scene.frame_start和scene.frame_end设置
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = 100
```

### 能见度导出

```python
# 导出能见度
bpy.ops.export_scene.abc(
    filepath='//visibility.abc',
    export_visibility=True
)

# 不导出能见度
bpy.ops.export_scene.abc(
    filepath='//no_visibility.abc',
    export_visibility=False
)
```

### 相机和灯光

```python
# 导出相机
bpy.ops.export_scene.abc(
    filepath='//cameras.abc',
    export_cameras=True
)

# 不导出相机
bpy.ops.export_scene.abc(
    filepath='//no_cameras.abc',
    export_cameras=False
)

# 导出灯光
bpy.ops.export_scene.abc(
    filepath='//lights.abc',
    export_lights=True
)

# 不导出灯光
bpy.ops.export_scene.abc(
    filepath='//no_lights.abc',
    export_lights=False
)
```

### 材质和纹理

```python
# 导出材质
bpy.ops.export_scene.abc(
    filepath='//materials.abc',
    export_materials=True
)

# 不导出材质
bpy.ops.export_scene.abc(
    filepath='//no_materials.abc',
    export_materials=False
)

# 打包图像
bpy.ops.export_scene.abc(
    filepath='//packed.abc',
    export_packed_images=True
)

# 不打包图像
bpy.ops.export_scene.abc(
    filepath='//no_packed.abc',
    export_packed_images=False
)

# 纹理压缩
bpy.ops.export_scene.abc(
    filepath='//compact.abc',
    export_texture_compaction=True
)
```

### 自定义属性

```python
# 导出自定义属性
bpy.ops.export_scene.abc(
    filepath='//props.abc',
    custom_props=True
)

# 不导出自定义属性
bpy.ops.export_scene.abc(
    filepath='//no_props.abc',
    custom_props=False
)
```

### GPU着色器

```python
# 导出GPU着色器
bpy.ops.export_scene.abc(
    filepath='//shader.abc',
    export_gps_shader=True
)

# 不导出GPU着色器
bpy.ops.export_scene.abc(
    filepath='//no_shader.abc',
    export_gps_shader=False
)
```

## 实用函数

```python
def export_abc_model(filepath, apply_modifiers=True):
    """导出Alembic模型"""
    bpy.ops.export_scene.abc(
        filepath=filepath,
        export_selected=True,
        export_uv=True,
        export_normals=True,
        export_anim=False,
        export_cameras=True,
        export_lights=True
    )

def export_abc_animation(filepath, start_frame=None, end_frame=None):
    """导出Alembic动画"""
    if start_frame is not None:
        bpy.context.scene.frame_start = start_frame
    if end_frame is not None:
        bpy.context.scene.frame_end = end_frame
    
    bpy.ops.export_scene.abc(
        filepath=filepath,
        export_selected=True,
        export_uv=True,
        export_normals=True,
        export_anim=True,
        export_anim_use_frame_range=True,
        export_anim_use_nla_strips=True,
        export_cameras=True,
        export_lights=True
    )

def export_abc_for_vfx(filepath):
    """导出Alembic用于VFX"""
    bpy.ops.export_scene.abc(
        filepath=filepath,
        export_selected=True,
        export_uv=True,
        export_normals=True,
        export_children=True,
        use_instancing=True,
        export_anim=True,
        export_anim_use_frame_range=True,
        export_anim_use_nla_strips=True,
        export_visibility=True,
        export_cameras=True,
        export_lights=True,
        export_materials=True,
        custom_props=True
    )

def export_abc_full_scene(filepath):
    """导出完整场景"""
    bpy.ops.export_scene.abc(
        filepath=filepath,
        export_selected=False,
        export_uv=True,
        export_normals=True,
        export_children=True,
        export_anim=True,
        export_anim_use_frame_range=True,
        export_visibility=True,
        export_cameras=True,
        export_lights=True,
        export_materials=True,
        custom_props=True
    )

def batch_export_abc(objects, output_dir):
    """批量导出Alembic"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for obj in objects:
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        
        filepath = os.path.join(output_dir, f'{obj.name}.abc')
        bpy.ops.export_scene.abc(
            filepath=filepath,
            export_selected=True,
            export_uv=True,
            export_normals=True,
            export_anim=True
        )
```

## 常见问题排查

### 导出文件过大
```python
# 检查对象数
meshes = [obj for obj in bpy.data.objects if obj.type == 'MESH']
print(f"网格数: {len(meshes)}")

# 检查顶点总数
total_verts = sum(len(obj.data.vertices) for obj in meshes)
print(f"总顶点数: {total_verts}")

# 建议优化
# 1. 减少导出精度
# 2. 使用实例
# 3. 禁用UV和法线导出
bpy.ops.export_scene.abc(
    filepath='//optimized.abc',
    export_uv=False,
    export_normals=False
)
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")
    if obj.animation_data.action:
        print(f"帧范围: {obj.animation_data.action.frame_range}")

# 检查NLA轨道
if obj.animation_data:
    for track in obj.animation_data.nla_tracks:
        print(f"NLA轨道: {track.name}")

# 确保导出动画选项
bpy.ops.export_scene.abc(
    filepath='//anim.abc',
    export_anim=True,
    export_anim_use_frame_range=True,
    export_anim_use_nla_strips=True
)
```

### 材质丢失
```python
# 检查材质
obj = bpy.context.active_object
print(f"材质数: {len(obj.data.materials) if obj.data else 0}")

# 确保导出材质
bpy.ops.export_scene.abc(
    filepath='//mat.abc',
    export_selected=True,
    export_materials=True,
    export_packed_images=True
)
```

### 坐标轴问题
```python
# 检查导出后的方向
# 在第三方软件中打开ABC文件检查

# 尝试不同轴向
bpy.ops.export_scene.abc(
    filepath='//zy.abc',
    axis_forward='Z',
    axis_up='Y'
)

bpy.ops.export_scene.abc(
    filepath='//-zy.abc',
    axis_forward='-Z',
    axis_up='Y'
)
```

### 性能问题
```python
# 检查帧范围
print(f"帧范围: {bpy.context.scene.frame_start} - {bpy.context.scene.frame_end}")

# 减少帧数
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = 100

# 禁用高精度选项
bpy.ops.export_scene.abc(
    filepath='//fast.abc',
    export_uv=False,
    export_normals=False,
    export_children=False,
    custom_props=False
)
```
