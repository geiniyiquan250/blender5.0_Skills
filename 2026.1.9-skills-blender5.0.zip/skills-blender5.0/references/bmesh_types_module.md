# bmesh.types 模块

## 模块概述

bmesh.types 模块定义了 BMesh 数据结构中使用的所有类型。BMesh 是 Blender 的自定义网格数据结构，提供了比传统 Mesh 更强大和灵活的网格操作能力。该模块包含网格操作所需的核心类型定义，如顶点、边、面、循环等，这些类型构成了 BMesh 的基本构建块。

与标准的 Mesh 数据结构不同，BMesh 使用显式的边和循环数据结构，这使得网格操作更加精确和可控。BMesh 维护了顶点、边、面之间的完整拓扑关系，可以方便地访问相邻元素和进行复杂的网格修改。这种设计使得 BMesh 成为实现雕刻工具、建模操作、程序化几何生成等功能的理想选择。

BMesh 类型系统的一个关键特性是其面向对象的结构。每个类型都继承自基类并包含特定于该元素的属性和方法。例如，BMVert 包含坐标、法线、选择状态等属性，而 BMEdge 包含两个端点的引用和边的硬度标记。理解这些类型的特性和相互关系是掌握 BMesh 编程的基础。

## BMesh 类

### 创建和初始化

BMesh 类是整个 BMesh 数据结构的容器。可以通过多种方式创建 BMesh 对象：从现有的 Mesh 数据创建、创建新的空 BMesh、或从其他 BMesh 复制。BMesh 对象维护了顶点、边、面的集合以及它们之间的拓扑关系。

```python
import bpy
import bmesh
from mathutils import Vector

# 创建新的空 BMesh
bme = bmesh.new()
print(f"新 BMesh: 顶点数={len(bme.verts)}, 边数={len(bme.edges)}, 面数={len(bme.faces)}")

# 从现有 Mesh 创建 BMesh
obj = bpy.context.active_object
if obj and obj.type == 'MESH':
    mesh = obj.data
    bme = bmesh.new(mesh=mesh)
    print(f"\n从 Mesh 创建的 BMesh:")
    print(f"  顶点数: {len(bme.verts)}")
    print(f"  边数: {len(bme.edges)}")
    print(f"  面数: {len(bme.faces)}")

# 复制现有 BMesh
def duplicate_bmesh(source_bme):
    """复制 BMesh"""
    dest_bme = bmesh.new()
    dest_bme.verts.ensure_lookup_table()
    dest_bme.edges.ensure_lookup_table()
    dest_bme.faces.ensure_lookup_table()
    
    # 复制顶点
    vert_map = {}
    for v in source_bme.verts:
        vert_map[v] = dest_bme.verts.new(v.co)
    
    # 复制边
    edge_map = {}
    for e in source_bme.edges:
        v1, v2 = e.verts
        edge_map[e] = dest_bme.edges.new((vert_map[v1], vert_map[v2]))
    
    # 复制面
    for f in source_bme.faces:
        verts = [vert_map[v] for v in f.verts]
        dest_bme.faces.new(verts)
    
    return dest_bme

# 使用示例
if 'bme' in dir():
    bme_copy = duplicate_bmesh(bme)
    print(f"\n复制的 BMesh:")
    print(f"  顶点数: {len(bme_copy.verts)}")
```

### 顶点管理

BMesh 提供了丰富的顶点管理功能，包括创建、删除、查找和遍历顶点。每个顶点可以存储坐标、法线、选择状态、自定义层数据等信息。

```python
import bmesh

# 创建顶点
bme = bmesh.new()

# 单个创建
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((0.0, 1.0, 0.0))

print("创建的顶点:")
for v in bme.verts:
    print(f"  索引={v.index}, 坐标={v.co}, 选择={v.select}")

# 批量创建
coords = [
    (1.0, 1.0, 0.0),
    (1.0, 0.0, 1.0),
    (0.0, 1.0, 1.0)
]
verts = bme.verts.new(coords for coords in coords)
print(f"\n批量创建了 {len(verts)} 个顶点")

# 确保顶点索引表更新
bme.verts.ensure_lookup_table()
print("\n更新后的顶点索引:")
for v in bme.verts:
    print(f"  索引={v.index}")

# 按索引查找顶点
if len(bme.verts) > 0:
    v = bme.verts[0]
    print(f"\n索引 0 的顶点: {v.co}")

# 查找特定坐标的顶点
def find_vert_by_co(bme, target_co, tolerance=0.001):
    """按坐标查找顶点"""
    for v in bme.verts:
        if (v.co - target_co).length < tolerance:
            return v
    return None

target = Vector((0.0, 0.0, 0.0))
found = find_vert_by_co(bme, target)
print(f"\n查找坐标 {target}: {'找到' if found else '未找到'}")
```

### 边和面管理

边和面是构成网格拓扑结构的关键元素。BMesh 提供了创建、删除和管理边和面的完整功能。

```python
import bmesh
from mathutils import Vector

bme = bmesh.new()

# 创建顶点
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((0.0, 1.0, 0.0))
v4 = bme.verts.new((1.0, 1.0, 0.0))

# 创建边
e1 = bme.edges.new((v1, v2))
e2 = bme.edges.new((v2, v4))
e3 = bme.edges.new((v4, v3))
e4 = bme.edges.new((v3, v1))
e5 = bme.edges.new((v1, v4))  # 对角线

print("创建的边:")
for e in bme.edges:
    v1, v2 = e.verts
    print(f"  边 {e.index}: {v1.co} - {v2.co}, 选中={e.select}")

# 创建面
f1 = bme.faces.new((v1, v2, v4, v3))
print(f"\n创建的面:")
print(f"  面 {f1.index}: 顶点数={len(f1.verts)}, 边数={len(f1.edges)}")

# 遍历面的顶点和边
print("\n面的拓扑结构:")
for i, v in enumerate(f1.verts):
    print(f"  顶点 {i}: {v.co}")

for i, e in enumerate(f1.edges):
    print(f"  边 {i}: {e.index}")

# 检查边是否属于面
print(f"\n对角线边 {e5.index} 是否在面中: {e5 in f1.edges}")
```

### 自定义数据层

BMesh 支持自定义数据层，允许为顶点、边、面附加额外的数据。这些数据层可以用于存储自定义属性、UV 坐标、顶点颜色等。

```python
import bmesh

bme = bmesh.new()

# 创建一些顶点
for i in range(4):
    bme.verts.new((i, 0, 0))
bme.verts.ensure_lookup_table()

# 创建浮点类型的数据层
float_layer = bme.verts.layers.float.new("my_float_data")
print("创建浮点数据层:", float_layer.name)

# 写入数据
for i, v in enumerate(bme.verts):
    v[float_layer] = i * 0.5

# 读取数据
print("\n读取浮点数据:")
for v in bme.verts:
    print(f"  顶点 {v.index}: {v[float_layer]}")

# 创建整数类型的数据层
int_layer = bme.verts.layers.int.new("my_int_data")
print("\n创建整数数据层:", int_layer.name)

# 创建字符串类型的数据层（用于顶点组名称等）
string_layer = bme.verts.layers.string.new("my_string_data")
print("创建字符串数据层:", string_layer.name)

# 顶点颜色层
if len(bme.faces) > 0:
    col_layer = bme.faces.layers.color.new("my_vertex_color")
    print("\n创建顶点颜色层:", col_layer.name)
```

## BMVert 类

### 顶点属性

BMVert 类代表网格中的顶点，包含坐标、法线、选择状态等核心属性，以及访问相邻元素的方法。

```python
import bmesh
from mathutils import Vector

bme = bmesh.new()

# 创建四面体
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((0.0, 1.0, 0.0))
v4 = bme.verts.new((0.0, 0.0, 1.0))

# 创建面（底面和三个侧面）
bme.faces.new((v1, v2, v3))
bme.faces.new((v1, v3, v4))
bme.faces.new((v1, v4, v2))
bme.faces.new((v2, v4, v3))

print("顶点属性测试:")
for v in bme.verts:
    print(f"\n顶点 {v.index}:")
    print(f"  坐标: {v.co}")
    print(f"  索引: {v.index}")
    print(f"  选择状态: {v.select}")
    print(f"  隐藏状态: {v.hide}")

    # 计算法线
    if v.normal.length > 0:
        print(f"  法线: {v.normal}")
    else:
        print(f"  法线: (未计算)")

    # 访问相邻顶点
    neighbor_coords = [n.co for n in v.link_verts]
    print(f"  相邻顶点: {neighbor_coords}")

    # 访问相邻边
    edge_indices = [e.index for e in v.link_edges]
    print(f"  相邻边: {edge_indices}")

    # 访问相邻面
    face_indices = [f.index for f in v.link_faces]
    print(f"  相邻面: {face_indices}")
```

### 顶点操作方法

BMVert 提供了多种操作方法，包括坐标变换、选择操作、隐藏操作等。

```python
import bmesh
from mathutils import Vector, Euler

bme = bmesh.new()

# 创建多个顶点
for i in range(5):
    bme.verts.new((i, 0, 0))
bme.verts.ensure_lookup_table()

print("顶点操作测试:")

# 选择操作
for v in bme.verts:
    v.select = True
print("所有顶点已选中")

# 隐藏操作
bme.verts[0].hide = True
print("顶点 0 已隐藏")

# 坐标操作
v = bme.verts[1]
print(f"\n顶点 {v.index} 原始坐标: {v.co}")

# 移动顶点
v.co = Vector((5.0, 5.0, 5.0))
print(f"移动后坐标: {v.co}")

# 计算到原点的距离
distance = v.co.length
print(f"到原点的距离: {distance}")

# 计算到另一个顶点的距离
v1 = bme.verts[0]
v2 = bme.verts[2]
distance_to_v2 = (v1.co - v2.co).length
print(f"顶点 0 到顶点 2 的距离: {distance_to_v2}")

# 顶点链操作
print("\n顶点链:")
for i in range(min(3, len(bme.verts))):
    v = bme.verts[i]
    print(f"  顶点 {i}: 链接边数={len(v.link_edges)}, 链接面数={len(v.link_faces)}")
```

## BMEdge 类

### 边属性

BMEdge 类代表网格中的边，包含两个端点的引用、选择状态、硬度标记等属性。

```python
import bmesh

bme = bmesh.new()

# 创建网格
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((1.0, 1.0, 0.0))
v4 = bme.verts.new((0.0, 1.0, 0.0))

# 创建边
e1 = bme.edges.new((v1, v2))
e2 = bme.edges.new((v2, v3))
e3 = bme.edges.new((v3, v4))
e4 = bme.edges.new((v4, v1))
e5 = bme.edges.new((v1, v3))

# 创建面
bme.faces.new((v1, v2, v3, v4))

print("边属性测试:")
for e in bme.edges:
    v1, v2 = e.verts
    print(f"\n边 {e.index}:")
    print(f"  端点: {v1.co} - {v2.co}")
    print(f"  长度: {e.calc_length():.4f}")
    print(f"  选择状态: {e.select}")
    print(f"  硬度(用于平滑着色): {e.use_edge_sharp}")
    print(f"  循环 seam: {e.use_seam}")
    print(f"  可见性: {not e.hide}")

    # 访问相邻面
    face_indices = [f.index for f in e.link_faces]
    print(f"  相邻面: {face_indices}")
```

### 边操作方法

BMEdge 提供了计算长度、判断相邻、获取共享面等方法。

```python
import bmesh

bme = bmesh.new()

# 创建更复杂的网格
verts = []
for x in range(3):
    for y in range(3):
        verts.append(bme.verts.new((x, y, 0)))
bme.verts.ensure_lookup_table()

# 创建边
edges = []
for y in range(3):
    for x in range(2):
        i = y * 3 + x
        edges.append(bme.edges.new((verts[i], verts[i + 1])))
for x in range(3):
    for y in range(2):
        i = y * 3 + x
        edges.append(bme.edges.new((verts[i], verts[i + 3])))

# 创建面
for y in range(2):
    for x in range(2):
        i = y * 3 + x
        bme.faces.new((verts[i], verts[i + 1], verts[i + 4], verts[i + 3]))

print("边操作测试:")
for e in bme.edges:
    print(f"\n边 {e.index}:")
    print(f"  长度: {e.calc_length():.4f}")

    # 判断是否是边界边
    is_boundary = e.is_boundary
    print(f"  边界边: {is_boundary}")

    # 判断是否是manifold边
    is_manifold = e.is_manifold
    print(f"  流形边: {is_manifold}")

    # 判断是否是wire边
    is_wire = e.is_wire
    print(f"  Wire边: {is_wire}")

    # 获取两个共享顶点
    v1, v2 = e.verts
    print(f"  顶点: {v1.index}, {v2.index}")

    # 获取相邻面
    adjacent_faces = list(e.link_faces)
    print(f"  相邻面数: {len(adjacent_faces)}")
```

## BMFace 类

### 面属性

BMFace 类代表网格中的面，包含顶点引用、边引用、法线、材质索引等属性。

```python
import bmesh
from mathutils import Vector

bme = bmesh.new()

# 创建立方体的顶点
verts = [
    bme.verts.new((-1, -1, -1)),
    bme.verts.new((1, -1, -1)),
    bme.verts.new((1, 1, -1)),
    bme.verts.new((-1, 1, -1)),
    bme.verts.new((-1, -1, 1)),
    bme.verts.new((1, -1, 1)),
    bme.verts.new((1, 1, 1)),
    bme.verts.new((-1, 1, 1))
]
bme.verts.ensure_lookup_table()

# 定义六个面
face_indices = [
    (0, 1, 2, 3),  # 前面
    (5, 4, 7, 6),  # 后面
    (4, 0, 3, 7),  # 左面
    (1, 5, 6, 2),  # 右面
    (3, 2, 6, 7),  # 顶面
    (4, 5, 1, 0),  # 底面
]

faces = []
for indices in face_indices:
    face_verts = [verts[i] for i in indices]
    faces.append(bme.faces.new(face_verts))

print("面属性测试:")
for f in faces:
    print(f"\n面 {f.index}:")
    print(f"  顶点数: {len(f.verts)}")
    print(f"  边数: {len(f.edges)}")
    print(f"  选择状态: {f.select}")
    print(f"  隐藏状态: {f.hide}")

    # 计算面积
    area = f.calc_area()
    print(f"  面积: {area:.4f}")

    # 计算法线
    normal = f.normal
    print(f"  法线: {normal}")

    # 获取材质索引
    mat_index = f.material_index
    print(f"  材质索引: {mat_index}")

    # 访问顶点
    print(f"  顶点索引: {[v.index for v in f.verts]}")
```

### 面操作方法

BMFace 提供了计算面积、法线、循环等方法。

```python
import bmesh
from mathutils import Vector

bme = bmesh.new()

# 创建三角形网格
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((2.0, 0.0, 0.0))
v3 = bme.verts.new((1.0, 2.0, 0.0))

f = bme.faces.new((v1, v2, v3))

print("面操作测试:")
print(f"\n面 {f.index}:")

# 计算面积
area = f.calc_area()
print(f"  面积: {area:.4f}")

# 验证面积（底*高/2）
base = (v2.co - v1.co).length
height = 2.0
expected_area = base * height / 2
print(f"  期望面积: {expected_area:.4f}")

# 计算法线
normal = f.normal
print(f"  法线: {normal}")

# 获取循环
loops = list(f.loops)
print(f"  循环数: {len(loops)}")
for i, loop in enumerate(loops):
    print(f"    循环 {i}: 顶点={loop.vert.index}, 边={loop.edge.index}")

# 判断面是否平整
is_planar = f.is_planar()
print(f"  是否平整: {is_planar}")

# 获取面的中心
center = f.center_median
print(f"  中心点(中位数): {center}")

center_geometric = f.center()
print(f"  中心点(几何): {center_geometric}")
```

## BMLoop 类

### 循环结构

BMLoop 是 BMesh 中的循环结构，连接顶点、边和面。每个面由多个循环组成，每个循环对应面的一条边。

```python
import bmesh

bme = bmesh.new()

# 创建正方形
v1 = bme.verts.new((0.0, 0.0, 0.0))
v2 = bme.verts.new((1.0, 0.0, 0.0))
v3 = bme.verts.new((1.0, 1.0, 0.0))
v4 = bme.verts.new((0.0, 1.0, 0.0))

f = bme.faces.new((v1, v2, v3, v4))

print("循环结构测试:")
print(f"面 {f.index} 有 {len(f.loops)} 个循环")

for i, loop in enumerate(f.loops):
    print(f"\n循环 {i}:")
    print(f"  顶点: {loop.vert.co}")
    print(f"  边: {loop.edge.index}")
    print(f"  面: {loop.face.index}")

    # 获取相邻循环（同一面上的下一个和上一个）
    next_loop = loop.link_loop_next
    prev_loop = loop.link_loop_prev
    print(f"  下一个循环: {next_loop.vert.index}")
    print(f"  上一个循环: {prev_loop.vert.index}")

    # 获取相邻循环（通过边连接到相邻面）
    radial_next = loop.link_loop_radial_next
    print(f"  径向下一个: {radial_next.vert.index if radial_next else '无'}")
```

### 循环遍历

循环提供了在网格拓扑中导航的能力，可以方便地访问相邻元素。

```python
import bmesh

bme = bmesh.new()

# 创建更复杂的网格以便演示循环遍历
verts = []
for x in range(3):
    for y in range(3):
        verts.append(bme.verts.new((x, y, 0)))
bme.verts.ensure_lookup_table()

# 创建面
for y in range(2):
    for x in range(2):
        i = y * 3 + x
        bme.faces.new((verts[i], verts[i + 1], verts[i + 4], verts[i + 3]))

print("循环遍历测试:")

# 遍历所有面的循环
for f in bme.faces:
    print(f"\n面 {f.index} 的循环:")
    for loop in f.loops:
        print(f"  顶点 {loop.vert.index} -> ", end="")

    # 使用循环遍历整个面
    start_loop = f.loops[0]
    current_loop = start_loop
    print("\n  遍历整个面:")
    i = 0
    while True:
        print(f"    顶点 {current_loop.vert.index}")
        current_loop = current_loop.link_loop_next
        i += 1
        if current_loop == start_loop or i >= len(f.loops):
            break

# 使用循环访问相邻面
print("\n通过循环访问相邻面:")
for f in bme.faces:
    adjacent_faces = set()
    for loop in f.loops:
        # 通过边的另一个面找到相邻面
        edge = loop.edge
        for adjacent_loop in edge.link_loops:
            if adjacent_loop.face != f:
                adjacent_faces.add(adjacent_loop.face.index)

    print(f"  面 {f.index} 的相邻面: {sorted(adjacent_faces)}")
```

## 实践示例

### 网格分析工具

这个示例展示了如何使用 bmesh.types 进行网格分析。

```python
import bmesh

class MeshAnalyzer:
    def __init__(self, bme):
        self.bme = bme

    def analyze_mesh(self):
        """全面分析网格"""
        report = {
            'vertex_count': len(self.bme.verts),
            'edge_count': len(self.bme.edges),
            'face_count': len(self.bme.faces),
            'total_area': 0,
            'total_edges': 0,
            'boundary_edges': 0,
            'manifold_edges': 0,
            'wire_edges': 0,
            'avg_face_area': 0,
            'hidden_verts': 0,
            'hidden_edges': 0,
            'hidden_faces': 0
        }

        # 统计面积
        for f in self.bme.faces:
            report['total_area'] += f.calc_area()
            if f.hide:
                report['hidden_faces'] += 1

        # 计算平均面面积
        if report['face_count'] > 0:
            report['avg_face_area'] = report['total_area'] / report['face_count']

        # 统计边
        for e in self.bme.edges:
            report['total_edges'] += 1
            if e.hide:
                report['hidden_edges'] += 1
            if e.is_boundary():
                report['boundary_edges'] += 1
            if e.is_manifold():
                report['manifold_edges'] += 1
            if e.is_wire():
                report['wire_edges'] += 1

        # 统计顶点
        for v in self.bme.verts:
            if v.hide:
                report['hidden_verts'] += 1

        return report

    def get_topology_info(self):
        """获取拓扑信息"""
        info = {
            'vertex_connectivity': {},
            'edge_connectivity': {},
            'face_sizes': {}
        }

        # 顶点连接度
        for v in self.bme.verts:
            edge_count = len(v.link_edges)
            face_count = len(v.link_faces)
            info['vertex_connectivity'][edge_count] = info['vertex_connectivity'].get(edge_count, 0) + 1

        # 边连接度
        for e in self.bme.edges:
            face_count = len(list(e.link_faces))
            info['edge_connectivity'][face_count] = info['edge_connectivity'].get(face_count, 0) + 1

        # 面大小
        for f in self.bme.faces:
            size = len(f.verts)
            info['face_sizes'][size] = info['face_sizes'].get(size, 0) + 1

        return info

    def print_report(self):
        """打印分析报告"""
        report = self.analyze_mesh()
        topology = self.get_topology_info()

        print("=" * 50)
        print("网格分析报告")
        print("=" * 50)

        print(f"\n基本统计:")
        print(f"  顶点数: {report['vertex_count']}")
        print(f"  边数: {report['edge_count']}")
        print(f"  面数: {report['face_count']}")

        print(f"\n几何属性:")
        print(f"  总面积: {report['total_area']:.4f}")
        print(f"  平均面面积: {report['avg_face_area']:.4f}")

        print(f"\n边类型统计:")
        print(f"  边界边: {report['boundary_edges']}")
        print(f"  流形边: {report['manifold_edges']}")
        print(f"  Wire边: {report['wire_edges']}")

        print(f"\n隐藏元素:")
        print(f"  隐藏顶点: {report['hidden_verts']}")
        print(f"  隐藏边: {report['hidden_edges']}")
        print(f"  隐藏面: {report['hidden_faces']}")

        print(f"\n拓扑信息:")
        print(f"  顶点连接度: {topology['vertex_connectivity']}")
        print(f"  边连接度: {topology['edge_connectivity']}")
        print(f"  面大小分布: {topology['face_sizes']}")

# 使用示例
bme = bmesh.new()
for x in range(3):
    for y in range(3):
        bme.verts.new((x, y, 0))
bme.verts.ensure_lookup_table()

for y in range(2):
    for x in range(2):
        i = y * 3 + x
        bme.faces.new((bme.verts[i], bme.verts[i + 1], bme.verts[i + 4], bme.verts[i + 3]))

analyzer = MeshAnalyzer(bme)
analyzer.print_report()
```

### 网格验证工具

这个示例展示了如何使用 bmesh.types 验证网格的有效性。

```python
import bmesh
from mathutils import Vector

class MeshValidator:
    def __init__(self, bme):
        self.bme = bme
        self.errors = []
        self.warnings = []
        self.info = []

    def validate(self):
        """验证网格的有效性"""
        self.errors = []
        self.warnings = []
        self.info = []

        self._check_vertices()
        self._check_edges()
        self._check_faces()
        self._check_manifold()
        self._check_geometry()

        return len(self.errors) == 0

    def _check_vertices(self):
        """检查顶点"""
        for v in self.bme.verts:
            # 检查孤立顶点
            if len(v.link_edges) == 0 and len(v.link_faces) == 0:
                self.warnings.append(f"顶点 {v.index} 是孤立的")

            # 检查重复坐标
            for other in self.bme.verts:
                if other != v and other != v:
                    if (v.co - other.co).length < 0.0001:
                        self.errors.append(f"顶点 {v.index} 和 {other.index} 坐标相同")
                        break

    def _check_edges(self):
        """检查边"""
        for e in self.bme.edges:
            # 检查零长度边
            if e.calc_length() < 0.0001:
                self.errors.append(f"边 {e.index} 长度为零")

            # 检查退化面
            for f in e.link_faces:
                if len(f.verts) < 3:
                    self.errors.append(f"面 {f.index} 顶点数不足")

    def _check_faces(self):
        """检查面"""
        for f in self.bme.faces:
            # 检查退化面
            if f.calc_area() < 0.0001:
                self.warnings.append(f"面 {f.index} 面积为零")

            # 检查非平面面
            if not f.is_planar():
                self.warnings.append(f"面 {f.index} 不是平整的")

    def _check_manifold(self):
        """检查流形"""
        boundary_count = 0
        non_manifold_count = 0

        for e in self.bme.edges:
            if e.is_boundary():
                boundary_count += 1
            elif not e.is_manifold():
                non_manifold_count += 1

        if boundary_count > 0:
            self.info.append(f"网格有 {boundary_count} 条边界边（边缘未封闭）")

        if non_manifold_count > 0:
            self.errors.append(f"网格有 {non_manifold_count} 条非流形边")

    def _check_geometry(self):
        """检查几何形状"""
        total_area = sum(f.calc_area() for f in self.bme.faces)
        if total_area == 0:
            self.warnings.append("网格总面积为零")

        # 检查法线方向
        normals = [f.normal for f in self.bme.faces]
        if normals:
            avg_normal = sum(normals, Vector((0, 0, 0))) / len(normals)
            if avg_normal.length < 0.001:
                self.warnings.append("大部分面法线方向不一致")

    def print_results(self):
        """打印验证结果"""
        is_valid = self.validate()

        print("=" * 50)
        print("网格验证结果")
        print("=" * 50)

        print(f"\n有效性: {'通过' if is_valid else '失败'}")

        if self.errors:
            print(f"\n错误 ({len(self.errors)}):")
            for error in self.errors:
                print(f"  - {error}")

        if self.warnings:
            print(f"\n警告 ({len(self.warnings)}):")
            for warning in self.warnings:
                print(f"  - {warning}")

        if self.info:
            print(f"\n信息 ({len(self.info)}):")
            for info in self.info:
                print(f"  - {info}")

        return is_valid

# 使用示例
bme = bmesh.new()
for x in range(3):
    for y in range(3):
        bme.verts.new((x, y, 0))
bme.verts.ensure_lookup_table()
for y in range(2):
    for x in range(2):
        i = y * 3 + x
        bme.faces.new((bme.verts[i], bme.verts[i + 1], bme.verts[i + 4], bme.verts[i + 3]))

validator = MeshValidator(bme)
validator.print_results()
```

## 注意事项

### 内存管理

BMesh 对象在使用完毕后应该调用 free 方法释放内存。这对于在循环中创建大量临时 BMesh 的场景尤其重要，可以避免内存泄漏。

### 索引维护

在对 BMesh 进行结构性修改（如添加、删除元素）后，应该调用 ensure_lookup_table 方法来更新索引查找表。在使用索引直接访问元素之前，务必确保索引表已更新。

### 拓扑关系访问

通过 link_verts、link_edges、link_faces 等属性访问相邻元素时，返回的是迭代器。如果需要多次访问同一组元素，应该先转换为列表以避免重复遍历。