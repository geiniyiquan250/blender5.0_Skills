# bpy.ops.sequencer - 序列编辑器操作模块

bpy.ops.sequencer模块提供了视频序列编辑器（Video Sequence Editor）中的操作功能，用于管理视频、音频和图像序列。

## 概述

视频序列编辑器是Blender中用于非线性视频编辑的工具。这个模块提供了条带管理、效果应用和编辑操作的功能。

## 核心功能

### 条带管理

```python
import bpy

def add_movie(filepath, location=0):
    """添加视频条带"""
    bpy.ops.sequencer.movie_strip_add(
        filepath=filepath,
        frame_start=location,
        channel=1
    )

def add_image(filepath, frame_start=0):
    """添加图像条带"""
    bpy.ops.sequencer.image_strip_add(
        filepath=filepath,
        frame_start=frame_start,
        channel=1
    )

def add_audio(filepath, frame_start=0):
    """添加音频条带"""
    bpy.ops.sequencer.sound_strip_add(
        filepath=filepath,
        frame_start=frame_start,
        channel=2
    )

def add_text(name, frame_start, duration=30):
    """添加文字条带"""
    bpy.ops.sequencer.text_strip_add(
        text=name,
        frame_start=frame_start,
        frame_end=frame_start + duration
    )
```

### 条带操作

```python
def delete_strip():
    """删除条带"""
    bpy.ops.sequencer.delete()

def duplicate_strip():
    """复制条带"""
    bpy.ops.sequencer.duplicate()

def cut_strip(frame, type='SOFT'):
    """切割条带"""
    bpy.ops.sequencer.cut(
        frame=frame,
        type=type,
        side='BOTH'
    )

def slip_strip(offset):
    """滑动条带"""
    bpy.ops.sequencer.slip(offset=offset)

def snap_strip():
    """吸附条带"""
    bpy.ops.sequencer.snap(frame=bpy.context.scene.frame_current)
```

### 选择操作

```python
def select_all():
    """全选"""
    bpy.ops.sequencer.select_all(action='SELECT')

def deselect_all():
    """取消全选"""
    bpy.ops.sequencer.select_all(action='DESELECT')

def select_border(extend=False):
    """框选"""
    bpy.ops.sequencer.select_border(
        extend=extend,
        channel_select=False
    )

def select_active_side(side='LEFT'):
    """选择激活侧"""
    bpy.ops.sequencer.select_active_side(side=side)
```

## 实用函数

### 效果添加

```python
def add_effect(effect_type, strip1=None, strip2=None):
    """添加效果"""
    bpy.ops.sequencer.effect_strip_add(
        type=effect_type,
        frame_start=strip1.frame_start if strip1 else 0,
        channel=1
    )

def add_crossfade():
    """添加交叉淡化"""
    add_effect('CROSS')

def add_wipe():
    """添加擦除"""
    add_effect('WIPE')

def add_glow():
    """添加发光"""
    add_effect('GLOW')

def add_color_mix():
    """添加颜色混合"""
    add_effect('COLOR')
```

### 时间操作

```python
def set_frame_start(frame):
    """设置起始帧"""
    bpy.context.scene.frame_start = frame

def set_frame_end(frame):
    """设置结束帧"""
    bpy.context.scene.frame_end = frame

def set_render_fps(fps):
    """设置渲染帧率"""
    bpy.context.scene.render.fps = fps

def preview_range_set(start, end):
    """设置预览范围"""
    bpy.context.scene.frame_preview_start = start
    bpy.context.scene.frame_preview_end = end
```

## 常见问题排查

### 条带问题

加载失败：
- 确认文件路径正确
- 检查编解码器支持
- 验证文件完整性

### 效果问题

效果不显示：
- 确认输入条带存在
- 检查效果设置正确
- 验证通道层叠顺序
