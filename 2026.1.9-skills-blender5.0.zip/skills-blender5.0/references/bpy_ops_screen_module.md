# bpy.ops.screen 模块

屏幕操作模块，用于管理编辑器区域、视图和屏幕布局。

## 概述

bpy.ops.screen 模块包含用于管理Blender界面布局、编辑器区域和屏幕视图的运算符。这些运算符控制界面的显示、区域分割和视图导航。

## 常用操作

### 屏幕管理

```python
import bpy

# 新建屏幕
bpy.ops.screen.new()

# 删除屏幕
bpy.ops.screen.delete()

# 重命名屏幕
bpy.ops.screen.rename(name='CustomLayout')

# 切换全屏
bpy.ops.screen.fullscreen_toggle()

# 切换装饰
bpy.ops.screen.decorator_toggle()

# 最大化区域
bpy.ops.screen.region_quadview()

# 切换到下一个屏幕
bpy.ops.screen.next_user_flip()

# 切换到上一个屏幕
bpy.ops.screen.previous_user_flip()

# 显示用户界面
bpy.ops.screen.userpref_show()
```

### 区域操作

```python
# 分割区域
bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.5)

# 水平分割
bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.5)

# 垂直分割
bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)

# 删除区域
bpy.ops.screen.area_delete(type='COLLAPSE')

# 折叠区域
bpy.ops.screen.area_flip()

# 交换区域
bpy.ops.screen.area_swap()

# 扩大区域
bpy.ops.screen.area_doubling()

# 最大化区域
bpy.ops.screen.maximise_border()
```

### 视图操作

```python
# 放大视图
bpy.ops.screen.zoom_in()

# 缩小视图
bpy.ops.screen.zoom_out()

# 放大边框
bpy.ops.screen.zoom_border(gesture_mode=0)

# 放大选择
bpy.ops.screen.zoom_to_selection()

# 全部视图
bpy.ops.screen.zoom_camera_1_to_1()

# 局部放大
bpy.ops.screen.zoom_in(factor=1.2)
bpy.ops.screen.zoom_out(factor=1.2)
```

### 帧操作

```python
# 播放动画
bpy.ops.screen.animation_play(reverse=False, sync=False)

# 反向播放
bpy.ops.screen.animation_play(reverse=True)

# 暂停
bpy.ops.screen.animation_play()

# 逐帧前进
bpy.ops.screen.frame_jump(end=False)

# 逐帧后退
bpy.ops.screen.frame_offset_backward(frame=1)

# 跳转到开始
bpy.ops.screen.frame_jump(end=False)

# 跳转到结束
bpy.ops.screen.frame_jump(end=True)
```

### 关键帧操作

```python
# 插入关键帧
bpy.ops.screen.keyframe_jump(next=True)
bpy.ops.screen.keyframe_jump(next=False)

# 跳转到关键帧
bpy.ops.screen.keyframe_jump(next=True)

# 上一个关键帧
bpy.ops.screen.keyframe_jump(next=False)
```

### 编辑器操作

```python
# 区域类型
bpy.ops.screen.area_duplicator()

# 复制区域
bpy.ops.screen.area_duplicator()

# 改变区域类型
bpy.ops.screen.change_area_type(region_type='VIEW_3D')

# 切换区域类型
bpy.ops.screen.change_area_type(region_type='GRAPH_EDITOR')

# 切换到时间线
bpy.ops.screen.change_area_type(region_type='TIMELINE')

# 切换到属性
bpy.ops.screen.change_area_type(region_type='PROPERTIES')

# 切换到大纲
bpy.ops.screen.change_area_type(region_type='OUTLINER')

# 切换到文件浏览器
bpy.ops.screen.change_area_type(region_type='FILE_BROWSER')
```

### 工具设置

```python
# 工具栏切换
bpy.ops.screen.toolbar_prompt(tool_idname='builtin.select')

# 侧边栏切换
bpy.ops.screen.sidebar_ui_show()
```

## 实际应用示例

### 创建自定义屏幕布局

```python
def create_custom_layout():
    """创建自定义屏幕布局"""
    # 新建屏幕
    bpy.ops.screen.new()
    screen = bpy.context.screen
    
    # 设置屏幕名称
    screen.name = 'CustomLayout'
    
    # 返回新屏幕
    return screen
```

### 设置四视图布局

```python
def setup_quadview():
    """设置四视图布局"""
    # 水平分割
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.5)
    
    # 获取区域列表
    areas = bpy.context.screen.areas
    
    # 垂直分割第一个区域
    if len(areas) > 0:
        bpy.context.area = areas[0]
        bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)
    
    # 垂直分割第二个区域
    if len(areas) > 1:
        bpy.context.area = areas[1]
        bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)
    
    # 切换区域类型
    for area in areas:
        if area.type == 'VIEW_3D':
            bpy.context.area = area
            bpy.ops.screen.change_area_type(region_type='VIEW_3D')
```

### 创建动画工作区

```python
def setup_animation_workspace():
    """设置动画工作区"""
    # 删除默认区域
    while len(bpy.context.screen.areas) > 1:
        bpy.ops.screen.area_delete(type='COLLAPSE')
    
    # 分割出时间线
    bpy.ops.screen.area_split(direction='VERTICAL', factor=0.7)
    
    # 设置左侧为3D视图
    bpy.context.screen.areas[0].type = 'VIEW_3D'
    
    # 设置右侧上半部分为曲线编辑器
    bpy.context.screen.areas[1].type = 'GRAPH_EDITOR'
    
    # 设置右侧下半部分为时间线
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.5)
```

### 创建材质工作区

```python
def setup_material_workspace():
    """设置材质工作区"""
    # 删除多余区域
    while len(bpy.context.screen.areas) > 1:
        bpy.ops.screen.area_delete(type='COLLAPSE')
    
    # 分割出属性面板
    bpy.ops.screen.area_split(direction='VERTICAL', factor=0.75)
    
    # 设置左侧为节点编辑器
    bpy.context.screen.areas[0].type = 'NODE_EDITOR'
    
    # 设置右侧为属性面板
    bpy.context.screen.areas[1].type = 'PROPERTIES'
```

### 创建脚本工作区

```python
def setup_scripting_workspace():
    """设置脚本工作区"""
    # 删除多余区域
    while len(bpy.context.screen.areas) > 1:
        bpy.ops.screen.area_delete(type='COLLAPSE')
    
    # 垂直分割
    bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)
    
    # 左侧上半部分为文本编辑器
    bpy.context.screen.areas[0].type = 'TEXT_EDITOR'
    
    # 左侧下半部分为系统控制台
    bpy.context.screen.areas[1].type = 'CONSOLE'
```

### 快速切换编辑器

```python
def switch_editor_type(editor_type):
    """快速切换编辑器类型"""
    # 设置当前区域为指定类型
    bpy.context.area.type = editor_type

# 使用示例
# switch_editor_type('VIEW_3D')  # 切换到3D视图
# switch_editor_type('NODE_EDITOR')  # 切换到节点编辑器
# switch_editor_type('GRAPH_EDITOR')  # 切换到曲线编辑器
```

### 创建渲染预览布局

```python
def setup_render_preview():
    """设置渲染预览布局"""
    # 删除多余区域
    while len(bpy.context.screen.areas) > 1:
        bpy.ops.screen.area_delete(type='COLLAPSE')
    
    # 分割出图像编辑器
    bpy.ops.screen.area_split(direction='VERTICAL', factor=0.7)
    
    # 设置左侧为图像编辑器
    bpy.context.screen.areas[0].type = 'IMAGE_EDITOR'
    
    # 设置右侧为属性面板
    bpy.context.screen.areas[1].type = 'PROPERTIES'
```

### 恢复默认布局

```python
def reset_to_default():
    """恢复到默认布局"""
    # 加载默认用户设置
    bpy.ops.wm.read_factory_settings(use_empty=True)
```

## 使用场景

- **界面布局**：创建自定义编辑器排列
- **工作区管理**：保存和切换工作区
- **视图控制**：缩放和导航视图
- **动画播放**：控制动画预览
- **区域管理**：分割和合并区域
- **编辑器切换**：快速切换不同编辑器

## 注意事项

- 区域操作会影响当前屏幕布局
- 分割操作需要指定方向和比例
- 屏幕布局可以保存为用户预设
- 全屏模式隐藏所有UI元素
- 恢复设置会影响所有屏幕
- 区域类型可以动态切换
