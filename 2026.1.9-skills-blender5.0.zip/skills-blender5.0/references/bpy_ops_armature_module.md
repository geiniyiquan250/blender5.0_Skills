# bpy.ops.armature 模块

骨骼操作模块，用于创建和编辑骨骼系统。

## 概述

bpy.ops.armature 模块包含用于创建、编辑和管理骨骼系统的运算符。这些运算符控制骨骼的创建、选择、变换和父子关系。

## 常用操作

### 骨骼创建

```python
import bpy

# 添加单根骨骼
bpy.ops.armature.bone_primitive_add(name='Bone', enter_editmode=True)

# 添加骨骼
bpy.ops.armature.bone_primitive_add()

# 添加骨骼并进入编辑模式
bpy.ops.armature.bone_primitive_add(enter_editmode=True)

# 复制骨骼
bpy.ops.armature.duplicate()

# 删除骨骼
bpy.ops.armature.delete()

# 重命名骨骼
bpy.ops.armature.rename(name='NewBone')
```

### 选择操作

```python
# 全选
bpy.ops.armature.select_all(action='SELECT')
bpy.ops.armature.select_all(action='DESELECT')
bpy.ops.armature.select_all(action='INVERT')

# 选择父子
bpy.ops.armature.select_hierarchy(direction='PARENT', extend=False)
bpy.ops.armature.select_hierarchy(direction='CHILD', extend=False)
bpy.ops.armature.select_hierarchy(direction='PARENT', extend=True)
bpy.ops.armature.select_hierarchy(direction='CHILD', extend=True)

# 选择同类型
bpy.ops.armature.select_similar(type='TYPE', compare='EQUAL')

# 选择连接
bpy.ops.armature.select_linked()

# 选择mirrored
bpy.ops.armature.select_mirror(only_active=False)
```

### 骨骼编辑

```pytho

# 细分骨骼
bpy.ops.armature.subdivide(number_cuts=1)

# 细分多级
bpy.ops.armature.subdivide(number_cuts=1, number_of_cuts=3)

# 合并骨骼
bpy.ops.armature.merge(type='AT_CURSOR')

# 分离骨骼
bpy.ops.armature.separate()

# 填充
bpy.ops.armature.fill()

# 对称
bpy.ops.armature.symmetric_make(use_flip_names=False)
```

### 骨骼变换

```python
# 移动
bpy.ops.transform.translate(value=(0, 0, 0))

# 旋转
bpy.ops.transform.rotate(value=0)

# 缩放
bpy.ops.transform.resize(value=(1, 1, 1))

# 平滑
bpy.ops.armature_smooth.smooth()
```

### 骨骼关系

```python
# 创建父子关系
bpy.ops.armature.parent_set(type='BONE')

# 清除父子关系
bpy.ops.armature.parent_clear(type='CLEAR')

# 设置为父级
bpy.ops.armature.parent_set(type='OBJECT')

# 设置为骨关联
bpy.ops.armature.parent_set(type='BONE_RELATIVE')
```

### 姿态模式

```python
# 进入姿态模式
bpy.ops.object.mode_set(mode='POSE')

# 退出姿态模式
bpy.ops.object.mode_set(mode='EDIT')

# 重置姿态
bpy.ops.pose.rot_clear()
bpy.ops.pose.loc_clear()
bpy.ops.pose.scale_clear()
bpy.ops.pose.transforms_clear()

# 应用姿态为姿态
bpy.ops.pose.visual_transform_apply()

# 应用姿态为绑定姿态
bpy.ops.pose.armature_apply()
```

### 约束操作

```python
# 添加约束
bpy.ops.pose.constraint_add(type='COPY_LOCATION')

# 复制约束
bpy.ops.pose.constraints_copy()

# 粘贴约束
bpy.ops.pose.constraints_paste()
```

### 驱动操作

```python
# 添加驱动
bpy.ops.pose.driver_add()

# 删除驱动
bpy.ops.pose.driver_remove()

# 添加变量
bpy.ops.pose.driver_add_target()

# 显示驱动
bpy.ops.pose.autoside_names_axials()
```

## 实际应用示例

### 创建基础骨骼链

```python
def create_basic_armature(name='BasicArmature'):
    """创建基础骨骼链"""
    # 创建空物体作为骨架容器
    bpy.ops.object.armature_add()
    armature = bpy.context.active_object
    armature.name = name
    
    # 进入编辑模式
    bpy.ops.object.mode_set(mode='EDIT')
    
    # 获取骨骼
    bones = armature.data.edit_bones
    
    # 创建骨骼链
    bone_count = 5
    bone_length = 0.5
    
    for i in range(bone_count):
        if i == 0:
            bone = bones[0]
            bone.name = f'Bone_{i}'
            bone.head = (0, 0, 0)
            bone.tail = (0, 0, bone_length)
        else:
            prev_bone = bones[f'Bone_{i-1}']
            bone = bones.new(f'Bone_{i}')
            bone.head = prev_bone.tail
            bone.tail = (0, 0, bone_length * (i + 2))
            bone.parent = prev_bone
    
    # 退出编辑模式
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return armature
```

### 创建两足动物骨骼

```python
def create_biped_armature(scale=1.0):
    """创建两足动物骨骼"""
    bpy.ops.object.armature_add()
    armature = bpy.context.active_object
    armature.name = 'Biped'
    
    bpy.ops.object.mode_set(mode='EDIT')
    bones = armature.data.edit_bones
    
    # 脊柱骨骼
    spine_len = 0.5 * scale
    
    # 骨盆
    pelvis = bones.new('Pelvis')
    pelvis.head = (0, 0, spine_len * 4)
    pelvis.tail = (0, 0, spine_len * 5)
    
    # 脊柱
    spine = bones.new('Spine')
    spine.head = pelvis.tail
    spine.tail = (0, 0, spine_len * 7)
    spine.parent = pelvis
    
    # 脖子
    neck = bones.new('Neck')
    neck.head = spine.tail
    neck.tail = (0, 0, spine_len * 8)
    neck.parent = spine
    
    # 头部
    head = bones.new('Head')
    head.head = neck.tail
    head.tail = (0, 0, spine_len * 9.5)
    head.parent = neck
    
    # 手臂（左）
    shoulder_l = bones.new('Shoulder_L')
    shoulder_l.head = spine.tail + (0.2 * scale, 0, 0)
    shoulder_l.tail = shoulder_l.head + (0.3 * scale, 0, 0)
    shoulder_l.parent = spine
    
    arm_l = bones.new('Arm_L')
    arm_l.head = shoulder_l.tail
    arm_l.tail = arm_l.head + (0, 0, -0.4 * scale)
    arm_l.parent = shoulder_l
    
    # 手臂（右）
    shoulder_r = bones.new('Shoulder_R')
    shoulder_r.head = spine.tail + (-0.2 * scale, 0, 0)
    shoulder_r.tail = shoulder_r.head + (-0.3 * scale, 0, 0)
    shoulder_r.parent = spine
    
    arm_r = bones.new('Arm_R')
    arm_r.head = shoulder_r.tail
    arm_r.tail = arm_r.head + (0, 0, -0.4 * scale)
    arm_r.parent = shoulder_r
    
    # 腿（左）
    hip_l = bones.new('Hip_L')
    hip_l.head = pelvis.head + (0.1 * scale, 0, 0)
    hip_l.tail = hip_l.head + (0, 0, -0.4 * scale)
    hip_l.parent = pelvis
    
    leg_l = bones.new('Leg_L')
    leg_l.head = hip_l.tail
    leg_l.tail = leg_l.head + (0, 0, -0.5 * scale)
    leg_l.parent = hip_l
    
    # 腿（右）
    hip_r = bones.new('Hip_R')
    hip_r.head = pelvis.head + (-0.1 * scale, 0, 0)
    hip_r.tail = hip_r.head + (0, 0, -0.4 * scale)
    hip_r.parent = pelvis
    
    leg_r = bones.new('Leg_R')
    leg_r.head = hip_r.tail
    leg_r.tail = leg_r.head + (0, 0, -0.5 * scale)
    leg_r.parent = hip_r
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return armature
```

### 创建程序化手指骨骼

```python
def create_finger_bones(finger_name, start_pos, length, segments=3):
    """创建手指骨骼"""
    armature = bpy.context.active_object
    
    bpy.ops.object.mode_set(mode='EDIT')
    bones = armature.data.edit_bones
    
    segment_length = length / segments
    
    for i in range(segments):
        bone = bones.new(f'{finger_name}_{i}')
        
        if i == 0:
            bone.head = start_pos
            bone.tail = (start_pos[0], start_pos[1], start_pos[2] + segment_length)
        else:
            prev_bone = bones[f'{finger_name}_{i-1}']
            bone.head = prev_bone.tail
            bone.tail = (bone.head[0], bone.head[1], bone.head[2] + segment_length)
            bone.parent = prev_bone
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return bones
```

### 添加IK约束

```python
def add_ik_constraint(pole_target, end_bone, chain_length=2):
    """添加IK约束"""
    # 进入姿态模式
    bpy.ops.object.mode_set(mode='POSE')
    
    # 获取末端骨骼
    pose_bones = bpy.context.active_object.pose.bones
    end_pose_bone = pose_bones[end_bone]
    
    # 添加IK约束
    ik_constraint = end_pose_bone.constraints.new(type='IK')
    ik_constraint.target = pole_target
    ik_constraint.chain_count = chain_length
    
    # 设置极向
    ik_constraint.pole_target = pole_target
    ik_constraint.pole_angle = 0
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return ik_constraint
```

### 批量应用约束

```python
def batch_add_constraints(constraints_config):
    """批量添加约束"""
    bpy.ops.object.mode_set(mode='POSE')
    
    armature = bpy.context.active_object
    
    for bone_name, constraint_type in constraints_config.items():
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone:
            constraint = pose_bone.constraints.new(type=constraint_type)
            print(f"已添加 {constraint_type} 到 {bone_name}")
    
    bpy.ops.object.mode_set(mode='OBJECT')
```

### 创建程序化行走动画

```python
def create_walk_cycle(armature, frames=30):
    """创建程序化行走循环"""
    bpy.ops.object.mode_set(mode='POSE')
    
    # 设置帧
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = frames
    
    # 获取姿态骨骼
    pose_bones = armature.pose.bones
    
    # 设置关键帧
    for frame in range(1, frames + 1):
        bpy.context.scene.frame_set(frame)
        
        # 简单的正弦波动画
        t = (frame - 1) / (frames - 1)
        angle = math.sin(t * 2 * math.pi) * 0.5
        
        # 设置腿部旋转
        if 'Leg_L' in pose_bones:
            pose_bones['Leg_L'].rotation_euler = (angle, 0, 0)
            pose_bones['Leg_L'].keyframe_insert(data_path='rotation_euler')
        
        if 'Leg_R' in pose_bones:
            pose_bones['Leg_R'].rotation_euler = (-angle, 0, 0)
            pose_bones['Leg_R'].keyframe_insert(data_path='rotation_euler')
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return armature
```

### 创建骨骼镜像

```python
def mirror_armature_arm(left_arm_name, right_arm_name):
    """镜像骨骼手臂"""
    bpy.ops.object.mode_set(mode='EDIT')
    
    # 选择左臂
    left_bone = armature.data.edit_bones.get(left_arm_name)
    if left_bone:
        bpy.ops.armature.select_all(action='DESELECT')
        left_bone.select = True
        bpy.context.active_object.data.edit_bones.active = left_bone
        
        # 执行镜像
        bpy.ops.armature.select_mirror(only_active=True)
    
    bpy.ops.object.mode_set(mode='OBJECT')
```

## 使用场景

- **角色绑定**：创建角色骨骼系统
- **动画制作**：创建和控制角色动画
- **IK系统**：添加反向动力学约束
- **FK系统**：正向动力学控制
- **程序化动画**：自动生成动画
- **骨骼镜像**：快速创建对称骨骼

## 注意事项

- 骨骼需要正确的父子关系
- IK链长度影响运动范围
- 骨骼名称用于引用和约束
- 姿态模式用于动画
- 编辑模式用于绑定
- 镜像需要正确命名
