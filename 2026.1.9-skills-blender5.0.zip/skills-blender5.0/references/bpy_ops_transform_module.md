# bpy.ops.transform 模块

变换操作模块，用于执行物体的变换操作（移动、旋转、缩放）。

## 概述

bpy.ops.transform 模块包含用于执行物体变换的运算符。这些运算符提供与变换操作符（Transform Operator）相同的功能，可以通过脚本控制物体的位置、旋转和缩放。

## 常用操作

### 通用变换参数

```python
import bpy

# 所有变换操作共享的参数
# value: 变换值（移动距离、旋转角度、缩放因子）
# orient_type: 变换轴向（'GLOBAL', 'LOCAL', 'NORMAL', 'GIMBAL', 'VIEW')
# orient_matrix_type: 方向矩阵类型
# constraint_axis: 约束轴 (x, y, z)
# constraint_orientation: 约束方向
# mirror: 镜像
# correct_aspect: 修正长宽比
# proportional: 使用比例编辑
# proportional_size: 比例编辑大小
# snap: 启用吸附
# snap_target: 吸附目标
# snap_point: 自定义吸附点
# snap_align: 对齐到吸附点
# use_transform_skip_children: 跳过子物体变换
```

### 平移操作

```python
# 沿指定轴移动
bpy.ops.transform.translate(
    value=(x, y, z),
    orient_type='GLOBAL',
    constraint_axis=(False, True, False)  # 仅Y轴
)

# 使用变换上下文移动
bpy.ops.transform.transform(
    mode='TRANSLATE',
    value=(1.0, 0.0, 0.0)
)
```

### 旋转操作

```python
# 旋转
bpy.ops.transform.rotate(
    value=radians,  # 弧度值
    orient_axis='Z',  # 旋转轴
    orient_type='GLOBAL'
)

# 自旋
bpy.ops.transform.spin(
    angle=radians,
    center=(0, 0, 0),
    axis='Z'
)

# 缩放
bpy.ops.transform.resize(
    value=(x, y, z),  # 缩放因子
    orient_type='GLOBAL',
    constraint_axis=(False, False, True)  # 仅Z轴
)
```

### 特殊变换

```python
# 倾斜
bpy.ops.transform.shear(
    value=(x, y, z),
    orient_axis_ortho='X',
    orient_axis='Z'
)

# 弯曲
bpy.ops.transform.bend(
    angle=radians,
    direction=(1, 0, 0),
    center=(0, 0, 0)
)

# 变形
bpy.ops.transform.deform(
    factor=1.0,
    mirror=True
)

# 推送
bpy.ops.transform.push_pull(
    value=1.0,
    mirror=True
)
```

### 变换应用

```python
# 应用旋转变换
bpy.ops.transform.rotate(value=0, mode='QUATERNION')

# 应用缩放变换
bpy.ops.transform.resize(value=(1, 1, 1))

# 应用所有变换
bpy.ops.transform.transform(mode='TRANSLATION')

# 重置变换
bpy.ops.transform.resize(value=(0, 0, 0))
```

## 实际应用示例

### 精确移动物体

```python
def precise_move(obj, target_location, axis_orient='GLOBAL'):
    """精确移动物体到指定位置"""
    # 计算移动值
    if axis_orient == 'GLOBAL':
        delta = (
            target_location[0] - obj.location.x,
            target_location[1] - obj.location.y,
            target_location[2] - obj.location.z
        )
    else:
        delta = target_location
    
    # 执行移动
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    bpy.ops.transform.translate(
        value=delta,
        orient_type=axis_orient
    )

# 使用示例
cube = bpy.data.objects['Cube']
precise_move(cube, (5.0, 0.0, 2.0), 'GLOBAL')
```

### 物体环绕动画

```python
def create_orbit_animation(obj, center_point, radius, num_frames=100):
    """创建物体环绕动画"""
    import math
    
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    for i in range(num_frames):
        angle = (2 * math.pi * i) / num_frames
        
        x = center_point[0] + radius * math.cos(angle)
        y = center_point[1] + radius * math.sin(angle)
        z = center_point[2]
        
        bpy.context.scene.frame_set(i)
        
        bpy.ops.transform.translate(
            value=(x - obj.location.x, y - obj.location.y, z - obj.location.z),
            orient_type='GLOBAL'
        )
        
        obj.keyframe_insert(data_path="location", frame=i)
```

### 批量缩放调整

```python
def batch_scale_objects(scale_factor, selected_only=True):
    """批量缩放选中物体"""
    if selected_only:
        objects = bpy.context.selected_objects
    else:
        objects = bpy.context.scene.objects
    
    bpy.ops.object.select_all(action='DESELECT')
    
    for obj in objects:
        obj.select_set(True)
    
    if not selected_only:
        bpy.ops.object.select_hierarchy(direction='CHILD', extend=True)
    
    bpy.ops.transform.resize(
        value=(scale_factor, scale_factor, scale_factor),
        orient_type='GLOBAL'
    )
```

### 沿法线挤出

```python
def extrude_along_normal(obj, distance, iterations=1):
    """沿法线方向挤出"""
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    
    for _ in range(iterations):
        bpy.ops.mesh.extrude_region_move(
            TRANSFORM_OT_translate={
                "value": (0, 0, distance),
                "orient_type": 'NORMAL'
            }
        )
    
    bpy.ops.object.mode_set(mode='OBJECT')
```

## 使用场景

- **物体定位**：通过脚本精确控制物体位置
- **动画创建**：批量生成变换动画关键帧
- **批量操作**：同时变换多个物体
- **几何编辑**：在编辑模式下变换几何元素
- **精确控制**：使用约束轴和方向进行精确变换

## 注意事项

- 变换操作影响当前选中的物体
- 在编辑模式下变换顶点、边、面
- 使用约束轴可以限制变换方向
- 比例编辑可以创建平滑变形效果
