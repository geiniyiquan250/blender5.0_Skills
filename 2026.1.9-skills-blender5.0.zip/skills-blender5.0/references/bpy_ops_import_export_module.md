# bpy.ops.import_export - Import and Export Operations Module

Blender 导入导出操作符，用于各种格式的文件导入和导出。

## Overview

`bpy.ops.import_export` 模块包含所有文件导入和导出的操作命令，支持多种 3D 格式、图像格式和动画格式。这个模块涵盖了从 OBJ、FBX、glTF 到 STL、PLY 等各种常用格式的导入导出功能。

## 核心导入操作

### 3D 模型导入

```python
import bpy

# 导入 OBJ
bpy.ops.import_scene.obj(filepath="//model.obj")

# 导入 FBX
bpy.ops.import_scene.fbx(filepath="//model.fbx")

# 导入 glTF
bpy.ops.import_scene.gltf(filepath="//model.gltf")
bpy.ops.import_scene.gltf(filepath="//model.glb")

# 导入 DAE
bpy.ops.import_scene.dae(filepath="//model.dae")

# 导入 3DS
bpy.ops.import_scene.three_ds(filepath="//model.3ds")

# 导入 X3D
bpy.ops.import_scene.x3d(filepath="//model.x3d")

# 导入 LWO
bpy.ops.import_scene.lwo(filepath="//model.lwo")

# 导入 LWS
bpy.ops.import_scene.lws(filepath="//model.lws")

# 导入 MS3D
bpy.ops.import_scene.ms3d(filepath="//model.ms3d")

# 导入 MDD
bpy.ops.import_scene.mdd(filepath="//model.mdd")

def import_obj_file(filepath, use_smooth_groups=True, use_edges=True):
    """导入 OBJ 文件"""
    bpy.ops.import_scene.obj(
        filepath=filepath,
        use_smooth_groups=use_smooth_groups,
        use_edges=use_edges
    )
    return bpy.context.active_object

def import_fbx_file(filepath, use_automatic_bone_orientation=True):
    """导入 FBX 文件"""
    bpy.ops.import_scene.fbx(
        filepath=filepath,
        use_automatic_bone_orientation=use_automatic_bone_orientation
    )
    return bpy.context.active_object

def import_gltf_file(filepath):
    """导入 glTF 文件"""
    bpy.ops.import_scene.gltf(filepath=filepath)
    return bpy.context.active_object
```

### 网格数据导入

```python
# 导入 PLY
bpy.ops.import_mesh.ply(filepath="//model.ply")

# 导入 STL
bpy.ops.import_mesh.stl(filepath="//model.stl")

# 导入 ABC（Alembic）
bpy.ops.wm.alembic_import(filepath="//model.abc")

# 导入 USD
bpy.ops.wm.usd_import(filepath="//model.usd")
bpy.ops.wm.usd_import(filepath="//model.usdz")

# 导入 VRML
bpy.ops.import_scene.vrml(filepath="//model.wrl")

# 导入 IFC
bpy.ops.import_scene.ifc(filepath="//model.ifc")

def import_ply_file(filepath):
    """导入 PLY 文件"""
    bpy.ops.import_mesh.ply(filepath=filepath)
    return bpy.context.active_object

def import_stl_file(filepath, scale=1.0):
    """导入 STL 文件"""
    bpy.ops.import_mesh.stl(filepath=filepath, scale=scale)
    return bpy.context.active_object

def import_alembic(filepath, frame_start=1, frame_end=30):
    """导入 Alembic 文件"""
    bpy.ops.wm.alembic_import(
        filepath=filepath,
        start=frame_start,
        end=frame_end
    )
    return bpy.context.active_object

def import_usd_file(filepath):
    """导入 USD 文件"""
    bpy.ops.wm.usd_import(filepath=filepath)
    return bpy.context.active_object
```

### 图像和纹理导入

```python
# 打开图像
bpy.ops.image.open(filepath="//texture.png")

# 打开序列图像
bpy.ops.image.open(filepath="//image_001.png")

# 打开 HDR
bpy.ops.image.open(filepath="//hdri.exr")

# 导入视频
bpy.ops.import_anim.gltf(filepath="//animation.glb")

def import_image(filepath):
    """导入图像"""
    bpy.ops.image.open(filepath=filepath)
    return bpy.context.active_object

def import_image_sequence(directory, start_frame=1):
    """导入图像序列"""
    import os
    files = sorted([f for f in os.listdir(directory) if f.endswith(('.png', '.jpg', '.jpeg'))])
    
    images = []
    for i, filename in enumerate(files):
        filepath = os.path.join(directory, filename)
        bpy.ops.image.open(filepath=filepath)
        img = bpy.context.active_image
        img.source = 'SEQUENCE'
        img_user = img.users[0] if img.users else None
        images.append(img)
    
    return images

def import_hdri(filepath):
    """导入 HDR 环境图"""
    bpy.ops.image.open(filepath=filepath)
    img = bpy.context.active_image
    img.source = 'FILE'
    return img
```

### 动画数据导入

```python
# 导入 MDD（动画变形）
bpy.ops.import_scene.mdd(filepath="//animation.mdd")

# 导入 BVH
bpy.ops.import_anim.bvh(filepath="//animation.bvh")

# 导入 glTF 动画
bpy.ops.import_scene.gltf(filepath="//animation.glb", export_format='GLTF')

# 导入 FBX 动画
bpy.ops.import_scene.fbx(filepath="//animation.fbx")

# 导入 Alembic 动画
bpy.ops.wm.alembic_import(filepath="//animation.abc")

# 导入 USD 动画
bpy.ops.wm.usd_import(filepath="//animation.usd")

def import_bvh_file(filepath, target_armature=None):
    """导入 BVH 动作文件"""
    bpy.ops.import_anim.bvh(
        filepath=filepath,
        target=target_armature
    )
    return bpy.context.active_object

def import_mdd_animation(filepath, target_object=None):
    """导入 MDD 动画"""
    bpy.ops.import_scene.mdd(filepath=filepath)
    return bpy.context.active_object
```

## 核心导出操作

### 3D 模型导出

```python
# 导出 OBJ
bpy.ops.export_scene.obj(filepath="//model.obj")

# 导出 FBX
bpy.ops.export_scene.fbx(filepath="//model.fbx")

# 导出 glTF
bpy.ops.export_scene.gltf(filepath="//model.gltf")
bpy.ops.export_scene.gltf(filepath="//model.glb")

# 导出 DAE
bpy.ops.export_scene.dae(filepath="//model.dae")

# 导出 3DS
bpy.ops.export_scene.three_ds(filepath="//model.3ds")

# 导出 X3D
bpy.ops.export_scene.x3d(filepath="//model.x3d")

# 导出 VRML
bpy.ops.export_scene.vrml(filepath="//model.wrl")

def export_obj_file(filepath, selection_only=False, use_smooth_groups=True):
    """导出 OBJ 文件"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        use_selection=selection_only,
        use_smooth_groups=use_smooth_groups
    )

def export_fbx_file(filepath, selection_only=False, apply_scale_options='FBX_SCALE_ALL'):
    """导出 FBX 文件"""
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        use_selection=selection_only,
        apply_scale_options=apply_scale_options
    )

def export_gltf_file(filepath, export_format='GLTF_EMBEDDED', selection_only=False):
    """导出 glTF 文件"""
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        export_format=export_format,
        use_selection=selection_only
    )
```

### 网格数据导出

```python
# 导出 PLY
bpy.ops.export_mesh.ply(filepath="//model.ply")

# 导出 STL
bpy.ops.export_mesh.stl(filepath="//model.stl")

# 导出 ABC（Alembic）
bpy.ops.wm.alembic_export(filepath="//model.abc")

# 导出 USD
bpy.ops.wm.usd_export(filepath="//model.usd")

# 导出 VRM
bpy.ops.export_scene.vrml(filepath="//model.vrm")

def export_ply_file(filepath, selection_only=False):
    """导出 PLY 文件"""
    bpy.ops.export_mesh.ply(
        filepath=filepath,
        use_selection=selection_only
    )

def export_stl_file(filepath, selection_only=False, scale=1.0):
    """导出 STL 文件"""
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        use_selection=selection_only,
        global_scale=scale
    )

def export_alembic(filepath, frame_start=1, frame_end=30):
    """导出 Alembic 文件"""
    bpy.ops.wm.alembic_export(
        filepath=filepath,
        start=frame_start,
        end=frame_end
    )

def export_usd_file(filepath, frame_start=1, frame_end=30):
    """导出 USD 文件"""
    bpy.ops.wm.usd_export(
        filepath=filepath,
        start=frame_start,
        end=frame_end
    )
```

### 图像导出

```python
# 保存图像
bpy.ops.image.save(filepath="//texture.png")

# 另存为
bpy.ops.image.save_as(filepath="//texture_new.png")

# 渲染并保存
bpy.ops.render.render(write_still=True)

# 导出渲染结果
bpy.ops.render.render(write_still=True)

def save_current_image(filepath):
    """保存当前图像"""
    bpy.ops.image.save(filepath=filepath)

def save_render_result(filepath):
    """保存渲染结果"""
    bpy.context.scene.render.filepath = filepath
    bpy.ops.render.render(write_still=True)

def export_render_sequence(output_dir, file_format='PNG'):
    """导出渲染序列"""
    scene = bpy.context.scene
    
    for frame in range(scene.frame_start, scene.frame_end + 1):
        scene.frame_set(frame)
        
        filename = f"frame_{frame:04d}.{file_format.lower()}"
        filepath = bpy.path.join(output_dir, filename)
        
        bpy.context.scene.render.filepath = filepath
        bpy.ops.render.render(write_still=True)
```

### 动画导出

```python
# 导出 BVH
bpy.ops.export_anim.bvh(filepath="//animation.bvh")

# 导出 glTF 动画
bpy.ops.export_scene.gltf(filepath="//animation.glb")

# 导出 ABC 动画
bpy.ops.wm.alembic_export(filepath="//animation.abc")

# 导出 USD 动画
bpy.ops.wm.usd_export(filepath="//animation.usd")

# 导出 FBX 动画
bpy.ops.export_scene.fbx(filepath="//animation.fbx", export_anim=True)

def export_bvh_file(filepath, frame_start=1, frame_end=30):
    """导出 BVH 动画"""
    bpy.ops.export_anim.bvh(
        filepath=filepath,
        frame_start=frame_start,
        frame_end=frame_end
    )

def export_animation(filepath, format='GLB'):
    """导出动画"""
    if format in ['GLB', 'GLTF']:
        bpy.ops.export_scene.gltf(
            filepath=filepath,
            export_format='GLTF_EMBEDDED' if format == 'GLTF' else 'GLB',
            export_anim=True
        )
    elif format == 'ABC':
        bpy.ops.wm.alembic_export(filepath=filepath)
    elif format == 'FBX':
        bpy.ops.export_scene.fbx(filepath=filepath, export_anim=True)
```

## 格式特定选项

### FBX 导出选项

```python
def export_fbx_animated(filepath, armature=None):
    """导出带动画的 FBX"""
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        use_selection=True if armature is None else False,
        apply_scale_options='FBX_SCALE_ALL',
        axis_forward='-Z',
        axis_up='Y',
        use_space_deform=True,
        bake_anim=True,
        bake_anim_use_all_bones=True,
        use_armature_deform=True
    )

def export_fbx_static(filepath):
    """导出静态 FBX"""
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        use_selection=True,
        apply_scale_options='FBX_SCALE_ALL',
        axis_forward='-Z',
        axis_up='Y',
        bake_anim=False
    )
```

### glTF 导出选项

```python
def export_gltf_with_materials(filepath, selection_only=False):
    """导出带材质的 glTF"""
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        export_format='GLTF_EMBEDDED',
        use_selection=selection_only,
        export_materials='EXPORT',
        export_colors=True,
        export_cameras=False,
        export_lights=False
    )

def export_gltf_animated(filepath, selection_only=False):
    """导出带动画的 glTF"""
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        export_format='GLB',
        use_selection=selection_only,
        export_anim=True,
        export_anim_use_nla_strips=True,
        export_anim_all_contacts=False,
        export_anim_sampling=True,
        export_anim_keyframe_tiers=False,
        export_lights=True,
        export_cameras=True
    )

def export_gltf_mesh_only(filepath, selection_only=False):
    """仅导出网格的 glTF"""
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        export_format='GLTF_SEPARATE',
        use_selection=selection_only,
        export_materials='EXPORT',
        export_anim=False,
        export_cameras=False,
        export_lights=False,
        export_extras=False
    )
```

### OBJ 导出选项

```python
def export_obj_with_materials(filepath):
    """导出带材质的 OBJ"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        use_selection=True,
        use_materials=True,
        use_triangles=False,
        use_normals=True,
        use_smooth_groups=True,
        use_uvs=True,
        axis_forward='-Z',
        axis_up='Y'
    )

def export_obj_for_3d_printing(filepath):
    """导出 3D 打印用的 OBJ"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        use_selection=True,
        use_materials=False,
        use_triangles=True,
        use_normals=True,
        use_smooth_groups=False,
        use_uvs=True,
        axis_forward='-Z',
        axis_up='Y'
    )
```

### STL 导出选项

```python
def export_stl_for_3d_printing(filepath, selection_only=False):
    """导出 3D 打印用的 STL"""
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        use_selection=selection_only,
        global_scale=1.0,
        apply_modifiers=True,
        use_mesh_modifiers=True,
        batch_mode='OFF'
    )

def export_stl_with_scale(filepath, scale=0.001, selection_only=False):
    """导出缩放的 STL"""
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        use_selection=selection_only,
        global_scale=scale,
        apply_modifiers=True,
        use_mesh_modifiers=True
    )
```

## 批量处理

```python
import bpy
import os

class BatchImporter:
    """批量导入器"""
    
    def __init__(self, directory):
        self.directory = directory
    
    def import_all_obj(self):
        """导入所有 OBJ 文件"""
        files = [f for f in os.listdir(self.directory) if f.endswith('.obj')]
        
        for filename in files:
            filepath = os.path.join(self.directory, filename)
            bpy.ops.import_scene.obj(filepath=filepath)
            print(f"导入: {filename}")
        
        return len(files)
    
    def import_all_fbx(self):
        """导入所有 FBX 文件"""
        files = [f for f in os.listdir(self.directory) if f.endswith('.fbx')]
        
        for filename in files:
            filepath = os.path.join(self.directory, filename)
            bpy.ops.import_scene.fbx(filepath=filepath)
            print(f"导入: {filename}")
        
        return len(files)
    
    def import_all_gltf(self):
        """导入所有 glTF 文件"""
        for ext in ['.gltf', '.glb']:
            files = [f for f in os.listdir(self.directory) if f.endswith(ext)]
            
            for filename in files:
                filepath = os.path.join(self.directory, filename)
                bpy.ops.import_scene.gltf(filepath=filepath)
                print(f"导入: {filename}")
        
        return len(files)

class BatchExporter:
    """批量导出器"""
    
    def __init__(self, directory):
        self.directory = directory
    
    def export_selected_as_obj(self):
        """导出选中的对象为 OBJ"""
        objects = bpy.context.selected_objects
        
        for obj in objects:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            
            filename = f"{obj.name}.obj"
            filepath = os.path.join(self.directory, filename)
            
            bpy.ops.export_scene.obj(filepath=filepath, use_selection=True)
            print(f"导出: {filename}")
        
        return len(objects)
    
    def export_selected_as_fbx(self):
        """导出选中的对象为 FBX"""
        objects = bpy.context.selected_objects
        
        for obj in objects:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            
            filename = f"{obj.name}.fbx"
            filepath = os.path.join(self.directory, filename)
            
            bpy.ops.export_scene.fbx(filepath=filepath, use_selection=True)
            print(f"导出: {filename}")
        
        return len(objects)
    
    def export_frame_range(self, output_dir, file_format='PNG'):
        """导出帧范围"""
        scene = bpy.context.scene
        
        for frame in range(scene.frame_start, scene.frame_end + 1):
            scene.frame_set(frame)
            
            filename = f"frame_{frame:04d}.{file_format.lower()}"
            filepath = os.path.join(output_dir, filename)
            
            bpy.context.scene.render.filepath = filepath
            bpy.ops.render.render(write_still=True)
            print(f"导出: {filename}")
        
        return scene.frame_end - scene.frame_start + 1

def batch_import_directory(directory, format='obj'):
    """批量导入目录"""
    importer = BatchImporter(directory)
    
    if format == 'obj':
        return importer.import_all_obj()
    elif format == 'fbx':
        return importer.import_all_fbx()
    elif format == 'gltf':
        return importer.import_all_gltf()
    
    return 0

def batch_export_directory(directory, format='obj'):
    """批量导出到目录"""
    exporter = BatchExporter(directory)
    
    if format == 'obj':
        return exporter.export_selected_as_obj()
    elif format == 'fbx':
        return exporter.export_selected_as_fbx()
    
    return 0
```

## 导入导出工程面板

```python
class ImportExportPanel(bpy.types.Panel):
    """导入导出面板"""
    bl_label = "导入导出"
    bl_idname = "IMPORT_EXPORT_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '导入导出'
    
    def draw(self, context):
        layout = self.layout
        
        layout.label(text="3D 模型导入:")
        
        row = layout.row()
        row.operator("import_scene.obj", text="OBJ")
        row.operator("import_scene.fbx", text="FBX")
        row.operator("import_scene.gltf", text="glTF")
        
        row = layout.row()
        row.operator("import_mesh.ply", text="PLY")
        row.operator("import_mesh.stl", text="STL")
        row.operator("import_scene.dae", text="DAE")
        
        layout.separator()
        layout.label(text="3D 模型导出:")
        
        row = layout.row()
        row.operator("export_scene.obj", text="OBJ")
        row.operator("export_scene.fbx", text="FBX")
        row.operator("export_scene.gltf", text="glTF")
        
        row = layout.row()
        row.operator("export_mesh.ply", text="PLY")
        row.operator("export_mesh.stl", text="STL")
        row.operator("export_scene.dae", text="DAE")
        
        layout.separator()
        layout.label(text="动画导入:")
        
        row = layout.row()
        row.operator("import_anim.bvh", text="BVH")
        row.operator("import_scene.mdd", text="MDD")
        row.operator("wm.alembic_import", text="Alembic")
        
        layout.separator()
        layout.label(text="动画导出:")
        
        row = layout.row()
        row.operator("export_anim.bvh", text="BVH")
        row.operator("wm.alembic_export", text="Alembic")
        row.operator("wm.usd_export", text="USD")

class BatchProcessPanel(bpy.types.Panel):
    """批量处理面板"""
    bl_label = "批量处理"
    bl_idname = "IMPORT_EXPORT_PT_batch"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '导入导出'
    
    def draw(self, context):
        layout = self.layout
        
        layout.label(text="批量导入:")
        
        row = layout.row()
        row.operator("batch_import.obj", text="导入 OBJ 目录")
        row.operator("batch_import.fbx", text="导入 FBX 目录")
        
        row = layout.row()
        row.operator("batch_import.gltf", text="导入 glTF 目录")
        row.operator("batch_import.images", text="导入图像目录")
        
        layout.separator()
        layout.label(text="批量导出:")
        
        row = layout.row()
        row.operator("batch_export.obj", text="导出 OBJ")
        row.operator("batch_export.fbx", text="导出 FBX")
        
        row = layout.row()
        row.operator("batch_export.images", text="导出图像序列")
        row.operator("batch_export.video", text="导出视频")
```

## 最佳实践

### 1. 导入最佳实践

```python
def import_with_cleanup(filepath, format='obj'):
    """导入并清理"""
    # 导入前选择所有对象
    bpy.ops.object.select_all(action='SELECT')
    
    # 导入
    if format == 'obj':
        bpy.ops.import_scene.obj(filepath=filepath)
    elif format == 'fbx':
        bpy.ops.import_scene.fbx(filepath=filepath)
    elif format == 'gltf':
        bpy.ops.import_scene.gltf(filepath=filepath)
    
    # 选择导入的对象
    imported_objects = [obj for obj in bpy.context.selected_objects if obj != bpy.context.active_object]
    
    return imported_objects

def import_and_setup(filepath, format='obj'):
    """导入并设置"""
    objects = import_with_cleanup(filepath, format)
    
    # 设置为平滑着色
    for obj in objects:
        if obj.type == 'MESH':
            bpy.ops.object.shade_smooth()
    
    # 重置变换
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    
    return objects
```

### 2. 导出最佳实践

```python
def export_selected_animated(filepath, format='glb'):
    """导出选中的动画对象"""
    # 确保选中的对象有动画
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        use_selection=True,
        export_anim=True,
        export_anim_use_nla_strips=True
    )

def export_for_web(filepath, format='glb'):
    """导出网页用模型"""
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        export_format='GLB',
        use_selection=False,
        export_materials='EXPORT',
        export_colors=True,
        export_anim=True,
        export_cameras=False,
        export_lights=True,
        export_extras=False,
        export_yup=True
    )

def export_for_game_engine(filepath, format='fbx'):
    """导出游戏引擎模型"""
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        use_selection=True,
        apply_scale_options='FBX_SCALE_ALL',
        axis_forward='-Z',
        axis_up='Y',
        bake_anim=True,
        use_armature_deform=True,
        export_anim=True,
        export_lights=True,
        export_cameras=False
    )
```

### 3. 格式转换

```python
def convert_format(input_path, output_path, input_format, output_format):
    """转换格式"""
    # 导入
    if input_format == 'obj':
        bpy.ops.import_scene.obj(filepath=input_path)
    elif input_format == 'fbx':
        bpy.ops.import_scene.fbx(filepath=input_path)
    elif input_format == 'gltf':
        bpy.ops.import_scene.gltf(filepath=input_path)
    
    # 导出
    if output_format == 'obj':
        bpy.ops.export_scene.obj(filepath=output_path)
    elif output_format == 'fbx':
        bpy.ops.export_scene.fbx(filepath=output_path)
    elif output_format == 'glb':
        bpy.ops.export_scene.gltf(filepath=output_path, export_format='GLB')

def batch_convert_format(input_dir, output_dir, input_format, output_format):
    """批量转换格式"""
    import os
    
    input_files = [f for f in os.listdir(input_dir) if f.endswith(f'.{input_format}')]
    
    for filename in input_files:
        input_path = os.path.join(input_dir, filename)
        
        base_name = os.path.splitext(filename)[0]
        output_filename = f"{base_name}.{output_format}"
        output_path = os.path.join(output_dir, output_filename)
        
        convert_format(input_path, output_path, input_format, output_format)
        print(f"转换: {filename} -> {output_filename}")
    
    return len(input_files)
```

## 常见问题

### Q: 导入的模型没有材质
A: 某些格式不支持材质，确保导出时包含材质信息。

### Q: 动画丢失
A: 检查时间轴设置，确保导出时包含动画数据。

### Q: 坐标系不同
A: 导出时调整轴向设置，Blender 使用 Y-up，DirectX 使用 Z-up。

### Q: 文件过大
A: 使用 glTF 的二进制格式，减小纹理分辨率或使用压缩。

## 相关模块

- [bpy.ops.file](bpy_ops_file_module.md) - 文件操作
- [bpy.ops.object](bpy_ops_object_module.md) - 对象操作
- [bpy.ops.scene](bpy_ops_detailed_module.md) - 场景操作
- [bpy.types](bpy_types_detailed_module.md) - 数据类型
