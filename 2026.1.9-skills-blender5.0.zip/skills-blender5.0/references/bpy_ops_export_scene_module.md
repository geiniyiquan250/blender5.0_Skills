# bpy.ops.export_scene - Scene Export Operations Module

Blender 场景导出操作符，用于将 Blender 场景导出为各种 3D 格式文件。

## Overview

`bpy.ops.export_scene` 模块包含场景导出操作命令，支持将场景导出为 FBX、OBJ、GLTF、3DS 等常用 3D 格式。这个模块提供了丰富的导出选项，满足不同平台和工作流程的需求。

## 核心功能

### 导出格式支持

```python
import bpy

# 导出 FBX 格式
bpy.ops.export_scene.fbx(
    filepath="C:/exports/character.fbx",
    use_selection=False,
    axis_forward='-Z',
    axis_up='Y',
    apply_unit_scale=True,
    apply_scale_options='FBX_SCALE_ALL',
    bake_space_transform=False,
    use_custom_normals=True,
    use_animations=True,
    use_anim_action_all=True,
    export_anim=True,
    export_anim_shape_keys=True,
    export_anim_use_nla_strips=True,
    export_anim_free_NLA=False,
    export_anim_use_all_bones=True,
    export_anim_force_euler_rotation=True,
    export_current_frame=True,
    export_skins=True,
    export_all_influences=False,
    export_deform_bones_only=False,
    export_lights=True,
    export_cameras=True,
    export_materials=True,
    export_textures=True,
    export_yup=True
)

# 导出 OBJ 格式
bpy.ops.export_scene.obj(
    filepath="C:/exports/model.obj",
    use_selection=False,
    use_triangles=False,
    use_normals=True,
    use_uvs=True,
    use_materials=True,
    use_nurbs=False,
    use_vertex_groups=False,
    use_mesh_modifiers=True,
    use_smooth_groups=False,
    use_smooth_groups_bitflags=False,
    use_polygon_groups=False,
    keep_vertex_order=False,
    export_uvs=True,
    export_normals=True,
    export_materials=True,
    export_cameras=False,
    export_lights=False,
    apply_modifiers=True,
    group_by_object=False,
    group_by_material=False,
    keep_vertex_order=True
)

# 导出 GLTF 格式
bpy.ops.export_scene.gltf(
    filepath="C:/exports/scene.glb",
    export_format='GLB',
    use_selection=False,
    export_apply=True,
    export_texcoords=True,
    export_normals=True,
    export_draco_mesh_compression_enable=False,
    export_draco_mesh_compression_level=6,
    export_draco_position_quantization=14,
    export_draco_normal_quantization=10,
    export_draco_texcoord_quantization=12,
    export_materials='EXPORT',
    export_colors=True,
    export_cameras=False,
    export_lights=False,
    export_yup=True,
    export_animations=True,
    export_frame_range=True,
    export_frame_step=1,
    export_nla_strips=True,
    export_nla_strip_merged_animation_name='NLA Merged',
    export_anim_single_armature=True,
    export_anim_use_nla_strips=True,
    export_anim_use_all_actions=True,
    export_anim_action_from_nla=False,
    export_anim_force_euler_rotation=True,
    export_anim_bake_all_skipped=False,
    export_anim_no_root_bones=False,
    export_anim_use_current_frame=False,
    export_anim_loop_restart=True
)

# 导出 ABC 格式（Alembic）
bpy.ops.export_scene.alembic(
    filepath="C:/exports/scene.abc",
    apply_unit_scale=True,
    export_hair=True,
    export_particles=True,
    export_anim=True,
    export_anim_include='SELECTED_OBJECTS',
    export_anim_hierarchy=True,
    export_anim_cacheable=True,
    export_anim_range=True,
    export_anim_frame_start=1,
    export_anim_frame_end=250,
    export_anim_step=1,
    export_anim_proxy=True,
    export_surface_type='MESH',
    export_group_by_object=False,
    export_group_by_collection=False,
    use_instance_collection=True,
    export_material_assignments=True
)
```

### FBX 导出详细选项

```python
def export_fbx(filepath, objects=None, animations=True, materials=True):
    """导出 FBX 文件"""
    if objects is None:
        objects = bpy.context.scene.objects
    
    # 选择对象
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        obj.select_set(True)
    
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        use_selection=True,
        axis_forward='-Z',
        axis_up='Y',
        apply_unit_scale=True,
        use_custom_normals=True,
        use_animations=animations,
        use_anim_action_all=True,
        export_anim=animations,
        export_skins=True,
        export_lights=True,
        export_cameras=True,
        export_materials=materials,
        export_textures=False,
        export_yup=True
    )
    print(f"已导出 FBX: {filepath}")
    return True

def export_fbx_animations_only(filepath, action_name=None):
    """仅导出动画"""
    if action_name:
        action = bpy.data.actions.get(action_name)
        if action:
            action.use_fake_user = True
    
    bpy.ops.export_scene.fbx(
        filepath=filepath,
        use_selection=False,
        export_anim=True,
        export_anim_shape_keys=True,
        export_anim_use_nla_strips=True,
        export_skins=False,
        export_materials=False,
        export_cameras=False,
        export_lights=False
    )
    return True
```

### OBJ 导出详细选项

```python
def export_obj(filepath, selected_only=True, apply_modifiers=True):
    """导出 OBJ 文件"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        use_selection=selected_only,
        use_triangles=False,
        use_normals=True,
        use_uvs=True,
        use_materials=True,
        use_mesh_modifiers=apply_modifiers,
        export_uvs=True,
        export_normals=True,
        export_materials=True,
        export_cameras=False,
        export_lights=False,
        apply_modifiers=apply_modifiers,
        group_by_object=False,
        group_by_material=False,
        keep_vertex_order=True
    )
    print(f"已导出 OBJ: {filepath}")
    return True

def export_obj_with_mtl(filepath, selected_only=True):
    """导出 OBJ 并包含 MTL 文件"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        use_selection=selected_only,
        use_triangles=False,
        use_normals=True,
        use_uvs=True,
        use_materials=True,
        export_uvs=True,
        export_normals=True,
        export_materials=True,
        export_cameras=False,
        export_lights=False
    )
    
    # OBJ 导出自动生成同名 .mtl 文件
    mtl_path = filepath.replace('.obj', '.mtl')
    if os.path.exists(mtl_path):
        print(f"MTL 文件已生成: {mtl_path}")
    
    return True
```

### GLTF 导出详细选项

```python
def export_gltf(filepath, format='GLB', selected_only=False, export_anim=True):
    """导出 GLTF/GLB 文件"""
    fmt_map = {'GLB': 'GLB', 'GLTF_EMBEDDED': 'GLTF_EMBEDDED', 'GLTF_SEPARATE': 'GLTF_SEPARATE'}
    
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        export_format=fmt_map.get(format, 'GLB'),
        use_selection=selected_only,
        export_apply=True,
        export_texcoords=True,
        export_normals=True,
        export_materials='EXPORT',
        export_colors=True,
        export_cameras=False,
        export_lights=False,
        export_animations=export_anim,
        export_frame_range=True,
        export_frame_step=1,
        export_nla_strips=True,
        export_anim_use_all_actions=True,
        export_anim_force_euler_rotation=True
    )
    print(f"已导出 GLTF: {filepath}")
    return True

def export_gltf_web(filepath):
    """导出适合 Web 使用的 GLTF"""
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        export_format='GLB',
        use_selection=False,
        export_texcoords=True,
        export_normals=True,
        export_materials='EXPORT',
        export_colors=True,
        export_cameras=False,
        export_lights=False,
        export_animations=True,
        export_frame_range=True,
        export_nla_strips=True,
        export_anim_use_all_actions=True
    )
    return True

def export_gltf_animations(filepath, frame_start=1, frame_end=250):
    """导出 GLTF 动画"""
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        export_format='GLB',
        use_selection=False,
        export_animations=True,
        export_anim_use_all_actions=True,
        export_anim_action_from_nla=False,
        export_anim_frame_start=frame_start,
        export_anim_frame_end=frame_end,
        export_nla_strips=True,
        export_nla_strip_merged_animation_name='ExportedAnimation'
    )
    return True
```

## 实际应用示例

### 批量导出管理器

```python
import bpy
import os
from pathlib import Path

class BatchExportManager:
    """批量导出管理器"""
    
    def __init__(self, export_dir):
        self.export_dir = export_dir
        self.exported_files = []
        self.failed_files = []
        os.makedirs(export_dir, exist_ok=True)
    
    def export_selected_objects(self, basename, format='fbx'):
        """导出选中的对象"""
        objects = bpy.context.selected_objects
        if not objects:
            print("没有选中的对象")
            return None
        
        filepath = os.path.join(self.export_dir, f"{basename}.{format}")
        
        if format == 'fbx':
            bpy.ops.export_scene.fbx(filepath=filepath, use_selection=True)
        elif format == 'obj':
            bpy.ops.export_scene.obj(filepath=filepath, use_selection=True)
        elif format == 'gltf':
            bpy.ops.export_scene.gltf(filepath=filepath, use_selection=True)
        
        self.exported_files.append(filepath)
        return filepath
    
    def export_by_collection(self, format='fbx'):
        """按集合导出"""
        for collection in bpy.data.collections:
            if not collection.objects:
                continue
            
            # 选择集合中的所有对象
            bpy.ops.object.select_all(action='DESELECT')
            for obj in collection.objects:
                obj.select_set(True)
            
            # 导出
            basename = collection.name.replace(' ', '_')
            filepath = os.path.join(self.export_dir, f"{basename}.{format}")
            
            try:
                if format == 'fbx':
                    bpy.ops.export_scene.fbx(filepath=filepath, use_selection=True)
                elif format == 'gltf':
                    bpy.ops.export_scene.gltf(filepath=filepath, use_selection=True)
                
                self.exported_files.append(filepath)
                print(f"已导出: {filepath}")
            except Exception as e:
                self.failed_files.append((collection.name, str(e)))
                print(f"导出失败: {collection.name} - {e}")
    
    def export_animation_ranges(self, format='gltf'):
        """按动画范围导出"""
        scene = bpy.context.scene
        
        # 导出当前动画范围
        filepath = os.path.join(self.export_dir, f"animation_{scene.frame_start}_{scene.frame_end}.{format}")
        
        if format == 'gltf':
            bpy.ops.export_scene.gltf(
                filepath=filepath,
                export_format='GLB',
                use_selection=False,
                export_animations=True,
                export_anim_frame_start=scene.frame_start,
                export_anim_frame_end=scene.frame_end
            )
        
        self.exported_files.append(filepath)
        return filepath
    
    def export_all_actions(self, format='gltf'):
        """导出所有动作"""
        for action in bpy.data.actions:
            if action.users == 0 and not action.use_fake_user:
                continue
            
            # 设置时间轴到动作范围
            if action.frame_range[1] > action.frame_range[0]:
                bpy.context.scene.frame_start = int(action.frame_range[0])
                bpy.context.scene.frame_end = int(action.frame_range[1])
            
            # 导出
            safe_name = "".join(c if c.isalnum() or c in ('_', '-') else '_' for c in action.name)
            filepath = os.path.join(self.export_dir, f"{safe_name}.{format}")
            
            if format == 'gltf':
                bpy.ops.export_scene.gltf(
                    filepath=filepath,
                    export_format='GLB',
                    export_animations=True,
                    export_anim_use_all_actions=False
                )
            
            self.exported_files.append(filepath)
        
        return self.exported_files
    
    def get_export_report(self):
        """获取导出报告"""
        return {
            'successful': len(self.exported_files),
            'failed': len(self.failed_files),
            'exported_files': self.exported_files.copy(),
            'failed_files': self.failed_files.copy()
        }


def batch_export_scene(export_dir, format='gltf'):
    """批量导出场景"""
    manager = BatchExportManager(export_dir)
    
    # 导出所有集合
    manager.export_by_collection(format=format)
    
    report = manager.get_export_report()
    print(f"\n导出完成:")
    print(f"  成功: {report['successful']} 个文件")
    print(f"  失败: {report['failed']} 个文件")
    
    return manager
```

### 导出预设系统

```python
import bpy
import json

class ExportPresetManager:
    """导出预设管理器"""
    
    presets = {}
    
    @classmethod
    def save_preset(cls, name, settings):
        """保存预设"""
        cls.presets[name] = settings
        return cls.presets
    
    @classmethod
    def get_preset(cls, name):
        """获取预设"""
        return cls.presets.get(name)
    
    @classmethod
    def list_presets(cls):
        """列出所有预设"""
        return list(cls.presets.keys())
    
    @classmethod
    def delete_preset(cls, name):
        """删除预设"""
        if name in cls.presets:
            del cls.presets[name]
            return True
        return False
    
    @classmethod
    def create_fbx_preset(cls, name, preset_type='character'):
        """创建 FBX 预设"""
        presets = {
            'character': {
                'use_selection': False,
                'export_anim': True,
                'export_skins': True,
                'export_materials': True,
                'export_lights': True,
                'export_cameras': True,
                'axis_forward': '-Z',
                'axis_up': 'Y'
            },
            'game_asset': {
                'use_selection': True,
                'export_anim': False,
                'export_skins': True,
                'export_materials': True,
                'export_lights': False,
                'export_cameras': False,
                'use_triangles': True,
                'apply_scale_options': 'FBX_SCALE_ALL'
            },
            'animation_only': {
                'use_selection': False,
                'export_anim': True,
                'export_skins': False,
                'export_materials': False,
                'export_lights': False,
                'export_cameras': False,
                'export_anim_use_all_actions': True
            }
        }
        
        if preset_type in presets:
            cls.presets[name] = presets[preset_type]
        
        return cls.presets[name]
    
    @classmethod
    def create_gltf_preset(cls, name, preset_type='web'):
        """创建 GLTF 预设"""
        presets = {
            'web': {
                'export_format': 'GLB',
                'use_selection': False,
                'export_materials': 'EXPORT',
                'export_animations': True,
                'export_cameras': False,
                'export_lights': False,
                'export_texcoords': True,
                'export_normals': True
            },
            'ar': {
                'export_format': 'GLB',
                'use_selection': True,
                'export_materials': 'EXPORT',
                'export_animations': False,
                'export_cameras': False,
                'export_lights': False,
                'export_draco_mesh_compression_enable': True
            },
            'interchange': {
                'export_format': 'GLTF_SEPARATE',
                'use_selection': False,
                'export_materials': 'EXPORT',
                'export_animations': True,
                'export_cameras': True,
                'export_lights': True,
                'export_texcoords': True,
                'export_normals': True
            }
        }
        
        if preset_type in presets:
            cls.presets[name] = presets[preset_type]
        
        return cls.presets[name]
    
    @classmethod
    def apply_preset(cls, name, filepath, format='fbx'):
        """应用预设导出"""
        preset = cls.presets.get(name)
        if not preset:
            print(f"未找到预设: {name}")
            return None
        
        kwargs = preset.copy()
        kwargs['filepath'] = filepath
        
        if format == 'fbx':
            bpy.ops.export_scene.fbx(**kwargs)
        elif format == 'gltf':
            bpy.ops.export_scene.gltf(**kwargs)
        
        return filepath
    
    @classmethod
    def export_to_preset(cls, preset_name, basename, export_dir, format='fbx'):
        """使用预设导出"""
        filepath = os.path.join(export_dir, f"{basename}.{format}")
        return cls.apply_preset(preset_name, filepath, format)


def setup_export_presets():
    """设置导出预设"""
    ExportPresetManager.create_fbx_preset('fbx_character', 'character')
    ExportPresetManager.create_fbx_preset('fbx_game_asset', 'game_asset')
    ExportPresetManager.create_fbx_preset('fbx_animation', 'animation_only')
    ExportPresetManager.create_gltf_preset('gltf_web', 'web')
    ExportPresetManager.create_gltf_preset('gltf_ar', 'ar')
    ExportPresetManager.create_gltf_preset('gltf_interchange', 'interchange')
    
    print("导出预设已创建:")
    print(ExportPresetManager.list_presets())
    
    return ExportPresetManager
```

### 游戏资产导出器

```python
import bpy
import os

class GameAssetExporter:
    """游戏资产导出器"""
    
    def __init__(self, export_dir):
        self.export_dir = export_dir
        os.makedirs(export_dir, exist_ok=True)
    
    def prepare_asset(self, obj, name):
        """准备资产"""
        # 复制对象
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.duplicate(linked=False)
        
        duplicate = bpy.context.active_object
        duplicate.name = name
        
        # 应用所有修改器
        for modifier in duplicate.modifiers:
            bpy.ops.object.modifier_apply(modifier=modifier.name)
        
        # 重置变换
        duplicate.location = (0, 0, 0)
        duplicate.rotation_euler = (0, 0, 0)
        duplicate.scale = (1, 1, 1)
        
        # 移除不需要的集合
        for collection in duplicate.users_collection:
            collection.objects.unlink(duplicate)
        
        return duplicate
    
    def export_static_mesh(self, obj, name, formats=None):
        """导出静态网格"""
        if formats is None:
            formats = ['fbx', 'obj', 'glb']
        
        prepared = self.prepare_asset(obj, name)
        results = []
        
        for fmt in formats:
            filepath = os.path.join(self.export_dir, f"{name}.{fmt}")
            
            if fmt == 'fbx':
                bpy.ops.export_scene.fbx(
                    filepath=filepath,
                    use_selection=True,
                    apply_scale_options='FBX_SCALE_ALL',
                    use_triangles=True,
                    export_anim=False,
                    export_materials=True
                )
            elif fmt == 'obj':
                bpy.ops.export_scene.obj(
                    filepath=filepath,
                    use_selection=True,
                    use_triangles=False,
                    export_anim=False,
                    export_materials=True
                )
            elif fmt == 'glb':
                bpy.ops.export_scene.gltf(
                    filepath=filepath,
                    export_format='GLB',
                    use_selection=True,
                    export_animations=False,
                    export_materials='EXPORT'
                )
            
            results.append(filepath)
        
        # 删除复制的对象
        bpy.data.objects.remove(prepared)
        
        return results
    
    def export_animated_mesh(self, obj, name, formats=None):
        """导出带动画的网格"""
        if formats is None:
            formats = ['fbx', 'glb']
        
        prepared = self.prepare_asset(obj, name)
        results = []
        
        for fmt in formats:
            filepath = os.path.join(self.export_dir, f"{name}_animated.{fmt}")
            
            if fmt == 'fbx':
                bpy.ops.export_scene.fbx(
                    filepath=filepath,
                    use_selection=True,
                    apply_scale_options='FBX_SCALE_ALL',
                    use_triangles=True,
                    export_anim=True,
                    export_skins=True,
                    export_anim_use_all_actions=True
                )
            elif fmt == 'glb':
                bpy.ops.export_scene.gltf(
                    filepath=filepath,
                    export_format='GLB',
                    use_selection=True,
                    export_animations=True,
                    export_anim_use_all_actions=True
                )
            
            results.append(filepath)
        
        return results
    
    def export_materials_only(self, mat, name):
        """仅导出材质信息"""
        # 材质无法直接导出，这里生成材质配置文件
        config = {
            'name': mat.name,
            'use_nodes': mat.use_nodes,
            'blend_method': mat.blend_method,
            'shadow_method': mat.shadow_method
        }
        
        if mat.use_nodes:
            config['node_tree'] = {
                'nodes': [n.type for n in mat.node_tree.nodes],
                'links': len(mat.node_tree.links)
            }
        
        filepath = os.path.join(self.export_dir, f"{name}_material.json")
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2)
        
        return filepath
    
    def export_texture_reference(self, image, name):
        """导出纹理引用"""
        filepath = os.path.join(self.export_dir, f"{name}_texture.txt")
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"Name: {image.name}\n")
            f.write(f"Size: {image.size[0]} x {image.size[1]}\n")
            f.write(f"Has Alpha: {image.alpha_mode != 'NONE'}\n")
            f.write(f"Source Path: {image.filepath}\n")
        
        return filepath


def export_game_assets(export_dir, selected_only=True):
    """导出游戏资产"""
    exporter = GameAssetExporter(export_dir)
    
    if selected_only:
        objects = bpy.context.selected_objects
    else:
        objects = list(bpy.data.objects)
    
    results = {
        'static_meshes': [],
        'animated_meshes': [],
        'materials': [],
        'textures': []
    }
    
    for obj in objects:
        if obj.type == 'MESH':
            # 检查是否有动画
            has_animation = any(
                fcurves for fcurves in obj.animation_data.action.fcurves
            ) if obj.animation_data and obj.animation_data.action else False
            
            name = obj.name.replace(' ', '_')
            
            if has_animation:
                exported = exporter.export_animated_mesh(obj, name)
                results['animated_meshes'].extend(exported)
            else:
                exported = exporter.export_static_mesh(obj, name)
                results['static_meshes'].extend(exported)
        
        elif obj.type == 'MATERIAL':
            results['materials'].append(
                exporter.export_materials_only(obj, obj.name)
            )
        
        elif obj.type == 'EMPTY' and obj.instance_type == 'COLLECTION':
            # 处理实例化的集合
            pass
    
    print(f"资产导出完成:")
    print(f"  静态网格: {len(results['static_meshes'])} 个")
    print(f"  动画网格: {len(results['animated_meshes'])} 个")
    print(f"  材质信息: {len(results['materials'])} 个")
    
    return results
```
