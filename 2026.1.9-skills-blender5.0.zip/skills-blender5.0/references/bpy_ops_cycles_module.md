# bpy.ops.cycles - Cycles Render Operations Module

Blender Cycles 渲染器操作符，用于 Cycles 渲染相关的操作。

## Overview

`bpy.ops.cycles` 模块包含 Cycles 渲染器的操作命令，支持渲染、光线追踪和着色器编辑。这个模块主要用于 Cycles 渲染引擎的控制和优化。

## 核心功能

```python
import bpy

# Cycles 渲染
bpy.ops.render.render()

# 采样控制
bpy.ops.render.sample()

# 光线追踪
bpy.ops.render.cycles_render()
```

## 实际应用示例

### Cycles 渲染管理器

```python
import bpy

class CyclesRenderManager:
    """Cycles 渲染管理器"""
    
    def __init__(self):
        self.render_settings = {}
    
    def set_samples(self, samples):
        """设置采样数"""
        bpy.context.scene.cycles.samples = samples
    
    def set_max_samples(self, samples):
        """设置最大采样"""
        bpy.context.scene.cycles.max_samples = samples
    
    def set_min_samples(self, samples):
        """设置最小采样"""
        bpy.context.scene.cycles.min_samples = samples
    
    def enable_adaptive_sampling(self, adaptive=True):
        """启用自适应采样"""
        bpy.context.scene.cycles.use_adaptive_sampling = adaptive
    
    def set_adaptive_threshold(self, threshold=0.05):
        """设置自适应阈值"""
        bpy.context.scene.cycles.adaptive_threshold = threshold
    
    def set_adaptive_steps(self, steps=2):
        """设置自适应步数"""
        bpy.context.scene.cycles.adaptive_steps = steps
    
    def set_tile_size(self, size=256):
        """设置分块大小"""
        bpy.context.scene.cycles.tile_size = size
    
    def set_tile_order(self, order='CENTER'):
        """设置分块顺序"""
        bpy.context.scene.cycles.tile_order = order
    
    def use_gpu(self, use=True):
        """使用 GPU"""
        bpy.context.scene.cycles.device = 'GPU' if use else 'CPU'
    
    def get_devices(self):
        """获取可用设备"""
        return bpy.context.scene.cycles.devices
    
    def set_device(self, device_type='CUDA'):
        """设置设备"""
        bpy.context.scene.cycles.device = device_type
    
    def enable_progressive_refine(self, enable=True):
        """启用渐进细化"""
        bpy.context.scene.cycles.use_progressive_refine = enable
    
    def set_blur_glossy(self, blur=0.0):
        """设置模糊光泽"""
        bpy.context.scene.cycles.blur_glossy = blur
    
    def set_light_sampling_threshold(self, threshold=0.0):
        """设置光线采样阈值"""
        bpy.context.scene.cycles.light_sampling_threshold = threshold
    
    def set_caustics_refractive(self, enable=True):
        """启用折射焦散"""
        bpy.context.scene.cycles.caustics_refractive = enable
    
    def set_caustics_reflective(self, enable=True):
        """启用反射焦散"""
        bpy.context.scene.cycles.caustics_reflective = enable
    
    def export_render_settings(self, filepath):
        """导出渲染设置"""
        settings = bpy.context.scene.cycles
        
        data = {
            'samples': settings.samples,
            'max_samples': settings.max_samples,
            'min_samples': settings.min_samples,
            'device': settings.device,
            'tile_size': settings.tile_size,
            'blur_glossy': settings.blur_glossy
        }
        
        import json
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        
        return filepath
    
    def import_render_settings(self, filepath):
        """导入渲染设置"""
        import json
        
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        settings = bpy.context.scene.cycles
        
        for key, value in data.items():
            if hasattr(settings, key):
                setattr(settings, key, value)
        
        return True


def setup_cycles_manager():
    """设置 Cycles 渲染管理器"""
    manager = CyclesRenderManager()
    
    print("Cycles 渲染管理器已设置")
    print("可用功能:")
    print("- set_samples: 设置采样")
    print("- use_gpu: 使用 GPU")
    print("- enable_adaptive_sampling: 自适应采样")
    
    return manager
```

### 渲染优化工具

```python
import bpy

class RenderOptimizationTool:
    """渲染优化工具"""
    
    def __init__(self):
        self.optimization_profiles = {}
    
    def create_preview_profile(self):
        """创建预览配置"""
        return {
            'samples': 32,
            'tile_size': 64,
            'max_bounces': 2,
            'use_gpu': True,
            'resolution_percent': 50
        }
    
    def create_final_profile(self):
        """创建最终渲染配置"""
        return {
            'samples': 256,
            'tile_size': 256,
            'max_bounces': 12,
            'use_gpu': True,
            'resolution_percent': 100
        }
    
    def create_quick_profile(self):
        """创建快速渲染配置"""
        return {
            'samples': 64,
            'tile_size': 128,
            'max_bounces': 4,
            'use_gpu': True,
            'resolution_percent': 75
        }
    
    def apply_profile(self, profile):
        """应用配置"""
        scene = bpy.context.scene
        cycles = scene.cycles
        
        cycles.samples = profile.get('samples', 128)
        cycles.tile_size = profile.get('tile_size', 256)
        scene.render.resolution_x = int(scene.render.resolution_x * profile.get('resolution_percent', 100) / 100)
        scene.render.resolution_y = int(scene.render.resolution_y * profile.get('resolution_percent', 100) / 100)
    
    def optimize_for_interactive(self):
        """优化交互渲染"""
        profile = {
            'samples': 16,
            'tile_size': 32,
            'use_gpu': True,
            'max_bounces': 2,
            'use_adaptive_sampling': True
        }
        
        self.apply_profile(profile)
    
    def optimize_for_final(self):
        """优化最终渲染"""
        profile = self.create_final_profile()
        self.apply_profile(profile)
    
    def set_resolution_scale(self, percent):
        """设置分辨率缩放"""
        bpy.context.scene.render.resolution_percentage = percent
    
    def set_quality_setting(self, quality='MEDIUM'):
        """设置质量"""
        settings = {
            'LOW': {'samples': 32, 'max_bounces': 2, 'tile_size': 64},
            'MEDIUM': {'samples': 128, 'max_bounces': 6, 'tile_size': 128},
            'HIGH': {'samples': 256, 'max_bounces': 12, 'tile_size': 256}
        }
        
        if quality in settings:
            for key, value in settings[quality].items():
                if key == 'samples':
                    bpy.context.scene.cycles.samples = value
                elif key == 'max_bounces':
                    bpy.context.scene.cycles.max_bounces = value
                elif key == 'tile_size':
                    bpy.context.scene.cycles.tile_size = value
    
    def enable_denoising(self, enable=True):
        """启用降噪"""
        bpy.context.scene.cycles.use_denoising = enable
    
    def set_denoiser(self, denoiser='OPENIMAGEDENOISE'):
        """设置降噪器"""
        bpy.context.scene.cycles.denoiser = denoiser
    
    def set_bvh_settings(self, bvh_type='DYNAMIC', spatial=None):
        """设置 BVH"""
        bpy.context.scene.cycles.bvh_type = bvh_type
        
        if spatial:
            bpy.context.scene.cycles.bvh_spatial_override = spatial
    
    def set_volume_step_size(self, size=0.1):
        """设置体积步长"""
        bpy.context.scene.cycles.volume_step_size = size
    
    def set_texture_limit(self, limit='OFF', max_size=4096):
        """设置纹理限制"""
        bpy.context.scene.cycles.texture_limit = limit
        
        if limit != 'OFF':
            bpy.context.scene.cycles.texture_limit_max = max_size
    
    def export_render_stats(self, filepath):
        """导出渲染统计"""
        scene = bpy.context.scene
        
        stats = {
            'resolution': f"{scene.render.resolution_x}x{scene.render.resolution_y}",
            'samples': scene.cycles.samples,
            'tile_size': scene.cycles.tile_size,
            'device': scene.cycles.device,
            'render_time': 'N/A'
        }
        
        import json
        
        with open(filepath, 'w') as f:
            json.dump(stats, f, indent=2)
        
        return filepath
    
    def estimate_render_time(self, samples=None):
        """估算渲染时间"""
        if samples is None:
            samples = bpy.context.scene.cycles.samples
        
        scene = bpy.context.scene
        
        # 简化的估算
        pixels = scene.render.resolution_x * scene.render.resolution_y
        pixels = pixels * (scene.render.resolution_percentage / 100) ** 2
        
        seconds_per_sample = 0.001  # 假设
        total_seconds = pixels * samples * seconds_per_sample
        
        return total_seconds


def setup_render_optimization():
    """设置渲染优化"""
    tool = RenderOptimizationTool()
    
    print("渲染优化工具已设置")
    print("可用配置:")
    print("- create_preview_profile: 预览")
    print("- create_final_profile: 最终")
    print("- create_quick_profile: 快速")
    
    return tool
```

### 着色器工具

```python
import bpy

class CyclesShaderTool:
    """Cycles 着色器工具"""
    
    def __init__(self):
        self.shaders = {}
    
    def get_active_material(self):
        """获取当前材质"""
        obj = bpy.context.active_object
        if obj and obj.active_material:
            return obj.active_material
        return None
    
    def get_principled_bsdf(self, material):
        """获取 Principled BSDF"""
        if not material or not material.use_nodes:
            return None
        
        nodes = material.node_tree.nodes
        return nodes.get('Principled BSDF')
    
    def set_base_color(self, material, color):
        """设置基础颜色"""
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            bsdf.inputs['Base Color'].default_value = color
    
    def set_metallic(self, material, metallic):
        """设置金属度"""
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            bsdf.inputs['Metallic'].default_value = metallic
    
    def set_roughness(self, material, roughness):
        """设置粗糙度"""
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            bsdf.inputs['Roughness'].default_value = roughness
    
    def set_specular(self, material, specular):
        """设置高光"""
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            bsdf.inputs['Specular'].default_value = specular
    
    def set_ior(self, material, ior):
        """设置折射率"""
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            bsdf.inputs['IOR'].default_value = ior
    
    def set_transmission(self, material, transmission):
        """设置透射"""
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            bsdf.inputs['Transmission'].default_value = transmission
    
    def set_emission(self, material, color, strength=1.0):
        """设置自发光"""
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            bsdf.inputs['Emission Color'].default_value = color
            bsdf.inputs['Emission Strength'].default_value = strength
    
    def create_glass_material(self, name, color=(1, 1, 1, 1), ior=1.45):
        """创建玻璃材质"""
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        
        bsdf = self.get_principled_bsdf(mat)
        if bsdf:
            bsdf.inputs['Base Color'].default_value = color
            bsdf.inputs['Metallic'].default_value = 0.0
            bsdf.inputs['Roughness'].default_value = 0.0
            bsdf.inputs['IOR'].default_value = ior
            bsdf.inputs['Transmission'].default_value = 1.0
        
        return mat
    
    def create_metal_material(self, name, color=(0.8, 0.8, 0.8, 1), 
                             roughness=0.3):
        """创建金属材质"""
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        
        bsdf = self.get_principled_bsdf(mat)
        if bsdf:
            bsdf.inputs['Base Color'].default_value = color
            bsdf.inputs['Metallic'].default_value = 1.0
            bsdf.inputs['Roughness'].default_value = roughness
        
        return mat
    
    def create_plastic_material(self, name, color=(0.2, 0.5, 0.8, 1),
                               roughness=0.5):
        """创建塑料材质"""
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        
        bsdf = self.get_principled_bsdf(mat)
        if bsdf:
            bsdf.inputs['Base Color'].default_value = color
            bsdf.inputs['Metallic'].default_value = 0.0
            bsdf.inputs['Roughness'].default_value = roughness
        
        return mat
    
    def create_emission_material(self, name, color=(1, 1, 1, 1),
                                 strength=5.0):
        """创建发光材质"""
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        
        bsdf = self.get_principled_bsdf(mat)
        if bsdf:
            bsdf.inputs['Base Color'].default_value = (0, 0, 0, 1)
            bsdf.inputs['Emission Color'].default_value = color
            bsdf.inputs['Emission Strength'].default_value = strength
        
        return mat
    
    def add_noise_texture(self, material, scale=1.0, detail=15):
        """添加噪声纹理"""
        nodes = material.node_tree.nodes
        links = material.node_tree.links
        
        noise = nodes.new(type='ShaderNodeTexNoise')
        noise.inputs['Scale'].default_value = scale
        noise.inputs['Detail'].default_value = detail
        
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            links.new(noise.outputs['Fac'], bsdf.inputs['Roughness'])
    
    def add_wave_texture(self, material, scale=1.0):
        """添加波浪纹理"""
        nodes = material.node_tree.nodes
        links = material.node_tree.links
        
        wave = nodes.new(type='ShaderNodeTexWave')
        wave.inputs['Scale'].default_value = scale
        
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            links.new(wave.outputs['Color'], bsdf.inputs['Base Color'])
    
    def add_voronoi_texture(self, material, scale=1.0):
        """添加 Voronoi 纹理"""
        nodes = material.node_tree.nodes
        links = material.node_tree.links
        
        voronoi = nodes.new(type='ShaderNodeTexVoronoi')
        voronoi.inputs['Scale'].default_value = scale
        
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            links.new(voronoi.outputs['Distance'], bsdf.inputs['Roughness'])
    
    def add_bump_map(self, material, texture_node, strength=1.0):
        """添加凹凸贴图"""
        nodes = material.node_tree.nodes
        links = material.node_tree.links
        
        bump = nodes.new(type='ShaderNodeBump')
        bump.inputs['Strength'].default_value = strength
        
        links.new(texture_node.outputs['Height'], bump.inputs['Height'])
        
        bsdf = self.get_principled_bsdf(material)
        if bsdf:
            links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])


def setup_cycles_shaders():
    """设置 Cycles 着色器"""
    tool = CyclesShaderTool()
    
    print("Cycles 着色器工具已设置")
    print("可用功能:")
    print("- create_glass_material: 玻璃")
    print("- create_metal_material: 金属")
    print("- create_emission_material: 发光")
    
    return tool
```
