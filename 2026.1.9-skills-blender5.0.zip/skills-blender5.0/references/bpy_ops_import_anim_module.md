# bpy.ops.import_anim - Animation Import Module

动画导入模块，用于导入BVH动作捕捉数据。

## 概述

`bpy.ops.import_anim` 模块提供了Blender中导入BVH（BioVision Hierarchy）动作捕捉文件的功能。BVH是一种广泛使用的动作数据格式，包含骨骼层级和动画关键帧信息，常用于角色动画制作。

## 核心功能

### BVH文件导入

```python
import bpy

# 导入BVH文件
bpy.ops.import_anim.bvh(
    filepath='',
    filter_glob='*.bvh',
    target='ARMATURE',
    global_scale=1.0,
    frame_start=1,
    use_fps_scale=False,
    update_scene_fps=False,
    update_scene_duration=False,
    use_cyclic=False,
    rotate_mode='NATIVE',
    axis_forward='-Z',
    axis_up='Y'
)
```

## 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| filepath | string | '' | BVH文件路径 |
| filter_glob | string | '*.bvh' | 文件过滤器 |
| target | string | 'ARMATURE' | 导入目标类型（ARMATURE, OBJECT） |
| global_scale | float | 1.0 | 全局缩放比例 |
| frame_start | int | 1 | 起始帧 |
| use_fps_scale | bool | False | 是否缩放帧率 |
| update_scene_fps | bool | False | 是否更新场景帧率 |
| update_scene_duration | bool | False | 是否更新场景持续时间 |
| use_cyclic | bool | False | 是否循环动画 |
| rotate_mode | string | 'NATIVE' | 旋转模式（NATIVE, QUATERNION, XYZ） |
| axis_forward | string | '-Z' | 向前轴向 |
| axis_up | string | 'Y' | 向上轴向 |

## 实用函数

```python
# 导入BVH文件并自动命名
def import_bvh_auto_name(filepath, target='ARMATURE'):
    # 获取文件名作为骨骼名称
    import os
    name = os.path.splitext(os.path.basename(filepath))[0]
    
    # 导入
    bpy.ops.import_anim.bvh(
        filepath=filepath,
        target=target,
        global_scale=1.0,
        frame_start=1
    )
    
    return name

# 批量导入多个BVH文件
def import_multiple_bvh(filepaths, target='ARMATURE'):
    for filepath in filepaths:
        import_bvh_auto_name(filepath, target)

# 导入并调整动画速度
def import_bvh_with_speed(filepath, speed_factor=1.0):
    bpy.ops.import_anim.bvh(
        filepath=filepath,
        target='ARMATURE',
        global_scale=1.0,
        use_fps_scale=True,
        frame_start=1
    )
    
    if speed_factor != 1.0:
        # 缩放动作数据
        # 注意：需要在导入后手动缩放关键帧

# 导入BVH并应用循环
def import_bvh_cyclic(filepath):
    bpy.ops.import_anim.bvh(
        filepath=filepath,
        target='ARMATURE',
        use_cyclic=True,
        global_scale=1.0
    )
```

## 常见问题排查

**问题：导入后骨骼方向错误**

- 调整`axis_forward`和`axis_up`参数
- 尝试不同的旋转模式（'NATIVE', 'QUATERNION', 'XYZ'）
- 在导入后使用`bpy.ops.object.transform_apply()`应用变换

**问题：动画速度不正确**

- 设置`use_fps_scale=True`来缩放帧率
- 调整`global_scale`参数
- 检查BVH文件中的原始帧率设置

**问题：骨骼无法正确绑定**

- 确认`target`参数设置为'ARMATURE'
- 检查场景中是否已有所需的骨骼
- 尝试使用OBJECT目标类型

**问题：动画帧数不对**

- 检查`frame_start`参数
- 设置`update_scene_duration=True`
- 验证BVH文件的原始帧范围

**问题：文件无法识别**

- 确认文件扩展名为.bvh
- 检查文件编码是否为ASCII或UTF-8
- 验证BVH文件格式是否完整

**问题：导入后骨骼缩放异常**

- 调整`global_scale`参数
- 尝试不同的缩放值（如0.01或100）
- 在导入后应用缩放变换
