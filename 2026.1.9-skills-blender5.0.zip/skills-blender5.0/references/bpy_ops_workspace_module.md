# bpy.ops.workspace 模块

工作区操作模块，用于管理Blender的工作区和界面布局。

## 概述

bpy.ops.workspace 模块包含用于操作工作区的运算符。工作区定义了Blender的界面布局，包括不同的编辑器区域、工具栏和面板配置。

## 常用操作

### 工作区管理

```python
import bpy

# 切换到工作区
bpy.ops.workspace.workspace_duplicate(new_workspace_name='NewWorkspace')

# 切换工作区
bpy.ops.workspace.append_activate(idname='Modeling')

# 删除工作区
bpy.ops.workspace.delete()
```

### 编辑器操作

```python
# 分割区域
bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)

# 合并区域
bpy.ops.screen.area_join(min_x=0, min_y=0, max_x=500, max_y=500)

# 切换编辑器类型
bpy.ops.screen.area_type_swap_or_assign(type='VIEW_3D')

# 全屏切换
bpy.ops.screen.fullscreen()
```

### 区域操作

```python
# 最大化区域
bpy.ops.screen.screen_full_area(use_hide_panels=False)

# 恢复区域
bpy.ops.screen.back_to_previous()

# 区域循环
bpy.ops.screen.area_next()

# 区域上一个
bpy.ops.screen.area_previous()
```

### 布局操作

```python
# 添加面板
bpy.ops.screen.area_add()

# 删除面板
bpy.ops.screen.area_delete()

# 面板复制
bpy.ops.screen.area_dupli()

# 面板循环
bpy.ops.screen.area_move()
```

### 用户界面

```python
# 显示工具设置
bpy.ops.wm.tool_set_by_id(name='builtin.select')

# 切换侧边栏
bpy.ops.wm.context_toggle(data_path='space_data.show_region_ui')

# 切换工具栏
bpy.ops.wm.context_toggle(data_path='space_data.show_region_toolbar')

# 切换属性面板
bpy.ops.wm.context_toggle(data_path='space_data.show_region_hud')
```

## 实际应用示例

### 创建自定义工作区

```python
def create_modeling_workspace():
    """创建建模工作区"""
    # 切换到默认工作区
    bpy.ops.workspace.append_activate(idname='Modeling')
    
    # 获取当前工作区
    workspace = bpy.context.workspace
    
    # 重命名工作区
    workspace.name = 'CustomModeling'
    
    # 配置编辑器布局
    configure_editors(workspace)
    
    return workspace

def configure_editors(workspace):
    """配置编辑器布局"""
    for area in workspace.screens[0].areas:
        for space in area.spaces:
            if space.type == 'VIEW_3D':
                # 配置3D视图
                space.show_region_toolbar = True
                space.show_region_ui = True
                space.overlay.show_overlays = True
            elif space.type == 'PROPERTIES':
                # 配置属性面板
                space.context = 'MODIFIER'
```

### 快速建模布局

```python
def setup_quick_modeling_layout():
    """设置快速建模布局"""
    # 创建水平分割
    bpy.ops.screen.area_split(direction='VERTICAL', factor=0.7)
    
    # 在左侧设置3D视图
    bpy.ops.screen.area_type_swap_or_assign(type='VIEW_3D')
    
    # 在右侧设置属性面板
    bpy.ops.screen.area_type_swap_or_assign(type='PROPERTIES')
    
    # 设置底部区域为时间线
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.8)
    bpy.ops.screen.area_type_swap_or_assign(type='TIMELINE')
```

### 动画工作区

```python
def setup_animation_workspace():
    """设置动画工作区"""
    # 清除当前布局
    bpy.ops.screen.delete()
    
    # 创建主3D视图
    bpy.ops.screen.area_split(direction='VERTICAL', factor=0.6)
    
    # 左侧3D视图
    bpy.ops.screen.area_type_swap_or_assign(type='VIEW_3D')
    
    # 右侧分割
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.5)
    
    # 右上动画曲线
    bpy.ops.screen.area_type_swap_or_assign(type='GRAPH_EDITOR')
    
    # 右下时间线
    bpy.ops.screen.area_type_swap_or_assign(type='TIMELINE')
    
    # 底部添加NLA编辑器
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.8)
    bpy.ops.screen.area_type_swap_or_assign(type='NLA_EDITOR')
```

### 绑定工作区

```python
def setup_rigging_workspace():
    """设置绑定工作区"""
    # 垂直分割
    bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)
    
    # 左侧3D视图
    bpy.ops.screen.area_type_swap_or_assign(type='VIEW_3D')
    
    # 右侧分割
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.3)
    
    # 右上大纲视图
    bpy.ops.screen.area_type_swap_or_assign(type='OUTLINER')
    
    # 右下属性面板
    bpy.ops.screen.area_type_swap_or_assign(type='PROPERTIES')
```

### 渲染工作区

```python
def setup_rendering_workspace():
    """设置渲染工作区"""
    # 创建渲染预览布局
    bpy.ops.screen.area_split(direction='VERTICAL', factor=0.4)
    
    # 左侧渲染结果
    bpy.ops.screen.area_type_swap_or_assign(type='IMAGE_EDITOR')
    
    # 右侧分割
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.5)
    
    # 右上节点编辑器
    bpy.ops.screen.area_type_swap_or_assign(type='NODE_EDITOR')
    
    # 右下属性面板
    bpy.ops.screen.area_type_swap_or_assign(type='PROPERTIES')
    
    # 底部添加控制台
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.8)
    bpy.ops.screen.area_type_swap_or_assign(type='CONSOLE')
```

### 视频编辑工作区

```python
def setup_video_editing_workspace():
    """设置视频编辑工作区"""
    # 底部时间线
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.3)
    bpy.ops.screen.area_type_swap_or_assign(type='SEQUENCE_EDITOR')
    
    # 左侧视频预览
    bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)
    bpy.ops.screen.area_type_swap_or_assign(type='IMAGE_EDITOR')
    
    # 右侧分割
    bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.5)
    
    # 右上属性
    bpy.ops.screen.area_type_swap_or_assign(type='PROPERTIES')
    
    # 右下音频混合器
    bpy.ops.screen.area_type_swap_or_assign(type='DOPESHEET_EDITOR')
```

### 切换快捷键设置

```python
def setup_quick_layouts():
    """设置快速布局切换"""
    # 创建几个预设布局
    
    # 布局1：仅3D视图
    bpy.ops.workspace.workspace_duplicate(new_workspace_name='Full3D')
    
    # 布局2：建模布局
    bpy.ops.workspace.workspace_duplicate(new_workspace_name='Modeling')
    setup_quick_modeling_layout()
    
    # 布局3：动画布局
    bpy.ops.workspace.workspace_duplicate(new_workspace_name='Animation')
    setup_animation_workspace()
    
    # 布局4：渲染布局
    bpy.ops.workspace.workspace_duplicate(new_workspace_name='Rendering')
    setup_rendering_workspace()
```

### 保存当前布局

```python
def save_current_layout_as_workspace(name):
    """保存当前布局为工作区"""
    # 复制当前工作区
    bpy.ops.workspace.workspace_duplicate(new_workspace_name=name)
    
    # 获取新工作区
    workspace = bpy.context.workspace
    
    # 锁定工作区防止误删
    if workspace.id_data:
        workspace.id_data.use_fake_user = True
    
    return workspace
```

### 恢复默认布局

```python
def reset_to_default_layout():
    """恢复默认布局"""
    # 切换到默认工作区
    bpy.ops.workspace.append_activate(idname='Layout')
    
    # 如果需要完全重置
    bpy.ops.screen.user_preset_warp()
```

### 批量配置工作区

```python
def configure_all_workspaces():
    """批量配置所有工作区"""
    # 获取所有工作区
    workspaces = bpy.data.workspaces
    
    for workspace in workspaces:
        try:
            # 为每个工作区设置统一配置
            configure_workspace_defaults(workspace)
        except Exception as e:
            print(f"配置工作区 {workspace.name} 失败: {e}")

def configure_workspace_defaults(workspace):
    """配置工作区默认设置"""
    for screen in workspace.screens:
        for area in screen.areas:
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    # 统一3D视图设置
                    space.shading.type = 'MATERIAL'
                    space.overlay.show_overlays = True
                elif space.type == 'PROPERTIES':
                    space.context = 'MATERIAL'
```

### 创建工作室环境

```python
def create_studio_workspace():
    """创建专业工作室工作区"""
    # 主工作区
    bpy.ops.workspace.workspace_duplicate(new_workspace_name='Studio')
    
    # 4视图布局
    for area in bpy.context.workspace.screens[0].areas:
        if area.type == 'VIEW_3D':
            space = area.spaces[0]
            space.region_quadviews[0].show = True
            space.region_quadviews[1].show = True
            space.region_quadviews[2].show = True
    
    # 辅助面板
    bpy.ops.screen.area_add()
    bpy.ops.screen.area_type_swap_or_assign(type='FILE_BROWSER')
```

## 使用场景

- **界面管理**：自定义Blender界面布局
- **工作流优化**：创建针对特定任务的工作区
- **团队协作**：共享统一的工作区配置
- **多任务处理**：快速切换不同工作模式
- **教学演示**：创建清晰的教学界面
- **专业制作**：配置专业制作环境
- **快捷操作**：设置快速布局切换
- **界面定制**：自定义编辑器显示
- **性能优化**：调整界面提高性能
- **远程协作**：通过工作区配置共享工作流

## 注意事项

- 工作区修改可能影响用户体验
- 大量编辑器会影响性能
- 工作区配置保存在用户设置中
- 共享工作区时注意相对路径
- 复杂布局可能不适合所有屏幕
- 定期备份工作区配置
- 使用快捷键可以提高切换效率
- 注意工作区与文件路径的关联
- 大纲视图有助于复杂场景管理
- 多屏用户需要特殊配置
