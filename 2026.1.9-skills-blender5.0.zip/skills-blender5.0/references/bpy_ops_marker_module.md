# bpy.ops.marker - Timeline Marker Operations Module

Blender 时间线标记操作符，用于管理场景中的时间线标记。

## Overview

`bpy.ops.marker` 模块包含时间线标记的操作命令，支持标记的创建、删除、移动和选择。这个模块主要用于动画时间线的组织和管理。

## 核心功能

```python
import bpy

# 添加标记
bpy.ops.marker.add()

# 移动标记
bpy.ops.marker.move(frames=10)

# 删除标记
bpy.ops.marker.delete()

# 选择标记
bpy.ops.marker.select(action='SELECT')

# 重命名标记
bpy.ops.marker.rename(name="NewName")

# 绑定相机
bpy.ops.marker.camera_bind()

# 解除相机绑定
bpy.ops.marker.camera_bind_clear()
```

## 实际应用示例

### 标记管理器

```python
import bpy

class MarkerManager:
    """标记管理器"""
    
    def __init__(self):
        self.markers = {}
    
    def add_marker(self, name=None, frame=None, camera=None):
        """添加标记"""
        if frame is None:
            frame = bpy.context.scene.frame_current
        
        bpy.ops.marker.add()
        marker = bpy.context.scene.timeline_markers[-1]
        
        if name:
            marker.name = name
        
        marker.frame = frame
        
        if camera:
            marker.camera = camera
        
        self.markers[marker.name] = marker
        return marker
    
    def add_markers_from_list(self, marker_list):
        """从列表添加标记"""
        for item in marker_list:
            self.add_marker(
                name=item.get('name'),
                frame=item.get('frame', bpy.context.scene.frame_current),
                camera=item.get('camera')
            )
    
    def move_marker(self, marker_name, frame):
        """移动标记"""
        marker = self.markers.get(marker_name)
        if marker:
            marker.frame = frame
    
    def move_marker_by_frames(self, marker_name, frames):
        """按帧数移动标记"""
        marker = self.markers.get(marker_name)
        if marker:
            marker.frame += frames
    
    def delete_marker(self, marker_name):
        """删除标记"""
        marker = self.markers.get(marker_name)
        if marker:
            bpy.context.scene.timeline_markers.active = marker
            bpy.ops.marker.delete()
            del self.markers[marker_name]
    
    def delete_all_markers(self):
        """删除所有标记"""
        for name in list(self.markers.keys()):
            self.delete_marker(name)
    
    def rename_marker(self, marker_name, new_name):
        """重命名标记"""
        marker = self.markers.get(marker_name)
        if marker:
            old_name = marker.name
            marker.name = new_name
            self.markers[new_name] = self.markers.pop(old_name)
    
    def select_marker(self, marker_name, select=True):
        """选择标记"""
        marker = self.markers.get(marker_name)
        if marker:
            marker.select = select
    
    def select_all_markers(self):
        """全选标记"""
        for marker in bpy.context.scene.timeline_markers:
            marker.select = True
    
    def deselect_all_markers(self):
        """取消选择"""
        for marker in bpy.context.scene.timeline_markers:
            marker.select = False
    
    def get_marker_at_frame(self, frame):
        """获取指定帧的标记"""
        for marker in bpy.context.scene.timeline_markers:
            if marker.frame == frame:
                return marker
        return None
    
    def get_next_marker(self, frame=None):
        """获取下一个标记"""
        if frame is None:
            frame = bpy.context.scene.frame_current
        
        next_markers = [m for m in bpy.context.scene.timeline_markers 
                       if m.frame > frame]
        
        return min(next_markers, key=lambda m: m.frame) if next_markers else None
    
    def get_previous_marker(self, frame=None):
        """获取上一个标记"""
        if frame is None:
            frame = bpy.context.scene.frame_current
        
        prev_markers = [m for m in bpy.context.scene.timeline_markers 
                       if m.frame < frame]
        
        return max(prev_markers, key=lambda m: m.frame) if prev_markers else None
    
    def jump_to_marker(self, marker_name):
        """跳转到标记"""
        marker = self.markers.get(marker_name)
        if marker:
            bpy.context.scene.frame_set(marker.frame)
    
    def jump_to_next_marker(self):
        """跳转到下一个标记"""
        marker = self.get_next_marker()
        if marker:
            self.jump_to_marker(marker.name)
    
    def jump_to_previous_marker(self):
        """跳转到上一个标记"""
        marker = self.get_previous_marker()
        if marker:
            self.jump_to_marker(marker.name)
    
    def set_camera_for_marker(self, marker_name, camera):
        """为标记设置相机"""
        marker = self.markers.get(marker_name)
        if marker:
            marker.camera = camera
    
    def bind_camera_to_marker(self, marker_name):
        """绑定相机到标记"""
        marker = self.markers.get(marker_name)
        if marker:
            bpy.context.scene.timeline_markers.active = marker
            bpy.ops.marker.camera_bind()
    
    def clear_camera_binding(self, marker_name):
        """清除相机绑定"""
        marker = self.markers.get(marker_name)
        if marker:
            bpy.context.scene.timeline_markers.active = marker
            bpy.ops.marker.camera_bind_clear()
    
    def duplicate_marker(self, marker_name):
        """复制标记"""
        marker = self.markers.get(marker_name)
        if marker:
            return self.add_marker(
                name=f"{marker.name}_copy",
                frame=marker.frame + 1,
                camera=marker.camera
            )
    
    def get_marker_info(self, marker_name):
        """获取标记信息"""
        marker = self.markers.get(marker_name)
        if not marker:
            return None
        
        return {
            'name': marker.name,
            'frame': marker.frame,
            'camera': marker.camera.name if marker.camera else None,
            'select': marker.select
        }
    
    def list_markers(self):
        """列出所有标记"""
        return [m.name for m in bpy.context.scene.timeline_markers]
    
    def export_markers(self, filepath):
        """导出标记"""
        import json
        
        marker_data = []
        for marker in bpy.context.scene.timeline_markers:
            marker_data.append({
                'name': marker.name,
                'frame': marker.frame,
                'camera': marker.camera.name if marker.camera else None
            })
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(marker_data, f, indent=2, ensure_ascii=False)
        
        return filepath
    
    def import_markers(self, filepath):
        """导入标记"""
        import json
        
        with open(filepath, 'r', encoding='utf-8') as f:
            marker_data = json.load(f)
        
        for item in marker_data:
            camera = bpy.data.objects.get(item['camera']) if item.get('camera') else None
            self.add_marker(
                name=item['name'],
                frame=item['frame'],
                camera=camera
            )
        
        return len(marker_data)


def setup_marker_workflow():
    """设置标记工作流程"""
    manager = MarkerManager()
    
    print("标记管理器已设置")
    print(f"当前标记: {manager.list_markers()}")
    
    return manager
```

### 动画场景管理器

```python
import bpy

class SceneAnimationManager:
    """场景动画管理器"""
    
    def __init__(self):
        self.scenes = {}
    
    def create_scene_for_marker(self, marker_name, scene_name=None):
        """为标记创建场景"""
        if scene_name is None:
            scene_name = f"{marker_name}_Scene"
        
        scene = bpy.data.scenes.new(name=scene_name)
        
        # 复制当前场景内容
        current_scene = bpy.context.scene
        
        for obj in current_scene.objects:
            if obj.users > 0:
                obj.users_collection[0].objects.link(obj)
        
        self.scenes[marker_name] = scene
        return scene
    
    def setup_scene_sequence(self, marker_list, scene_prefix="Scene"):
        """设置场景序列"""
        for i, marker_data in enumerate(marker_list):
            scene_name = f"{scene_prefix}_{i+1}"
            
            # 创建场景
            scene = bpy.data.scenes.new(name=scene_name)
            
            # 复制对象
            current_scene = bpy.context.scene
            for obj in current_scene.objects:
                if obj.name in marker_data.get('objects', []):
                    obj.users_collection[0].objects.link(obj)
            
            # 创建标记
            manager = MarkerManager()
            manager.add_marker(
                name=f"Scene_{i+1}",
                frame=marker_data.get('frame', i * 30)
            )
            
            self.scenes[scene_name] = scene
        
        return self.scenes
    
    def create_cut_points(self, frame_list):
        """创建剪辑点"""
        manager = MarkerManager()
        
        for i, frame in enumerate(frame_list):
            manager.add_marker(
                name=f"Cut_{i+1}",
                frame=frame
            )
        
        return len(frame_list)
    
    def create_chapter_markers(self, chapters):
        """创建章节标记"""
        manager = MarkerManager()
        
        for chapter in chapters:
            manager.add_marker(
                name=chapter['name'],
                frame=chapter['frame']
            )
        
        return len(chapters)
    
    def setup_camera_switches(self, camera_list):
        """设置相机切换"""
        manager = MarkerManager()
        
        for i, (frame, camera_name) in enumerate(camera_list):
            camera = bpy.data.objects.get(camera_name)
            if camera:
                manager.add_marker(
                    name=f"Camera_{i+1}",
                    frame=frame,
                    camera=camera
                )
        
        return len(camera_list)
    
    def animate_transitions(self, transition_list):
        """设置过渡动画"""
        for transition in transition_list:
            start_frame = transition['start_frame']
            end_frame = transition['end_frame']
            transition_type = transition.get('type', 'fade')
            
            # 创建标记
            manager = MarkerManager()
            manager.add_marker(
                name=f"{transition_type}_in",
                frame=start_frame
            )
            manager.add_marker(
                name=f"{transition_type}_out",
                frame=end_frame
            )
            
            # 创建过渡动画
            # 这里可以添加实际的过渡效果代码
    
    def create_keyframe_markers(self, object_name, keyframe_frames):
        """创建关键帧标记"""
        manager = MarkerManager()
        
        for i, frame in enumerate(keyframe_frames):
            manager.add_marker(
                name=f"{object_name}_Key_{i+1}",
                frame=frame
            )
        
        return len(keyframe_frames)
    
    def organize_animation_timeline(self, sections):
        """组织动画时间线"""
        manager = MarkerManager()
        
        for section in sections:
            manager.add_marker(
                name=section['name'],
                frame=section['start_frame']
            )
        
        return True
    
    def export_timeline_layout(self, filepath):
        """导出时间线布局"""
        import json
        
        layout = {
            'markers': [],
            'scenes': list(self.scenes.keys())
        }
        
        for marker in bpy.context.scene.timeline_markers:
            layout['markers'].append({
                'name': marker.name,
                'frame': marker.frame,
                'camera': marker.camera.name if marker.camera else None
            })
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(layout, f, indent=2, ensure_ascii=False)
        
        return filepath


def setup_animation_workflow():
    """设置动画工作流程"""
    manager = SceneAnimationManager()
    
    print("场景动画管理器已设置")
    print("可用功能:")
    print("- create_cut_points: 创建剪辑点")
    print("- create_chapter_markers: 创建章节标记")
    print("- setup_camera_switches: 设置相机切换")
    print("- animate_transitions: 设置过渡动画")
    
    return manager
```

### 音频同步工具

```python
import bpy

class AudioSyncTool:
    """音频同步工具"""
    
    def __init__(self):
        self.audio_events = {}
    
    def add_audio_marker(self, name, frame, audio_path=None):
        """添加音频事件标记"""
        marker = MarkerManager().add_marker(
            name=name,
            frame=frame
        )
        
        self.audio_events[name] = {
            'frame': frame,
            'audio_path': audio_path
        }
        
        return marker
    
    def import_audio_events(self, audio_path, event_frames):
        """导入音频事件"""
        for i, frame in enumerate(event_frames):
            self.add_audio_marker(
                name=f"AudioEvent_{i+1}",
                frame=frame,
                audio_path=audio_path
            )
    
    def sync_to_audio_peaks(self, audio_path, peak_frames):
        """同步到音频峰值"""
        manager = MarkerManager()
        
        for i, frame in enumerate(peak_frames):
            manager.add_marker(
                name=f"Peak_{i+1}",
                frame=frame
            )
        
        return len(peak_frames)
    
    def create_audio_guide_track(self, audio_path, interval=30):
        """创建音频引导轨道"""
        manager = MarkerManager()
        
        # 获取音频长度
        sound = bpy.data.sounds.get(audio_path)
        if not sound:
            return 0
        
        total_frames = int(sound.length * bpy.context.scene.render.fps)
        
        # 每隔 interval 帧添加标记
        for frame in range(0, total_frames, interval):
            manager.add_marker(
                name=f"Guide_{frame}",
                frame=frame
            )
        
        return total_frames // interval
    
    def sync_animations_to_audio(self, object_name, animation_data, fps=30):
        """同步动画到音频"""
        manager = MarkerManager()
        
        for event in animation_data:
            manager.add_marker(
                name=f"{object_name}_{event['name']}",
                frame=int(event['time'] * fps)
            )
        
        return len(animation_data)
    
    def create_lip_sync_markers(self, phoneme_data, fps=24):
        """创建口型同步标记"""
        manager = MarkerManager()
        
        for phoneme in phoneme_data:
            start_frame = int(phoneme['start_time'] * fps)
            end_frame = int(phoneme['end_time'] * fps)
            
            manager.add_marker(
                name=f"LipSync_{phoneme['phoneme']}_{start_frame}",
                frame=start_frame
            )
        
        return len(phoneme_data)
    
    def create_beat_markers(self, bpm, start_frame=1, duration_bars=4,
                           beats_per_bar=4):
        """创建节拍标记"""
        manager = MarkerManager()
        
        fps = bpy.context.scene.render.fps
        seconds_per_beat = 60 / bpm
        frames_per_beat = int(seconds_per_beat * fps)
        frames_per_bar = frames_per_beat * beats_per_bar
        
        for bar in range(duration_bars):
            for beat in range(beats_per_bar):
                frame = start_frame + bar * frames_per_bar + beat * frames_per_beat
                
                name = f"Bar{bar+1}_Beat{beat+1}"
                manager.add_marker(name=name, frame=frame)
        
        return duration_bars * beats_per_bar
    
    def export_audio_sync_data(self, filepath):
        """导出音频同步数据"""
        import json
        
        sync_data = {
            'events': [],
            'total_duration_frames': bpy.context.scene.frame_end
        }
        
        for name, data in self.audio_events.items():
            sync_data['events'].append({
                'name': name,
                'frame': data['frame'],
                'audio_path': data['audio_path']
            })
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(sync_data, f, indent=2, ensure_ascii=False)
        
        return filepath


def setup_audio_sync():
    """设置音频同步"""
    tool = AudioSyncTool()
    
    print("音频同步工具已设置")
    print("可用功能:")
    print("- create_beat_markers: 创建节拍标记")
    print("- create_lip_sync_markers: 创建口型同步")
    print("- sync_animations_to_audio: 同步动画到音频")
    
    return tool
```
