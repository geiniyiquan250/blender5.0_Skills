# gpu - GPU 编程模块完整参考

Blender GPU 模块提供底层 GPU 访问功能，用于自定义着色器和效果开发。

## Overview

`gpu` 模块及其子模块提供了在 Blender 中进行 GPU 编程的能力，包括自定义着色器、离屏渲染、纹理操作和选择功能。

## 子模块概览

```python
import gpu
from gpu import types
from gpu import state
from gpu import matrix
from gpu import shader
from gpu import texture
from gpu import select
from gpu import platform
```

## GPU 初始化与检测

```python
import gpu

# 检查 GPU 是否可用
print(f"GPU 可用: {gpu.is_compute_available()}")

# 获取 GPU 信息
print(f"GPU 厂商: {gpu.platform.info_get()['VENDOR']}")
print(f"GPU 渲染器: {gpu.platform.info_get()['RENDERER']}")
print(f"驱动版本: {gpu.platform.info_get()['VERSION']}")

# 检查 OpenGL 上下文
print(f"OpenGL 上下文: {gpu.context.active}")
```

## GPU 类型 (gpu.types)

### 离屏缓冲区 (GPUOffScreen)

```python
import gpu
from gpu import types

# 创建离屏渲染缓冲区
offscreen = gpu.types.GPUOffScreen(512, 512)

# 检查是否有效
print(f"离屏有效: {offscreen.is_valid}")

# 获取纹理
texture = offscreen.texture
print(f"纹理: {texture}")

# 绑定和渲染
with offscreen.bind():
    # 在这里进行渲染操作
    pass

# 清理
offscreen.free()

# 使用上下文管理器
with gpu.types.GPUOffScreen(512, 512) as offscreen:
    # 渲染操作
    pass
```

### 着色器程序 (GPUShader)

```python
import gpu
from gpu import types

# 创建着色器
shader = gpu.types.GPUShader(
    vertex_shader="""
    in vec3 position;
    in vec3 color;
    out vec3 v_color;
    uniform mat4 u_model_view_projection_matrix;
    
    void main() {
        gl_Position = u_model_view_projection_matrix * vec4(position, 1.0);
        v_color = color;
    }
    """,
    fragment_shader="""
    in vec3 v_color;
    out vec4 fragColor;
    
    void main() {
        fragColor = vec4(v_color, 1.0);
    }
    """
)

# 绑定着色器
shader.bind()

# 设置 uniform
shader.uniform_float("u_model_view_projection_matrix", matrix)

# 获取 uniform 位置
loc = shader.uniform_location("u_model_view_projection_matrix")

# 清理
shader.free()

# 检查编译状态
print(f"着色器编译成功: {shader.is_valid}")
```

### GPU 纹理 (GPUTexture)

```python
import gpu
from gpu import types
import numpy as np

# 从数据创建纹理
data = np.zeros((256, 256, 4), dtype=np.uint8)
texture = gpu.types.GPUTexture(256, 256, data=data)

# 从图像创建
import bpy
img = bpy.data.images[0]
texture = gpu.types.GPUTexture(img.size[0], img.size[1], data=np.array(img.pixels))

# 绑定纹理
texture.bind(0)  # 绑定到纹理单元 0

# 设置过滤器
texture.filter(gpu.types.GPU_NEAREST, gpu.types.GPU_NEAREST)

# 设置包裹模式
texture.filter(gpu.types.GPU_LINEAR, gpu.types.GPU_LINEAR, 
               gpu.types.GPU_REPEAT, gpu.types.GPU_REPEAT)

# 读取纹理数据
data = texture.read()
print(f"数据形状: {data.shape}")

# 清理
texture.free()
```

### 顶点缓冲区 (GPUVertBuf)

```python
import gpu
from gpu import types
import numpy as np

# 定义顶点格式
format = gpu.types.GPUVertFormat()
format.attr_add(id="position", comp_type=gpu.types.FLOAT3, 
                fetch=gpu.types.FLOAT, offset=0)
format.attr_add(id="color", comp_type=gpu.types.UBYTE4, 
                fetch=gpu.types.INT, offset=12)

# 创建顶点数据
vertices = np.array([
    [0.0, 0.0, 0.0, 255, 0, 0, 255],
    [1.0, 0.0, 0.0, 0, 255, 0, 255],
    [0.0, 1.0, 0.0, 0, 0, 255, 255],
], dtype=np.float32)

# 创建顶点缓冲区
vbo = gpu.types.GPUVertBuf(format=format, len=3, data=vertices)

# 绑定
vbo.bind()

# 清理
vbo.free()
```

### 索引缓冲区 (GPUIndexBuf)

```python
import gpu
from gpu import types
import numpy as np

# 创建索引数据
indices = np.array([0, 1, 2], dtype=np.uint32)

# 创建索引缓冲区
ibo = gpu.types.GPUIndexBuf(data=indices)

# 绑定
ibo.bind()

# 清理
ibo.free()
```

### 批处理 (GPUBatch)

```python
import gpu
from gpu import types

# 创建批处理
batch = gpu.types.GPUBatch(vert_buf=vbo, elem_buf=ibo, prim_type=gpu.types.TRIANGLES)

# 绘制
batch.draw()

# 不同的图元类型
batch = gpu.types.GPUBatch(vert_buf=vbo, prim_type=gpu.types.POINTS)
batch = gpu.types.GPUBatch(vert_buf=vbo, prim_type=gpu.types.LINES)
batch = gpu.types.GPUBatch(vert_buf=vbo, prim_type=gpu.types.TRIANGLE_STRIP)

# 清理
batch.free()
```

## GPU 状态管理 (gpu.state)

```python
from gpu import state

# 混合状态
state.blend_set('ADD')
state.blend_set('ALPHA')
state.blend_set('NONE')

# 深度测试
state.depth_mask_set(True)
state.depth_test_set('LEQUAL')
state.depth_test_set('ALWAYS')
state.depth_test_set('NEVER')
state.depth_test_set('LESS')
state.depth_test_set('EQUAL')

# 面剔除
state.face_culling_set('BACK')
state.face_culling_set('FRONT')
state.face_culling_set('BOTH')
state.face_culling_set('NONE')

# 保存和恢复状态
state.push()
# ... 修改状态
state.pop()

# 视口设置
state.viewport_set(0, 0, 512, 512)

# 裁剪平面
state.scissor_test_set(True)
state.scissor_set(0, 0, 512, 512)

# 颜色掩码
state.color_mask_set(True, True, True, True)

# 清除缓冲区
state.clear_color(0.0, 0.0, 0.0, 1.0)
state.clear(depth=1.0, stencil=0)
state.clear_color()
```

## GPU 矩阵操作 (gpu.matrix)

```python
from gpu import matrix

# 投影矩阵
matrix.load_projection_matrix(1.0, 1920/1080, 0.1, 100.0)

# 视图矩阵
matrix.load_view_matrix(
    ((1, 0, 0, 0),
     (0, 1, 0, 0),
     (0, 0, 1, 0),
     (0, 0, 5, 1))
)

# 模型矩阵
matrix.load_matrix()

# 组合矩阵
matrix.multiply()

# 矩阵操作
matrix.translate(1.0, 2.0, 3.0)
matrix.rotate(0.785, 'X')
matrix.scale(2.0, 2.0, 2.0)

# 获取当前矩阵
mvp = matrix.get_model_view_projection_matrix()
model = matrix.get_model_matrix()
view = matrix.get_view_matrix()
proj = matrix.get_projection_matrix()

# 矩阵堆栈
matrix.push()
matrix.translate(1, 0, 0)
# ... 渲染操作
matrix.pop()

# 正交投影
matrix.ortho_projection(-1, 1, -1, 1, -1, 1)

# 透视投影
matrix.perspective_projection(0.1, 10.0, 45, 1920/1080)

# 逆矩阵
inv_matrix = matrix.inverse(model)
```

## GPU 着色器编程 (gpu.shader)

```python
from gpu import shader

# 创建着色器程序
def create_custom_shader():
    """创建自定义着色器"""
    return shader.from_builtin('UNIFORM_COLOR')

# 内置着色器
from gpu import types

# 统一颜色着色器
color_shader = shader.from_builtin('UNIFORM_COLOR')
color_shader.bind()
color_shader.uniform_float("color", (1.0, 0.5, 0.2, 1.0))

# 3D 着色器
shader_3d = shader.from_builtin('SMOOTH_3D')

# 3D 法线着色器
normal_shader = shader.from_builtin('FLAT_3D')

# 多边形描边着色器
poly_shader = shader.from_builtin('POLYLINE_UNIFORM_COLOR')

# 自定义着色器
custom_shader = shader.compile(
    vertex_code="""
    uniform mat4 u_model_view_projection_matrix;
    in vec3 position;
    in vec3 normal;
    out vec3 v_normal;
    
    void main() {
        gl_Position = u_model_view_projection_matrix * vec4(position, 1.0);
        v_normal = normal;
    }
    """,
    fragment_code="""
    in vec3 v_normal;
    out vec4 fragColor;
    
    void main() {
        vec3 light = normalize(vec3(1.0, 1.0, 1.0));
        float diff = max(dot(v_normal, light), 0.2);
        fragColor = vec4(vec3(diff), 1.0);
    }
    """
)

# 清理
color_shader.dispose()
custom_shader.dispose()
```

## GPU 选择功能 (gpu.select)

```python
from gpu import select

# 初始化选择
select.select_init()

# 绘制对象用于选择
with select.draw_region_overlay(bpy.context.region):
    for obj in bpy.context.scene.objects:
        select.draw_id(obj)

# 获取选择
def get_selected_object(x, y):
    """获取指定位置的选中对象"""
    ids = []
    for obj in bpy.context.scene.objects:
        ids.append(obj)
    
    # 框选
    select.select_box(0, 0, 100, 100)
    
    # 圆形选择
    select.select_circle(50, 50, 20)
    
    # 套索选择
    select.select_lasso([(10, 10), (20, 20), (10, 30)])
    
    return select.select_pick(x, y)
```

## GPU 平台信息 (gpu.platform)

```python
from gpu import platform

# 获取 GPU 信息
info = platform.info_get()
print(f"厂商: {info['VENDOR']}")
print(f"渲染器: {info['RENDERER']}")
print(f"版本: {info['VERSION']}")
print(f"着色语言版本: {info['GLSL_VERSION']}")

# 检查特性支持
print(f"Compute 支持: {platform.info_get()['COMPUTE']}")
print(f"Geometry Shader 支持: {platform.info_get()['GEOMETRY_SHADER']}")
print(f"Tessellation 支持: {platform.info_get()['TESSELLATION_SHADER']}")

# 获取详细 GPU 信息
gpu_info = platform.get_gpu_info()
print(gpu_info)
```

## 完整示例

### 自定义网格绘制

```python
import bpy
import gpu
from gpu import types, matrix, state, shader
import numpy as np

class CustomDrawOperator(bpy.types.Operator):
    bl_idname = "object.custom_draw"
    bl_label = "自定义绘制"
    
    def execute(self, context):
        return {'FINISHED'}
    
    def draw(self, context):
        pass
    
    def invoke(self, context, event):
        # 注册绘制回调
        self.draw_callback = context.space_data.draw_handler_add(
            self.draw_callback_function, (), 'WINDOW', 'POST_VIEW'
        )
        return {'RUNNING_MODAL'}
    
    def draw_callback_function(self):
        """绘制回调函数"""
        # 准备数据
        vertices = np.array([
            [0, 0, 0],
            [1, 0, 0],
            [0, 1, 0],
        ], dtype=np.float32)
        
        colors = np.array([
            [255, 0, 0, 255],
            [0, 255, 0, 255],
            [0, 0, 255, 255],
        ], dtype=np.uint8)
        
        # 创建顶点格式
        fmt = types.GPUVertFormat()
        fmt.attr_add(id="position", comp_type=types.FLOAT3, 
                    fetch=types.FLOAT, offset=0)
        fmt.attr_add(id="color", comp_type=types.UBYTE4, 
                    fetch=types.INT, offset=12)
        
        # 创建缓冲区
        vbo = types.GPUVertBuf(format=fmt, len=3, data=np.concatenate([vertices, colors], axis=1))
        
        # 创建着色器
        sh = shader.from_builtin('SMOOTH_3D')
        sh.bind()
        
        # 设置矩阵
        matrix.load_view_matrix(
            ((1, 0, 0, 0),
             (0, 1, 0, 0),
             (0, 0, 1, 0),
             (0, 0, -5, 1))
        )
        matrix.load_projection_matrix(1.0, 16/9, 0.1, 100.0)
        
        # 创建批处理
        batch = types.GPUBatch(vert_buf=vbo, prim_type=types.TRIANGLES)
        
        # 绘制
        state.blend_set('ALPHA')
        batch.draw(sh)
        
        # 清理
        batch.free()
        sh.dispose()
        vbo.free()
```

### 离屏渲染

```python
import bpy
import gpu
from gpu import types, matrix, state, shader
import numpy as np

def render_to_texture(obj, width=512, height=512):
    """离屏渲染到纹理"""
    # 创建离屏缓冲区
    offscreen = types.GPUOffScreen(width, height)
    
    with offscreen.bind():
        # 清除
        state.clear_color(0.2, 0.2, 0.2, 1.0)
        state.clear(depth=1.0)
        
        # 设置相机
        matrix.load_view_matrix(
            ((1, 0, 0, 0),
             (0, 1, 0, 0),
             (0, 0, 1, 0),
             (0, 0, -5, 1))
        )
        matrix.load_projection_matrix(1.0, width/height, 0.1, 100.0)
        
        # 渲染对象
        # ... 渲染代码
        
        # 读取像素
        buffer = offscreen.texture.read()
    
    # 清理
    offscreen.free()
    
    return buffer
```

### 动态纹理生成

```python
import bpy
import gpu
from gpu import types
import numpy as np

def generate_gradient_texture(width=256, height=256):
    """生成渐变纹理"""
    # 创建图像数据
    data = np.zeros((width, height, 4), dtype=np.uint8)
    
    for y in range(height):
        for x in range(width):
            data[y, x, 0] = int(255 * x / width)  # R
            data[y, x, 1] = int(255 * y / height)  # G
            data[y, x, 2] = 128  # B
            data[y, x, 3] = 255  # A
    
    # 创建纹理
    texture = types.GPUTexture(width, height, data=data)
    
    return texture

def apply_texture_to_material(texture, material_name="Gradient"):
    """应用纹理到材质"""
    # 创建或获取材质
    if material_name not in bpy.data.materials:
        mat = bpy.data.materials.new(name=material_name)
        mat.use_nodes = True
    else:
        mat = bpy.data.materials[material_name]
    
    # 获取着色器节点
    nodes = mat.node_tree.nodes
    principled = nodes.get("Principled BSDF")
    
    if principled:
        # 创建图像节点
        img_node = nodes.new(type='ShaderNodeTexImage')
        img_node.width_hidden = 200
        
        # 设置图像
        img = bpy.data.images.new("DynamicGradient", 
                                  width=256, height=256)
        
        # 从 GPU 纹理复制数据
        gpu_data = texture.read()
        img.pixels = gpu_data.flatten().tolist()
        
        img_node.image = img
        img_node.interpolation = 'Linear'
        
        # 连接到 Principled BSDF
        principled.inputs["Base Color"].default_value = (1, 1, 1, 1)
    
    return mat
```

## 性能优化

### 1. 资源共享

```python
# 共享顶点缓冲区
vbo1 = types.GPUVertBuf(format, len, data)
vbo2 = types.GPUVertBuf(existing=vbo1)
```

### 2. 批处理

```python
# 合并绘制调用
batch1.draw()
batch2.draw()
# 替换为
batches = [batch1, batch2]
for batch in batches:
    batch.draw()
```

### 3. 及时清理

```python
def cleanup_gpu_resources():
    """清理 GPU 资源"""
    for tex in textures:
        tex.free()
    for buf in vbos:
        buf.free()
    for sh in shaders:
        sh.dispose()
```

### 4. 使用上下文管理器

```python
# 推荐
with gpu.types.GPUOffScreen(w, h) as offscreen:
    # 渲染操作
    pass
# 自动清理

# 不推荐
offscreen = gpu.types.GPUOffScreen(w, h)
# 使用后需要手动 offscreen.free()
```

## 常见问题

### Q: 着色器编译失败
A: 检查 GLSL 语法，确保使用正确的版本和语法。

### Q: 纹理不显示
A: 检查纹理绑定单元和采样器设置。

### Q: 性能差
A: 使用批处理减少绘制调用，避免频繁状态切换。

### Q: 内存泄漏
A: 确保所有 GPU 资源正确释放，使用上下文管理器。

## 相关模块

- [gpu.types](gpu_types_module.md) - GPU 类型定义
- [gpu.shader](gpu_shader_module.md) - GPU 着色器
- [gpu.state](gpu_state_module.md) - GPU 状态管理
- [gpu.texture](gpu_texture_module.md) - GPU 纹理
- [gpu.matrix](gpu_matrix_module.md) - GPU 矩阵操作
- [gpu.select](gpu_select_module.md) - GPU 选择
- [gpu.platform](gpu_platform_module.md) - GPU 平台信息
