# bpy.ops.import_mesh - PLY导入操作模块

Blender PLY文件导入操作符，用于将PLY网格文件导入Blender。

## 概述

`bpy.ops.import_mesh.ply` 模块提供用于将Polygon File Format（PLY）格式网格文件导入Blender的功能，支持顶点和面数据。

## 核心功能

### 基础导入

```python
import bpy

# 导入PLY文件
bpy.ops.import_mesh.ply(
    filepath='//model.ply',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    directory='//',
    files=[{'name': 'model.ply'}]
)

# 导入多个PLY文件
bpy.ops.import_mesh.ply(
    filepath='//parts/',
    directory='//parts/',
    files=[{'name': 'part1.ply'}, {'name': 'part2.ply'}]
)
```

### 颜色导入

```python
# 导入顶点颜色
bpy.ops.import_mesh.ply(
    filepath='//colored_model.ply',
    import_vertex_color=True
)

# 不导入顶点颜色
bpy.ops.import_mesh.ply(
    filepath='//model.ply',
    import_vertex_color=False
)
```

### 法线导入

```python
# 导入法线
bpy.ops.import_mesh.ply(
    filepath='//model.ply',
    import_normals=True
)

# 不导入法线
bpy.ops.import_mesh.ply(
    filepath='//model.ply',
    import_normals=False
)
```

### UV导入

```python
# 导入UV
bpy.ops.import_mesh.ply(
    filepath='//model.ply',
    import_uv=True
)

# 不导入UV
bpy.ops.import_mesh.ply(
    filepath='//model.ply',
    import_uv=False
)
```

### 变换设置

```python
# 应用全局矩阵
bpy.ops.import_mesh.ply(
    filepath='//model.ply',
    global_matrix=None
)

# 自定义变换矩阵
import mathutils
matrix = mathutils.Matrix.Rotation(math.radians(45), 4, 'Z')
bpy.ops.import_mesh.ply(
    filepath='//model.ply',
    global_matrix=matrix
)
```

## 实用函数

```python
def import_ply_model(filepath, apply_transform=True):
    """导入PLY模型"""
    bpy.ops.import_mesh.ply(filepath=filepath)
    obj = bpy.context.active_object
    
    if apply_transform:
        bpy.ops.object.transform_apply(
            location=True,
            rotation=True,
            scale=True
        )
    
    return obj

def import_ply_with_colors(filepath):
    """导入PLY带颜色"""
    bpy.ops.import_mesh.ply(
        filepath=filepath,
        import_vertex_color=True,
        import_normals=True,
        import_uv=True
    )
    return bpy.context.active_object

def import_ply_for_editing(filepath):
    """导入PLY用于编辑"""
    bpy.ops.import_mesh.ply(
        filepath=filepath,
        import_vertex_color=False,
        import_normals=False,
        import_uv=False
    )
    obj = bpy.context.active_object
    
    # 进入编辑模式检查网格
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return obj

def import_ply_scaled(filepath, target_size=1.0):
    """导入PLY并缩放"""
    bpy.ops.import_mesh.ply(filepath=filepath)
    obj = bpy.context.active_object
    
    max_dim = max(obj.dimensions)
    if max_dim > 0:
        scale = target_size / max_dim
        obj.scale = (scale, scale, scale)
    
    bpy.ops.object.transform_apply(scale=True)
    
    return obj

def batch_import_ply_files(ply_files):
    """批量导入PLY文件"""
    objects = []
    
    for ply_file in ply_files:
        bpy.ops.import_mesh.ply(filepath=ply_file)
        obj = bpy.context.active_object
        obj.name = bpy.path.basename(ply_file).replace('.ply', '')
        objects.append(obj)
    
    return objects

def import_ply_and_setup(filepath, name, material=None):
    """导入PLY并设置"""
    bpy.ops.import_mesh.ply(filepath=filepath)
    obj = bpy.context.active_object
    obj.name = name
    
    if material:
        obj.data.materials.append(material)
    
    return obj
```

## 常见问题排查

### 导入后模型不可见
```python
# 检查对象
obj = bpy.context.active_object
print(f"对象: {obj.name}")
print(f"类型: {obj.type}")
print(f"顶点数: {len(obj.data.vertices)}")

# 检查隐藏状态
print(f"隐藏: {obj.hide_viewport}")
obj.hide_viewport = False

# 检查显示类型
obj.display_type = 'SOLID'
```

### 颜色不显示
```python
# 检查顶点颜色层
mesh = bpy.context.active_object.data
print(f"顶点颜色层: {[l.name for l in mesh.vertex_colors]}")

# 启用顶点颜色
if mesh.vertex_colors:
    mat = bpy.context.active_object.active_material
    if mat:
        print(f"使用顶点颜色: {mat.use_vertex_color_paint}")
        mat.use_vertex_color_paint = True

# 检查材质
obj = bpy.context.active_object
if obj.data.materials:
    for mat in obj.data.materials:
        print(f"材质: {mat.name}")
```

### 法线问题
```python
# 检查法线
mesh = bpy.context.active_object.data
print(f"自定义法线: {mesh.has_custom_normals}")

# 重新计算法线
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.mesh.normals_make_consistent(inside=False)
bpy.ops.object.mode_set(mode='OBJECT')

# 检查面法线
for poly in mesh.polygons:
    if not poly.use_smooth:
        print(f"平面面: {poly.index}")
```

### 网格质量问题
```python
# 检查网格
mesh = bpy.context.active_object.data
print(f"顶点数: {len(mesh.vertices)}")
print(f"面数: {len(mesh.polygons)}")
print(f"边数: {len(mesh.edges)}")

# 检查零面积面
zero_area = 0
for poly in mesh.polygons:
    if poly.area < 0.0001:
        zero_area += 1
print(f"零面积面: {zero_area}")

# 检查重叠顶点
print(f"顶点数: {len(mesh.vertices)}")
```
