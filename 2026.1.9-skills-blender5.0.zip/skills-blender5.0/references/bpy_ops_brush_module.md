# bpy.ops.brush 模块

画笔操作模块，用于管理和操作绘画画笔。

## 概述

bpy.ops.brush 模块包含用于管理绘画画笔、画笔预设和画笔设置的运算符。这些运算符用于创建、编辑、删除画笔，以及管理画笔库。

## 常用操作

### 画笔选择和管理

```python
import bpy

# 激活画笔
bpy.ops.brush.active_index_set(brush_type='SCULPT', index=0)

# 获取当前活动画笔
active_brush = bpy.context.tool_settings.sculpt.brush

# 复制画笔
bpy.ops.brush.add()
bpy.ops.brush.duplicate(name="New Brush")

# 删除画笔
bpy.ops.brush.remove()

# 重命名画笔
bpy.ops.brush.rename(name="Renamed Brush")
```

### 画笔预设

```python
# 保存画笔预设
bpy.ops.brush.preset_add(name="My Preset")

# 删除画笔预设
bpy.ops.brush.preset_remove(name="My Preset")

# 调用画笔预设菜单
bpy.ops.brush.preset_menu()
```

### 画笔图标

```python
# 添加自定义画笔图标
bpy.ops.brush.icon_add(filepath="//brush_icon.png")

# 清除画笔图标
bpy.ops.brush.icon_clear()
```

### 纹理管理

```python
# 添加纹理到画笔
bpy.ops.brush.texture_add()

# 移除画笔纹理
bpy.ops.brush.texture_remove()

# 创建纹理
bpy.ops.brush.texture_slot_new()
```

### 曲线管理

```python
# 添加曲线到画笔
bpy.ops.brush.curve_brush_add()

# 清除画笔曲线
bpy.ops.brush.curve_brush_clear()

# 插槽操作
bpy.ops.brush.curve_brush_slot_stroke()
bpy.ops.brush.curve_brush_slot_strength()
bpy.ops.brush.curve_brush_slot_color()
```

## 实际应用示例

### 创建自定义画笔

```python
def create_custom_brush(name, size=50, strength=1.0, color=(1, 0.5, 0)):
    """创建自定义画笔"""
    brush_type = bpy.context.tool_settings.sculpt.brush
    
    # 复制当前画笔
    bpy.ops.sculpt.brush_add(name=name)
    
    # 设置画笔属性
    brush = bpy.context.tool_settings.sculpt.brush
    brush.size = size
    brush.strength = strength
    
    # 设置颜色
    brush.cursor_color_add(color)
    
    return brush
```

### 画笔库管理

```python
def export_brush_library(filepath):
    """导出画笔库"""
    brushes = []
    for brush in bpy.data.brushes:
        if brush.sculpt:
            brush_data = {
                'name': brush.name,
                'size': brush.size,
                'strength': brush.strength,
                'hardness': brush.hardness,
            }
            brushes.append(brush_data)
    
    # 保存到文件
    import json
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(brushes, f, ensure_ascii=False, indent=2)

def import_brush_library(filepath):
    """导入画笔库"""
    import json
    
    with open(filepath, 'r', encoding='utf-8') as f:
        brushes = json.load(f)
    
    for brush_data in brushes:
        # 激活雕塑工具
        bpy.ops.sculpt.brush_add(name=brush_data['name'])
        
        # 应用设置
        brush = bpy.context.tool_settings.sculpt.brush
        brush.size = brush_data.get('size', 50)
        brush.strength = brush_data.get('strength', 1.0)
        brush.hardness = brush_data.get('hardness', 0.5)
```

### 批量画笔设置

```python
def batch_update_brush_settings(size_factor=1.0, strength_factor=1.0):
    """批量更新所有画笔设置"""
    for brush in bpy.data.brushes:
        if brush.sculpt:
            brush.size = max(1, int(brush.size * size_factor))
            brush.strength = min(1.0, brush.strength * strength_factor)

def reset_all_brushes():
    """重置所有画笔为默认值"""
    for brush in bpy.data.brushes:
        if brush.sculpt:
            brush.size = 50
            brush.strength = 1.0
            brush.hardness = 0.5
```

## 使用场景

- **画笔创建和管理**：创建自定义画笔和预设
- **画笔库操作**：导入导出画笔库
- **批量设置**：批量调整画笔参数
- **纹理和曲线管理**：管理画笔的纹理和力量曲线
- **自动化脚本**：在脚本中动态创建和配置画笔

## 注意事项

- 画笔操作需要先激活相应的绘制模式
- 不同绘制模式（雕塑、绘制、纹理绘制）的画笔是分开的
- 画笔设置更改后可能需要重绘笔触预览
