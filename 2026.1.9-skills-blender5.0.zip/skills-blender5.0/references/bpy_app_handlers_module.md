# bpy.app.handlers Module Reference

bpy.app.handlers 模块提供应用程序事件处理程序，用于在特定事件发生时执行自定义代码。

## handlers 概述

handlers 允许脚本响应 Blender 的各种事件：
- 帧更改
- 文件保存/加载
- 渲染开始/结束
- 场景更新
- 撤销/重做

### 何时使用 handlers

- 自动保存和备份
- 数据验证和同步
- 动画更新
- 渲染前/后处理
- 场景变更响应

## 可用处理程序列表

### frame_change_post

在帧更改后执行。

```python
import bpy

def frame_change_handler(scene):
    print(f"Frame changed to: {scene.frame_current}")

# 注册处理程序
bpy.app.handlers.frame_change_post.append(frame_change_handler)

# 注销处理程序
bpy.app.handlers.frame_change_post.remove(frame_change_handler)
```

### frame_change_pre

在帧更改前执行。

```python
import bpy

def frame_change_pre_handler(scene):
    print(f"About to change frame from: {scene.frame_current}")

bpy.app.handlers.frame_change_pre.append(frame_change_pre_handler)
```

### render_pre

在渲染开始前执行。

```python
import bpy

def render_pre_handler(scene):
    print(f"Starting render: {scene.name}")
    print(f"Resolution: {scene.render.resolution_x}x{scene.render.resolution_y}")

bpy.app.handlers.render_pre.append(render_pre_handler)
```

### render_post

在渲染结束后执行。

```python
import bpy

def render_post_handler(scene):
    print(f"Render completed: {scene.name}")

bpy.app.handlers.render_post.append(render_post_handler)
```

### render_cancel

渲染取消时执行。

```python
import bpy

def render_cancel_handler(scene):
    print(f"Render cancelled: {scene.name}")

bpy.app.handlers.render_cancel.append(render_cancel_handler)
```

### save_pre

在保存文件前执行。

```python
import bpy

def save_pre_handler(filepath):
    print(f"Saving file: {filepath}")

bpy.app.handlers.save_pre.append(save_pre_handler)
```

### save_post

在保存文件后执行。

```python
import bpy

def save_post_handler(filepath):
    print(f"File saved: {filepath}")

bpy.app.handlers.save_post.append(save_post_handler)
```

### load_pre

在加载文件前执行。

```python
import bpy

def load_pre_handler(filepath):
    print(f"Loading file: {filepath}")

bpy.app.handlers.load_pre.append(load_pre_handler)
```

### load_post

在加载文件后执行。

```python
import bpy

def load_post_handler(filepath):
    print(f"File loaded: {filepath}")
    # 执行加载后的初始化操作

bpy.app.handlers.load_post.append(load_post_handler)
```

### undo_pre

在撤销前执行。

```python
import bpy

def undo_pre_handler():
    print("About to undo")

bpy.app.handlers.undo_pre.append(undo_pre_handler)
```

### undo_post

在撤销后执行。

```python
import bpy

def undo_post_handler():
    print("Undo completed")

bpy.app.handlers.undo_post.append(undo_post_handler)
```

### redo_pre

在重做前执行。

```python
import bpy

def redo_pre_handler():
    print("About to redo")

bpy.app.handlers.redo_pre.append(redo_pre_handler)
```

### redo_post

在重做后执行。

```python
import bpy

def redo_post_handler():
    print("Redo completed")

bpy.app.handlers.redo_post.append(redo_post_handler)
```

### version_update

当 Blender 版本更新时执行。

```python
import bpy

def version_update_handler():
    current_version = bpy.app.version
    print(f"Blender version: {current_version}")

bpy.app.handlers.version_update.append(version_update_handler)
```

### dependency_update

当依赖项更新时执行。

```python
import bpy

def dependency_update_handler(scene):
    print(f"Dependencies updated in scene: {scene.name}")

bpy.app.handlers.dependency_update.append(dependency_update_handler)
```

### object_base_update

当对象基础数据更新时执行。

```python
import bpy

def object_base_update_handler(scene):
    print(f"Object base updated in scene: {scene.name}")

bpy.app.handlers.object_base_update.append(object_base_update_handler)
```

## 处理程序属性

### frame_change_pre

帧更改前处理程序列表。

```python
import bpy

print(f"Number of frame_change_pre handlers: {len(bpy.app.handlers.frame_change_pre)}")

for handler in bpy.app.handlers.frame_change_pre:
    print(f"Handler: {handler}")
```

### frame_change_post

帧更改后处理程序列表。

```python
import bpy

print(f"Number of frame_change_post handlers: {len(bpy.app.handlers.frame_change_post)}")
```

### render_pre

渲染前处理程序列表。

```python
import bpy

print(f"Number of render_pre handlers: {len(bpy.app.handlers.render_pre)}")
```

### render_post

渲染后处理程序列表。

```python
import bpy

print(f"Number of render_post handlers: {len(bpy.app.handlers.render_post)}")
```

### save_pre

保存前处理程序列表。

```python
import bpy

print(f"Number of save_pre handlers: {len(bpy.app.handlers.save_pre)}")
```

### save_post

保存后处理程序列表。

```python
import bpy

print(f"Number of save_post handlers: {len(bpy.app.handlers.save_post)}")
```

### load_pre

加载前处理程序列表。

```python
import bpy

print(f"Number of load_pre handlers: {len(bpy.app.handlers.load_pre)}")
```

### load_post

加载后处理程序列表。

```python
import bpy

print(f"Number of load_post handlers: {len(bpy.app.handlers.load_post)}")
```

## 完整示例

### 自动保存备份

```python
import bpy
import os
import shutil
from datetime import datetime

backup_dir = "//backups"

def auto_backup(filepath):
    """在保存时自动创建备份"""
    if not filepath:
        return
    
    # 创建备份目录
    backup_path = bpy.path.abspath(backup_dir)
    if not os.path.exists(backup_path):
        os.makedirs(backup_path)
    
    # 生成备份文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = os.path.basename(filepath)
    backup_file = os.path.join(backup_path, f"{timestamp}_{filename}")
    
    # 复制文件
    shutil.copy2(filepath, backup_file)
    print(f"Backup created: {backup_file}")

# 注册处理程序
bpy.app.handlers.save_post.append(auto_backup)
```

### 帧范围同步

```python
import bpy

def sync_frame_range(scene):
    """同步所有场景的帧范围"""
    start_frame = scene.frame_start
    end_frame = scene.frame_end
    
    for other_scene in bpy.data.scenes:
        if other_scene != scene:
            other_scene.frame_start = start_frame
            other_scene.frame_end = end_frame

# 在帧更改时同步
bpy.app.handlers.frame_change_post.append(sync_frame_range)
```

### 渲染统计

```python
import bpy
import time

render_stats = {
    'total_renders': 0,
    'total_time': 0.0,
    'last_render_time': 0.0
}

def start_render_stats(scene):
    render_stats['start_time'] = time.time()

def end_render_stats(scene):
    end_time = time.time()
    duration = end_time - render_stats.get('start_time', end_time)
    render_stats['total_renders'] += 1
    render_stats['total_time'] += duration
    render_stats['last_render_time'] = duration
    
    print(f"Render #{render_stats['total_renders']}: {duration:.2f}s")
    print(f"Total renders: {render_stats['total_renders']}")
    print(f"Average time: {render_stats['total_time'] / render_stats['total_renders']:.2f}s")

bpy.app.handlers.render_pre.append(start_render_stats)
bpy.app.handlers.render_post.append(end_render_stats)
```

### 加载后初始化

```python
import bpy

def setup_scene_on_load(filepath):
    """加载文件后设置场景"""
    scene = bpy.context.scene
    
    # 设置默认渲染设置
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 128
    
    # 设置时间线范围
    scene.frame_start = 1
    scene.frame_end = 250
    
    print(f"Scene initialized: {scene.name}")

bpy.app.handlers.load_post.append(setup_scene_on_load)
```

### 验证数据完整性

```python
import bpy

def validate_scene(scene):
    """验证场景数据的完整性"""
    issues = []
    
    # 检查对象
    for obj in scene.objects:
        if not obj.data and obj.type not in ('EMPTY', 'CAMERA', 'LIGHT'):
            issues.append(f"Object {obj.name} has no data")
        
        # 检查变换
        if obj.scale.x < 0 or obj.scale.y < 0 or obj.scale.z < 0:
            issues.append(f"Object {obj.name} has negative scale")
    
    # 检查材质
    for mat in bpy.data.materials:
        if not mat.node_tree and not mat.use_nodes:
            issues.append(f"Material {mat.name} has no nodes")
    
    # 报告问题
    if issues:
        print(f"Scene validation issues ({len(issues)}):")
        for issue in issues:
            print(f"  - {issue}")
    else:
        print("Scene validation passed")

# 在保存前验证
def validate_on_save(filepath):
    validate_scene(bpy.context.scene)

bpy.app.handlers.save_pre.append(validate_on_save)
```

### 动画录制

```python
import bpy

class AnimationRecorder:
    def __init__(self):
        self.animations = {}
    
    def record_frame(self, scene):
        frame = scene.frame_current
        
        for obj in scene.objects:
            if obj.animation_data and obj.animation_data.action:
                action = obj.animation_data.action.name
                
                if action not in self.animations:
                    self.animations[action] = {}
                
                self.animations[action][frame] = {
                    'location': obj.location.copy(),
                    'rotation': obj.rotation_euler.copy(),
                    'scale': obj.scale.copy()
                }
    
    def get_animation(self, action_name):
        return self.animations.get(action_name, {})

recorder = AnimationRecorder()

def start_recording(scene):
    global recorder
    recorder = AnimationRecorder()

def record_frame_handler(scene):
    recorder.record_frame(scene)

# 开始录制时初始化
# bpy.app.handlers.frame_change_post.append(record_frame_handler)
```

## 注意事项

### 处理程序执行顺序

- 处理程序按注册顺序执行
- 相同类型的多个处理程序都会执行
- 处理程序中发生的错误会中断后续处理程序

### 避免无限循环

```python
# 错误示例：在处理程序中修改帧会触发新的处理程序调用
def bad_handler(scene):
    scene.frame_current += 1  # 这会导致无限循环

bpy.app.handlers.frame_change_post.append(bad_handler)  # 不要这样做
```

### 性能影响

- 处理程序应尽量轻量
- 避免在处理程序中进行复杂计算
- 使用条件检查减少不必要的操作

### 注册和注销

```python
import bpy

def my_handler(scene):
    pass

# 注册
bpy.app.handlers.frame_change_post.append(my_handler)

# 注销
if my_handler in bpy.app.handlers.frame_change_post:
    bpy.app.handlers.frame_change_post.remove(my_handler)

# 安全注销
try:
    bpy.app.handlers.frame_change_post.remove(my_handler)
except ValueError:
    pass
```

## 最佳实践

1. **模块化**：将处理程序定义在单独的函数或类中
2. **清理**：在插件卸载时移除所有处理程序
3. **错误处理**：在处理程序中添加异常处理
4. **条件执行**：仅在需要时执行处理程序
5. **性能优化**：避免在处理程序中进行耗时操作
