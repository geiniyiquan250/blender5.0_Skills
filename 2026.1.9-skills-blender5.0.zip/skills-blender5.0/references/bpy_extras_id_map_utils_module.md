# bpy_extras.id_map_utils - ID映射工具模块

bpy_extras.id_map_utils模块提供了ID数据块与名称之间的映射转换功能。

## 概述

ID映射工具用于在不同数据块之间建立名称与实际数据对象的映射关系。这在处理资源导入导出、数据迁移等场景中非常有用。

## 核心功能

### ID映射创建

```python
import bpy
from bpy_extras.id_map_utils import (
    get_data_from_id,
    get_name_from_id
)

def create_id_map(id_block):
    """创建ID映射字典"""
    id_map = {}
    if hasattr(id_block, 'items'):
        for name, item in id_block.items():
            id_map[name] = item
    return id_map

def create_object_name_map(scene=None):
    """创建对象名称映射"""
    if scene is None:
        scene = bpy.context.scene
    name_map = {}
    for obj in scene.objects:
        name_map[obj.name] = obj
    return name_map

def create_material_name_map():
    """创建材质名称映射"""
    mat_map = {}
    for mat in bpy.data.materials:
        mat_map[mat.name] = mat
    return mat_map
```

### ID查询

```python
def get_object_by_name(name, scene=None):
    """通过名称获取对象"""
    if scene is None:
        scene = bpy.context.scene
    return scene.objects.get(name)

def get_material_by_name(name):
    """通过名称获取材质"""
    return bpy.data.materials.get(name)

def get_texture_by_name(name):
    """通过名称获取纹理"""
    return bpy.data.textures.get(name)

def get_image_by_name(name):
    """通过名称获取图像"""
    return bpy.data.images.get(name)

def get_collection_by_name(name, scene=None):
    """通过名称获取集合"""
    if scene is None:
        scene = bpy.context.scene
    return scene.collection.children.get(name) or bpy.data.collections.get(name)

def get_armature_by_name(name):
    """通过名称获取骨架"""
    return bpy.data.armatures.get(name)
```

### ID列表操作

```python
def get_all_object_names(scene=None):
    """获取所有对象名称"""
    if scene is None:
        scene = bpy.context.scene
    return [obj.name for obj in scene.objects]

def get_all_material_names():
    """获取所有材质名称"""
    return [mat.name for mat in bpy.data.materials]

def filter_objects_by_type(obj_type, scene=None):
    """按类型过滤对象"""
    if scene is None:
        scene = bpy.context.scene
    return {obj.name: obj for obj in scene.objects if obj.type == obj_type}

def filter_objects_by_layer(scene=None, only_visible=True):
    """按图层过滤对象"""
    if scene is None:
        scene = bpy.context.scene
    result = {}
    for obj in scene.objects:
        if only_visible and not obj.visible_get():
            continue
        result[obj.name] = obj
    return result
```

## 实用函数

### 数据迁移

```python
def remap_object_references(
    obj, 
    old_name_map, 
    new_name_map, 
    data_path='collection'
):
    """重新映射对象引用"""
    if data_path not in obj:
        return
    collection = obj[data_path]
    if isinstance(collection, bpy.types.Collection):
        new_collection = new_name_map.get(collection.name)
        if new_collection:
            obj[data_path] = new_collection

def remap_material_references(obj, old_mat_map, new_mat_map):
    """重新映射材质引用"""
    if obj.type != 'MESH':
        return
    for i, slot in enumerate(obj.material_slots):
        new_mat = new_mat_map.get(slot.material.name)
        if new_mat:
            obj.material_slots[i].material = new_mat

def batch_remap_references(
    objects, 
    old_name_map, 
    new_name_map, 
    reference_type='object'
):
    """批量重新映射引用"""
    for obj in objects:
        if reference_type == 'collection':
            remap_object_references(obj, old_name_map, new_name_map, 'collection')
        elif reference_type == 'material':
            remap_material_references(obj, old_name_map, new_name_map)
```

### 验证工具

```python
def validate_object_references(obj, name_map):
    """验证对象引用有效性"""
    issues = []
    for attr in ['active_material', 'data']:
        if hasattr(obj, attr):
            ref = getattr(obj, attr)
            if ref and hasattr(ref, 'name'):
                if ref.name not in name_map:
                    issues.append(f"{attr}: {ref.name}")
    return issues

def find_broken_references(scene=None):
    """查找断开的引用"""
    if scene is None:
        scene = bpy.context.scene
    broken = []
    for obj in scene.objects:
        issues = validate_object_references(obj, scene.objects)
        if issues:
            broken.append((obj.name, issues))
    return broken

def cleanup_unused_materials():
    """清理未使用的材质"""
    used_mats = set()
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            for slot in obj.material_slots:
                if slot.material:
                    used_mats.add(slot.material)
    unused = [mat for mat in bpy.data.materials if mat not in used_mats]
    for mat in unused:
        bpy.data.materials.remove(mat)
    return len(unused)
```

## 常见问题排查

### 名称冲突

多个对象同名：
- Blender允许同名对象在不同集合中
- 使用完整的对象路径进行区分
- 使用object.name_full获取全名

### 引用丢失

数据块已删除：
- 检查是否所有引用都指向有效对象
- 使用try-except处理可能的空引用
- 在操作前验证名称映射

### 映射不完整

数据未加载：
- 确保相关数据块已加载到内存
- 检查collection层级结构
- 验证引用路径的正确性
