# bpy.ops.export_scene - OBJ导出操作模块

Blender OBJ文件导出操作符，用于将场景导出为OBJ格式。

## 概述

`bpy.ops.export_scene.obj` 模块提供用于将Blender场景导出为Wavefront OBJ格式的功能，支持几何体、材质和纹理的导出。

## 核心功能

### 基础导出

```python
import bpy

# 导出选中对象
bpy.ops.export_scene.obj(
    filepath='//model.obj',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    export_selected=True,
    use_selection=False,
    use_triangles=False,
    use_normals=True,
    use_uv=True,
    use_materials=True,
    use_nurbs=False,
    use_vertex_groups=False,
    use_blen_objects=True,
    group_by_object=False,
    group_by_material=False,
    keep_vertex_order=True,
    use_verbose=False,
    use_mirror_x=False,
    global_scale=1.0,
    path_mode='RELATIVE'
)
```

### 导出范围

```python
# 只导出选中对象
bpy.ops.export_scene.obj(
    filepath='//selected.obj',
    export_selected=True
)

# 导出所有对象
bpy.ops.export_scene.obj(
    filepath='//all.obj',
    export_selected=False
)
```

### 几何体设置

```python
# 三角化
bpy.ops.export_scene.obj(
    filepath='//triangulated.obj',
    use_triangles=True
)

# 不三角化
bpy.ops.export_scene.obj(
    filepath='//model.obj',
    use_triangles=False
)

# 导出法线
bpy.ops.export_scene.obj(
    filepath='//normals.obj',
    use_normals=True
)

# 不导出法线
bpy.ops.export_scene.obj(
    filepath='//no_normals.obj',
    use_normals=False
)
```

### UV设置

```python
# 导出UV
bpy.ops.export_scene.obj(
    filepath='//uv.obj',
    use_uv=True
)

# 不导出UV
bpy.ops.export_scene.obj(
    filepath='//no_uv.obj',
    use_uv=False
)
```

### 材质设置

```python
# 导出材质
bpy.ops.export_scene.obj(
    filepath='//materials.obj',
    use_materials=True
)

# 不导出材质
bpy.ops.export_scene.obj(
    filepath='//no_materials.obj',
    use_materials=False
)
```

### 顶点组设置

```python
# 导出顶点组
bpy.ops.export_scene.obj(
    filepath='//vertex_groups.obj',
    use_vertex_groups=True
)

# 不导出顶点组
bpy.ops.export_scene.obj(
    filepath='//no_groups.obj',
    use_vertex_groups=False
)
```

### 分组设置

```python
# 按对象分组
bpy.ops.export_scene.obj(
    filepath='//by_object.obj',
    group_by_object=True
)

# 按材质分组
bpy.ops.export_scene.obj(
    filepath='//by_material.obj',
    group_by_material=True
)

# 不分组
bpy.ops.export_scene.obj(
    filepath='//no_group.obj',
    group_by_object=False,
    group_by_material=False
)
```

### 顶点顺序

```python
# 保持顶点顺序
bpy.ops.export_scene.obj(
    filepath='//ordered.obj',
    keep_vertex_order=True
)

# 不保持顶点顺序
bpy.ops.export_scene.obj(
    filepath='//unordered.obj',
    keep_vertex_order=False
)
```

### 缩放和镜像

```python
# 设置全局缩放
bpy.ops.export_scene.obj(
    filepath='//scaled.obj',
    global_scale=1.0
)

# 镜像X轴
bpy.ops.export_scene.obj(
    filepath='//mirrored.obj',
    use_mirror_x=True
)
```

### 路径模式

```python
# 相对路径
bpy.ops.export_scene.obj(
    filepath='//model.obj',
    path_mode='RELATIVE'
)

# 绝对路径
bpy.ops.export_scene.obj(
    filepath='//model.obj',
    path_mode='ABSOLUTE'
)

# 条带
bpy.ops.export_scene.obj(
    filepath='//model.obj',
    path_mode='STRIP'
)
```

### 详细输出

```python
# 详细输出
bpy.ops.export_scene.obj(
    filepath='//verbose.obj',
    use_verbose=True
)

# 不详细输出
bpy.ops.export_scene.obj(
    filepath='//quiet.obj',
    use_verbose=False
)
```

## 实用函数

```python
def export_obj_model(filepath, apply_modifiers=True):
    """导出OBJ模型"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        export_selected=True,
        use_triangles=False,
        use_normals=True,
        use_uv=True,
        use_materials=True,
        use_vertex_groups=False
    )

def export_obj_triangulated(filepath):
    """导出OBJ三角化"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        export_selected=True,
        use_triangles=True,
        use_normals=True,
        use_uv=True,
        use_materials=True
    )

def export_obj_for_cad(filepath):
    """导出OBJ用于CAD"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        export_selected=True,
        use_triangles=True,
        use_normals=True,
        use_uv=False,
        use_materials=False,
        global_scale=1.0
    )

def export_obj_for_print(filepath):
    """导出OBJ用于3D打印"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        export_selected=True,
        use_triangles=True,
        use_normals=True,
        use_uv=False,
        use_materials=False,
        use_vertex_groups=False
    )

def export_obj_with_materials(filepath):
    """导出OBJ带材质"""
    bpy.ops.export_scene.obj(
        filepath=filepath,
        export_selected=True,
        use_triangles=False,
        use_normals=True,
        use_uv=True,
        use_materials=True,
        path_mode='RELATIVE'
    )

def export_obj_batched(output_dir):
    """批量导出OBJ"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            filepath = os.path.join(output_dir, f'{obj.name}.obj')
            bpy.ops.export_scene.obj(
                filepath=filepath,
                export_selected=True,
                use_triangles=False,
                use_normals=True,
                use_uv=True
            )

def export_obj_collection(collection, filepath):
    """导出集合为OBJ"""
    bpy.ops.object.select_all(action='DESELECT')
    
    for obj in collection.objects:
        if obj.type == 'MESH':
            obj.select_set(True)
    
    if bpy.context.selected_objects:
        bpy.ops.export_scene.obj(
            filepath=filepath,
            export_selected=True,
            use_triangles=False,
            use_normals=True,
            use_uv=True,
            use_materials=True
        )
```

## 常见问题排查

### 导出后模型缺失
```python
# 检查选中对象
selected = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
print(f"选中网格: {len(selected)}")

# 确保对象可见
for obj in selected:
    obj.hide_viewport = False
    obj.hide_render = False

# 检查网格数据
for obj in selected:
    print(f"{obj.name}: 顶点数={len(obj.data.vertices)}, 面数={len(obj.data.polygons)}")
```

### UV丢失
```python
# 检查UV层
mesh = bpy.context.active_object.data
print(f"UV层: {[l.name for l in mesh.uv_layers]}")

# 确保导出UV选项
bpy.ops.export_scene.obj(
    filepath='//uv.obj',
    export_selected=True,
    use_uv=True
)
```

### 材质丢失
```python
# 检查材质
obj = bpy.context.active_object
print(f"材质数: {len(obj.data.materials) if obj.data else 0}")

# 确保导出材质选项
bpy.ops.export_scene.obj(
    filepath='//mat.obj',
    export_selected=True,
    use_materials=True
)

# 检查mtl文件
mtl_path = bpy.path.abspath('//model.mtl')
print(f"mtl文件存在: {bpy.path.exists(mtl_path)}")
```

### 法线问题
```python
# 检查法线
mesh = bpy.context.active_object.data
print(f"自定义法线: {mesh.has_custom_normals}")

# 重新计算法线
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.mesh.normals_make_consistent(inside=False)
bpy.ops.object.mode_set(mode='OBJECT')

# 确保导出法线选项
bpy.ops.export_scene.obj(
    filepath='//normals.obj',
    export_selected=True,
    use_normals=True
)
```

### 文件路径问题
```python
# 检查路径模式
print(f"路径模式: RELATIVE")

# 使用相对路径
bpy.ops.export_scene.obj(
    filepath='//model.obj',
    path_mode='RELATIVE'
)

# 使用绝对路径
bpy.ops.export_scene.obj(
    filepath='C:/project/model.obj',
    path_mode='ABSOLUTE'
)

# 检查导出目录
export_dir = bpy.path.dirname(bpy.path.abspath('//model.obj'))
print(f"导出目录: {export_dir}")
print(f"目录存在: {bpy.path.exists(export_dir)}")
```

### 顶点顺序问题
```python
# 检查顶点顺序
obj = bpy.context.active_object
print(f"顶点数: {len(obj.data.vertices)}")

# 重新排序顶点
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.mesh.remove_doubles()
bpy.ops.object.mode_set(mode='OBJECT')

# 保持顶点顺序导出
bpy.ops.export_scene.obj(
    filepath='//ordered.obj',
    export_selected=True,
    keep_vertex_order=True
)
```
