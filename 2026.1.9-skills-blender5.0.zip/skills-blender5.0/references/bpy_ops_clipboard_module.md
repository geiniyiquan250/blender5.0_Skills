# bpy.ops.clipboard - 剪贴板操作模块

Blender剪贴板操作符，用于复制和粘贴数据。

## 概述

`bpy.ops.clipboard` 模块提供用于在Blender中进行复制、粘贴和剪贴操作的功能。这些操作符可以跨不同对象和编辑器使用。

## 核心功能

### 复制操作

```python
import bpy

# 复制选中的对象
bpy.ops.object.copy()

# 复制选中的数据
bpy.ops.data_copy()

# 复制属性
bpy.ops.clipboard.copy(
    type='PROPERTIES'
)

# 复制变换
bpy.ops.transform.copy()

# 复制材质
bpy.ops.object.material_copy()

# 复制顶点组
bpy.ops.object.vertex_group_copy()

# 复制修改器
bpy.ops.object.modifier_copy()

# 复制约束
bpy.ops.object.constraint_copy()

# 复制动画数据
bpy.ops.action.copy()

# 复制驱动
bpy.ops.graph.copy_driver()
```

### 粘贴操作

```python
# 粘贴对象
bpy.ops.object.paste()

# 粘贴数据
bpy.ops.data_paste()

# 粘贴属性
bpy.ops.clipboard.paste(
    type='PROPERTIES'
)

# 粘贴变换
bpy.ops.transform.paste()

# 粘贴材质
bpy.ops.object.material_paste(
    replace=True
)

# 粘贴顶点组
bpy.ops.object.vertex_group_paste()

# 粘贴修改器
bpy.ops.object.modifier_paste()

# 粘贴约束
bpy.ops.object.constraint_paste()

# 粘贴动画数据
bpy.ops.action.paste()

# 粘贴驱动
bpy.ops.graph.paste_driver()
```

### 特殊粘贴操作

```python
# 粘贴到所有选中对象
bpy.ops.object.paste_to_all()

# 原地粘贴
bpy.ops.object.paste_in_place()

# 反向粘贴
bpy.ops.object.paste_in_reverse()

# 混合粘贴
bpy.ops.object.paste_mix(
    factor=0.5
)

# 偏移粘贴
bpy.ops.object.paste_offset(
    offset=(1.0, 0.0, 0.0)
)

# 镜像粘贴
bpy.ops.object.paste_mirror(
    axis='X'
)
```

### 剪贴操作

```python
# 剪贴选中对象
bpy.ops.object.cut(
    clipboard=True
)

# 剪贴并链接
bpy.ops.object.cut(
    clipboard=True,
    link=True
)

# 删除到剪贴板
bpy.ops.object.delete(
    use_global=False
)

# 全局删除到剪贴板
bpy.ops.object.delete(
    use_global=True
)
```

## 实用函数

```python
def copy_object_with_children(obj):
    """复制对象及其子对象"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.select_hierarchy(
        direction='CHILD',
        extend=True
    )
    bpy.ops.object.copy()

def duplicate_object(obj, linked=False):
    """复制对象"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.duplicate(
        linked=linked,
        mode='DUPLICATE'
    )
    return bpy.context.active_object

def batch_copy_objects(object_names, offset=(2.0, 0, 0)):
    """批量复制对象"""
    copies = []
    for obj_name in object_names:
        obj = bpy.data.objects.get(obj_name)
        if obj:
            copy = duplicate_object(obj)
            copy.location += offset
            copies.append(copy)
    return copies

def mirror_object_across_axis(obj, axis='X'):
    """沿轴镜像对象"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.duplicate()
    bpy.ops.transform.mirror(
        orient_type='GLOBAL',
        constraint_axis=(axis == 'X', axis == 'Y', axis == 'Z'),
        orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1))
    )

def offset_duplicate_and_chain(base_obj, count, offset):
    """链式偏移复制"""
    result = [base_obj]
    for i in range(count):
        prev = result[-1]
        bpy.ops.object.select_all(action='DESELECT')
        prev.select_set(True)
        bpy.active = prev
.context.view_layer.objects        bpy.ops.object.duplicate()
        new_obj = bpy.context.active_object
        new_obj.location += offset * (i + 1)
        result.append(new_obj)
    return result

def copy_material_to_objects(material_name, object_names):
    """将材质复制到多个对象"""
    material = bpy.data.materials.get(material_name)
    if material:
        for obj_name in object_names:
            obj = bpy.data.objects.get(obj_name)
            if obj and obj.data and hasattr(obj.data, 'materials'):
                if material not in obj.data.materials:
                    obj.data.materials.append(material)

def transfer_vertex_groups(source_obj, target_objs, replace=False):
    """传输顶点组"""
    for target_name in target_objs:
        target = bpy.data.objects.get(target_name)
        if target and target.type == source_obj.type:
            for vg in source_obj.vertex_groups:
                if vg.name not in [tvg.name for tvg in target.vertex_groups] or replace:
                    if replace:
                        target.vertex_groups.remove(target.vertex_groups.get(vg.name))
                    new_vg = target.vertex_groups.new(name=vg.name)
                    new_vg.lock_weight = vg.lock_weight
```

## 常见问题排查

### 复制粘贴无响应
```python
# 检查是否有选中对象
selected = [obj for obj in bpy.context.selected_objects]
print(f"选中对象数: {len(selected)}")

# 检查活动对象
print(f"活动对象: {bpy.context.active_object}")

# 检查对象是否在视图中
for obj in selected:
    print(f"对象 {obj.name}: 隐藏={obj.hide_viewport}, 可选={obj.hide_select}")

# 确保对象可见且可选
for obj in selected:
    obj.hide_viewport = False
    obj.hide_select = False
```

### 粘贴位置错误
```python
# 检查原点位置
obj = bpy.context.active_object
print(f"原点: {obj.location}")

# 检查世界原点
print(f"世界原点: {bpy.context.scene.cursor.location}")

# 设置正确的粘贴位置
bpy.context.scene.cursor.location = (0, 0, 0)
bpy.ops.object.paste_location()

# 检查吸附设置
print(f"吸附: {bpy.context.scene.tool_settings.use_snap}")
```

### 材质复制问题
```python
# 检查材质
obj = bpy.context.active_object
print(f"对象材质: {obj.data.materials if obj.data else 'N/A'}")

# 检查源材质
source_mat = bpy.context.scene.clipboard
if isinstance(source_mat, bpy.types.Material):
    print(f"源材质: {source_mat.name}")

# 重新分配材质
if obj.data:
    obj.data.materials.clear()
    obj.data.materials.append(source_mat)
```
