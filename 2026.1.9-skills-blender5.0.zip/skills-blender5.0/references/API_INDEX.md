# Blender技能包API文档分类索引

本文档整理了Blender 5.0技能包API文档的分类结构，方便快速查找和导航。

## 一、核心基础模块 (Core)

### 1.1 Blender Python基础
- [bpy_module.md](bpy_module.md) - Blender Python主模块
- [bpy_data_module.md](bpy_data_module.md) - 数据访问模块
- [bpy_context_module.md](bpy_context_module.md) - 上下文模块
- [bpy_props_module.md](bpy_props_module.md) - 属性模块
- [bpy_utils_module.md](bpy_utils_module.md) - 工具模块
- [bpy_utils_units_module.md](bpy_utils_units_module.md) - 单位工具模块
- [bpy_path_module.md](bpy_path_module.md) - 路径模块
- [bpy_types.md](bpy_types.md) - 类型定义
- [bpy_types_detailed_module.md](bpy_types_detailed_module.md) - 详细类型定义
- [bpy_app_module.md](bpy_app_module.md) - 应用程序模块
- [bpy_app_handlers_module.md](bpy_app_handlers_module.md) - 事件处理器
- [bpy_app_timers_module.md](bpy_app_timers_module.md) - 定时器模块
- [bpy_app_icons_module.md](bpy_app_icons_module.md) - 图标模块
- [bpy_app_translations_module.md](bpy_app_translations_module.md) - 翻译模块
- [bpy_extras_module.md](bpy_extras_module.md) - 扩展模块

### 1.2 Blender附加模块
- [aud_module.md](aud_module.md) - 音频模块
- [bl_math_module.md](bl_math_module.md) - 数学扩展模块
- [blf_module.md](blf_module.md) - 字体渲染模块
- [idprop_module.md](idprop_module.md) - ID属性模块
- [idprop_types_module.md](idprop_types_module.md) - ID属性类型模块
- [imbuf_module.md](imbuf_module.md) - 图像缓冲模块
- [imbuf_types_module.md](imbuf_types_module.md) - 图像缓冲类型模块

### 1.3 Mathutils数学模块
- [mathutils_module.md](mathutils_module.md) - 数学工具主模块
- [mathutils_geometry_module.md](mathutils_geometry_module.md) - 几何模块
- [mathutils_noise_module.md](mathutils_noise_module.md) - 噪声模块

### 1.4 Freestyle模块
- [freestyle_module.md](freestyle_module.md) - Freestyle主模块
- [freestyle_types_module.md](freestyle_types_module.md) - Freestyle类型模块
- [freestyle_utils_module.md](freestyle_utils_module.md) - Freestyle工具模块

## 二、BMesh几何模块

### 2.1 基础BMesh
- [bmesh_module.md](bmesh_module.md) - BMesh主模块
- [bmesh_types_module.md](bmesh_types_module.md) - BMesh类型模块
- [bmesh_types_detailed_module.md](bmesh_types_detailed_module.md) - BMesh详细类型模块

### 2.2 BMesh操作
- [bmesh_geometry_module.md](bmesh_geometry_module.md) - BMesh几何模块
- [bmesh_ops_module.md](bmesh_ops_module.md) - BMesh操作模块
- [bmesh_utils_module.md](bmesh_utils_module.md) - BMesh工具模块

## 三、GPU图形模块

### 3.1 GPU基础
- [gpu_module.md](gpu_module.md) - GPU主模块
- [gpu_types_module.md](gpu_types_module.md) - GPU类型模块
- [gpu_platform_module.md](gpu_platform_module.md) - GPU平台模块
- [gpu_state_module.md](gpu_state_module.md) - GPU状态模块

### 3.2 GPU功能
- [gpu_shader_module.md](gpu_shader_module.md) - GPU着色器模块
- [gpu_matrix_module.md](gpu_matrix_module.md) - GPU矩阵模块
- [gpu_texture_module.md](gpu_texture_module.md) - GPU纹理模块
- [gpu_select_module.md](gpu_select_module.md) - GPU选择模块
- [gpu_extras_module.md](gpu_extras_module.md) - GPU扩展模块
- [gpu_detailed_module.md](gpu_detailed_module.md) - GPU详细模块

## 四、bpy.ops操作符模块

### 4.1 操作符基础与索引
- [bpy_ops.md](bpy_ops.md) - 操作符主文档
- [bpy_ops_summary.md](bpy_ops_summary.md) - 操作符概述
- [bpy_ops_detailed_module.md](bpy_ops_detailed_module.md) - 详细操作符文档

### 4.2 基础操作 (Basic Operations)
- [bpy_ops_object_module.md](bpy_ops_object_module.md) - 对象基础操作
- [bpy_ops_transform_module.md](bpy_ops_transform_module.md) - 变换操作
- [bpy_ops_file_module.md](bpy_ops_file_module.md) - 文件操作
- [bpy_ops_wm_module.md](bpy_ops_wm_module.md) - 窗口管理操作
- [bpy_ops_workspace_module.md](bpy_ops_workspace_module.md) - 工作区操作
- [bpy_ops_screen_module.md](bpy_ops_screen_module.md) - 屏幕操作
- [bpy_ops_ui_module.md](bpy_ops_ui_module.md) - UI操作
- [bpy_ops_console_module.md](bpy_ops_console_module.md) - 控制台操作
- [bpy_ops_script_module.md](bpy_ops_script_module.md) - 脚本操作
- [bpy_ops_preferences_module.md](bpy_ops_preferences_module.md) - 首选项操作

### 4.3 编辑器操作 (Editors)
- [bpy_ops_area_module.md](bpy_ops_area_module.md) - 区域编辑器操作
- [bpy_ops_view3d_module.md](bpy_ops_view3d_module.md) - 3D视图操作
- [bpy_ops_view2d_module.md](bpy_ops_view2d_module.md) - 2D视图操作
- [bpy_ops_text_editor_module.md](bpy_ops_text_editor_module.md) - 文本编辑器操作
- [bpy_ops_spreadsheet_module.md](bpy_ops_spreadsheet_module.md) - 电子表格操作
- [bpy_ops_outliner_module.md](bpy_ops_outliner_module.md) - 大纲操作
- [bpy_ops_properties_module.md](bpy_ops_properties_module.md) - 属性编辑器操作
- [bpy_ops_info_module.md](bpy_ops_info_module.md) - 信息编辑器操作
- [bpy_ops_nla_module.md](bpy_ops_nla_module.md) - NLA编辑器操作
- [bpy_ops_graph_module.md](bpy_ops_graph_module.md) - 图表编辑器操作
- [bpy_ops_dopesheet_module.md](bpy_ops_dopesheet_module.md) - 动画摄影表操作
- [bpy_ops_video_seq_module.md](bpy_ops_video_seq_module.md) - 视频序列操作

### 4.4 选择与视图 (Selection & View)
- [bpy_ops_view3d_ruler_module.md](bpy_ops_view3d_ruler_module.md) - 标尺测量操作
- [bpy_ops_header_module.md](bpy_ops_header_module.md) - 标题栏操作
- [bpy_ops_toolshelf_module.md](bpy_ops_toolshelf_module.md) - 工具架操作
- [bpy_ops_screen_region_toggle_module.md](bpy_ops_screen_region_toggle_module.md) - 区域切换操作
- [bpy_ops_ed_module.md](bpy_ops_ed_module.md) - 编辑器操作
- [bpy_ops_uilist_module.md](bpy_ops_uilist_module.md) - UI列表操作
- [bpy_ops_clipboard_module.md](bpy_ops_clipboard_module.md) - 剪贴板操作

### 4.5 网格建模 (Mesh Modeling)
- [bpy_ops_mesh_module.md](bpy_ops_mesh_module.md) - 网格操作
- [bpy_ops_uv_module.md](bpy_ops_uv_module.md) - UV操作
- [bpy_ops_material_module.md](bpy_ops_material_module.md) - 材质操作
- [bpy_ops_texture_module.md](bpy_ops_texture_module.md) - 纹理操作
- [bpy_ops_modifier_module.md](bpy_ops_modifier_module.md) - 修改器操作
- [bpy_ops_gizmo_module.md](bpy_ops_gizmo_module.md) - 小工具操作
- [bpy_ops_gizmogroup_module.md](bpy_ops_gizmogroup_module.md) - 小工具组操作

### 4.6 曲线建模 (Curve Modeling)
- [bpy_ops_curve_module.md](bpy_ops_curve_module.md) - 曲线操作
- [bpy_ops_surface_module.md](bpy_ops_surface_module.md) - 曲面操作
- [bpy_ops_text_module.md](bpy_ops_text_module.md) - 文本操作
- [bpy_ops_curves_module.md](bpy_ops_curves_module.md) - 曲线系统操作
- [bpy_ops_paintcurve_module.md](bpy_ops_paintcurve_module.md) - 绘画曲线操作
- [bpy_ops_paint_curve_module.md](bpy_ops_paint_curve_module.md) - 绘画曲线模块操作

### 4.7 雕刻与绘画 (Sculpting & Painting)
- [bpy_ops_sculpt_module.md](bpy_ops_sculpt_module.md) - 雕刻操作
- [bpy_ops_brush_module.md](bpy_ops_brush_module.md) - 笔刷操作
- [bpy_ops_paint_module.md](bpy_ops_paint_module.md) - 绘画操作
- [bpy_ops_paint_vertex_module.md](bpy_ops_paint_vertex_module.md) - 顶点绘画操作
- [bpy_ops_paint_weight_module.md](bpy_ops_paint_weight_module.md) - 权重绘画操作
- [bpy_ops_paint_texture_module.md](bpy_ops_paint_texture_module.md) - 纹理绘画操作
- [bpy_ops_palette_module.md](bpy_ops_palette_module.md) - 调色板操作
- [bpy_ops_sculpt_curves_module.md](bpy_ops_sculpt_curves_module.md) - 雕刻曲线操作

### 4.8 动画系统 (Animation)
- [bpy_ops_anim_module.md](bpy_ops_anim_module.md) - 动画操作
- [bpy_ops_animation_module.md](bpy_ops_animation_module.md) - 动画系统操作
- [bpy_ops_action_module.md](bpy_ops_action_module.md) - 动作操作
- [bpy_ops_pose_module.md](bpy_ops_pose_module.md) - 姿势操作
- [bpy_ops_keying_set_module.md](bpy_ops_keying_set_module.md) - 关键帧设置操作
- [bpy_ops_marker_module.md](bpy_ops_marker_module.md) - 标记操作
- [bpy_ops_poselib_module.md](bpy_ops_poselib_module.md) - 姿势库操作
- [bpy_ops_export_anim_module.md](bpy_ops_export_anim_module.md) - 动画导出操作
- [bpy_ops_export_animation_module.md](bpy_ops_export_animation_module.md) - 动画序列导出操作

### 4.9 骨骼与约束 (Armature & Constraints)
- [bpy_ops_armature_module.md](bpy_ops_armature_module.md) - 骨骼操作
- [bpy_ops_constraint_module.md](bpy_ops_constraint_module.md) - 约束操作
- [bpy_ops_rigidbody_module.md](bpy_ops_rigidbody_module.md) - 刚体操作

### 4.10 粒子与物理 (Particles & Physics)
- [bpy_ops_particle_module.md](bpy_ops_particle_module.md) - 粒子操作
- [bpy_ops_ptcache_module.md](bpy_ops_ptcache_module.md) - 粒子缓存操作
- [bpy_ops_fluid_module.md](bpy_ops_fluid_module.md) - 流体操作
- [bpy_ops_cloth_module.md](bpy_ops_cloth_module.md) - 布料操作
- [bpy_ops_boid_module.md](bpy_ops_boid_module.md) - Boid粒子操作
- [bpy_ops_pointcloud_module.md](bpy_ops_pointcloud_module.md) - 点云操作
- [bpy_ops_import_hair_module.md](bpy_ops_import_hair_module.md) - 毛发导入操作

### 4.11 角色装备 (Character Rigging)
- [bpy_ops_grease_pencil_module.md](bpy_ops_grease_pencil_module.md) - 涂鸦铅笔操作
- [bpy_ops_gpencil_module.md](bpy_ops_gpencil_module.md) - 涂鸦铅笔模块操作
- [bpy_ops_mask_module.md](bpy_ops_mask_module.md) - 遮罩操作
- [bpy_ops_lattice_module.md](bpy_ops_lattice_module.md) - 晶格操作
- [bpy_ops_empty_module.md](bpy_ops_empty_module.md) - 空对象操作
- [bpy_ops_mball_module.md](bpy_ops_mball_module.md) -  Metaball操作

### 4.12 场景管理 (Scene Management)
- [bpy_ops_scene_module.md](bpy_ops_scene_module.md) - 场景操作
- [bpy_ops_collection_module.md](bpy_ops_collection_module.md) - 集合操作
- [bpy_ops_group_module.md](bpy_ops_group_module.md) - 组操作
- [bpy_ops_world_module.md](bpy_ops_world_module.md) - 世界操作
- [bpy_ops_camera_module.md](bpy_ops_camera_module.md) - 相机操作
- [bpy_ops_speaker_module.md](bpy_ops_speaker_module.md) - 扬声器操作
- [bpy_ops_light_probe_module.md](bpy_ops_light_probe_module.md) - 光照探针操作

### 4.13 资源与数据 (Assets & Data)
- [bpy_ops_asset_module.md](bpy_ops_asset_module.md) - 资源操作
- [bpy_ops_cachefile_module.md](bpy_ops_cachefile_module.md) - 缓存文件操作
- [bpy_ops_geometry_module.md](bpy_ops_geometry_module.md) - 几何数据操作
- [bpy_ops_image_module.md](bpy_ops_image_module.md) - 图像操作
- [bpy_ops_sound_module.md](bpy_ops_sound_module.md) - 声音操作

### 4.14 渲染输出 (Rendering)
- [bpy_ops_render_module.md](bpy_ops_render_module.md) - 渲染操作
- [bpy_ops_render_animation_module.md](bpy_ops_render_animation_module.md) - 动画渲染操作
- [bpy_ops_render_opengl_module.md](bpy_ops_render_opengl_module.md) - OpenGL渲染操作
- [bpy_ops_eevee_module.md](bpy_ops_eevee_module.md) - EEVEE渲染操作
- [bpy_ops_cycles_module.md](bpy_ops_cycles_module.md) - Cycles渲染操作
- [bpy_ops_workbench_module.md](bpy_ops_workbench_module.md) - Workbench渲染操作
- [bpy_ops_viewport_module.md](bpy_ops_viewport_module.md) - 视口操作

### 4.15 合成与后期 (Compositing & Post-processing)
- [bpy_ops_sequencer_module.md](bpy_ops_sequencer_module.md) - 序列器操作
- [bpy_ops_sequencer_strip_modifier_module.md](bpy_ops_sequencer_strip_modifier_module.md) - 条带修改器操作
- [bpy_ops_compositor_module.md](bpy_ops_compositor_module.md) - 合成器操作
- [bpy_ops_clip_module.md](bpy_ops_clip_module.md) - 剪辑操作
- [bpy_ops_movieclip_module.md](bpy_ops_movieclip_module.md) - 视频剪辑操作

### 4.16 节点编辑 (Node Editing)
- [bpy_ops_node_module.md](bpy_ops_node_module.md) - 节点操作
- [bpy_ops_node_add_module.md](bpy_ops_node_add_module.md) - 添加节点操作
- [bpy_ops_shader_node_module.md](bpy_ops_shader_node_module.md) - 着色器节点操作

### 4.17 导入导出 (Import/Export)

#### 通用导入导出
- [bpy_ops_import_export_module.md](bpy_ops_import_export_module.md) - 导入导出基础操作
- [bpy_ops_import_scene_module.md](bpy_ops_import_scene_module.md) - 场景导入操作
- [bpy_ops_export_scene_module.md](bpy_ops_export_scene_module.md) - 场景导出操作

#### 模型格式导入
- [bpy_ops_import_gltf_module.md](bpy_ops_import_gltf_module.md) - GLTF导入操作
- [bpy_ops_import_obj_module.md](bpy_ops_import_obj_module.md) - OBJ导入操作
- [bpy_ops_import_stl_module.md](bpy_ops_import_stl_module.md) - STL导入操作
- [bpy_ops_import_ply_module.md](bpy_ops_import_ply_module.md) - PLY导入操作
- [bpy_ops_import_fbx_module.md](bpy_ops_import_fbx_module.md) - FBX导入操作
- [bpy_ops_import_abc_module.md](bpy_ops_import_abc_module.md) - Alembic导入操作
- [bpy_ops_import_usd_module.md](bpy_ops_import_usd_module.md) - USD导入操作
- [bpy_ops_import_dae_module.md](bpy_ops_import_dae_module.md) - COLLADA导入操作
- [bpy_ops_import_x3d_module.md](bpy_ops_import_x3d_module.md) - X3D导入操作
- [bpy_ops_import_images_module.md](bpy_ops_import_images_module.md) - 图像序列导入操作

#### 模型格式导出
- [bpy_ops_export_gltf_module.md](bpy_ops_export_gltf_module.md) - GLTF导出操作
- [bpy_ops_export_obj_module.md](bpy_ops_export_obj_module.md) - OBJ导出操作
- [bpy_ops_export_stl_module.md](bpy_ops_export_stl_module.md) - STL导出操作
- [bpy_ops_export_ply_module.md](bpy_ops_export_ply_module.md) - PLY导出操作
- [bpy_ops_export_fbx_module.md](bpy_ops_export_fbx_module.md) - FBX导出操作
- [bpy_ops_export_abc_module.md](bpy_ops_export_abc_module.md) - Alembic导出操作
- [bpy_ops_export_usd_module.md](bpy_ops_export_usd_module.md) - USD导出操作
- [bpy_ops_export_dae_module.md](bpy_ops_export_dae_module.md) - COLLADA导出操作
- [bpy_ops_export_x3d_module.md](bpy_ops_export_x3d_module.md) - X3D导出操作
- [bpy_ops_export_mesh_module.md](bpy_ops_export_mesh_module.md) - 网格导出操作

#### 曲线与动画导出
- [bpy_ops_export_curve_module.md](bpy_ops_export_curve_module.md) - 曲线导出操作
- [bpy_ops_export_anim_module.md](bpy_ops_export_anim_module.md) - 动画导出操作

#### 数据导出
- [bpy_ops_wm_path_open_module.md](bpy_ops_wm_path_open_module.md) - 路径打开操作
- [bpy_ops_dpaint_module.md](bpy_ops_dpaint_module.md) - 动态绘制操作
- [bpy_ops_buttons_module.md](bpy_ops_buttons_module.md) - 按钮面板操作

### 4.18 扩展与插件 (Extensions & Add-ons)
- [bpy_ops_extensions_module.md](bpy_ops_extensions_module.md) - 扩展操作
- [bpy_ops_addon_module.md](bpy_ops_addon_module.md) - 插件操作
- [bpy_ops_module_utils_module.md](bpy_ops_module_utils_module.md) - 模块工具操作

## 五、快速导航索引

### 按功能快速查找

**开始学习Blender Python:**
- → [bpy_module.md](bpy_module.md) - 基础入门
- → [bpy_ops.md](bpy_ops.md) - 操作符概述

**进行3D建模:**
- → [bpy_ops_mesh_module.md](bpy_ops_mesh_module.md) - 网格建模
- → [bpy_ops_curve_module.md](bpy_ops_curve_module.md) - 曲线建模
- → [bpy_ops_sculpt_module.md](bpy_ops_sculpt_module.md) - 雕刻

**创建动画:**
- → [bpy_ops_anim_module.md](bpy_ops_anim_module.md) - 动画基础
- → [bpy_ops_armature_module.md](bpy_ops_armature_module.md) - 骨骼动画
- → [bpy_ops_particle_module.md](bpy_ops_particle_module.md) - 粒子动画

**渲染输出:**
- → [bpy_ops_render_module.md](bpy_ops_render_module.md) - 渲染操作
- → [bpy_ops_export_gltf_module.md](bpy_ops_export_gltf_module.md) - 导出GLTF
- → [bpy_ops_export_fbx_module.md](bpy_ops_export_fbx_module.md) - 导出FBX

**数据处理:**
- → [bpy_data_module.md](bpy_data_module.md) - 数据访问
- → [bpy_ops_import_export_module.md](bpy_ops_import_export_module.md) - 导入导出

**高级功能:**
- → [bmesh_module.md](bmesh_module.md) - BMesh几何操作
- → [gpu_module.md](gpu_module.md) - GPU着色器
- → [mathutils_module.md](mathutils_module.md) - 数学工具

## 六、文件命名规范

### 命名规则
- **bpy_*** - Blender Python核心模块
- **bpy_ops_*** - 操作符模块
- **bmesh_*** - BMesh几何模块
- **gpu_*** - GPU渲染模块
- **mathutils_*** - 数学工具模块
- **freestyle_*** - Freestyle线条渲染模块
- **bl_*** - Blender辅助模块
- **idprop_*** - ID属性模块
- **imbuf_*** - 图像缓冲模块

### 后缀说明
- *_module.md* - 功能模块文档
- *_detailed_module.md* - 详细文档
- *_types_module.md* - 类型定义文档
- *_utils_module.md* - 工具函数文档

## 七、版本信息

- **Blender版本**: 5.0
- **文档更新时间**: 2024年
- **维护状态**: 持续更新中
