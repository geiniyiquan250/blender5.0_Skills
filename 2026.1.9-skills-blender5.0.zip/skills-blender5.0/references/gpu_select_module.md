# gpu.select - GPU选择模块

gpu.select模块提供了GPU对象选择功能，用于在3D视图中进行射线投射和对象选择。

## 概述

GPU选择模块封装了GPU渲染中的对象选择功能，支持通过射线投射获取视图中指定位置的对象。这对于开发交互式工具和视口选择功能非常有用。

## 核心功能

### 射线投射

```python
import gpu
from gpu.select import (
    ray_cast,
    ray_cast_all,
    ray_cast_scene,
    bvh_ray_cast
)

def cast_ray_from_view(view_matrix, projection_matrix, mouse_x, mouse_y):
    """从视图位置发射射线"""
    origin, direction = gpu.select.mouse_ray_cast(
        mouse_x, mouse_y, 
        view_matrix, 
        projection_matrix
    )
    return origin, direction

def cast_ray_from_camera(camera, mouse_x, mouse_y):
    """从相机位置发射射线"""
    view_matrix = camera.matrix_world.inverted()
    projection_matrix = camera.calc_matrix_camera(
        bpy.context.scene,
        bpy.context.view_layer
    )
    return cast_ray_from_view(view_matrix, projection_matrix, mouse_x, mouse_y)

def cast_ray_to_object(origin, direction, obj, distance=1000):
    """向对象投射射线"""
    return gpu.select.ray_cast_object(
        origin, 
        direction, 
        obj, 
        distance
    )

def cast_ray_scene(origin, direction, scene=None, distance=1000):
    """在场景中投射射线"""
    if scene is None:
        scene = bpy.context.scene
    return gpu.select.ray_cast_scene(
        origin, 
        direction, 
        scene, 
        distance
    )
```

### 对象选择

```python
from gpu.select import (
    select_object,
    select_objects_in_box,
    select_objects_in_circle,
    deselect_all
)

def pick_object(mouse_x, mouse_y):
    """拾取对象"""
    hit = gpu.select.pick(
        mouse_x, 
        mouse_y,
        bpy.context.view_layer,
        predicate=lambda obj: obj.visible_get()
    )
    return hit

def pick_objects_in_region(x, y, width, height):
    """在区域中拾取对象"""
    hits = gpu.select.pick_region(
        x, y, width, height,
        bpy.context.view_layer
    )
    return hits

def pick_objects_near_point(x, y, radius):
    """在圆形区域内拾取对象"""
    hits = gpu.select.pick_circle(
        x, y, radius,
        bpy.context.view_layer
    )
    return hits

def select_under_mouse(mouse_x, mouse_y, extend=False):
    """选择鼠标下的对象"""
    if not extend:
        deselect_all()
    
    hit = pick_object(mouse_x, mouse_y)
    if hit:
        obj = hit.object
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
    return hit
```

### BVH射线投射

```python
from gpu.select import BVHTree

def create_bvh_from_mesh(mesh):
    """从网格创建BVH树"""
    verts = [v.co for v in mesh.vertices]
    faces = [p.vertices for p in mesh.polygons]
    return BVHTree.FromPolygons(verts, faces)

def ray_cast_bvh(bvh_tree, origin, direction, distance=1000):
    """在BVH树上投射射线"""
    return bvh_tree.ray_cast(origin, direction, distance)

def find_closest_point_bvh(bvh_tree, point):
    """查找BVH树中最近的点"""
    return bvh_tree.find_nearest(point)

def find_points_in_sphere_bvh(bvh_tree, center, radius):
    """查找球体内的点"""
    return bvh_tree.find_near(center, radius)

def find_all_intersections_bvh(bvh_tree, origin, direction, distance=1000):
    """查找所有交点"""
    return bvh_tree.ray_cast_all(origin, direction, distance)
```

## 实用函数

### 距离计算

```python
def distance_to_object(origin, direction, obj):
    """计算到对象的距离"""
    hit = cast_ray_to_object(origin, direction, obj)
    if hit:
        return hit.distance
    return None

def distance_to_plane(origin, direction, plane_co, plane_no):
    """计算到平面的距离"""
    denom = direction.dot(plane_no)
    if abs(denom) > 1e-6:
        t = (plane_co - origin).dot(plane_no) / denom
        if t >= 0:
            return t
    return None

def get_closest_intersection(origin, direction, objects):
    """获取最近的交点"""
    closest = None
    min_dist = float('inf')
    
    for obj in objects:
        hit = cast_ray_to_object(origin, direction, obj)
        if hit and hit.distance < min_dist:
            min_dist = hit.distance
            closest = hit
    
    return closest
```

### 区域查询

```python
def get_objects_in_frustum(camera, matrix=None):
    """获取视锥体内的对象"""
    if matrix is None:
        matrix = camera.matrix_world
    
    frustum = gpu.select.calculate_frustum(
        camera.calc_matrix_camera(bpy.context.scene, bpy.context.view_layer),
        bpy.context.region.width,
        bpy.context.region.height
    )
    
    objects_in_frustum = []
    for obj in bpy.context.scene.objects:
        if gpu.select.object_in_frustum(obj, frustum, matrix):
            objects_in_frustum.append(obj)
    
    return objects_in_frustum

def get_objects_near_ray(origin, direction, distance, objects):
    """获取射线附近的对象"""
    nearby = []
    for obj in objects:
        dist = distance_to_object(origin, direction, obj)
        if dist is not None and dist <= distance:
            nearby.append(obj)
    return nearby
```

### 碰撞检测

```python
def check_object_collision(obj1, obj2):
    """检查两个对象是否碰撞"""
    bvh1 = create_bvh_from_mesh(obj1.to_mesh())
    bvh2 = create_bvh_from_mesh(obj2.to_mesh())
    return bvh1.intersects(bvh2)

def get_collision_contacts(obj1, obj2):
    """获取碰撞接触点"""
    bvh1 = create_bvh_from_mesh(obj1.to_mesh())
    bvh2 = create_bvh_from_mesh(obj2.to_mesh())
    return bvh1.intersections(bvh2)

def find_overlapping_bvh(bvh1, bvh2, threshold=0.001):
    """查找重叠区域"""
    overlaps = []
    for tri1 in bvh1.triangles():
        for tri2 in bvh2.triangles():
            if tri1.intersects(tri2, threshold):
                overlaps.append((tri1, tri2))
    return overlaps
```

## 常见问题排查

### 射线未命中

参数问题：
- 检查射线原点和方向
- 确认距离足够大
- 验证对象可见性

### 选择不准确

坐标问题：
- 确认鼠标坐标正确
- 检查视口转换
- 验证投影矩阵

### 性能问题

BVH过大：
- 简化网格BVH
- 使用包围盒预检测
- 限制搜索距离
