# bpy.ops.lattice - Lattice Operations Module

Blender 晶格操作符，用于创建和编辑晶格变形对象。

## Overview

`bpy.ops.lattice` 模块包含晶格（Lattice）对象的操作命令，支持晶格的创建、编辑和变形应用。这个模块主要用于网格变形和动画控制。

## 核心功能

```python
import bpy

# 创建晶格
bpy.ops.object.lattice_add(location=(0, 0, 0))

# 晶格设置
bpy.ops.lattice.select_all(action='SELECT')
bpy.ops.lattice.select_more()
bpy.ops.lattice.select_less()
bpy.ops.lattice.select_ungrouped()

# 变形操作
bpy.ops.lattice.make_regular(type='BONE')
bpy.ops.lattice.flip(axis='X')
```

## 实际应用示例

### 晶格管理器

```python
import bpy
import math

class LatticeManager:
    """晶格管理器"""
    
    def __init__(self):
        self.lattices = {}
    
    def create_lattice(self, name, location=(0, 0, 0), 
                       dimensions=(2, 2, 2),
                       size=2.0):
        """创建晶格"""
        bpy.ops.object.lattice_add(location=location)
        lattice = bpy.context.active_object
        lattice.name = name
        
        # 设置晶格参数
        lattice.data.points_u = dimensions[0]
        lattice.data.points_v = dimensions[1]
        lattice.data.points_w = dimensions[2]
        lattice.data.size = size
        
        self.lattices[name] = lattice
        return lattice
    
    def create_adaptive_lattice(self, target_obj, resolution=2, size=1.0):
        """创建自适应晶格"""
        # 基于目标对象大小创建晶格
        bbox = target_obj.bound_box
        min_x = min(v[0] for v in bbox)
        max_x = max(v[0] for v in bbox)
        min_y = min(v[1] for v in bbox)
        max_y = max(v[1] for v in bbox)
        min_z = min(v[2] for v in bbox)
        max_z = max(v[2] for v in bbox)
        
        center = target_obj.location
        
        lattice = self.create_lattice(
            f"{target_obj.name}_Lattice",
            location=center,
            dimensions=(resolution, resolution, resolution),
            size=size * max(
                max_x - min_x,
                max_y - min_y,
                max_z - min_z
            )
        )
        
        return lattice
    
    def apply_lattice_to_object(self, lattice_name, target_name):
        """应用晶格到对象"""
        lattice = bpy.data.objects.get(lattice_name)
        target = bpy.data.objects.get(target_name)
        
        if not lattice or not target:
            return
        
        # 添加晶格修改器
        mod = target.modifiers.new(name="Lattice", type='LATTICE')
        mod.object = lattice
        
        return mod
    
    def create_deformation_lattice(self, target_obj, resolution=3, 
                                   influence=1.0, location_offset=(0, 0, 0)):
        """创建变形晶格"""
        lattice = self.create_adaptive_lattice(target_obj, resolution)
        lattice.location = (
            target_obj.location.x + location_offset[0],
            target_obj.location.y + location_offset[1],
            target_obj.location.z + location_offset[2]
        )
        
        # 应用晶格
        mod = self.apply_lattice_to_object(lattice.name, target_obj.name)
        mod.strength = influence
        
        return lattice, mod
    
    def set_lattice_resolution(self, lattice_name, u, v, w):
        """设置晶格分辨率"""
        lattice = bpy.data.objects.get(lattice_name)
        if lattice:
            lattice.data.points_u = u
            lattice.data.points_v = v
            lattice.data.points_w = w
    
    def get_lattice_info(self, lattice_name):
        """获取晶格信息"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return None
        
        return {
            'name': lattice.name,
            'resolution': (
                lattice.data.points_u,
                lattice.data.points_v,
                lattice.data.points_w
            ),
            'size': lattice.data.size,
            'point_count': (
                lattice.data.points_u * 
                lattice.data.points_v * 
                lattice.data.points_w
            )
        }
    
    def export_lattice_points(self, lattice_name):
        """导出晶格点"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return []
        
        points = []
        for point in lattice.data.points:
            points.append(point.co_deform.copy())
        
        return points
    
    def import_lattice_points(self, lattice_name, points):
        """导入晶格点"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return
        
        for i, point in enumerate(points):
            if i < len(lattice.data.points):
                lattice.data.points[i].co_deform = point


def setup_lattice_workflow():
    """设置晶格工作流程"""
    manager = LatticeManager()
    
    print("晶格管理器已设置")
    print("可用功能:")
    print("- create_lattice: 创建晶格")
    print("- apply_lattice_to_object: 应用晶格")
    print("- set_lattice_resolution: 设置分辨率")
    
    return manager
```

### 晶格动画系统

```python
import bpy
import math

class LatticeAnimationSystem:
    """晶格动画系统"""
    
    def __init__(self):
        self.animated_lattices = {}
    
    def create_squash_stretch_animation(self, lattice_name, target_name,
                                        start_frame=1, end_frame=30,
                                        squash_amount=0.5, stretch_amount=1.5):
        """创建挤压拉伸动画"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return None
        
        # 挤压
        bpy.context.scene.frame_set(start_frame)
        lattice.scale = (1, 1, 1)
        lattice.keyframe_insert(data_path='scale', frame=start_frame)
        
        bpy.context.scene.frame_set(start_frame + (end_frame - start_frame) // 3)
        lattice.scale = (stretch_amount, squash_amount, stretch_amount)
        lattice.keyframe_insert(data_path='scale', frame=start_frame + (end_frame - start_frame) // 3)
        
        # 拉伸
        bpy.context.scene.frame_set(start_frame + 2 * (end_frame - start_frame) // 3)
        lattice.scale = (squash_amount, stretch_amount, squash_amount)
        lattice.keyframe_insert(data_path='scale', frame=start_frame + 2 * (end_frame - start_frame) // 3)
        
        # 恢复
        bpy.context.scene.frame_set(end_frame)
        lattice.scale = (1, 1, 1)
        lattice.keyframe_insert(data_path='scale', frame=end_frame)
        
        return lattice
    
    def create_wave_deformation(self, lattice_name, start_frame=1,
                                amplitude=0.5, frequency=2.0):
        """创建波浪变形动画"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return None
        
        for frame in range(start_frame, start_frame + 60):
            bpy.context.scene.frame_set(frame)
            
            time = (frame - start_frame) / 30.0
            
            for i, point in enumerate(lattice.data.points):
                z = point.co_deform.z
                offset = i % lattice.data.points_u
                wave = amplitude * math.sin(2 * math.pi * frequency * time + offset)
                
                new_z = z + wave
                point.co_deform.z = new_z
            
            lattice.data.update()
            
            if frame == start_frame:
                point.co_deform.keyframe_insert(data_path='co_deform', index=2)
        
        return lattice
    
    def create_morph_targets(self, lattice_name, target_shapes, start_frame=1):
        """创建变形目标"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return {}
        
        shapes = {}
        
        for shape_name, shape_points in target_shapes.items():
            # 保存原始形状
            original_points = [(p.co_deform.copy(), p.co_latt) 
                             for p in lattice.data.points]
            
            # 应用新形状
            for i, point in enumerate(lattice.data.points):
                if i < len(shape_points):
                    point.co_deform = shape_points[i]
            
            # 插入关键帧
            bpy.context.scene.frame_set(start_frame)
            for point in lattice.data.points:
                point.co_deform.keyframe_insert(data_path='co_deform', index=-1)
            
            # 恢复原始形状
            for i, (orig_co, orig_cl) in enumerate(original_points):
                lattice.data.points[i].co_deform = orig_co
                lattice.data.points[i].co_latt = orig_cl
            
            shapes[shape_name] = lattice
        
        return shapes
    
    def create_puppet_deformation(self, target_name, control_bones,
                                  lattice_resolution=3):
        """创建木偶变形"""
        # 创建晶格
        target = bpy.data.objects.get(target_name)
        if not target:
            return None
        
        manager = LatticeManager()
        lattice = manager.create_adaptive_lattice(target, lattice_resolution)
        manager.apply_lattice_to_object(lattice.name, target_name)
        
        return lattice
    
    def keyframe_point_movement(self, lattice_name, point_index,
                                keyframes):
        """关键帧点移动"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice or point_index >= len(lattice.data.points):
            return
        
        point = lattice.data.points[point_index]
        
        for frame, position in keyframes.items():
            bpy.context.scene.frame_set(frame)
            point.co_deform = position
            point.co_deform.keyframe_insert(data_path='co_deform', index=-1)
    
    def create_point_constraint(self, lattice_name, point_index, target):
        """创建点约束"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice or point_index >= len(lattice.data.points):
            return None
        
        # 创建空对象作为控制器
        bpy.ops.object.empty_add(type='ARROWS', location=target.location)
        controller = bpy.context.active_object
        controller.name = f"{lattice.name}_Point{point_index}_Controller"
        
        return controller


def setup_lattice_animation():
    """设置晶格动画"""
    system = LatticeAnimationSystem()
    
    print("晶格动画系统已设置")
    print("可用功能:")
    print("- create_squash_stretch_animation: 挤压拉伸")
    print("- create_wave_deformation: 波浪变形")
    print("- create_morph_targets: 变形目标")
    
    return system
```

### 晶格变形工具

```python
import bpy
import math

class LatticeDeformationTool:
    """晶格变形工具"""
    
    def __init__(self):
        self.deformation_types = ['affine', 'bilinear', 'barycentric']
    
    def apply_bend_deformation(self, lattice_name, angle, axis='z',
                               center=(0, 0, 0)):
        """应用弯曲变形"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return
        
        angle_rad = math.radians(angle)
        
        for point in lattice.data.points:
            x, y, z = point.co_deform
            
            if axis == 'z':
                # Z轴弯曲
                radius = (z - center[2]) if z != center[2] else 1.0
                new_x = radius * math.sin(angle_rad * (x / radius)) + center[0]
                new_y = radius * (1 - math.cos(angle_rad * (x / radius))) + center[1]
                point.co_deform = (new_x, new_y, z)
            
            elif axis == 'y':
                # Y轴弯曲
                radius = (y - center[1]) if y != center[1] else 1.0
                new_x = radius * math.sin(angle_rad * (x / radius)) + center[0]
                new_z = radius * (1 - math.cos(angle_rad * (x / radius))) + center[2]
                point.co_deform = (new_x, y, new_z)
            
            elif axis == 'x':
                # X轴弯曲
                radius = (x - center[0]) if x != center[0] else 1.0
                new_y = radius * math.sin(angle_rad * (y / radius)) + center[1]
                new_z = radius * (1 - math.cos(angle_rad * (y / radius))) + center[2]
                point.co_deform = (x, new_y, new_z)
        
        lattice.data.update()
    
    def apply_twist_deformation(self, lattice_name, angle, axis='z'):
        """应用扭曲变形"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return
        
        angle_rad = math.radians(angle)
        
        for point in lattice.data.points:
            x, y, z = point.co_deform
            
            if axis == 'z':
                factor = z
            elif axis == 'y':
                factor = y
            else:
                factor = x
            
            rotation = angle_rad * factor
            
            new_x = x * math.cos(rotation) - y * math.sin(rotation)
            new_y = x * math.sin(rotation) + y * math.cos(rotation)
            
            point.co_deform = (new_x, new_y, z)
        
        lattice.data.update()
    
    def apply_taper_deformation(self, lattice_name, amount, axis='z',
                                factor=1.0):
        """应用锥化变形"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return
        
        for point in lattice.data.points:
            x, y, z = point.co_deform
            
            if axis == 'z':
                factor_z = z * amount
                point.co_deform = (x * (1 + factor_z * factor),
                                 y * (1 + factor_z * factor), z)
            elif axis == 'y':
                factor_y = y * amount
                point.co_deform = (x * (1 + factor_y * factor), y,
                                 z * (1 + factor_y * factor))
            else:
                factor_x = x * amount
                point.co_deform = (x, y * (1 + factor_x * factor),
                                 z * (1 + factor_x * factor))
        
        lattice.data.update()
    
    def apply_shear_deformation(self, lattice_name, amount, axis='z',
                                direction='x'):
        """应用剪切变形"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return
        
        for point in lattice.data.points:
            x, y, z = point.co_deform
            
            if axis == 'z':
                if direction == 'x':
                    point.co_deform = (x + amount * z, y, z)
                else:
                    point.co_deform = (x, y + amount * z, z)
            elif axis == 'y':
                if direction == 'x':
                    point.co_deform = (x + amount * y, y, z)
                else:
                    point.co_deform = (x, y, z + amount * y)
            else:
                if direction == 'y':
                    point.co_deform = (x, y + amount * x, z)
                else:
                    point.co_deform = (x, y, z + amount * x)
        
        lattice.data.update()
    
    def apply_jitter_deformation(self, lattice_name, amount=0.1):
        """应用抖动变形"""
        import random
        
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return
        
        for point in lattice.data.points:
            point.co_deform = (
                point.co_deform[0] + random.uniform(-amount, amount),
                point.co_deform[1] + random.uniform(-amount, amount),
                point.co_deform[2] + random.uniform(-amount, amount)
            )
        
        lattice.data.update()
    
    def apply_noise_deformation(self, lattice_name, scale=1.0, amplitude=0.1):
        """应用噪声变形"""
        import random
        
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return
        
        for i, point in enumerate(lattice.data.points):
            noise = random.random() * 2 - 1
            point.co_deform = (
                point.co_deform[0] + noise * amplitude,
                point.co_deform[1] + noise * amplitude,
                point.co_deform[2] + noise * amplitude
            )
        
        lattice.data.update()
    
    def create_symmetrical_lattice(self, lattice_name, axis='x'):
        """创建对称晶格"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return
        
        # 获取点数据
        points = [(p.co_deform.copy(), p.co_latt) for p in lattice.data.points]
        
        # 镜像点
        for i, (orig_co, orig_cl) in enumerate(points):
            if axis == 'x':
                mirrored = (-orig_co[0], orig_co[1], orig_co[2])
            elif axis == 'y':
                mirrored = (orig_co[0], -orig_co[1], orig_co[2])
            else:
                mirrored = (orig_co[0], orig_co[1], -orig_co[2])
            
            # 找到对称点并应用
            if i + len(points) // 2 < len(lattice.data.points):
                lattice.data.points[i + len(points) // 2].co_deform = mirrored
        
        lattice.data.update()
    
    def reset_lattice_shape(self, lattice_name):
        """重置晶格形状"""
        lattice = bpy.data.objects.get(lattice_name)
        if not lattice:
            return
        
        for point in lattice.data.points:
            point.co_deform = point.co_latt.copy()
        
        lattice.data.update()


def setup_deformation_tool():
    """设置变形工具"""
    tool = LatticeDeformationTool()
    
    print("晶格变形工具已设置")
    print("可用变形:")
    print("- bend: 弯曲")
    print("- twist: 扭曲")
    print("- taper: 锥化")
    print("- shear: 剪切")
    print("- jitter: 抖动")
    print("- noise: 噪声")
    
    return tool
```
