# bpy.ops.fluid 模块

流体模拟操作模块，用于配置和管理流体物理模拟。

## 概述

bpy.ops.fluid 模块包含用于配置流体物理模拟的运算符。流体模拟可以创建液体、烟雾、火焰等效果，支持复杂的流体动力学计算。

## 常用操作

### 域操作

```python
import bpy

# 添加流体域
bpy.ops.object.fluid_add(type='DOMAIN')

# 添加流体对象
bpy.ops.object.fluid_add(type='FLOW')

# 添加流体障碍物
bpy.ops.object.fluid_add(type='EFFECTOR')

# 设置域类型为液体
bpy.ops.fluid.fluid_set(type='LIQUID')

# 设置域类型为气体
bpy.ops.fluid.fluid_set(type='GAS')

# 设置分辨率
bpy.ops.fluid.resolution_set(resolution=64)
```

### 流动源设置

```python
# 设置为流入
bpy.ops.fluid.flow_set(type='INFLOW')

# 设置为流出
bpy.ops.fluid.flow_set(type='OUTFLOW')

# 设置为几何体流
bpy.ops.fluid.flow_set(type='GEOMETRY')

# 设置为体积流
bpy.ops.fluid.flow_source_set(type='VOLUME')

# 设置为表面流
bpy.ops.fluid.flow_source_set(type='MESH')
```

### 障碍物设置

```python
# 设置为碰撞
bpy.ops.fluid.effector_set(type='COLLISION')

# 设置为引导
bpy.ops.fluid.effector_set(type='GUIDE')

# 设置为吸收
bpy.ops.fluid.effector_set(type='ABSORPTION')

# 设置为流动引导
bpy.ops.fluid.effector_set(type='FLUID_GUIDE')
```

### 属性设置

```python
# 设置初始温度
bpy.ops.fluid.initial_temperature_set(temperature=25.0)

# 设置密度
bpy.ops.fluid.density_set(density=1.0)

# 设置粘度
bpy.ops.fluid.viscosity_set(value=1.0)

# 设置表面张力
bpy.ops.fluid.surface_tension_set(value=0.0)

# 设置颜色
bpy.ops.fluid.color_set(color=(1.0, 0.0, 0.0, 1.0))
```

### 缓存操作

```python
# 创建缓存
bpy.ops.fluid.cache_create()

# 删除缓存
bpy.ops.fluid.cache_delete()

# 清除缓存
bpy.ops.fluid.cache_clear()

# 重置缓存
bpy.ops.fluid.cache_reset()
```

### 模拟控制

```python
# 开始模拟
bpy.ops.fluid.simulate()

# 停止模拟
bpy.ops.fluid.stop_simulation()

# 重置模拟
bpy.ops.fluid.reset_simulation()

# 清除模拟
bpy.ops.fluid.clear_simulation()
```

## 实际应用示例

### 创建液体模拟

```python
def create_liquid_simulation(domain_obj, flow_obj):
    """创建液体模拟"""
    # 设置域
    domain_obj.select_set(True)
    bpy.context.view_layer.objects.active = domain_obj
    
    # 添加流体修改器
    fluid_mod = domain_obj.modifiers.new(name='Fluid', type='FLUID')
    fluid_mod.fluid_type = 'DOMAIN'
    
    # 设置为液体
    fluid_mod.domain_settings.fluid_type = 'LIQUID'
    
    # 设置分辨率
    fluid_mod.domain_settings.resolution = 64
    
    # 设置缓存路径
    fluid_mod.domain_settings.cache_directory = '//fluid_cache/'
    
    # 设置流动源
    flow_obj.select_set(True)
    bpy.context.view_layer.objects.active = flow_obj
    
    flow_mod = flow_obj.modifiers.new(name='Flow', type='FLUID')
    flow_mod.fluid_type = 'FLOW'
    flow_mod.flow_settings.flow_type = 'LIQUID'
    flow_mod.flow_settings.flow_behavior = 'INFLOW'
    
    return fluid_mod
```

### 创建烟雾模拟

```python
def create_smoke_simulation(domain_obj, emitter_obj):
    """创建烟雾模拟"""
    # 设置域
    domain_obj.select_set(True)
    bpy.context.view_layer.objects.active = domain_obj
    
    # 添加流体修改器
    fluid_mod = domain_obj.modifiers.new(name='Smoke', type='FLUID')
    fluid_mod.fluid_type = 'DOMAIN'
    
    # 设置为气体
    fluid_mod.domain_settings.fluid_type = 'GAS'
    
    # 设置高分辨率
    fluid_mod.domain_settings.resolution = 128
    
    # 创建缓存
    bpy.ops.fluid.cache_create()
    
    # 设置发射器
    emitter_obj.select_set(True)
    bpy.context.view_layer.objects.active = emitter_obj
    
    flow_mod = emitter_obj.modifiers.new(name='SmokeEmitter', type='FLUID')
    flow_mod.fluid_type = 'FLOW'
    flow_mod.flow_settings.flow_type = 'SMOKE'
    flow_mod.flow_settings.flow_behavior = 'OUTFLOW'
    
    # 设置烟雾密度
    flow_mod.flow_settings.density = 1.0
    
    return fluid_mod
```

### 创建火焰模拟

```python
def create_fire_simulation(domain_obj, burner_obj):
    """创建火焰模拟"""
    # 设置域
    domain_obj.select_set(True)
    bpy.context.view_layer.objects.active = domain_obj
    
    # 添加流体修改器
    fluid_mod = domain_obj.modifiers.new(name='Fire', type='FLUID')
    fluid_mod.fluid_type = 'DOMAIN'
    
    # 设置为气体
    fluid_mod.domain_settings.fluid_type = 'GAS'
    
    # 设置火焰温度
    fluid_mod.domain_settings.flame_buoyancy = 1.0
    
    # 设置燃烧时间
    fluid_mod.domain_settings.burn_time = 2.0
    
    # 设置发射器
    burner_obj.select_set(True)
    bpy.context.view_layer.objects.active = burner_obj
    
    flow_mod = burner_obj.modifiers.new(name='FireSource', type='FLUID')
    flow_mod.fluid_type = 'FLOW'
    flow_mod.flow_settings.flow_type = 'FIRE'
    flow_mod.flow_settings.flow_behavior = 'OUTFLOW'
    
    return fluid_mod
```

### 创建水流碰撞

```python
def create_water_collision(domain_obj, obstacle_obj):
    """创建水流碰撞效果"""
    # 设置障碍物
    obstacle_obj.select_set(True)
    bpy.context.view_layer.objects.active = obstacle_obj
    
    # 添加流体修改器
    fluid_mod = obstacle_obj.modifiers.new(name='Collision', type='FLUID')
    fluid_mod.fluid_type = 'EFFECTOR'
    
    # 设置为碰撞
    fluid_mod.effector_settings.effector_type = 'COLLISION'
    
    # 设置碰撞强度
    fluid_mod.effector_settings.correction = 0.0
    
    # 设置阻力
    fluid_mod.effector_settings.damping = 0.5
    
    return fluid_mod
```

### 创建引导流

```python
def create_guide_flow(domain_obj, guide_obj):
    """创建引导流效果"""
    # 设置引导物体
    guide_obj.select_set(True)
    bpy.context.view_layer.objects.active = guide_obj
    
    # 添加流体修改器
    fluid_mod = guide_obj.modifiers.new(name='Guide', type='FLUID')
    fluid_mod.fluid_type = 'EFFECTOR'
    
    # 设置为引导
    fluid_mod.effector_settings.effector_type = 'GUIDE'
    
    # 设置引导力量
    fluid_mod.effector_settings.guide_velocity = (0, 0, 1)
    fluid_mod.effector_settings.guide_free = 0.5
    
    return fluid_mod
```

### 创建多重流

```python
def create_multi_flow(domain_obj, sources):
    """创建多重流动效果"""
    # 设置域
    domain_obj.select_set(True)
    bpy.context.view_layer.objects.active = domain_obj
    
    # 添加流体修改器
    fluid_mod = domain_obj.modifiers.new(name='MultiFluid', type='FLUID')
    fluid_mod.fluid_type = 'DOMAIN'
    fluid_mod.domain_settings.fluid_type = 'LIQUID'
    fluid_mod.domain_settings.resolution = 64
    
    # 设置多个流动源
    for i, source_obj in enumerate(sources):
        source_obj.select_set(True)
        bpy.context.view_layer.objects.active = source_obj
        
        flow_mod = source_obj.modifiers.new(name=f'Flow_{i}', type='FLUID')
        flow_mod.fluid_type = 'FLOW'
        flow_mod.flow_settings.flow_type = 'LIQUID'
        flow_mod.flow_settings.flow_behavior = 'INFLOW'
        
        # 设置不同颜色
        if i == 0:
            flow_mod.flow_settings.color = (1.0, 0.0, 0.0, 1.0)
        else:
            flow_mod.flow_settings.color = (0.0, 0.0, 1.0, 1.0)
    
    return fluid_mod
```

## 使用场景

- **液体模拟**：水、牛奶、油等液体效果
- **烟雾效果**：云、烟、蒸汽等气体效果
- **火焰特效**：火焰、爆炸等燃烧效果
- **流体碰撞**：水流与障碍物的交互
- **引导流**：控制流体运动方向
- **多重流体**：多种不相容的流体

## 注意事项

- 流体模拟需要较高的计算资源
- 分辨率影响模拟精度和性能
- 缓存管理对于大模拟很重要
- 粘度设置影响液体行为
- 温度影响气体行为
- 碰撞设置需要仔细调整
- 引导流可以控制流体运动
- 火焰模拟需要额外的渲染设置
