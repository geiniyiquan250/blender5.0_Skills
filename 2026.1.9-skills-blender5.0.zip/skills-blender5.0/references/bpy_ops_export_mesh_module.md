# bpy.ops.export_mesh - 网格导出操作模块

Blender网格导出操作符，用于将网格数据导出为各种3D文件格式。

## 概述

`bpy.ops.export_mesh` 模块提供用于将Blender中的网格数据导出为外部文件格式的功能，包括OBJ、STL、PLY等。

## 核心功能

### OBJ导出

```python
import bpy

# 导出为OBJ
bpy.ops.export_mesh.obj(
    filepath='//model.obj',
    export_selected=True,
    export_uv=True,
    export_normals=True,
    export_materials=True,
    export_triangulated=False,
    export_apply_modifiers=True,
    export_group_by_material=False,
    export_group_by_object=False,
    export_nurbs=False,
    export_curves_as_nurbs=False,
    export_alpha_mode='STRAIGHT',
    export_image_format='NONE',
    export_axis_forward='-Z',
    export_axis_up='Y',
    export_metalness=False,
    export_roughness=False
)

# 导出选中网格
bpy.ops.export_mesh.obj(
    filepath='//selected.obj',
    export_selected=True
)

# 导出所有网格
bpy.ops.export_mesh.obj(
    filepath='//all.obj',
    export_selected=False
)

# 导出带UV的网格
bpy.ops.export_mesh.obj(
    filepath='//with_uv.obj',
    export_uv=True
)

# 导出带法线的网格
bpy.ops.export_mesh.obj(
    filepath='//with_normals.obj',
    export_normals=True
)

# 导出带材质的网格
bpy.ops.export_mesh.obj(
    filepath='//with_materials.obj',
    export_materials=True
)

# 应用修改器后导出
bpy.ops.export_mesh.obj(
    filepath='//applied.obj',
    export_apply_modifiers=True
)

# 三角化导出
bpy.ops.export_mesh.obj(
    filepath='//triangulated.obj',
    export_triangulated=True
)
```

### STL导出

```python
# 导出为STL
bpy.ops.export_mesh.stl(
    filepath='//model.stl',
    export_selected=True,
    export_apply_modifiers=True,
    export_backface_culling=False,
    export_uv=False,
    export_normals=True,
    export_colors=False,
    export_triangulated_mesh=False
)

# 导出选中对象为STL
bpy.ops.export_mesh.stl(
    filepath='//selected.stl',
    export_selected=True
)

# 应用所有修改器
bpy.ops.export_mesh.stl(
    filepath='//applied.stl',
    export_apply_modifiers=True
)

# 三角化网格
bpy.ops.export_mesh.stl(
    filepath='//triangulated.stl',
    export_triangulated_mesh=True
)

# 导出为二进制STL
bpy.ops.export_mesh.stl(
    filepath='//binary.stl',
    export_ascii=False
)

# 导出为ASCII STL
bpy.ops.export_mesh.stl(
    filepath='//ascii.stl',
    export_ascii=True
)
```

### PLY导出

```python
# 导出为PLY
bpy.ops.export_mesh.ply(
    filepath='//model.ply',
    export_selected=True,
    export_uv=True,
    export_normals=True,
    export_colors=True,
    export_triangulated=False,
    export_apply_modifiers=True,
    export_colors_type='SRGB'
)

# 导出带颜色的PLY
bpy.ops.export_mesh.ply(
    filepath='//colored.ply',
    export_colors=True
)

# 导出带UV的PLY
bpy.ops.export_mesh.ply(
    filepath='//with_uv.ply',
    export_uv=True
)

# 导出顶点颜色
bpy.ops.export_mesh.ply(
    filepath='//vertex_colors.ply',
    export_colors=True,
    export_colors_type='LINEAR'
)
```

### 通用网格导出选项

```python
# 设置导出比例
bpy.ops.export_mesh.obj(
    filepath='//scaled.obj',
    export_scale=1.0
)

# 设置轴向
bpy.ops.export_mesh.obj(
    filepath='//y_up.obj',
    export_axis_forward='-Z',
    export_axis_up='Y'
)

# 选择导出格式
bpy.ops.export_mesh.stl(
    filepath='//model.stl',
    export_ascii=False
)

bpy.ops.export_mesh.ply(
    filepath='//model.ply',
    export_format='ASCII'
)

bpy.ops.export_mesh.ply(
    filepath='//model_binary.ply',
    export_format='BINARY'
)
```

### 批量导出

```python
# 批量导出为STL
def batch_export_stl(objects, output_dir):
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for obj in objects:
        if obj.type == 'MESH':
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            filepath = os.path.join(output_dir, f'{obj.name}.stl')
            bpy.ops.export_mesh.stl(filepath=filepath, export_selected=True)

# 导出所有变体
def export_all_variants(base_name):
    obj = bpy.context.active_object
    
    # 原始
    bpy.ops.export_mesh.obj(filepath=f'{base_name}_original.obj')
    
    # 三角化
    for modifier in obj.modifiers:
        if modifier.type == 'TRIANGULATE':
            modifier.show_viewport = True
    bpy.ops.export_mesh.obj(filepath=f'{base_name}_triangulated.obj', export_triangulated=True)

# 按材质导出
def export_by_material(output_dir):
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    objects_by_material = {}
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH' and obj.data.materials:
            mat = obj.data.materials[0]
            if mat.name not in objects_by_material:
                objects_by_material[mat.name] = []
            objects_by_material[mat.name].append(obj)
    
    for mat_name, objects in objects_by_material.items():
        for obj in objects:
            obj.select_set(True)
        bpy.ops.export_mesh.obj(
            filepath=os.path.join(output_dir, f'{mat_name}.obj'),
            export_group_by_material=True
        )
        for obj in objects:
            obj.select_set(False)
```

## 实用函数

```python
def export_selected_as_obj(filepath, apply_modifiers=True):
    """导出选中的网格为OBJ"""
    bpy.ops.export_mesh.obj(
        filepath=filepath,
        export_selected=True,
        export_apply_modifiers=apply_modifiers,
        export_uv=True,
        export_normals=True,
        export_materials=True
    )

def export_selected_as_stl(filepath, apply_modifiers=True):
    """导出选中的网格为STL"""
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        export_selected=True,
        export_apply_modifiers=apply_modifiers
    )

def export_selected_as_ply(filepath, apply_modifiers=True):
    """导出选中的网格为PLY"""
    bpy.ops.export_mesh.ply(
        filepath=filepath,
        export_selected=True,
        export_apply_modifiers=apply_modifiers,
        export_uv=True,
        export_normals=True,
        export_colors=True
    )

def export_mesh_with_options(filepath, format='obj', **options):
    """使用自定义选项导出网格"""
    if format == 'obj':
        bpy.ops.export_mesh.obj(filepath=filepath, **options)
    elif format == 'stl':
        bpy.ops.export_mesh.stl(filepath=filepath, **options)
    elif format == 'ply':
        bpy.ops.export_mesh.ply(filepath=filepath, **options)
    else:
        raise ValueError(f'不支持的格式: {format}')

def export_all_meshes(filepath, format='obj'):
    """导出所有网格"""
    bpy.ops.object.select_all(action='DESELECT')
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            obj.select_set(True)
    bpy.ops.export_mesh.obj(filepath=filepath, export_selected=False)

def export_mesh_stripped(filepath):
    """导出剥离所有数据的网格"""
    bpy.ops.export_mesh.obj(
        filepath=filepath,
        export_selected=True,
        export_apply_modifiers=True,
        export_uv=False,
        export_normals=False,
        export_materials=False
    )

def export_mesh_for_print(filepath):
    """导出为3D打印格式"""
    obj = bpy.context.active_object
    
    # 确保应用所有修改器
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    # 三角化
    if 'Triangulate' not in obj.modifiers:
        bpy.ops.object.modifier_add(type='TRIANGULATE')
    
    for modifier in obj.modifiers:
        modifier.show_viewport = True
        modifier.show_render = True
    
    # 导出
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        export_selected=True,
        export_apply_modifiers=True,
        export_triangulated_mesh=True
    )
```

## 常见问题排查

### 导出为空文件
```python
# 检查选中的网格
meshes = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
print(f"选中网格数: {len(meshes)}")

# 检查所有网格
all_meshes = [obj for obj in bpy.data.objects if obj.type == 'MESH']
print(f"总网格数: {len(all_meshes)}")

# 检查网格数据
for mesh in all_meshes:
    print(f"顶点数: {len(mesh.data.vertices)}")
    print(f"面数: {len(mesh.data.polygons)}")

# 确保网格未被隐藏
for mesh in all_meshes:
    mesh.hide_viewport = False
    mesh.hide_render = False
```

### 法线问题
```python
# 检查法线
mesh = bpy.context.active_object.data
print(f"面法线: {mesh.has_custom_normals}")

# 重新计算法线
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.mesh.normals_make_consistent(inside=False)
bpy.ops.object.mode_set(mode='OBJECT')

# 导出时包含法线
bpy.ops.export_mesh.obj(
    filepath='//with_normals.obj',
    export_normals=True
)

# 切线空间
print(f"切线: {mesh.uv_layers.active.tangent_dimension if mesh.uv_layers.active else 'N/A'}")
```

### 材质丢失
```python
# 检查材质
obj = bpy.context.active_object
if obj.data.materials:
    print(f"材质数: {len(obj.data.materials)}")
    for mat in obj.data.materials:
        print(f"材质: {mat.name}")
else:
    print("没有材质")

# 导出时包含材质
bpy.ops.export_mesh.obj(
    filepath='//with_materials.obj',
    export_materials=True
)

# 检查材质路径
for mat in obj.data.materials:
    if mat.use_nodes:
        print("使用节点")
    else:
        print(f"基础颜色: {mat.diffuse_color}")
```

### 修改器未应用
```python
# 检查修改器
obj = bpy.context.active_object
print(f"修改器数: {len(obj.modifiers)}")

for modifier in obj.modifiers:
    print(f"修改器: {modifier.type}, 显示: {modifier.show_viewport}, 渲染: {modifier.show_render}")

# 应用所有修改器
bpy.ops.object.select_all(action='DESELECT')
obj.select_set(True)
bpy.context.view_layer.objects.active = obj
bpy.ops.object.convert(target='MESH')
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

# 导出时应用修改器
bpy.ops.export_mesh.obj(
    filepath='//applied.obj',
    export_apply_modifiers=True
)
```
