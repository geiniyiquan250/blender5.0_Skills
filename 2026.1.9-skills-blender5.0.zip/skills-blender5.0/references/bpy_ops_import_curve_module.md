# bpy.ops.import_curve - 曲线导入操作模块

Blender曲线导入操作符，用于从各种文件格式导入曲线数据。

## 概述

`bpy.ops.import_curve` 模块提供用于从外部文件格式导入曲线数据的功能。支持SVG、DXF、AI等常见的曲线文件格式。

## 核心功能

### SVG导入

```python
import bpy

# 导入SVG文件
bpy.ops.import_curve.svg(
    filepath='//design.svg',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    filter_btx=False,
    filter_collada=False,
    filter_alembic=False,
    directory='',
    files=[{'name': 'design.svg', 'name': 'design.svg'}],
    ui_tab='MAIN',
    use_sequence=False,
    use_svg_version='',
    scale=1.0,
    stroke_to_curve=True,
    fill=True,
    pre_simplify=True,
    pre_simplify_distance=0.1,
    apply_transforms=True,
    center=True,
    use_colors=True
)

# 导入SVG并创建曲线
bpy.ops.import_curve.svg(
    filepath='//vector_art.svg',
    stroke_to_curve=True,
    fill=True
)

# 导入SVG作为路径
bpy.ops.import_curve.svg(
    filepath='//path.svg',
    stroke_to_curve=True,
    fill=False
)
```

### DXF导入

```python
# 导入DXF文件
bpy.ops.import_curve.dxf(
    filepath='//drawing.dxf',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    filter_btx=False,
    filter_collada=False,
    filter_alembic=False,
    directory='',
    files=[{'name': 'drawing.dxf', 'name': 'drawing.dxf'}],
    ui_tab='MAIN',
    scale=1.0,
    apply_transforms=True,
    center=True,
    layers='ALL',
    colors=True,
    line_thickness=True,
    use_matcaps=False,
    use_plain_lines=True,
    use_default_illumination=True,
    backslash_as_forward=False
)

# 导入DXF中的所有层
bpy.ops.import_curve.dxf(
    filepath='//cad_drawing.dxf',
    layers='ALL'
)

# 只导入指定层
bpy.ops.import_curve.dxf(
    filepath='//cad_drawing.dxf',
    layers=['Layer1', 'Layer2']
)
```

### Adobe Illustrator导入

```python
# 导入AI文件
bpy.ops.import_curve.ai(
    filepath='//illustration.ai',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    filter_btx=False,
    filter_collada=False,
    filter_alembic=False,
    directory='',
    files=[{'name': 'illustration.ai', 'name': 'illustration.ai'}],
    ui_tab='MAIN',
    scale=1.0,
    apply_transforms=True,
    center=True,
    resolution=12,
    use_stroke=True,
    use_fill=True
)

# 高精度导入AI
bpy.ops.import_curve.ai(
    filepath='//logo.ai',
    resolution=24
)

# 只导入路径
bpy.ops.import_curve.ai(
    filepath='//logo.ai',
    use_stroke=True,
    use_fill=False
)
```

### 通用曲线导入选项

```python
# 设置导入比例
bpy.ops.import_curve.svg(
    filepath='//design.svg',
    scale=0.01
)

# 应用变换
bpy.ops.import_curve.svg(
    filepath='//design.svg',
    apply_transforms=True
)

# 居中曲线
bpy.ops.import_curve.svg(
    filepath='//design.svg',
    center=True
)

# 导入后简化
bpy.ops.import_curve.svg(
    filepath='//design.svg',
    pre_simplify=True,
    pre_simplify_distance=0.01
)
```

### 导入后处理

```python
# 导入后选择导入的曲线
bpy.ops.import_curve.svg(filepath='//design.svg')
bpy.ops.object.select_all(action='DESELECT')
for obj in bpy.context.selected_objects:
    if obj.type == 'CURVE':
        obj.select_set(True)
bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]

# 合并导入的曲线
bpy.ops.import_curve.svg(filepath='//design.svg')
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.join()

# 分离导入的曲线
bpy.ops.import_curve.svg(filepath='//design.svg')
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.join()
bpy.ops.curve.separate()
```

## 实用函数

```python
def import_svg_file(filepath, scale=1.0, merge=True):
    """导入SVG文件并返回曲线对象"""
    bpy.ops.import_curve.svg(
        filepath=filepath,
        scale=scale,
        stroke_to_curve=True,
        fill=True
    )
    curves = [obj for obj in bpy.context.selected_objects if obj.type == 'CURVE']
    if merge and len(curves) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in curves:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = curves[0]
        bpy.ops.object.join()
        return [bpy.context.active_object]
    return curves

def import_dxf_file(filepath, layers=None, scale=1.0):
    """导入DXF文件"""
    kwargs = {
        'filepath': filepath,
        'scale': scale,
        'layers': 'ALL' if layers is None else layers
    }
    bpy.ops.import_curve.dxf(**kwargs)
    return list(bpy.context.selected_objects)

def batch_import_svg_files(filepaths, scale=1.0):
    """批量导入SVG文件"""
    curves = []
    for filepath in filepaths:
        result = import_svg_file(filepath, scale)
        curves.extend(result)
    return curves

def import_and_center_svg(filepath, scale=1.0):
    """导入SVG并居中"""
    bpy.ops.import_curve.svg(
        filepath=filepath,
        scale=scale,
        center=True
    )
    # 设置原点到几何中心
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
    return bpy.context.selected_objects

def import_svg_with_options(filepath, stroke=True, fill=True, simplify=True):
    """使用自定义选项导入SVG"""
    bpy.ops.import_curve.svg(
        filepath=filepath,
        stroke_to_curve=stroke,
        fill=fill,
        pre_simplify=simplify,
        pre_simplify_distance=0.1
    )
    return bpy.context.selected_objects

def convert_imported_to_bezier():
    """将导入的曲线转换为贝塞尔曲线"""
    for obj in bpy.context.selected_objects:
        if obj.type == 'CURVE':
            for spline in obj.data.splines:
                spline.type = 'BEZIER'
```

## 常见问题排查

### 导入后曲线不可见
```python
# 检查曲线是否选中
print(f"选中对象数: {len(bpy.context.selected_objects)}")

# 检查曲线类型
for obj in bpy.context.selected_objects:
    if obj.type == 'CURVE':
        print(f"曲线类型: {obj.data.splines[0].type if obj.data.splines else 'N/A'}")

# 检查渲染属性
obj = bpy.context.active_object
print(f"显示类型: {obj.display_type}")
print(f"渲染: {obj.hide_render}")

# 切换显示
for obj in bpy.context.selected_objects:
    obj.hide_viewport = False
    obj.hide_render = False
```

### 导入的曲线精度问题
```python
# 增加导入分辨率
bpy.ops.import_curve.svg(
    filepath='//design.svg',
    scale=1.0
)

# 减少简化距离
bpy.ops.import_curve.svg(
    filepath='//design.svg',
    pre_simplify=True,
    pre_simplify_distance=0.01
)

# 不简化
bpy.ops.import_curve.svg(
    filepath='//design.svg',
    pre_simplify=False
)

# 检查曲线点数
obj = bpy.context.active_object
if obj.type == 'CURVE':
    for spline in obj.data.splines:
        print(f"点数: {len(spline.bezier_points) if spline.type == 'BEZIER' else len(spline.points)}")
```

### 颜色丢失
```python
# 确保导入颜色
bpy.ops.import_curve.svg(
    filepath='//colored_design.svg',
    use_colors=True
)

# 检查材质
obj = bpy.context.active_object
if obj.data.materials:
    print(f"材质数: {len(obj.data.materials)}")
else:
    print("没有材质")

# 手动添加材质
mat = bpy.data.materials.new(name='ImportedColor')
mat.use_nodes = True
bsdf = mat.node_tree.nodes['Principled BSDF']
bsdf.inputs['Base Color'].default_value = (1, 0, 0, 1)
bpy.context.active_object.data.materials.append(mat)
```
