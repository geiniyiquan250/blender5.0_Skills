# bpy.ops.view2d - 2D视图操作模块

bpy.ops.view2d模块提供了2D视图（如Timeline、Graph Editor等）中的导航和操作功能。

## 概述

2D视图是Blender中用于查看时间轴、动画曲线等2D数据的编辑器。这个模块提供了视图导航、缩放和平移操作。

## 核心功能

### 视图导航

```python
import bpy

def view_all():
    """查看全部"""
    bpy.ops.view2d.view_all()

def view_selected():
    """查看选中"""
    bpy.ops.view2d.view_selected()

def view_center():
    """视图居中"""
    bpy.ops.view2d.center()

def view_center_cursor():
    """视图居中到光标"""
    bpy.ops.view2d.center_cursor()
```

### 缩放操作

```python
def zoom_in():
    """放大"""
    bpy.ops.view2d.zoom_in()

def zoom_out():
    """缩小"""
    bpy.ops.view2d.zoom_out()

def zoom_in_10():
    """放大10%"""
    bpy.ops.view2d.zoom_in(factor=1.1)

def zoom_out_10():
    """缩小10%"""
    bpy.ops.view2d.zoom_out(factor=0.9)

def zoom_border(xmin, ymin, xmax, ymax):
    """缩放到边框"""
    bpy.ops.view2d.zoom_border(
        xmin=xmin,
        ymin=ymin,
        xmax=xmax,
        ymax=ymax
    )
```

### 平移操作

```python
def pan_left():
    """左移"""
    bpy.ops.view2d.pan(direction='LEFT')

def pan_right():
    """右移"""
    bpy.ops.view2d.pan(direction='RIGHT')

def pan_up():
    """上移"""
    bpy.ops.view2d.pan(direction='UP')

def pan_down():
    """下移"""
    bpy.ops.view2d.pan(direction='DOWN')
```

## 实用函数

### 滚动操作

```python
def scroll_up():
    """向上滚动"""
    bpy.ops.view2d.scroll_up()

def scroll_down():
    """向下滚动"""
    bpy.ops.view2d.scroll_down()

def scroll_left():
    """向左滚动"""
    bpy.ops.view2d.scroll_left()

def scroll_right():
    """向右滚动"""
    bpy.ops.view2d.scroll_right()

def scroll_page_up():
    """向上翻页"""
    bpy.ops.view2d.scroll_page(
        up=True,
        page=True
    )

def scroll_page_down():
    """向下翻页"""
    bpy.ops.view2d.scroll_page(
        up=False,
        page=True
    )
```

### 区域操作

```python
def scroller_drag():
    """拖动滚动条"""
    bpy.ops.view2d.scroller_drag()

def scroll_match():
    """滚动匹配"""
    bpy.ops.view2d.scroll_match()
```

## 常见问题排查

### 视图问题

视图无响应：
- 确认编辑器激活
- 检查鼠标位置
- 验证视图类型

### 缩放问题

缩放失效：
- 检查缩放限制
- 确认视口焦点
- 验证数据范围
