# bpy.ops.paint.weight - 权重绘画操作模块

bpy.ops.paint.weight模块提供了权重绘画（weight painting）模式下的操作功能，用于编辑顶点组的权重值。

## 概述

权重绘画是Blender中为顶点分配权重值的重要工具，用于骨骼绑定和变形。这个模块提供了在权重绘画模式下的选择、绘制和编辑操作。

## 核心功能

### 权重选择

```python
import bpy

def select_all_vertices():
    """选择所有顶点"""
    bpy.ops.paint.select_all(action='SELECT')

def deselect_all_vertices():
    """取消选择所有顶点"""
    bpy.ops.paint.select_all(action='DESELECT')

def invert_selection():
    """反选"""
    bpy.ops.paint.select_all(action='INVERT')

def select_by_weight(min_weight, threshold=0.01):
    """按权重选择"""
    bpy.ops.paint.weight_select(
        action='SELECT',
        min_weight=min_weight,
        threshold=threshold
    )
```

### 权重操作

```python
def assign_default_weight():
    """分配默认权重"""
    bpy.ops.object.vertex_group_assign_default()

def assign_weight(value=1.0):
    """分配权重"""
    bpy.ops.object.vertex_group_assign(
        weight=value
    )

def remove_weight():
    """移除权重"""
    bpy.ops.object.vertex_group_remove_from()

def normalize_weights():
    """归一化权重"""
    bpy.ops.object.vertex_group_normalize()

def invert_weights():
    """反转权重"""
    bpy.ops.object.vertex_group_invert()
```

### 绘制操作

```python
def set_weight(value):
    """设置权重"""
    bpy.ops.paint.weight_paint_toggle()
    bpy.context.tool_settings.weight_paint.brush.weight = value

def sample_weight():
    """采样权重"""
    bpy.ops.paint.weight_sample()

def sample_group():
    """采样组"""
    bpy.ops.paint.weight_sample_group()
```

## 实用函数

### 选择工具

```python
def grow_selection():
    """扩展选择"""
    bpy.ops.paint.select_border(extend=True)

def shrink_selection():
    """收缩选择"""
    bpy.ops.paint.select_less()

def select_linked():
    """选择连接"""
    bpy.ops.paint.select_linked()

def deselect_hierarchy():
    """取消选择层级"""
    bpy.ops.paint.select_hierarchy(
        action='DESELECT',
        direction='PARENT'
    )
```

### 权重工具

```python
def blend_weights(factor=0.5):
    """混合权重"""
    bpy.ops.object.vertex_group_blend(factor=factor)

def clean_weights(threshold=0.01):
    """清理权重"""
    bpy.ops.object.vertex_group_clean(
        limit=threshold
    )

def quantize_weights(steps=4):
    """量化权重"""
    bpy.ops.object.vertex_group_quantize(
        steps=steps
    )
```

## 常见问题排查

### 选择问题

选择不准确：
- 调整选择阈值
- 检查顶点组是否存在
- 确认权重模式正确

### 权重分配失败

组问题：
- 确认选择了正确的顶点组
- 检查对象是否有顶点组
- 验证权重值范围有效
