# freestyle.functions - 线条函数模块

freestyle.functions模块提供了Freestyle线条渲染中的函数工具，用于定义线条样式和效果。

## 概述

线条函数模块是Freestyle样式系统的核心组件，提供了各种函数来定义线条的行为和外观。这些函数可以组合使用来创建复杂的线条效果。

## 核心功能

### 曲线函数

```python
import math
from freestyle.functions import (
    curveLength,
    curveU,
    curveTi,
    curveTsi,
    curveNi,
    getParameter,
    getNormalizedParameter
)

def calculate_curve_length(stroke):
    """计算曲线长度"""
    return curveLength(stroke)

def get_u_at_point(stroke, point):
    """获取点的U参数"""
    return curveU(stroke, point)

def get_tangent_at_index(stroke, index):
    """获取指定索引处的切线"""
    return curveTi(stroke, index)

def get_smooth_tangent(stroke, index):
    """获取平滑切线"""
    return curveTsi(stroke, index)

def get_curvature(stroke, index):
    """获取曲率"""
    return curveNi(stroke, index)
```

### 参数函数

```python
def get_absolute_parameter(stroke, normalized_value):
    """获取绝对参数"""
    return getParameter(stroke, normalized_value)

def get_normalized_parameter(stroke, absolute_value):
    """获取归一化参数"""
    return getNormalizedParameter(stroke, absolute_value)

def map_range(value, in_min, in_max, out_min, out_max):
    """映射范围"""
    if in_max - in_min == 0:
        return out_min
    normalized = (value - in_min) / (in_max - in_min)
    return out_min + normalized * (out_max - out_min)
```

### 距离函数

```python
def get_distance_2d(point1, point2):
    """计算2D距离"""
    dx = point1.x - point2.x
    dy = point1.y - point2.y
    return math.sqrt(dx * dx + dy * dy)

def get_distance_3d(point1, point2):
    """计算3D距离"""
    dx = point1.x - point2.x
    dy = point1.y - point2.y
    dz = point1.z - point2.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
```

## 实用函数

### 角度函数

```python
def get_angle(vector1, vector2):
    """计算两个向量之间的角度"""
    dot = vector1.dot(vector2)
    len1 = vector1.length
    len2 = vector2.length
    if len1 == 0 or len2 == 0:
        return 0
    cos_angle = dot / (len1 * len2)
    cos_angle = max(-1, min(1, cos_angle))
    return math.degrees(math.acos(cos_angle))

def get_direction_angle(vector):
    """获取向量方向角度"""
    return math.degrees(math.atan2(vector.y, vector.x))
```

### 插值函数

```python
def lerp(start, end, factor):
    """线性插值"""
    return start + (end - start) * factor

def ease_in_out(t):
    """缓入缓出"""
    return t * t * (3 - 2 * t)

def smooth_step(edge0, edge1, x):
    """平滑阶梯"""
    t = clamp((x - edge0) / (edge1 - edge0), 0, 1)
    return t * t * (3 - 2 * t)

def clamp(x, min_val, max_val):
    """限制范围"""
    return max(min_val, min(x, max_val))
```

### 曲线评估

```python
def evaluate_bezier(t, control_points):
    """评估贝塞尔曲线"""
    n = len(control_points) - 1
    result = Vector((0, 0, 0))
    for i, point in enumerate(control_points):
        bernstein = binomial(n, i) * (1 - t) ** (n - i) * t ** i
        result += point * bernstein
    return result

def binomial(n, k):
    """计算二项式系数"""
    if k < 0 or k > n:
        return 0
    result = 1
    for i in range(1, min(k, n - k) + 1):
        result = result * (n - i + 1) // i
    return result
```

## 常见问题排查

### 计算错误

参数问题：
- 确认输入值在有效范围
- 检查向量长度非零
- 验证曲线点数量

### 性能问题

计算复杂：
- 缓存常用计算结果
- 减少不必要的函数调用
- 使用近似计算
