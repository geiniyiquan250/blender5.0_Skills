# bpy.ops.world 模块

世界环境操作模块，用于管理场景的世界环境和光照设置。

## 概述

bpy.ops.world 模块包含用于配置场景世界环境的运算符。世界环境控制场景的背景颜色、环境光照、雾效和整体氛围。

## 常用操作

### 世界创建

```python
import bpy

# 创建新世界
bpy.ops.world.new(name='MyWorld')

# 设置活动世界
bpy.ops.world.set_active()

# 复制世界
bpy.ops.world.duplicate(world='MyWorld')
```

### 颜色设置

```python
# 设置背景颜色
bpy.ops.world.color_set(color=(0.1, 0.1, 0.1, 1.0))

# 设置环境颜色
bpy.ops.world.ambient_color_set(color=(0.5, 0.5, 0.5))

# 设置地平线颜色
bpy.ops.world.horizon_color_set(color=(0.0, 0.0, 0.0))

# 设置天顶颜色
bpy.ops.world.zenith_color_set(color=(0.0, 0.1, 0.3))
```

### 环境纹理

```python
# 加载环境纹理
bpy.ops.world.texface_image_add(filepath='//hdr.exr')

# 加载平铺环境纹理
bpy.ops.world.texface_image_add(filepath='//hdr.exr', tiling='4')

# 设置环境纹理强度
bpy.ops.world.light_texmat_image_set(intensity=1.0)
```

### 雾效设置

```python
# 设置雾类型
bpy.ops.world.mist_set(type='LINEAR')

# 设置线性雾
bpy.ops.world.mist_set(type='LINEAR', start=5.0, depth=20.0)

# 设置指数雾
bpy.ops.world.mist_set(type='EXP2', start=5.0, depth=20.0)

# 设置平方反比雾
bpy.ops.world.mist_set(type='INVERSE_SQUARE', start=5.0, depth=20.0)

# 清除雾效
bpy.ops.world.mist_clear()
```

### 环镜光遮蔽

```python
# 设置环境光遮蔽
bpy.ops.world.ao_environment_map_create()

# 创建环境光遮蔽纹理
bpy.ops.world.ao_environment_map_create(samples=16)

# 设置环境光遮蔽因子
bpy.ops.world.ao_set(factor=1.0)
```

### 节点操作

```python
# 新建节点树
bpy.ops.world.new()

# 复制节点树
bpy.ops.world.duplicate()

# 粘贴节点
bpy.ops.world.node_tree_socket_copy()

# 粘贴节点
bpy.ops.world.node_tree_socket_paste()
```

### 灯光设置

```python
# 添加环境光
bpy.ops.world.light_add()

# 添加区域光
bpy.ops.world.light_add(type='AREA')

# 添加太阳光
bpy.ops.world.light_add(type='SUN')
```

## 实际应用示例

### 创建程序化天空

```python
def create_procedural_sky():
    """创建程序化天空环境"""
    # 创建新世界
    bpy.ops.world.new(name='ProceduralSky')
    world = bpy.data.worlds['ProceduralSky']
    
    # 设置节点材质
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    
    # 创建天空节点
    sky_node = nodes.new(type='ShaderNodeTexSky')
    sky_node.sun_direction = (0.0, 0.0, 1.0)
    sky_node.turbidity = 2.0
    sky_node.ground_albedo = 0.3
    
    # 创建坐标节点
    coord_node = nodes.new(type='ShaderNodeTexCoord')
    
    # 创建映射节点
    mapping_node = nodes.new(type='ShaderNodeMapping')
    
    # 创建背景节点
    background_node = nodes.new(type='ShaderNodeBackground')
    
    # 创建输出节点
    output_node = nodes.get('World Output')
    
    # 连接节点
    links.new(coord_node.outputs['Generated'], mapping_node.inputs['Vector'])
    links.new(mapping_node.outputs['Vector'], sky_node.inputs['Vector'])
    links.new(sky_node.outputs['Color'], background_node.inputs['Color'])
    links.new(background_node.outputs['Background'], output_node.inputs['Surface'])
    
    return world
```

### 创建HDRI环境

```python
def create_hdri_environment(hdr_path, strength=1.0):
    """创建HDRI环境"""
    # 创建新世界
    bpy.ops.world.new(name='HDRI_Environment')
    world = bpy.data.worlds['HDRI_Environment']
    
    # 设置节点材质
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    
    # 创建环境纹理节点
    env_tex = nodes.new(type='ShaderNodeTexEnvironment')
    env_tex.image = bpy.data.images.load(hdr_path)
    env_tex.interpolation = 'Linear'
    
    # 创建背景节点
    background = nodes.new(type='ShaderNodeBackground')
    background.inputs['Strength'].default_value = strength
    
    # 获取输出节点
    output = nodes.get('World Output')
    
    # 连接节点
    links.new(env_tex.outputs['Color'], background.inputs['Color'])
    links.new(background.outputs['Background'], output.inputs['Surface'])
    
    # 设置世界到场景
    bpy.context.scene.world = world
    
    return world
```

### 创建雾效场景

```python
def create_foggy_scene(fog_start=5.0, fog_depth=20.0, fog_color=(0.8, 0.8, 0.9)):
    """创建雾效场景"""
    # 获取当前世界
    world = bpy.context.scene.world
    
    if not world:
        bpy.ops.world.new(name='FoggyWorld')
        world = bpy.data.worlds['FoggyWorld']
    
    # 设置雾效
    world.mist_settings.use_mist = True
    world.mist_settings.intensity = 0.5
    world.mist_settings.start = fog_start
    world.mist_settings.depth = fog_depth
    world.mist_settings.falloff = 'LINEAR'
    
    # 设置雾颜色
    world.mist_settings.color = fog_color
    
    return world
```

### 创建渐变背景

```python
def create_gradient_background(top_color=(0.0, 0.1, 0.4), bottom_color=(0.5, 0.7, 0.9)):
    """创建渐变背景"""
    # 创建新世界
    bpy.ops.world.new(name='GradientBackground')
    world = bpy.data.worlds['GradientBackground']
    
    # 设置节点材质
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    
    # 创建渐变纹理节点
    gradient = nodes.new(type='ShaderNodeTexGradient')
    gradient.gradient_type = 'LINEAR'
    
    # 创建颜色节点
    top_col = nodes.new(type='ShaderNodeRGB')
    top_col.outputs[0].default_value = (*top_color, 1.0)
    
    bottom_col = nodes.new(type='ShaderNodeRGB')
    bottom_col.outputs[0].default_value = (*bottom_color, 1.0)
    
    # 创建混合节点
    mix = nodes.new(type='ShaderNodeMixRGB')
    mix.inputs['Fac'].default_value = 0.5
    
    # 创建背景节点
    background = nodes.new(type='ShaderNodeBackground')
    
    # 创建输出节点
    output = nodes.get('World Output')
    
    # 连接节点
    links.new(top_col.outputs['Color'], mix.inputs['Color1'])
    links.new(bottom_col.outputs['Color'], mix.inputs['Color2'])
    links.new(gradient.outputs['Color'], mix.inputs['Fac'])
    links.new(mix.outputs['Color'], background.inputs['Color'])
    links.new(background.outputs['Background'], output.inputs['Surface'])
    
    return world
```

### 创建程序化星星背景

```python
def create_star_background(star_count=1000, star_size=1.0, background_color=(0.0, 0.0, 0.05)):
    """创建星星背景"""
    # 创建新世界
    bpy.ops.world.new(name='StarBackground')
    world = bpy.data.worlds['StarBackground']
    
    # 设置节点材质
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    
    # 创建背景色
    background = nodes.new(type='ShaderNodeBackground')
    background.inputs['Color'].default_value = (*background_color, 1.0)
    
    # 创建输出节点
    output = nodes.get('World Output')
    
    # 连接节点
    links.new(background.outputs['Background'], output.inputs['Surface'])
    
    return world
```

### 创建多云天空

```python
def create_cloudy_sky(cloud_coverage=0.5, sun_direction=(1.0, 0.5, 0.5)):
    """创建多云天空"""
    # 创建新世界
    bpy.ops.world.new(name='CloudySky')
    world = bpy.data.worlds['CloudySky']
    
    # 设置节点材质
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    
    # 创建天空节点
    sky = nodes.new(type='ShaderNodeTexSky')
    sky.sun_direction = sun_direction
    sky.turbidity = 3.0
    sky.exposure = 1.0
    sky.ground_albedo = 0.5
    
    # 创建噪波纹理
    noise = nodes.new(type='ShaderNodeTexNoise')
    noise.noise_scale = 5.0
    noise.noise_depth = 2
    
    # 创建颜色渐变
    gradient = nodes.new(type='ShaderNodeTexGradient')
    gradient.gradient_type = 'LINEAR'
    
    # 创建混合节点
    mix = nodes.new(type='ShaderNodeMixRGB')
    mix.inputs['Fac'].default_value = cloud_coverage
    
    # 创建背景节点
    background = nodes.new(type='ShaderNodeBackground')
    
    # 创建输出节点
    output = nodes.get('World Output')
    
    # 连接节点
    links.new(sky.outputs['Color'], mix.inputs['Color1'])
    links.new(noise.outputs['Color'], mix.inputs['Color2'])
    links.new(mix.outputs['Color'], background.inputs['Color'])
    links.new(background.outputs['Background'], output.inputs['Surface'])
    
    return world
```

## 使用场景

- **环境设置**：设置场景的整体光照和氛围
- **HDRI照明**：使用HDRI图像进行环境照明
- **雾效制作**：创建雾、烟等大气效果
- **天空系统**：创建程序化天空和云层
- **背景设置**：设置渲染背景
- **光照烘焙**：烘焙环境光照

## 注意事项

- 世界设置影响整个场景的照明
- HDRI贴图需要高动态范围格式
- 雾效影响场景的深度感
- 节点系统提供更灵活的控制
- 世界设置可以链接到其他场景
- 环境光遮蔽需要额外的计算时间
