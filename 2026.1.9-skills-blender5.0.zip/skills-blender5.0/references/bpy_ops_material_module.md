# bpy.ops.material 模块

材质操作模块，用于在材质属性面板中创建和管理材质。

## 概述

bpy.ops.material 模块包含用于创建、编辑和应用材质的运算符。这些运算符控制材质的属性、输出和与其他对象的关联。

## 常用操作

### 材质创建

```python
import bpy

# 新建材质
bpy.ops.material.new(name='NewMaterial')

# 新建材质并设置
bpy.ops.material.new(name='MyMaterial')

# 复制材质
bpy.ops.material.copy()

# 粘贴材质
bpy.ops.material.paste()

# 删除材质
bpy.ops.material.delete()

# 重命名材质
bpy.ops.material.rename(name='RenamedMaterial')
```

### 材质分配

```python
# 分配材质到物体
bpy.ops.object.material_slot_add()

# 分配新材质
bpy.ops.object.material_slot_add()

# 分配材质
bpy.ops.object.material_slot_assign()

# 取消分配
bpy.ops.object.material_slot_deselect()

# 选择已分配
bpy.ops.object.material_slot_select()

# 复制材质分配
bpy.ops.object.material_slot_copy()

# 粘贴材质分配
bpy.ops.object.material_slot_paste()

# 删除材质槽
bpy.ops.object.material_slot_remove()

# 删除未使用材质
bpy.ops.object.material_slot_remove_unused()
```

### 材质设置

```python
# 设置表面
bpy.ops.material.surface_set()

# 清除表面
bpy.ops.material.surface_clear()

# 设置体积
bpy.ops.material.volume_set()

# 清除体积
bpy.ops.material.volume_clear()

# 设置置换
bpy.ops.material.displacement_set()

# 清除置换
bpy.ops.material.displacement_clear()
```

### 材质预览

```python
# 设置预览类型
bpy.ops.material.preview_sample()

# 刷新预览
bpy.ops.material.preview_refresh()
```

## 实际应用示例

### 创建标准PBR材质

```python
def create_pbr_material(name, base_color, metallic, roughness):
    """创建标准PBR材质"""
    # 创建新材质
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    
    # 获取节点树
    tree = mat.node_tree
    
    # 清理默认节点
    for node in tree.nodes:
        tree.nodes.remove(node)
    
    # 创建Principled BSDF
    principled = tree.nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (0, 0)
    principled.inputs['Base Color'].default_value = (*base_color, 1.0)
    principled.inputs['Metallic'].default_value = metallic
    principled.inputs['Roughness'].default_value = roughness
    
    # 创建输出
    output = tree.nodes.new('ShaderNodeOutputMaterial')
    output.location = (300, 0)
    
    # 连接节点
    tree.links.new(principled.outputs['BSDF'], output.inputs['Surface'])
    
    return mat
```

### 创建程序化纹理材质

```python
def create_procedural_material(name):
    """创建程序化纹理材质"""
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    tree = mat.node_tree
    
    # 创建纹理坐标
    tex_coord = tree.nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (-600, 0)
    
    # 创建映射
    mapping = tree.nodes.new('ShaderNodeMapping')
    mapping.location = (-400, 0)
    
    # 创建噪声纹理
    noise = tree.nodes.new('ShaderNodeTexNoise')
    noise.location = (-200, 0)
    noise.noise_scale = 5.0
    
    # 创建颜色渐变
    gradient = tree.nodes.new('ShaderNodeValToRGB')
    gradient.location = (0, 0)
    
    # 创建Principled BSDF
    principled = tree.nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (200, 0)
    
    # 创建输出
    output = tree.nodes.new('ShaderNodeOutputMaterial')
    output.location = (400, 0)
    
    # 连接节点
    tree.links.new(tex_coord.outputs['Generated'], mapping.inputs['Vector'])
    tree.links.new(mapping.outputs['Vector'], noise.inputs['Vector'])
    tree.links.new(noise.outputs['Fac'], gradient.inputs['Fac'])
    tree.links.new(gradient.outputs['Color'], principled.inputs['Base Color'])
    tree.links.new(principled.outputs['BSDF'], output.inputs['Surface'])
    
    return mat
```

### 创建玻璃材质

```python
def create_glass_material(name, transmission=1.0, roughness=0.0, ior=1.45):
    """创建玻璃材质"""
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    tree = mat.node_tree
    
    # 清理
    for node in tree.nodes:
        tree.nodes.remove(node)
    
    # 创建Principled BSDF
    principled = tree.nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (0, 0)
    principled.inputs['Base Color'].default_value = (1.0, 1.0, 1.0, 1.0)
    principled.inputs['Metallic'].default_value = 0.0
    principled.inputs['Roughness'].default_value = roughness
    principled.inputs['IOR'].default_value = ior
    principled.inputs['Transmission'].default_value = transmission
    
    # 创建输出
    output = tree.nodes.new('ShaderNodeOutputMaterial')
    output.location = (300, 0)
    
    # 连接
    tree.links.new(principled.outputs['BSDF'], output.inputs['Surface'])
    
    return mat
```

### 创建发光材质

```python
def create_emission_material(name, color, strength=5.0):
    """创建发光材质"""
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    tree = mat.node_tree
    
    # 清理
    for node in tree.nodes:
        tree.nodes.remove(node)
    
    # 创建发射节点
    emission = tree.nodes.new('ShaderNodeEmission')
    emission.location = (0, 0)
    emission.inputs['Color'].default_value = (*color, 1.0)
    emission.inputs['Strength'].default_value = strength
    
    # 创建输出
    output = tree.nodes.new('ShaderNodeOutputMaterial')
    output.location = (300, 0)
    
    # 连接
    tree.links.new(emission.outputs['Emission'], output.inputs['Surface'])
    
    return mat
```

### 批量创建材质

```python
def batch_create_materials(material_data):
    """批量创建材质"""
    created_materials = []
    
    for name, params in material_data.items():
        if params['type'] == 'pbr':
            mat = create_pbr_material(
                name,
                params.get('base_color', (1, 1, 1)),
                params.get('metallic', 0.0),
                params.get('roughness', 0.5)
            )
        elif params['type'] == 'glass':
            mat = create_glass_material(
                name,
                params.get('transmission', 1.0),
                params.get('roughness', 0.0)
            )
        elif params['type'] == 'emission':
            mat = create_emission_material(
                name,
                params.get('color', (1, 1, 1)),
                params.get('strength', 5.0)
            )
        else:
            mat = create_pbr_material(name)
        
        created_materials.append(mat)
    
    return created_materials
```

### 应用材质到物体

```python
def apply_material_to_objects(material, objects):
    """应用材质到多个物体"""
    for obj in objects:
        # 添加材质槽
        obj.data.materials.append(material)
    
    return objects
```

### 复制物体材质

```python
def copy_material_from_source(source_obj, target_objects):
    """从源物体复制材质到目标"""
    if not source_obj.data.materials:
        return
    
    # 获取源材质
    source_mat = source_obj.data.materials[0]
    
    # 复制材质
    new_mat = source_mat.copy()
    new_mat.name = f'{source_mat.name}_copy'
    
    # 应用到目标
    apply_material_to_objects(new_mat, target_objects)
    
    return new_mat
```

### 创建材质库

```python
def create_material_library(materials_dict, library_name='MaterialLibrary'):
    """创建材质库"""
    library = bpy.data.textures.new(name=library_name)
    
    materials = []
    for name, params in materials_dict.items():
        if params['type'] == 'pbr':
            mat = create_pbr_material(name, params['color'], params['metallic'], params['roughness'])
        else:
            mat = create_pbr_material(name)
        
        materials.append(mat)
    
    return materials
```

## 使用场景

- **材质创建**：创建新的材质
- **材质管理**：组织和复制材质
- **PBR工作流**：创建物理材质
- **程序化纹理**：使用节点创建材质
- **批量应用**：快速应用材质到多个物体
- **材质库**：创建可复用材质集合

## 注意事项

- 材质使用节点系统更灵活
- PBR材质需要正确设置
- 玻璃材质需要传输设置
- 发光材质影响渲染
- 材质复制会共享节点树
- 大量材质影响性能
