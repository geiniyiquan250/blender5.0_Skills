# bpy.ops.curves - Curves Operations Module

Blender 曲线操作符，用于创建和编辑曲线对象。

## Overview

`bpy.ops.curves` 模块包含曲线对象的操作命令，支持曲线笔刷、曲线编辑和曲线属性设置。这个模块主要用于 Grease Pencil 和曲线绘制。

## 核心功能

```python
import bpy

# 曲线选择
bpy.ops.curves.select_all(action='SELECT')
bpy.ops.curves.select_less()
bpy.ops.curves.select_more()

# 曲线编辑
bpy.ops.curves.subdivide()
bpy.ops.curves.delete()
bpy.ops.curves.duplicate()

# 曲线笔刷
bpy.ops.curves.draw()
bpy.ops.curves.stroke(
    stroke=[{"name": "Empty", "location": (0, 0, 0), "pressure": 1, "time": 0}]
)
```

## 实际应用示例

### 曲线管理器

```python
import bpy
import math

class CurvesManager:
    """曲线管理器"""
    
    def __init__(self):
        self.curves = {}
    
    def select_all_curves(self, action='SELECT'):
        """选择所有曲线"""
        bpy.ops.curves.select_all(action=action)
    
    def deselect_all(self):
        """取消选择"""
        self.select_all_curves(action='DESELECT')
    
    def select_more(self):
        """扩大选择"""
        bpy.ops.curves.select_more()
    
    def select_less(self):
        """缩小选择"""
        bpy.ops.curves.select_less()
    
    def select_linked(self):
        """选择连接"""
        bpy.ops.curves.select_linked()
    
    def select_random(self, percent=50, seed=0):
        """随机选择"""
        bpy.ops.curves.select_random(percent=percent, seed=seed)
    
    def subdivide_curves(self, number_of_cuts=1):
        """细分曲线"""
        bpy.ops.curves.subdivide(number_of_cuts=number_of_cuts)
    
    def delete_curves(self, type='SELECTED'):
        """删除曲线"""
        bpy.ops.curves.delete(type=type)
    
    def delete_points(self, type='POINTS'):
        """删除点"""
        bpy.ops.curves.delete(type=type)
    
    def duplicate_curves(self):
        """复制曲线"""
        bpy.ops.curves.duplicate()
    
    def duplicate_linked(self):
        """复制连接"""
        bpy.ops.curves.duplicate_linked()
    
    def merge_points(self, distance=0.1, mode='AT_LAST'):
        """合并点"""
        bpy.ops.curves.merge_points(distance=distance, mode=mode)
    
    def select_first(self):
        """选择第一个"""
        bpy.ops.curves.select_first()
    
    def select_last(self):
        """选择最后一个"""
        bpy.ops.curves.select_last()
    
    def set_selection_radius(self, radius=0.1):
        """设置选择半径"""
        bpy.ops.curves.selection_set(radius=radius)


def setup_curves_manager():
    """设置曲线管理器"""
    manager = CurvesManager()
    
    print("曲线管理器已设置")
    print("可用功能:")
    print("- select_all_curves: 全选")
    print("- subdivide_curves: 细分")
    print("- merge_points: 合并点")
    
    return manager
```

### 曲线笔刷工具

```python
import bpy

class CurvesBrushTool:
    """曲线笔刷工具"""
    
    def __init__(self):
        self.brushes = {}
    
    def set_brush_size(self, size):
        """设置笔刷大小"""
        bpy.context.scene.tool_settings.curves_paint.brush.size = size
    
    def set_brush_strength(self, strength):
        """设置笔刷强度"""
        bpy.context.scene.tool_settings.curves_paint.brush.strength = strength
    
    def set_brush_color(self, color):
        """设置笔刷颜色"""
        bpy.context.scene.tool_settings.curves_paint.brush.color = color
    
    def set_curve_mode(self, mode='ADD'):
        """设置曲线模式"""
        bpy.context.scene.tool_settings.curves_paint.mode = mode
    
    def use_curve_sculpting(self, use=True):
        """启用曲线雕刻"""
        bpy.context.scene.tool_settings.use_curves_sculpt = use
    
    def apply_brush_stroke(self, stroke_points):
        """应用笔刷笔触"""
        bpy.ops.curves.stroke(
            stroke=stroke_points,
            mode='REPLACE'
        )
    
    def draw_curve(self, start_point, end_point):
        """绘制曲线"""
        stroke = [
            {"name": "Empty", "location": start_point, "pressure": 1, "time": 0},
            {"name": "Empty", "location": end_point, "pressure": 1, "time": 1}
        ]
        
        self.apply_brush_stroke(stroke)
    
    def create_smooth_curve(self, points, smooth_strength=1.0):
        """创建平滑曲线"""
        for i, point in enumerate(points):
            if i == 0:
                continue
            
            stroke = [
                {"name": "Empty", "location": points[i-1], "pressure": 1, "time": 0},
                {"name": "Empty", "location": point, "pressure": 1, "time": 1}
            ]
            
            bpy.ops.curves.stroke(
                stroke=stroke,
                mode='SMOOTH'
            )
    
    def create_thick_curve(self, points, thickness):
        """创建粗曲线"""
        for i, point in enumerate(points):
            if i == 0:
                continue
            
            stroke = [
                {"name": "Empty", "location": points[i-1], "pressure": thickness, "time": 0},
                {"name": "Empty", "location": point, "pressure": thickness, "time": 1}
            ]
            
            bpy.ops.curves.stroke(
                stroke=stroke,
                mode='REPLACE'
            )
    
    def create_tapered_curve(self, points, start_thickness=1.0, end_thickness=0.1):
        """创建锥形曲线"""
        for i, point in enumerate(points):
            if i == 0:
                continue
            
            t = i / len(points)
            thickness = start_thickness + (end_thickness - start_thickness) * t
            
            stroke = [
                {"name": "Empty", "location": points[i-1], "pressure": thickness, "time": 0},
                {"name": "Empty", "location": point, "pressure": thickness, "time": 1}
            ]
            
            bpy.ops.curves.stroke(
                stroke=stroke,
                mode='REPLACE'
            )
    
    def smooth_selected_curves(self, strength=1.0):
        """平滑选中曲线"""
        bpy.ops.curves.smooth(strength=strength)
    
    def thin_selected_curves(self, factor=0.5):
        """变细选中曲线"""
        bpy.ops.curves.thin(factor=factor)
    
    def thick_selected_curves(self, factor=2.0):
        """变粗选中曲线"""
        bpy.ops.curves.thin(factor=factor, inverse=True)


def setup_brush_tool():
    """设置笔刷工具"""
    tool = CurvesBrushTool()
    
    print("曲线笔刷工具已设置")
    print("可用功能:")
    print("- set_brush_size: 设置大小")
    print("- apply_brush_stroke: 应用笔触")
    print("- smooth_selected_curves: 平滑")
    
    return tool
```

### 曲线动画工具

```python
import bpy

class CurvesAnimationTool:
    """曲线动画工具"""
    
    def __init__(self):
        self.keyframes = {}
    
    def insert_keyframe(self, data_path, index=-1, frame=None):
        """插入关键帧"""
        if frame is None:
            frame = bpy.context.scene.frame_current
        
        bpy.ops.anim.keyframe_insert(data_path=data_path, type='DEFAULT', index=index)
        bpy.context.scene.frame_set(frame)
    
    def animate_curve_thickness(self, curve_name, keyframes):
        """动画曲线粗细"""
        curve = bpy.data.objects.get(curve_name)
        if not curve:
            return
        
        for frame, thickness in keyframes.items():
            bpy.context.scene.frame_set(frame)
            curve.data.bevel_depth = thickness
            curve.data.keyframe_insert(data_path='bevel_depth', frame=frame)
    
    def animate_curve_color(self, curve_name, keyframes):
        """动画曲线颜色"""
        curve = bpy.data.objects.get(curve_name)
        if not curve:
            return
        
        for frame, color in keyframes.items():
            bpy.context.scene.frame_set(frame)
            curve.data.materials[0].node_tree.nodes["Principled BSDF"].inputs['Base Color'].default_value = color
            curve.data.materials[0].node_tree.nodes["Principled BSDF"].inputs['Base Color'].keyframe_insert(
                data_path='default_value', frame=frame
            )
    
    def create_path_animation(self, curve_name, target_object, frames):
        """创建路径动画"""
        curve = bpy.data.objects.get(curve_name)
        target = bpy.data.objects.get(target_object)
        
        if not curve or not target:
            return
        
        # 添加跟随路径约束
        constraint = target.constraints.new(type='FOLLOW_PATH')
        constraint.target = curve
        constraint.use_curve_follow = True
        
        # 插入关键帧
        for i, frame in enumerate(frames):
            bpy.context.scene.frame_set(frame)
            constraint.offset_factor = i / len(frames)
            constraint.keyframe_insert(data_path='offset_factor', frame=frame)
    
    def animate_along_curve(self, object_name, curve_name, start_frame=1, end_frame=100):
        """沿曲线动画"""
        obj = bpy.data.objects.get(object_name)
        curve = bpy.data.objects.get(curve_name)
        
        if not obj or not curve:
            return
        
        # 创建路径约束
        constraint = obj.constraints.new(type='FOLLOW_PATH')
        constraint.target = curve
        constraint.use_curve_follow = True
        
        # 设置动画
        for frame in range(start_frame, end_frame + 1):
            bpy.context.scene.frame_set(frame)
            constraint.offset_factor = (frame - start_frame) / (end_frame - start_frame)
            constraint.keyframe_insert(data_path='offset_factor', frame=frame)
    
    def create_wiggle_effect(self, curve_name, amplitude=0.1, frequency=1.0, frames=60):
        """创建摆动效果"""
        curve = bpy.data.objects.get(curve_name)
        if not curve:
            return
        
        import math
        
        for frame in range(frames):
            bpy.context.scene.frame_set(frame + 1)
            
            time = frame / 30.0
            
            # 移动曲线点
            for point in curve.data.splines[0].points:
                point.co = (
                    point.co[0] + amplitude * math.sin(frequency * time),
                    point.co[1] + amplitude * math.cos(frequency * time),
                    point.co[2],
                    point.co[3]
                )
            
            curve.data.splines[0].keyframe_insert(data_path='points', frame=frame + 1)
    
    def export_curve_animation(self, curve_name, output_path):
        """导出曲线动画"""
        curve = bpy.data.objects.get(curve_name)
        if not curve:
            return None
        
        # 导出为关键帧数据
        frames = []
        
        for frame in range(
            bpy.context.scene.frame_start,
            bpy.context.scene.frame_end + 1
        ):
            bpy.context.scene.frame_set(frame)
            
            frame_data = {
                'frame': frame,
                'points': []
            }
            
            for point in curve.data.splines[0].points:
                frame_data['points'].append(point.co.copy())
            
            frames.append(frame_data)
        
        # 保存数据
        import json
        
        with open(output_path, 'w') as f:
            json.dump(frames, f, indent=2)
        
        return output_path


def setup_curves_animation():
    """设置曲线动画"""
    tool = CurvesAnimationTool()
    
    print("曲线动画工具已设置")
    print("可用功能:")
    print("- animate_curve_thickness: 粗细动画")
    print("- animate_along_curve: 沿曲线动画")
    print("- create_wiggle_effect: 摆动效果")
    
    return tool
```
