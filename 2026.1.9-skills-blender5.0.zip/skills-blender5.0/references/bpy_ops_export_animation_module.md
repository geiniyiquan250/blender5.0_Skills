# bpy.ops.export_animation - 动画导出操作模块

Blender动画导出操作符，用于将动画数据导出为各种动画文件格式。

## 概述

`bpy.ops.export_animation` 模块提供用于将Blender中的动画数据导出为外部文件格式的功能，包括FBX、ABC、USD等。

## 核心功能

### FBX导出

```python
import bpy

# 导出为FBX
bpy.ops.export_animation.fbx(
    filepath='//animation.fbx',
    export_selected=True,
    apply_scale_settings='FBX_SCALE_ALL',
    apply_unit_scale=True,
    axis_forward='-Z',
    axis_up='Y',
    bake_space_transform=False,
    use_selection=True,
    use_visible=True,
    use_active_collection=False,
    export_animation=True,
    export_nla_strips=True,
    export_lights=True,
    export_cameras=True,
    export_mesh_modifiers=True,
    export_armature=True,
    export_skins=True,
    export_all_influences=False,
    deform_bones_only=False,
    sampling_rate=0,
    export_bake=False,
    export_anim=True,
    export_anim_action='ACTIVE',
    export_anim_action_all=True,
    export_anim_use_nla=True,
    export_anim_use_all_bones=True,
    export_anim_optimize=True,
    export_anim_sampling_rate=1.0,
    export_anim_opacity=True
)

# 导出选中对象动画
bpy.ops.export_animation.fbx(
    filepath='//selected_anim.fbx',
    export_selected=True,
    use_selection=True
)

# 导出所有动画
bpy.ops.export_animation.fbx(
    filepath='//all_anim.fbx',
    export_selected=False
)

# 导出骨骼动画
bpy.ops.export_animation.fbx(
    filepath='//armature_anim.fbx',
    export_armature=True,
    export_skins=True
)

# 导出带NLA的动画
bpy.ops.export_animation.fbx(
    filepath='//nla_anim.fbx',
    export_animation=True,
    export_nla_strips=True
)
```

### Alembic导出

```python
# 导出为Alembic
bpy.ops.export_animation.alembic(
    filepath='//animation.abc',
    export_selected=True,
    apply_subdiv=False,
    export_visible=True,
    export_hair=True,
    export_particles=True,
    export_deforum=False,
    export_uv=True,
    export_normals=True,
    export_vcol=False,
    export_material_names=False,
    export_vertex_groups=False,
    export_triangulated=False,
    export_yup=True,
    renderable_only=False,
    visible_only=False,
    use_selection=True,
    end_frame=250,
    start_frame=1,
    stride=1,
    shutter_open=0.0,
    shutter_close=1.0,
    compression='ogawa'
)

# 导出所有帧
bpy.ops.export_animation.alembic(
    filepath='//full_anim.abc',
    start_frame=bpy.context.scene.frame_start,
    end_frame=bpy.context.scene.frame_end
)

# 导出粒子系统
bpy.ops.export_animation.alembic(
    filepath='//particles.abc',
    export_particles=True
)

# 导出毛发
bpy.ops.export_animation.alembic(
    filepath='//hair.abc',
    export_hair=True
)

# 高压缩导出
bpy.ops.export_animation.alembic(
    filepath='//compressed.abc',
    compression='hdf5'
)
```

### USD导出

```python
# 导出为USD
bpy.ops.export_animation.usd(
    filepath='//animation.usd',
    export_selected=True,
    export_visible=True,
    export_cameras=True,
    export_lights=True,
    export_materials=True,
    export_modifiers=True,
    export_type='MESH',
    export_pbr_material=True,
    export_textures=True,
    export_frame_range=True,
    export_frame_step=1,
    export_uv=True,
    export_normals=True,
    export_compression=False,
    export_hair=True,
    export_particles=True
)

# 导出带材质的USD
bpy.ops.export_animation.usd(
    filepath='//with_materials.usd',
    export_materials=True,
    export_pbr_material=True
)

# 导出特定帧范围
bpy.ops.export_animation.usd(
    filepath='//frame_range.usd',
    export_frame_range=True,
    start_frame=1,
    end_frame=100
)

# 导出为USDZ
bpy.ops.export_animation.usd(
    filepath='//animation.usdz',
    export_compression=True
)
```

### GLTF导出（动画相关）

```python
# 导出为GLTF（包含动画）
bpy.ops.export_animation.gltf(
    filepath='//animation.glb',
    export_selected=True,
    export_format='GLB',
    export_cameras=True,
    export_lights=True,
    export_animations=True,
    export_frame_range=True,
    export_frame_step=1,
    export_skins=True,
    export_all_influences=False,
    export_morph=True,
    export_yup=True,
    export_apply=True
)

# 导出动画为GLTF
bpy.ops.export_animation.gltf(
    filepath='//anim_only.glb',
    export_format='GLB',
    export_cameras=False,
    export_lights=False,
    export_animations=True
)

# 导出为GLTF动画片段
bpy.ops.export_animation.gltf(
    filepath='//animation.gltf',
    export_format='GLTF_SEPARATE',
    export_animations=True
)
```

### 动画烘焙导出

```python
# 烘焙所有动画
bpy.ops.export_animation.bake(
    start_frame=1,
    end_frame=250,
    step=1,
    apply_scale=True,
    apply_transforms=True,
    clear_constraints=True,
    clear_parents=False,
    export_global_objects=True,
    export_selected_objects=True
)

# 烘焙选中的骨骼动画
bpy.ops.export_animation.bake(
    object_type='ARMATURE',
    export_selected=True,
    bake_anim=True,
    bake_anim_action_all=True
)

# 烘焙变形目标动画
bpy.ops.export_animation.bake(
    object_type='MESH',
    bake_anim=True,
    bake_morph=True
)
```

## 实用函数

```python
def export_animation_fbx(filepath, selected_only=True):
    """导出动画为FBX格式"""
    bpy.ops.export_animation.fbx(
        filepath=filepath,
        export_selected=selected_only,
        export_anim=True,
        export_anim_action='ACTIVE'
    )

def export_animation_alembic(filepath, start_frame=1, end_frame=250):
    """导出动画为Alembic格式"""
    bpy.ops.export_animation.alembic(
        filepath=filepath,
        start_frame=start_frame,
        end_frame=end_frame,
        export_anim=True
    )

def export_animation_usd(filepath, start_frame=1, end_frame=250):
    """导出动画为USD格式"""
    bpy.ops.export_animation.usd(
        filepath=filepath,
        export_frame_range=True,
        start_frame=start_frame,
        end_frame=end_frame,
        export_animations=True
    )

def batch_export_animations(output_dir):
    """批量导出多个动画"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 导出FBX
    export_animation_fbx(os.path.join(output_dir, 'animation.fbx'))
    
    # 导出Alembic
    export_animation_alembic(os.path.join(output_dir, 'animation.abc'))
    
    # 导出USD
    export_animation_usd(os.path.join(output_dir, 'animation.usd'))

def export_selected_armature_anim(filepath):
    """导出选中的骨骼动画"""
    bpy.ops.export_animation.fbx(
        filepath=filepath,
        export_selected=True,
        export_armature=True,
        export_skins=True,
        export_animation=True,
        export_anim_action='ACTIVE'
    )

def export_all_actions(filepath):
    """导出所有动作"""
    bpy.ops.export_animation.fbx(
        filepath=filepath,
        export_selected=False,
        export_anim=True,
        export_anim_action='ALL'
    )
```

## 常见问题排查

###
```python
 动画丢失# 检查对象动画
obj = bpy.context.active_object
print(f"对象类型: {obj.type}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")
    if obj.animation_data.action:
        print(f"帧范围: {obj.animation_data.action.frame_range}")

# 检查NLA轨道
for nla_track in obj.animation_data.nla_tracks:
    for strip in nla_track.strips:
        print(f"NLA轨道: {nla_track.name}, 片段: {strip.name}")

# 检查约束
for constraint in obj.constraints:
    print(f"约束类型: {constraint.type}")

# 确保动画已启用导出
bpy.ops.export_animation.fbx(
    filepath='//test.fbx',
    export_anim=True
)
```

### 骨骼动画问题
```python
# 检查骨骼
armature = bpy.context.active_object
if armature.type == 'ARMATURE':
    print(f"骨骼数: {len(armature.data.bones)}")
    
    # 检查骨骼变换
    for bone in armature.data.bones:
        print(f"骨骼: {bone.name}, 位置: {bone.head_local}")

# 检查权重
mesh = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH'][0]
if mesh.vertex_groups:
    print(f"顶点组数: {len(mesh.vertex_groups)}")

# 导出时包含所有骨骼
bpy.ops.export_animation.fbx(
    filepath='//armature.fbx',
    export_armature=True,
    export_skins=True,
    export_anim_use_all_bones=True
)
```

### 烘焙问题
```python
# 检查帧范围
print(f"开始帧: {bpy.context.scene.frame_start}")
print(f"结束帧: {bpy.context.scene.frame_end}")

# 检查帧率
print(f"帧率: {bpy.context.scene.render.fps}")

# 设置正确的帧范围
bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = 250

# 烘焙前应用所有修改
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.visual_transform_apply()

# 清除约束后烘焙
bpy.ops.export_animation.bake(
    export_anim=True,
    bake_anim=True,
    clear_constraints=True
)
```

### 导出格式不支持
```python
# 检查可用的导出操作
print("可用的导出操作:")
for op in dir(bpy.ops.export_animation):
    if not op.startswith('_'):
        print(f"  - {op}")

# 检查导出选项
bpy.ops.export_animation.fbx('//test.fbx', export_selected=True)
print("FBX导出可用")

# 尝试Alembic
try:
    bpy.ops.export_animation.alembic('//test.abc', export_selected=True)
    print("Alembic导出可用")
except:
    print("Alembic导出不可用")
```
