# bpy_extras.io_utils - 输入输出工具模块

bpy_extras.io_utils模块提供了文件路径处理、数据导入导出和资源路径管理的实用工具函数。

## 概述

输入输出工具模块封装了Blender中常见的文件操作和路径处理任务。包括相对路径转换、文件查找、数据块导入导出等功能。

## 核心功能

### 路径处理

```python
import bpy
import os
from bpy_extras.io_utils import (
    path_reference_target,
    path_resolve
)

def blender_path_to_system(blender_path):
    """将Blender路径转换为系统路径"""
    if blender_path.startswith('//'):
        blend_dir = bpy.path.abspath('//')
        return os.path.join(blend_dir, blender_path[2:])
    return blender_path

def system_path_to_blender(system_path):
    """将系统路径转换为Blender相对路径"""
    blend_file = bpy.data.filepath
    if not blend_file:
        return system_path
    blend_dir = os.path.dirname(blend_file)
    if system_path.startswith(blend_dir):
        return '//' + os.path.relpath(system_path, blend_dir)
    return system_path

def resolve_path(path, absolute=True):
    """解析路径"""
    if path.startswith('//'):
        resolved = bpy.path.abspath(path)
    else:
        resolved = os.path.abspath(path)
    if not absolute:
        resolved = os.path.relpath(resolved, bpy.path.abspath('//'))
    return resolved

def get_relative_path(from_path, to_path):
    """获取相对路径"""
    from_abs = blender_path_to_system(from_path) if from_path.startswith('//') else from_path
    to_abs = blender_path_to_system(to_path) if to_path.startswith('//') else to_path
    return os.path.relpath(to_abs, os.path.dirname(from_abs))
```

### 文件操作

```python
def find_file(directory, filename):
    """在目录中查找文件"""
    for root, dirs, files in os.walk(directory):
        if filename in files:
            return os.path.join(root, filename)
    return None

def find_files(directory, pattern):
    """查找匹配模式的文件"""
    results = []
    for root, dirs, files in os.walk(directory):
        for f in files:
            if pattern in f or f.endswith(pattern):
                results.append(os.path.join(root, f))
    return results

def list_directory(directory, extensions=None):
    """列出目录内容"""
    if not os.path.exists(directory):
        return []
    items = os.listdir(directory)
    if extensions:
        items = [i for i in items if any(i.endswith(ext) for ext in extensions)]
    return items

def create_directory(path):
    """创建目录"""
    if not os.path.exists(path):
        os.makedirs(path)
    return path
```

### 数据块导出

```python
def export_data_block(data_block, filepath, data_type='auto'):
    """导出数据块"""
    if data_type == 'auto':
        if isinstance(data_block, bpy.types.Mesh):
            data_type = 'mesh'
        elif isinstance(data_block, bpy.types.Material):
            data_type = 'material'
        elif isinstance(data_block, bpy.types.Object):
            data_type = 'object'
    
    if data_type == 'object':
        export_object_to_obj(data_block, filepath)
    elif data_type == 'mesh':
        export_mesh_to_file(data_block, filepath)
    
    return filepath

def export_object_to_obj(obj, filepath):
    """将对象导出为OBJ"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.export_scene.obj(
        filepath=filepath,
        use_selection=True,
        use_normals=True,
        use_triangles=True
    )

def export_objects_to_gltf(objects, filepath):
    """将多个对象导出为GLTF"""
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objects:
        obj.select_set(True)
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        use_selection=True,
        export_apply=True
    )
```

## 实用函数

### 数据块导入

```python
def import_data_block(filepath, data_type, link=False):
    """导入数据块"""
    if data_type == 'object':
        return import_object(filepath, link)
    elif data_type == 'material':
        return import_material(filepath, link)
    return None

def import_object(filepath, link=False):
    """导入对象"""
    if filepath.endswith('.obj'):
        bpy.ops.import_scene.obj(filepath=filepath)
    elif filepath.endswith('.gltf') or filepath.endswith('.glb'):
        bpy.ops.import_scene.gltf(filepath=filepath)
    elif filepath.endswith('.fbx'):
        bpy.ops.import_scene.fbx(filepath=filepath)
    return bpy.context.selected_objects[-1] if bpy.context.selected_objects else None

def import_material(filepath):
    """导入材质"""
    if filepath.endswith('.blend'):
        bpy.ops.wm.append(
            filepath=filepath,
            directory=os.path.dirname(filepath) + '/Material/',
            files=[{'name': os.path.splitext(os.path.basename(filepath))[0]}]
        )
    return bpy.data.materials[-1] if bpy.data.materials else None
```

### 资源管理

```python
def get_resource_path(resource_type):
    """获取资源类型路径"""
    prefs = bpy.context.preferences
    if resource_type == 'texture':
        return prefs.filepaths.texture_directory
    elif resource_type == 'script':
        return prefs.filepaths.script_directory
    elif resource_type == 'font':
        return prefs.filepaths.font_directory
    return ''

def set_resource_path(resource_type, path):
    """设置资源类型路径"""
    prefs = bpy.context.preferences
    if resource_type == 'texture':
        prefs.filepaths.texture_directory = path
    elif resource_type == 'script':
        prefs.filepaths.script_directory = path
    elif resource_type == 'font':
        prefs.filepaths.font_directory = path

def find_resources(resource_type, pattern):
    """查找资源"""
    resource_dir = get_resource_path(resource_type)
    if resource_dir and os.path.exists(resource_dir):
        return find_files(resource_dir, pattern)
    return []
```

### 文件验证

```python
def validate_file_exists(filepath):
    """验证文件存在"""
    if filepath.startswith('//'):
        abs_path = blender_path_to_system(filepath)
    else:
        abs_path = filepath
    return os.path.exists(abs_path)

def validate_blend_file(filepath):
    """验证blend文件"""
    if not validate_file_exists(filepath):
        return False
    with open(filepath, 'rb') as f:
        header = f.read(7)
        return header == b'BLENDER'
    
def get_file_size(filepath):
    """获取文件大小"""
    abs_path = blender_path_to_system(filepath)
    if os.path.exists(abs_path):
        return os.path.getsize(abs_path)
    return 0

def get_file_mtime(filepath):
    """获取文件修改时间"""
    abs_path = blender_path_to_system(filepath)
    if os.path.exists(abs_path):
        return os.path.getmtime(abs_path)
    return 0
```

## 常见问题排查

### 相对路径无效

文件未保存：
- 相对路径需要先保存blend文件
- 使用绝对路径进行测试
- 检查路径是否正确

### 导入导出失败

格式不支持：
- 确认文件格式被Blender支持
- 安装必要的导入导出插件
- 检查文件是否损坏

### 路径分隔符

跨平台问题：
- 使用os.path.join构建路径
- 避免硬编码分隔符
- 使用bpy.path模块处理Blender路径
