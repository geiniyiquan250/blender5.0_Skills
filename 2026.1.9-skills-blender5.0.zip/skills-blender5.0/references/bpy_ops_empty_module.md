# bpy.ops.empty - 空对象操作模块

Blender空对象操作符，用于创建和管理空对象，常用作占位符、父子关系锚点或自定义属性载体。

## 概述

`bpy.ops.empty` 模块提供用于操作Blender中空对象的功能。空对象是不可见的对象，可用于组织场景层级、设置变换中心点或作为脚本的占位符。

## 核心功能

### 空对象创建

```python
import bpy

# 添加普通空对象
bpy.ops.object.empty_add(
    type='PLAIN_AXES',
    location=(0, 0, 0),
    rotation=(0, 0, 0)
)

# 添加箭头空对象
bpy.ops.object.empty_add(
    type='ARROWS',
    location=(2.0, 0, 0)
)

# 添加单十字空对象
bpy.ops.object.empty_add(
    type='SINGLE_ARROW',
    location=(0, 2.0, 0)
)

# 添加球体空对象
bpy.ops.object.empty_add(
    type='SPHERE',
    location=(0, 0, 2.0)
)

# 添加立方体空对象
bpy.ops.object.empty_add(
    type='CUBE',
    location=(1.0, 1.0, 1.0)
)

# 添加圆锥体空对象
bpy.ops.object.empty_add(
    type='CONE',
    location=(3.0, 3.0, 0)
)

# 添加图像空对象
bpy.ops.object.empty_add(
    type='IMAGE',
    location=(0, 0, 0)
)
```

### 空对象显示设置

```python
# 设置空对象显示类型
empty = bpy.context.active_object
empty.empty_display_type = 'PLAIN_AXES'
empty.empty_display_type = 'ARROWS'
empty.empty_display_type = 'SINGLE_ARROW'
empty.empty_display_type = 'SPHERE'
empty.empty_display_type = 'CUBE'
empty.empty_display_type = 'CONE'
empty.empty_display_type = 'CIRCLE'
empty.empty_display_type = 'DIAMOND'
empty.empty_display_type = 'THICK_CROSS'
empty.empty_display_type = 'SLIM_CROSS'
empty.empty_display_type = 'IMAGE'

# 设置显示大小
empty.empty_display_size = 0.5

# 设置图像
if empty.empty_display_type == 'IMAGE':
    empty.data.source = '//reference.png'

# 始终显示图像
empty.data.use_alpha = True
```

### 空对象变换

```python
# 移动空对象
empty.location = (5.0, 0, 0)

# 旋转空对象
empty.rotation_euler = (0, 0, math.radians(45))

# 缩放空对象
empty.scale = (1.0, 2.0, 1.0)

# 应用变换
bpy.ops.object.transform_apply(
    location=True,
    rotation=True,
    scale=True
)

# 设置父对象
child = bpy.data.objects['Cube']
empty.select_set(True)
child.select_set(True)
bpy.context.view_layer.objects.active = empty
bpy.ops.object.parent_set()

# 清除父对象
bpy.ops.object.parent_clear(
    type='CLEAR_KEEP_TRANSFORM'
)
```

### 空对象作为占位符

```python
# 创建网格占位符
bpy.ops.object.empty_add(type='SPHERE')
placeholder = bpy.context.active_object
placeholder.name = 'Placeholder_Cube'
placeholder.empty_display_size = 1.0
placeholder.empty_display_type = 'CUBE'

# 创建相机目标空对象
bpy.ops.object.empty_add(type='PLAIN_AXES')
camera_target = bpy.context.active_object
camera_target.name = 'CameraTarget'
bpy.context.scene.camera.data.target = camera_target

# 创建空对象组
bpy.ops.object.empty_add(type='SPHERE')
group_root = bpy.context.active_object
group_root.name = 'Group_Root'

# 将多个对象设为子对象
for obj in ['Cube', 'Sphere', 'Cylinder']:
    bpy.ops.object.empty_add(type='SPHERE')
    child = bpy.context.active_object
    child.name = f'Child_{obj}'
    child.parent = group_root
    child.location = (i * 2, 0, 0)
```

## 实用函数

```python
def create_placeholder(name, location, display_type='CUBE', size=1.0):
    """创建占位符空对象"""
    bpy.ops.object.empty_add(type=display_type, location=location)
    empty = bpy.context.active_object
    empty.name = name
    empty.empty_display_size = size
    return empty

def create_empty_group(name, location, children_names=None):
    """创建空对象组"""
    bpy.ops.object.empty_add(type='SPHERE', location=location)
    group = bpy.context.active_object
    group.name = name
    
    if children_names:
        for child_name in children_names:
            child = bpy.data.objects.get(child_name)
            if child:
                child.parent = group
    
    return group

def setup_camera_target(camera_name, target_name, offset=(0, 0, 0)):
    """设置相机目标空对象"""
    camera = bpy.data.objects.get(camera_name)
    target = bpy.data.objects.get(target_name)
    
    if camera and target:
        bpy.context.view_layer.objects.active = camera
        camera.select_set(True)
        target.select_set(True)
        bpy.ops.object.constraint_add(type='TRACK_TO')
        camera.constraints['Track To'].target = target
        camera.constraints['Track To'].track_axis = 'TRACK_NEGATIVE_Z'
        camera.constraints['Track To'].up_axis = 'UP_Y'

def create_rig_pivot(name, location, axis='Z'):
    """创建骨骼绑定枢轴空对象"""
    bpy.ops.object.empty_add(type='SPHERE', location=location)
    pivot = bpy.context.active_object
    pivot.name = name
    pivot.empty_display_size = 0.2
    
    if axis == 'X':
        pivot.empty_display_type = 'SINGLE_ARROW'
        pivot.rotation_euler = (0, math.radians(90), 0)
    elif axis == 'Y':
        pivot.empty_display_type = 'SINGLE_ARROW'
        pivot.rotation_euler = (math.radians(90), 0, 0)
    else:
        pivot.empty_display_type = 'SINGLE_ARROW'
    
    return pivot

def create_image_reference(image_path, location, scale=1.0):
    """创建图像参考空对象"""
    bpy.ops.object.empty_add(type='IMAGE', location=location)
    ref = bpy.context.active_object
    ref.name = 'ImageReference'
    ref.data.source = image_path
    ref.empty_display_size = scale
    return ref

def batch_create_waypoints(names, locations, display_type='SPHERE'):
    """批量创建路径点空对象"""
    waypoints = []
    for name, loc in zip(names, locations):
        bpy.ops.object.empty_add(type=display_type, location=loc)
        wp = bpy.context.active_object
        wp.name = name
        waypoints.append(wp)
    return waypoints
```

## 常见问题排查

### 空对象不可见
```python
# 检查显示类型
empty = bpy.context.active_object
print(f"显示类型: {empty.empty_display_type}")

# 检查显示大小
print(f"显示大小: {empty.empty_display_size}")

# 检查隐藏状态
print(f"隐藏: {empty.hide_viewport}")

# 设置可见
empty.hide_viewport = False

# 增大显示大小
empty.empty_display_size = 1.0

# 切换显示类型
empty.empty_display_type = 'CUBE'
```

### 空对象显示问题
```python
# 检查显示比例
print(f"比例: {empty.scale}")

# 重置显示设置
empty.empty_display_type = 'PLAIN_AXES'
empty.empty_display_size = 0.5

# 同步显示设置到所有空对象
for obj in bpy.data.objects:
    if obj.type == 'EMPTY':
        obj.empty_display_type = empty.empty_display_type
        obj.empty_display_size = empty.empty_display_size
```

### 父子关系问题
```python
# 检查父对象
child = bpy.context.active_object
print(f"父对象: {child.parent}")

# 检查子对象
parent = bpy.context.active_object
children = [obj for obj in bpy.data.objects if obj.parent == parent]
print(f"子对象数: {len(children)}")

# 设置父对象
child.parent = parent
bpy.ops.object.parent_set()

# 清除父对象
bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
```
