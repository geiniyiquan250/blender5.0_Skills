# bpy.ops.render 模块

渲染操作模块，用于控制渲染设置和执行渲染操作。

## 概述

bpy.ops.render 模块包含用于设置渲染参数、执行渲染和查看渲染结果的运算符。这些运算符控制渲染引擎、输出设置和渲染过程。

## 常用操作

### 渲染执行

```python
import bpy

# 渲染当前帧
bpy.ops.render.render(write_still=False)

# 渲染动画
bpy.ops.render.render(animation=True, write_still=False)

# 渲染区域
bpy.ops.render.render(use_area=False)

# 背景渲染
bpy.ops.render.render(background=True)

# 取消渲染
bpy.ops.render.cancel()

# 查看渲染
bpy.ops.render.view_show()
```

### 渲染设置

```python
# 引擎选择
bpy.ops.render.engine_set(engine='CYCLES')
bpy.ops.render.engine_set(engine='BLENDER_EEVEE')

# 设置渲染分辨率
bpy.ops.render.render()

# 设置采样
bpy.ops.render.render()
```

### 视口渲染

```python
# 渲染视口
bpy.ops.render.opengl()

# 渲染视口动画
bpy.ops.render.opengl(animation=True)

# 渲染视口并保存
bpy.ops.render.opengl(write_still=True)

# 渲染视口区域
bpy.ops.render.opengl(view_context=False)
```

### 渲染层设置

```python
# 切换渲染层
bpy.ops.render.render_set()

# 设置渲染层
bpy.ops.render.render_set(layer='RenderLayer')

# 清除渲染层
bpy.ops.render.render_clear()
```

### 渲染 Pass 设置

```python
# 切换Pass
bpy.ops.render.render_set()

# 添加Pass
bpy.ops.render.render_set()

# 移除Pass
bpy.ops.render.render_set()
```

### 图像操作

```python
# 打开渲染结果
bpy.ops.render.read_render()

# 保存渲染
bpy.ops.render.render()

# 清除渲染结果
bpy.ops.render.render_clear()

# 重新加载渲染结果
bpy.ops.render.read_render()
```

### 动画播放

```python
# 播放渲染预览
bpy.ops.render.play_rendered_anim()

# 暂停播放
bpy.ops.render.play_rendered_anim()
```

## 实际应用示例

### 创建标准渲染设置

```python
def setup_standard_render():
    """设置标准渲染参数"""
    scene = bpy.context.scene
    
    # 设置渲染引擎
    scene.render.engine = 'CYCLES'
    
    # 设置分辨率
    scene.render.resolution_x = 1920
    scene.render.resolution_y = 1080
    scene.render.resolution_percentage = 100
    
    # 设置帧范围
    scene.frame_start = 1
    scene.frame_end = 250
    scene.render.fps = 24
    
    # 设置输出格式
    scene.render.image_settings.file_format = 'PNG'
    scene.render.filepath = '//renders/frame_'
    
    return scene
```

### 创建批量渲染

```python
def batch_render_scenes(scene_files, output_dir):
    """批量渲染多个场景"""
    import os
    
    for scene_file in scene_files:
        # 打开场景
        bpy.ops.wm.open_mainfile(filepath=scene_file)
        
        # 获取场景名称
        scene_name = os.path.splitext(os.path.basename(scene_file))[0]
        
        # 设置输出路径
        bpy.context.scene.render.filepath = os.path.join(
            output_dir,
            f'{scene_name}_'
        )
        
        # 执行渲染
        bpy.ops.render.render(
            animation=True,
            write_still=False
        )
```

### 创建分层渲染

```python
def setup分层_render(layers_config):
    """设置分层渲染"""
    scene = bpy.context.scene
    
    # 启用分层渲染
    scene.render.use_multilayer = True
    
    # 配置渲染层和Pass
    for layer_name, passes in layers_config.items():
        if layer_name not in scene.render.layers:
            continue
            
        render_layer = scene.render.layers[layer_name]
        
        # 设置Pass
        render_layer.use_pass_combined = 'COMBINED' in passes
        render_layer.use_pass_z = 'DEPTH' in passes
        render_layer.use_pass_normal = 'NORMAL' in passes
        render_layer.use_pass_diffuse = 'DIFFUSE' in passes
        render_layer.use_pass_glossy = 'GLOSSY' in passes
        render_layer.use_pass_emit = 'EMIT' in passes
        render_layer.use_pass_shadow = 'SHADOW' in passes
    
    return scene.render
```

### 创建渲染队列

```python
def create_render_queue(render_tasks):
    """创建渲染队列"""
    for task in render_tasks:
        scene_name = task['scene']
        output_path = task['output']
        frame_start = task.get('start', 1)
        frame_end = task.get('end', 250)
        
        # 设置帧范围
        bpy.context.scene.frame_start = frame_start
        bpy.context.scene.frame_end = frame_end
        
        # 设置输出
        bpy.context.scene.render.filepath = output_path
        
        # 渲染
        bpy.ops.render.render(
            animation=True,
            write_still=False
        )
```

### 创建高分辨率渲染

```python
def setup_high_resolution_render(width=8192, height=8192, samples=500):
    """设置高分辨率渲染"""
    scene = bpy.context.scene
    
    # 设置分辨率
    scene.render.resolution_x = width
    scene.render.resolution_y = height
    
    # 设置采样
    scene.cycles.samples = samples
    scene.cycles.adaptive_threshold = 0.01
    
    # 设置Tiles
    scene.cycles.tile_size = 2048
    
    # 启用GPU渲染
    scene.cycles.device = 'GPU'
    
    return scene
```

### 创建Web渲染

```python
def setup_web_render():
    """设置网页渲染参数"""
    scene = bpy.context.scene
    
    # 设置适合Web的分辨率
    scene.render.resolution_x = 1920
    scene.render.resolution_y = 1080
    
    # 设置Web格式
    scene.render.image_settings.file_format = 'WEBP'
    scene.render.image_settings.webp_codec = 'LOSSY'
    scene.render.image_settings.quality = 90
    
    # 优化透明度
    scene.render.image_settings.exr_codec = 'DWAA'
    
    return scene
```

### 创建动画渲染

```python
def setup_animation_render(output_path, start_frame=1, end_frame=250):
    """设置动画渲染"""
    scene = bpy.context.scene
    
    # 设置帧范围
    scene.frame_start = start_frame
    scene.frame_end = end_frame
    
    # 设置输出格式
    scene.render.image_settings.file_format = 'FFMPEG'
    scene.render.ffmpeg.format = 'MPEG4'
    scene.render.ffmpeg.codec = 'H264'
    scene.render.ffmpeg.constant_rate_factor = 'HIGH'
    
    # 设置输出路径
    scene.render.filepath = output_path
    
    # 设置音频（如果有）
    scene.render.ffmpeg.audio_codec = 'AAC'
    
    return scene
```

### 创建实时预览渲染

```python
def setup_realtime_preview():
    """设置实时预览渲染"""
    scene = bpy.context.scene
    
    # 使用Eevee引擎
    scene.render.engine = 'BLENDER_EEVEE'
    
    # 优化实时性能
    scene.eevee.taa_render_samples = 16
    scene.eevee.use_gtao = True
    scene.eevee.use_bloom = True
    scene.eevee.use_ssr = True
    
    # 降低采样
    scene.eevee.samples = 32
    
    # 启用快速GI
    scene.eevee.use_gtao = True
    
    return scene
```

## 使用场景

- **静态渲染**：渲染单帧图像
- **动画渲染**：渲染动画序列
- **分层渲染**：分离不同渲染元素
- **批量渲染**：处理多个渲染任务
- **实时预览**：快速预览效果
- **高分辨率**：输出大型图像

## 注意事项

- 高采样增加渲染时间
- 高分辨率需要更多内存
- 动画渲染需要足够磁盘空间
- GPU渲染需要兼容设备
- 分层渲染增加处理时间
- 取消渲染可能留下临时文件
