# bpy.ops.clip - Clip Operations Module

剪辑操作模块，用于视频追踪、相机解算和运动导入。

## 概述

`bpy.ops.clip` 模块是Blender运动追踪工作区的核心操作模块，提供了视频素材加载、特征点检测、追踪、相机解算、三维重建等功能。该模块涵盖了从素材导入到最终数据应用的全流程。

## 核心功能

### 素材管理

```python
import bpy

# 打开视频素材
bpy.ops.clip.open(
    filepath='',
    directory='',
    files='',
    filter_blender=False,
    filter_image=True,
    filter_movie=True,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    filter_btx=False,
    filter_alembic=False,
    filter_usd=False,
    filter_obj=False,
    filter_volume=False,
    filter_folder=True,
    filter_blenlib=False,
    filemode=9,
    relative_path=True,
    display_type='DEFAULT',
    sort_method=''
)

# 加载输入素材
bpy.ops.clip.load_input()

# 加载视频
bpy.ops.clip.load_movie()
```

### 标记点操作

```python
# 添加标记
bpy.ops.clip.add_marker(location=(0.0, 0.0))

# 点击位置添加标记
bpy.ops.clip.add_marker_at_click()

# 移动添加标记
bpy.ops.clip.add_marker_move()

# 滑动添加标记
bpy.ops.clip.add_marker_slide()

# 删除标记
bpy.ops.clip.delete_marker(confirm=True)

# 删除代理
bpy.ops.clip.delete_proxy()

# 删除轨迹
bpy.ops.clip.delete_track(confirm=True)

# 锁定轨迹
bpy.ops.clip.lock_tracks()

# 解锁轨迹
bpy.ops.clip.unlock_tracks()

# 禁用标记
bpy.ops.clip.disable_markers(action='DISABLE')
```

### 特征点检测

```python
# 检测特征点
bpy.ops.clip.detect_features(
    placement='FRAME',
    margin=16,
    threshold=0.5,
    min_distance=120
)
```

### 追踪操作

```python
# 选择操作
bpy.ops.clip.select()
bpy.ops.clip.select_all(action='SELECT')
bpy.ops.clip.select_border(gesture_mode=0, xmin=0, xmax=0, ymin=0, ymax=0)
bpy.ops.clip.select_circle(x=0, y=0, radius=0)
bpy.ops.clip.select_lasso(path=[], mode='SET')
bpy.ops.clip.select_grouped(type='', extend=False)
bpy.ops.clip.select_less()
bpy.ops.clip.select_more()

# 追踪
# 注意：具体的追踪操作需要结合追踪设置

# 清除轨迹路径
bpy.ops.clip.clear_track_path(action='REMAINED', clear_active=False)

# 过滤轨迹
bpy.ops.clip.filter_tracks(track_threshold=5.0)

# 清理轨迹
bpy.ops.clip.clean_tracks(frames=0, error=0.0, action='SELECT')

# 合并轨迹
bpy.ops.clip.merge_tracks()

# 平均轨迹
bpy.ops.clip.average_tracks(keep_original=True)

# 复制轨迹
bpy.ops.clip.copy_tracks()

# 粘贴轨迹
bpy.ops.clip.paste_tracks()

# 反转轨迹
bpy.ops.clip.track_mirror()

# 连接轨迹
bpy.ops.clip.join_tracks()

# 轨迹转空物体
bpy.ops.clip.track_to_empty()
```

### 平面追踪

```python
# 创建平面轨迹
bpy.ops.clip.create_plane_track()
```

### 相机解算

```python
# 应用解算缩放
bpy.ops.clip.apply_solution_scale(distance=0.0)

# 清除解算
bpy.ops.clip.clear_solution()

# 约束转f曲线
bpy.ops.clip.constraint_to_fcurve()

# 解算转约束
bpy.ops.clip.solver_as_constraint()

# 解算约束转f曲线
bpy.ops.clip.solver_constraint_to_fcurve()

# 束转网格
bpy.ops.clip.bundles_to_mesh()

# 曲线插值
bpy.ops.clip.graph_interpolate()
```

### 稳定化

```python
# 添加稳定器
bpy.ops.clip.stabilizer_add()

# 添加稳定器目标
bpy.ops.clip.stabilizer_add_target()

# 移除稳定器
bpy.ops.clip.stabilizer_remove()

# 选择稳定器
bpy.ops.clip.stabilizer_select()

# 设置稳定器为激活
bpy.ops.clip.stabilizer_set_active()
```

### 代理管理

```python
# 创建代理
bpy.ops.clip.make_proxy()

# 重建代理
bpy.ops.clip.rebuild_proxy()
```

### 关键帧操作

```python
# 插入关键帧
bpy.ops.clip.keyframe_insert()

# 删除关键帧
bpy.ops.clip.keyframe_delete()

# 设置解算关键帧
bpy.ops.clip.set_solver_keyframe()
```

### 轨迹颜色

```python
# 添加轨迹颜色预设
bpy.ops.clip.track_color_preset_add(name='', remove_name=False, remove_active=False, color=(0, 0, 0))
```

### 追踪对象管理

```python
# 创建追踪对象
bpy.ops.clip.tracking_object_create()

# 删除追踪对象
bpy.ops.clip.tracking_object_delete()
```

### 追踪设置

```python
# 添加追踪设置预设
bpy.ops.clip.tracking_settings_preset_add(name='', remove_name=False, remove_active=False)
```

### 相机预设

```python
# 添加相机预设
bpy.ops.clip.camera_preset_add(name='', remove_name=False, remove_active=False, use_focal_length=True)
```

### 用户预设

```python
# 添加用户预设
bpy.ops.clip.user_preset_add(name='', remove_name=False, remove_active=False)
```

### 帧操作

```python
# 跳转帧
bpy.ops.clip.frame_jump(position='PATHSTART')

# 改变帧
bpy.ops.clip.change_frame(frame=0)

# 设置场景帧
bpy.ops.clip.set_scene_frames()

# 预读取
bpy.ops.clip.prefetch()
```

### 视图操作

```python
# 视图操作
bpy.ops.clip.view_all()
bpy.ops.clip.view_center_cursor()
bpy.ops.clip.view_center_pick()
bpy.ops.clip.view_selected()
bpy.ops.clip.view_ndof()
bpy.ops.clip.view_zoom_in()
bpy.ops.clip.view_zoom_out()
bpy.ops.clip.view_zoom_ratio(ratio=1.0)

# 曲线视图
bpy.ops.clip.graph_view_all()
bpy.ops.clip.graph_center_current_frame()

# 时间轴视图
bpy.ops.clip.dopesheet_view_all()

# 设置活动剪辑
bpy.ops.clip.set_active_clip()
```

### 光标操作

```python
# 设置光标
bpy.ops.clip.cursor_set(location=(0.0, 0.0))

# 移动2D光标
bpy.ops.clip.move_2d_cursor(location=(0.0, 0.0))
```

### 曲线编辑

```python
# 曲线操作
bpy.ops.clip.graph_select(location=(0.0, 0.0), extend=False)
bpy.ops.clip.graph_select_all(action='SELECT')
bpy.ops.clip.graph_select_border(gesture_mode=0, xmin=0, xmax=0, ymin=0, ymax=0)
bpy.ops.clip.graph_delete_curve()
bpy.ops.clip.graph_delete_knot()
bpy.ops.clip.graph_follow_batch()
```

### 隐藏操作

```python
# 隐藏轨迹
bpy.ops.clip.hide_tracks(action='HIDE', unselected=False)
```

### 模式设置

```python
# 设置模式
bpy.ops.clip.mode_set(mode='TRACKING')
```

## 实用函数

```python
# 自动追踪选定标记
def auto_track_selected(backwards=False, sequence=False):
    # 设置追踪参数
    # 执行追踪
    pass

# 批量处理视频素材
def load_video_sequence(directory):
    # 加载目录下所有视频文件
    pass

# 创建完整的相机解算流程
def full_camera_solve():
    # 1. 加载素材
    # 2. 检测特征
    # 3. 追踪
    # 4. 解算相机
    pass

# 应用追踪数据到场景
def apply_tracking_to_scene():
    # 创建相机
    # 应用约束
    pass
```

## 常见问题排查

**问题：特征点检测失败**

- 检查视频素材是否清晰
- 调整检测参数（margin、threshold、min_distance）
- 尝试在对比度高的区域手动添加标记

**问题：追踪不稳定**

- 减小追踪搜索半径
- 启用子像素精度
- 清理误差大的追踪点
- 使用更好的特征点

**问题：相机解算失败**

- 确保有足够的特征点覆盖画面
- 检查是否有移动物体干扰
- 尝试增加关键帧数量
- 调整最小匹配数量

**问题：代理生成失败**

- 检查磁盘空间
- 确认输出路径可写
- 尝试重新生成代理

**问题：追踪数据无法应用**

- 确保解算已成功完成
- 检查场景中是否有冲突的相机
- 尝试重建场景结构

**问题：视频不同步**

- 检查素材帧率设置
- 确认场景帧率与素材匹配
- 调整时间偏移

**问题：稳定化效果不佳**

- 增加稳定器标记点数量
- 调整稳定化权重
- 尝试不同的稳定化模式
