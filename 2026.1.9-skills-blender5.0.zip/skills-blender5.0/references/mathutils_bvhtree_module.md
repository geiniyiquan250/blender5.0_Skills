# mathutils.bvhtree - BVHTree Utilities Module

BVHTree模块提供了包围体层次树（Bounding Volume Hierarchy Tree）的创建和查询功能，用于高效的碰撞检测、射线投射和最近点查找。

## 概述

BVHTree是一种空间数据结构，将几何体组织成层次化的包围体，以便快速进行空间查询。它在物理模拟、碰撞检测、光线追踪和视觉选择等场景中非常有用。

## 核心功能

### BVHTree创建

```python
import bpy
import mathutils
from mathutils.bvhtree import BVHTree

def create_bvh_from_mesh(mesh):
    """从网格创建BVHTree"""
    verts = [v.co for v in mesh.vertices]
    edges = [e.vertices for e in mesh.edges]
    return BVHTree.FromPolygons(verts, edges)

def create_bvh_from_object(obj):
    """从对象创建BVHTree"""
    if obj.type == 'MESH':
        depsgraph = bpy.context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh()
        try:
            return create_bvh_from_mesh(mesh)
        finally:
            eval_obj.to_mesh_clear()

def create_bvh_from_faces(vertices, face_indices):
    """从顶点和面索引创建BVHTree"""
    return BVHTree.FromPolygons(vertices, face_indices)
```

### 查找最近点

```python
def find_nearest_point(bvh_tree, point):
    """查找BVHTree中最近的点"""
    nearest_co, normal, index, distance = bvh_tree.find_nearest(point)
    return {
        'point': nearest_co,
        'normal': normal,
        'face_index': index,
        'distance': distance
    }

def find_nearest_point_on_mesh(obj, point):
    """在对象表面查找最近点"""
    bvh = create_bvh_from_object(obj)
    if bvh:
        return find_nearest_point(bvh, point)
    return None

def find_all_nearby_points(bvh_tree, point, max_distance):
    """查找一定距离内的所有点"""
    results = []
    bvh_tree.find_nearest_range(point, max_distance, lambda co, no, index, dist: results.append({
        'point': co,
        'normal': no,
        'face_index': index,
        'distance': dist
    }))
    return results
```

### 射线投射

```python
def ray_cast(bvh_tree, origin, direction, distance=1.70141e+38):
    """从原点沿方向发射射线"""
    location, normal, index, distance = bvh_tree.ray_cast(origin, direction, distance)
    if location is not None:
        return {
            'location': location,
            'normal': normal,
            'face_index': index,
            'distance': distance
        }
    return None

def ray_cast_from_mouse(bvh_tree, mouse_pos, camera_matrix, distance=1000):
    """从鼠标位置发射射线"""
    region = bpy.context.region
    rv3d = bpy.context.space_data.region_3d
    view_vector = rv3d.view_vector_from_point(mouse_pos)
    return ray_cast(bvh_tree, mouse_pos, view_vector, distance)

def ray_cast_all_intersections(bvh_tree, origin, direction):
    """获取射线的所有交点"""
    results = []
    def callback(loc, nor, idx, dist):
        results.append({'location': loc, 'normal': nor, 'index': idx, 'distance': dist})
    bvh_tree.ray_cast(origin, direction, lambda loc, nor, idx, dist: callback(loc, nor, idx, dist) or dist)
    return results
```

### 碰撞检测

```python
def check_collision(bvh1, bvh2):
    """检查两个BVHTree是否相交"""
    overlapping = bvh1.overlap(bvh2)
    return len(overlapping) > 0

def get_colliding_faces(bvh1, bvh2):
    """获取相交的面对"""
    return bvh1.overlap(bvh2)

def get_collision_pairs(trees_dict):
    """获取所有碰撞的物体对"""
    objects = list(trees_dict.keys())
    collisions = []
    for i, obj1 in enumerate(objects):
        for obj2 in objects[i+1:]:
            if check_collision(trees_dict[obj1], trees_dict[obj2]):
                collisions.append((obj1, obj2))
    return collisions

def distance_between_objects(obj1, obj2):
    """计算两个对象之间的最短距离"""
    bvh1 = create_bvh_from_object(obj1)
    bvh2 = create_bvh_from_object(obj2)
    if bvh1 and bvh2:
        pairs = bvh1.overlap(bvh2)
        if pairs:
            min_dist = float('inf')
            for pair in pairs:
                for p1 in pair[0]:
                    for p2 in pair[1]:
                        dist = (p1 - p2).length
                        if dist < min_dist:
                            min_dist = dist
            return min_dist
    return None
```

## 实用函数

### 简单封装

```python
def build_bvh(obj, depsgraph=None):
    """快速构建对象的BVH树"""
    if depsgraph is None:
        depsgraph = bpy.context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    try:
        verts = [v.co for v in mesh.vertices]
        polys = [p.vertices for p in mesh.polygons]
        return BVHTree.FromPolygons(verts, polys)
    finally:
        eval_obj.to_mesh_clear()

def update_scene_bvh():
    """更新场景中所有对象的BVH"""
    bvh_trees = {}
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            bvh_trees[obj.name] = build_bvh(obj, depsgraph)
    return bvh_trees
```

### 高级查询

```python
def find_points_in_sphere(bvh_tree, center, radius):
    """查找球体内的所有点"""
    points = []
    bvh_tree.find_nearest_range(center, radius, 
        lambda co, no, idx, dist: points.append({'point': co, 'index': idx}))
    return points

def get_face_center(bvh_tree, face_index):
    """获取指定面的中心点"""
    for vert in bvh_tree.polygons[face_index]:
        pass
    return None

def project_point_to_surface(bvh_tree, point):
    """将点投影到BVH表面"""
    result = bvh_tree.find_nearest(point)
    if result[0] is not None:
        return result[0], result[1], result[3]
    return None, None, None
```

## 常见问题排查

### 性能问题

BVHTree查询很慢：
- 确保BVHTree只创建一次并复用
- 对于动态对象，使用eval对象创建
- 使用较低的精度设置可以提高速度

内存占用过高：
- 及时清理不再使用的BVHTree
- 对于大型场景，分区域创建BVHTree

### 射线投射无结果

射线方向错误：
- 确保方向向量是归一化的
- 检查原点和方向是否在正确的坐标系中

距离值太小：
- 增大ray_cast的distance参数
- 默认距离可能不足以到达目标

### 碰撞检测不准确

顶点位置不匹配：
- 确保使用evaluated对象获取网格数据
- 检查对象的世界矩阵变换

面索引无效：
- 检查返回的face_index是否在有效范围内
- 网格数据可能已更改，需要重新创建BVHTree
