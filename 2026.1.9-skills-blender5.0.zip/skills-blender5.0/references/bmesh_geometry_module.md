# bmesh.geometry 模块

bmesh.geometry 模块提供了 BMesh 数据结构的几何运算函数，包括距离计算、射线投射、网格分析等操作。

## 几何运算概述

几何运算模块包含了一系列用于处理三维几何数据的实用函数，这些函数可以直接应用于 BMesh 对象。

### 何时使用几何运算

- 计算点与几何元素之间的距离
- 执行射线投射检测
- 分析网格属性
- 进行几何变换和计算

## 距离计算

### bmesh.geometry.distance_point_to_plane

计算点到平面的距离。

```python
import bmesh
import bpy
from mathutils import Vector

# 获取当前 BMesh
bm = bmesh.from_edit_mesh(bpy.context.object.data)

# 定义平面（通过三个顶点定义）
v1 = bm.verts[0]
v2 = bm.verts[1]
v3 = bm.verts[2]

# 定义测试点
point = Vector((1.0, 2.0, 3.0))

# 计算点到平面的距离
plane_normal = (v2.co - v1.co).cross(v3.co - v1.co).normalized()
distance = bmesh.geometry.distance_point_to_plane(point, v1.co, plane_normal)

print(f"点到平面的距离: {distance}")
```

### bmesh.geometry.distance_point_to_face

计算点到面的距离。

```python
import bmesh
import bpy
from mathutils import Vector

# 获取当前 BMesh
bm = bmesh.from_edit_mesh(bpy.context.object.data)

# 获取一个面
face = bm.faces[0]

# 定义测试点
point = Vector((5.0, 5.0, 5.0))

# 计算点到面的最短距离
distance = bmesh.geometry.distance_point_to_face(point, face)

print(f"点到面的距离: {distance:.4f}")
```

## 射线投射

### bmesh.geometry.ray_cast

执行射线投射检测。

```python
import bmesh
import bpy
from mathutils import Vector, Matrix

# 获取当前 BMesh
bm = bmesh.from_edit_mesh(bpy.context.object.data)

# 定义射线原点（相机位置）
ray_origin = Vector((10.0, 10.0, 10.0))

# 定义射线方向（朝向场景中心）
ray_direction = (Vector((0.0, 0.0, 0.0)) - ray_origin).normalized()

# 执行射线投射
location, normal, face_index = bmesh.geometry.ray_cast(
    bm, ray_origin, ray_direction
)

if location:
    print(f"击中位置: {location}")
    print(f"击中法线: {normal}")
    print(f"击中面索引: {face_index}")
else:
    print("射线未击中任何几何体")
```

### 多射线投射

```python
import bmesh
import bpy
from mathutils import Vector

def ray_cast_multiple(bm, origins, directions):
    """执行多条射线的投射检测"""
    results = []
    
    for origin, direction in zip(origins, directions):
        result = bmesh.geometry.ray_cast(bm, origin, direction)
        results.append(result)
    
    return results

# 示例：从多个光源位置投射射线
bm = bmesh.from_edit_mesh(bpy.context.object.data)

light_positions = [
    Vector((10.0, 10.0, 10.0)),
    Vector((-10.0, 10.0, 10.0)),
    Vector((0.0, 10.0, -10.0))
]

ray_directions = [
    (Vector((0.0, 0.0, 0.0)) - pos).normalized()
    for pos in light_positions
]

results = ray_cast_multiple(bm, light_positions, ray_directions)

for i, (loc, norm, face_idx) in enumerate(results):
    print(f"射线 {i}: {'击中' if loc else '未击中'}")
```

## 网格分析

### bmesh.geometry.mesh_area

计算网格总表面积。

```python
import bmesh
import bpy

# 获取当前 BMesh
bm = bmesh.from_edit_mesh(bpy.context.object.data)

# 计算总表面积
total_area = bmesh.geometry.mesh_area(bm)

print(f"网格总表面积: {total_area:.4f} 平方单位")

# 计算单个面的面积
for i, face in enumerate(bm.faces):
    area = bmesh.geometry.face_area(face)
    print(f"面 {i} 面积: {area:.4f}")
```

### bmesh.geometry.face_area

计算单个面的面积。

```python
import bmesh
import bpy

# 获取当前 BMesh
bm = bmesh.from_edit_mesh(bpy.context.object.data)

# 计算每个面的面积
for face in bm.faces:
    area = bmesh.geometry.face_area(face)
    if area > 0.1:  # 找出较大的面
        print(f"面 {face.index}: 面积 = {area:.4f}")
```

### bmesh.geometry.bound_box_2d

计算二维边界框。

```python
import bmesh
import bpy
import numpy as np

def get_mesh_bbox_2d(bm, axis='XY'):
    """获取网格在指定平面上的二维边界框"""
    vertices = [v.co for v in bm.verts]
    
    if axis == 'XY':
        coords = [(v.x, v.y) for v in vertices]
    elif axis == 'XZ':
        coords = [(v.x, v.z) for v in vertices]
    elif axis == 'YZ':
        coords = [(v.y, v.z) for v in vertices]
    else:
        coords = [(v.x, v.y) for v in vertices]
    
    min_x = min(c[0] for c in coords)
    max_x = max(c[0] for c in coords)
    min_y = min(c[1] for c in coords)
    max_y = max(c[1] for c in coords)
    
    return (min_x, min_y, max_x, max_y)

# 获取 XY 平面边界框
bm = bmesh.from_edit_mesh(bpy.context.object.data)
bbox = get_mesh_bbox_2d(bm, 'XY')

print(f"X 范围: {bbox[0]:.2f} 到 {bbox[2]:.2f}")
print(f"Y 范围: {bbox[1]:.2f} 到 {bbox[3]:.2f}")
```

## 实际应用示例

### 碰撞检测系统

```python
import bmesh
import bpy
from mathutils import Vector, Matrix

class BMeshCollisionDetector:
    def __init__(self, obj):
        self.obj = obj
        self.bm = bmesh.new()
        self.bm.from_mesh(obj.data)
        self.bm.verts.ensure_lookup_table()
        self.bm.faces.ensure_lookup_table()
    
    def point_inside_mesh(self, point):
        """检查点是否在网格内部"""
        # 使用射线投射方法：从点到无穷远的射线
        direction = Vector((0.0, 0.0, 1.0))
        
        # 多次投射以提高准确性
        intersections = 0
        
        for test_dir in [
            Vector((1.0, 0.0, 0.0)),
            Vector((0.0, 1.0, 0.0)),
            Vector((0.0, 0.0, 1.0)),
            Vector((1.0, 1.0, 1.0)).normalized()
        ]:
            loc, norm, face_idx = bmesh.geometry.ray_cast(
                self.bm, point - test_dir * 1000, test_dir
            )
            if loc:
                intersections += 1
        
        return intersections % 2 == 1
    
    def distance_to_surface(self, point):
        """计算点到网格表面的最短距离"""
        min_distance = float('inf')
        
        for face in self.bm.faces:
            dist = bmesh.geometry.distance_point_to_face(point, face)
            if dist < min_distance:
                min_distance = dist
        
        return min_distance
    
    def closest_point_on_surface(self, point):
        """找到网格表面上最近的点"""
        closest_point = None
        min_distance = float('inf')
        
        for face in self.bm.faces:
            # 计算投影点
            plane_normal = face.normal
            projected = bmesh.geometry.distance_point_to_plane(
                point, face.calc_center_median(), plane_normal
            )
            
            # 检查点是否在面内
            face_point = point - plane_normal * projected
            if self._point_in_face(face_point, face):
                dist = abs(projected)
                if dist < min_distance:
                    min_distance = dist
                    closest_point = face_point
        
        # 如果没有找到面内投影，检查边和顶点
        if not closest_point:
            closest_point, _ = self.closest_point_on_edges(point)
        
        return closest_point
    
    def _point_in_face(self, point, face):
        """检查点是否在面内"""
        # 使用重心坐标方法
        return face.point_inside(point)
    
    def closest_point_on_edges(self, point):
        """找到网格边上最近的点"""
        closest_point = None
        min_distance = float('inf')
        
        for edge in self.bm.edges:
            v1, v2 = edge.verts
            edge_vec = v2.co - v1.co
            edge_length = edge_vec.length
            
            if edge_length < 0.0001:
                continue
            
            # 计算点到线段的投影
            t = ((point - v1.co).dot(edge_vec)) / (edge_length * edge_length)
            t = max(0.0, min(1.0, t))
            
            closest = v1.co + edge_vec * t
            dist = (point - closest).length
            
            if dist < min_distance:
                min_distance = dist
                closest_point = closest
        
        return closest_point, min_distance
    
    def intersect_ray(self, ray_origin, ray_direction):
        """检测射线与网格的交点"""
        location, normal, face_index = bmesh.geometry.ray_cast(
            self.bm, ray_origin, ray_direction
        )
        
        return location, normal, face_index
    
    def intersect_segment(self, point1, point2):
        """检测线段与网格的交点"""
        direction = (point2 - point1).normalized()
        distance = (point2 - point1).length
        
        location, normal, face_index = bmesh.geometry.ray_cast(
            self.bm, point1, direction, distance
        )
        
        return location, normal, face_index
    
    def cleanup(self):
        """清理资源"""
        self.bm.free()


def detect_collisions(object_a, object_b):
    """检测两个对象之间的碰撞"""
    detector_a = BMeshCollisionDetector(object_a)
    detector_b = BMeshCollisionDetector(object_b)
    
    collision_points = []
    
    # 检测 B 的顶点是否在 A 内部
    for vert in detector_b.bm.verts:
        world_co = object_b.matrix_world @ vert.co
        if detector_a.point_inside_mesh(world_co):
            collision_points.append(('vertex_A', world_co))
    
    # 检测 A 的顶点是否在 B 内部
    for vert in detector_a.bm.verts:
        world_co = object_a.matrix_world @ vert.co
        if detector_b.point_inside_mesh(world_co):
            collision_points.append(('vertex_B', world_co))
    
    detector_a.cleanup()
    detector_b.cleanup()
    
    return collision_points
```

### 网格优化工具

```python
import bmesh
import bpy
from mathutils import Vector

class MeshOptimizer:
    def __init__(self, obj):
        self.obj = obj
        self.bm = bmesh.new()
        self.bm.from_mesh(obj.data)
    
    def remove_small_faces(self, min_area=0.001):
        """移除面积过小的面"""
        faces_to_remove = []
        
        for face in self.bm.faces:
            area = bmesh.geometry.face_area(face)
            if area < min_area:
                faces_to_remove.append(face)
        
        for face in faces_to_remove:
            bmesh.ops.delete(self.bm, geom=[face], context='FACES')
        
        print(f"移除了 {len(faces_to_remove)} 个小面")
        return len(faces_to_remove)
    
    def merge_close_vertices(self, threshold=0.001):
        """合并距离过近的顶点"""
        result = bmesh.ops.remove_doubles(
            self.bm,
            verts=self.bm.verts,
            dist=threshold
        )
        
        print(f"合并了 {len(result['vert_len'])} 个顶点")
        return len(result['vert_len'])
    
    def fill_holes(self, hole_size_limit=10):
        """填充孔洞"""
        holes_filled = 0
        
        for face in self.bm.faces:
            face.select_set(False)
        
        # 找到边界边
        boundary_edges = [e for e in self.bm.edges if len(e.link_faces) == 1]
        
        while boundary_edges:
            # 获取边界循环
            boundary_verts = self._get_boundary_loop(boundary_edges[0])
            
            if len(boundary_verts) <= hole_size_limit:
                # 填充孔洞
                bmesh.ops.holes_fill(self.bm, edges=[boundary_edges[0]])
                holes_filled += 1
            
            boundary_edges = [e for e in self.bm.edges if len(e.link_faces) == 1]
        
        print(f"填充了 {holes_filled} 个孔洞")
        return holes_filled
    
    def _get_boundary_loop(self, start_edge):
        """获取边界循环的顶点"""
        loop_verts = []
        current_edge = start_edge
        visited_edges = set()
        
        while current_edge not in visited_edges:
            visited_edges.add(current_edge)
            
            # 获取边界边上的两个顶点
            v1, v2 = current_edge.verts
            
            # 找到下一个边界边
            next_edge = None
            for edge in v2.link_edges:
                if edge != current_edge and len(edge.link_faces) == 1:
                    next_edge = edge
                    break
            
            if next_edge:
                current_edge = next_edge
                loop_verts.append(v1.co.copy())
            else:
                break
        
        return loop_verts
    
    def recalculate_normals(self):
        """重新计算法线"""
        bmesh.ops.recalc_face_normals(self.bm, faces=self.bm.faces)
    
    def triangulate(self):
        """三角化网格"""
        result = bmesh.ops.triangulate(
            self.bm,
            faces=self.bm.faces,
            quad_method='BEAUTY',
            ngon_method='BEAUTY'
        )
        
        print(f"三角化了 {len(result['faces'])} 个面")
        return len(result['faces'])
    
    def decimate(self, ratio=0.5):
        """简化网格"""
        # 计算目标顶点数
        original_vert_count = len(self.bm.verts)
        target_vert_count = int(original_vert_count * ratio)
        
        if target_vert_count < 4:
            print("简化比例太小")
            return 0
        
        result = bmesh.ops.decimate(
            self.bm,
            verts=self.bm.verts,
            edges=self.bm.edges,
            factor=1.0 - ratio,
            use_edge_collapse=True
        )
        
        removed = original_vert_count - len(self.bm.verts)
        print(f"简化网格：移除了 {removed} 个顶点")
        return removed
    
    def apply_changes(self):
        """应用更改到原始网格"""
        self.bm.to_mesh(self.obj.data)
        self.bm.free()
        self.obj.data.update()


def optimize_mesh(obj, remove_small=True, merge_close=True, 
                  triangulate=True, decimate_ratio=None):
    """完整的网格优化流程"""
    optimizer = MeshOptimizer(obj)
    
    if remove_small:
        optimizer.remove_small_faces()
    
    if merge_close:
        optimizer.merge_close_vertices()
    
    if triangulate:
        optimizer.triangulate()
    
    if decimate_ratio is not None:
        optimizer.decimate(decimate_ratio)
    
    optimizer.recalculate_normals()
    optimizer.apply_changes()
    
    print(f"网格 {obj.name} 优化完成")
```

### 几何测量工具

```python
import bmesh
import bpy
from mathutils import Vector, Matrix
import numpy as np

class GeometryMeasurer:
    def __init__(self, obj):
        self.obj = obj
        self.bm = bmesh.new()
        self.bm.from_mesh(obj.data)
        self.bm.verts.ensure_lookup_table()
        self.bm.faces.ensure_lookup_table()
    
    def measure_all(self):
        """执行所有测量"""
        measurements = {
            'bounding_box': self.measure_bounding_box(),
            'surface_area': self.measure_surface_area(),
            'volume': self.measure_volume(),
            'dimensions': self.measure_dimensions(),
            'vertex_count': len(self.bm.verts),
            'edge_count': len(self.bm.edges),
            'face_count': len(self.bm.faces),
            'triangle_count': self._count_triangles(),
            'quad_count': self._count_quads(),
            'ngon_count': self._count_ngons()
        }
        
        return measurements
    
    def measure_bounding_box(self):
        """测量边界框"""
        coords = [v.co for v in self.bm.verts]
        
        min_x = min(v.x for v in coords)
        max_x = max(v.x for v in coords)
        min_y = min(v.y for v in coords)
        max_y = max(v.y for v in coords)
        min_z = min(v.z for v in coords)
        max_z = max(v.z for v in coords)
        
        return {
            'min': Vector((min_x, min_y, min_z)),
            'max': Vector((max_x, max_y, max_z)),
            'center': Vector(( (min_x + max_x) / 2, (min_y + max_y) / 2, (min_z + max_z) / 2)),
            'size': Vector((max_x - min_x, max_y - min_y, max_z - min_z))
        }
    
    def measure_surface_area(self):
        """测量表面积"""
        total_area = 0.0
        
        for face in self.bm.faces:
            if len(face.verts) == 3:
                # 三角形
                v1, v2, v3 = face.verts
                area = 0.5 * (v2.co - v1.co).cross(v3.co - v1.co).length
            elif len(face.verts) == 4:
                # 四边形 - 分割为两个三角形
                v1, v2, v3, v4 = face.verts
                area1 = 0.5 * (v2.co - v1.co).cross(v3.co - v1.co).length
                area2 = 0.5 * (v4.co - v1.co).cross(v3.co - v1.co).length
                area = area1 + area2
            else:
                # 多边形
                area = bmesh.geometry.face_area(face)
            
            total_area += area
        
        return total_area
    
    def measure_volume(self):
        """测量体积（仅对封闭网格有效）"""
        total_volume = 0.0
        
        for face in self.bm.faces:
            if len(face.verts) < 3:
                continue
            
            # 使用有符号体积方法
            v1 = face.verts[0].co
            for i in range(1, len(face.verts) - 1):
                v2 = face.verts[i].co
                v3 = face.verts[i + 1].co
                
                # 计算四面体体积
                cross = (v2 - v1).cross(v3 - v1)
                volume = v1.dot(cross) / 6.0
                total_volume += volume
        
        return abs(total_volume)
    
    def measure_dimensions(self):
        """测量尺寸"""
        bbox = self.measure_bounding_box()
        return bbox['size']
    
    def _count_triangles(self):
        """统计三角形数量"""
        return sum(1 for f in self.bm.faces if len(f.verts) == 3)
    
    def _count_quads(self):
        """统计四边形数量"""
        return sum(1 for f in self.bm.faces if len(f.verts) == 4)
    
    def _count_ngons(self):
        """统计多边形数量"""
        return sum(1 for f in self.bm.faces if len(f.verts) > 4)
    
    def cleanup(self):
        """清理资源"""
        self.bm.free()


def analyze_selected_object():
    """分析选中对象"""
    obj = bpy.context.active_object
    
    if not obj or obj.type != 'MESH':
        print("请选中一个网格对象")
        return
    
    measurer = GeometryMeasurer(obj)
    measurements = measurer.measure_all()
    measurer.cleanup()
    
    print(f"\n=== 对象分析报告: {obj.name} ===")
    print(f"尺寸: X={measurements['dimensions'].x:.3f}, "
          f"Y={measurements['dimensions'].y:.3f}, "
          f"Z={measurements['dimensions'].z:.3f}")
    print(f"表面积: {measurements['surface_area']:.3f}")
    print(f"体积: {measurements['volume']:.3f}")
    print(f"顶点数: {measurements['vertex_count']}")
    print(f"边数: {measurements['edge_count']}")
    print(f"面数: {measurements['face_count']}")
    print(f"  - 三角形: {measurements['triangle_count']}")
    print(f"  - 四边形: {measurements['quad_count']}")
    print(f"  - 多边形: {measurements['ngon_count']}")
```

## 最佳实践

1. **性能考虑**：对于大型网格，尽量减少重复的几何计算
2. **数据更新**：修改 BMesh 后记得调用 bm.to_mesh() 应用更改
3. **法线方向**：确保网格法线方向一致，闭合网格使用统一法线
4. **体积计算**：体积计算要求网格是闭合的，否则结果不准确
5. **射线投射**：使用适当的距离限制可以提高投射性能
