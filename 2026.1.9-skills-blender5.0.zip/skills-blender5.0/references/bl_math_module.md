# bl_math 额外数学函数模块

提供 Blender 专用的额外数学工具函数，补充 Python 标准库和 mathutils 的功能。

## 函数

### clamp

```python
from bl_math import clamp

result = clamp(0.5)           # 0.5
result = clamp(1.5)           # 1.0
result = clamp(-0.5)          # 0.0
result = clamp(0.5, 0.2, 0.8) # 0.5
result = clamp(1.5, 0.2, 0.8) # 0.8
result = clamp(-0.5, 0.2, 0.8) # 0.2
```

将浮点值限制在最小值和最大值之间。为避免混淆，调用时必须使用全部三个参数或只使用一个参数。

**参数：**

- `value` (float): 要限制的值。
- `min` (float): 最小值，默认为 0。
- `max` (float): 最大值，默认为 1。

**返回：**

- float: 限制后的值。

**注意：** 如果只提供一个参数，则 min=0 且 max=1。

---

### lerp

```python
from bl_math import lerp

result = lerp(0.0, 10.0, 0.0)  # 0.0
result = lerp(0.0, 10.0, 0.5)  # 5.0
result = lerp(0.0, 10.0, 1.0)  # 10.0
result = lerp(0.0, 10.0, 2.0)  # 20.0 (超出范围)
```

基于因子在两个浮点值之间进行线性插值。

**参数：**

- `from_value` (float): 当因子为 0 时返回的值。
- `to_value` (float): 当因子为 1 时返回的值。
- factor (float): 插值因子，通常在 [0.0, 1.0] 范围内。

**返回：**

- float: 插值后的值。

**注意：** 因子可以超出 [0, 1] 范围进行外推。

---

### smoothstep

```python
from bl_math import smoothstep

result = smoothstep(0.0, 1.0, 0.0)  # 0.0
result = smoothstep(0.0, 1.0, 0.5)  # 0.5
result = smoothstep(0.0, 1.0, 1.0)  # 1.0
result = smoothstep(0.0, 1.0, 0.25) # ~0.156
result = smoothstep(0.0, 1.0, 0.75) # ~0.844

result = smoothstep(0.0, 1.0, -0.5) # 0.0 (超出范围)
result = smoothstep(0.0, 1.0, 1.5)  # 1.0 (超出范围)
```

在 0 和 1 之间执行平滑插值，当值在 from 和 to 之间变化时。在范围外，函数返回与最近边缘相同的值。

**参数：**

- `from_value` (float): 结果为 0 的边缘值。
- `to_value` (float): 结果为 1 的边缘值。
- `value` (float): 插值值。

**返回：**

- float: 范围在 [0.0, 1.0] 内的插值值。

**数学公式：**
```
smoothstep(from, to, value) = t * t * (3 - 2 * t)
其中 t = clamp((value - from) / (to - from))
```

---

## 使用示例

### 颜色插值

```python
from bl_math import lerp, clamp
import math

def interpolate_color(color1, color2, factor):
    return tuple(
        lerp(color1[i], color2[i], factor)
        for i in range(len(color1))
    )

red = (1.0, 0.0, 0.0)
blue = (0.0, 0.0, 1.0)

purple = interpolate_color(red, blue, 0.5)
print(purple)  # (0.5, 0.0, 0.5)
```

### 属性动画

```python
from bl_math import lerp, smoothstep, clamp

def ease_in_out(current_time, start_value, end_value, duration):
    progress = clamp(current_time / duration)
    eased = smoothstep(0.0, 1.0, progress)
    return lerp(start_value, end_value, eased)

start_scale = 1.0
end_scale = 2.0

for frame in range(0, 101, 10):
    scale = ease_in_out(frame, start_scale, end_scale, 100)
    print(f"Frame {frame}: Scale {scale:.3f}")
```

### 权重遮罩

```python
from bl_math import clamp, smoothstep

def create_weight_mask(x, y, width, height, center_x, center_y, radius):
    distance = math.sqrt((x - center_x)**2 + (y - center_y)**2)
    normalized = clamp(distance / radius)
    weight = smoothstep(1.0, 0.0, normalized)
    return weight

width, height = 100, 100
center = (50, 50)
radius = 30

mask_values = []
for y in range(height):
    row = []
    for x in range(width):
        weight = create_weight_mask(x, y, width, height, center[0], center[1], radius)
        row.append(weight)
    mask_values.append(row)
```

### 物理模拟缓动

```python
from bl_math import lerp, clamp

class SpringSimulation:
    def __init__(self, target, stiffness=0.1, damping=0.8):
        self.target = target
        self.position = target
        self.velocity = 0.0
        self.stiffness = stiffness
        self.damping = damping
    
    def update(self, new_target, delta_time):
        self.target = new_target
        
        force = (self.target - self.position) * self.stiffness
        force -= self.velocity * self.damping
        
        self.velocity += force * delta_time
        self.position += self.velocity * delta_time
        
        return self.position
    
    def set_value(self, value):
        self.position = value
        self.velocity = 0.0

spring = SpringSimulation(0.0)

for i in range(100):
    target = clamp(i / 50.0 - 1.0, 0.0, 1.0)
    pos = spring.update(target, 1.0)
    print(f"Step {i}: Position {pos:.3f}")
```

### 混合形状权重平滑

```python
from bl_math import lerp, clamp, smoothstep

def smooth_blend_weights(weights, blend_factor, threshold=0.01):
    result = []
    for w in weights:
        if abs(w) < threshold:
            w = 0.0
        elif w > 1.0 - threshold:
            w = 1.0
        
        smoothed = smoothstep(0.0, 1.0, w)
        result.append(lerp(w, smoothed, blend_factor))
    return result

original_weights = [0.0, 0.25, 0.5, 0.75, 1.0]
smoothed = smooth_blend_weights(original_weights, 0.5)
print(smoothed)  # 平滑后的权重值
```

### 相机焦点平滑

```python
from bl_math import lerp, clamp, smoothstep

class CameraFocus:
    def __init__(self, current_focus=10.0, smoothing=0.1):
        self.current_focus = current_focus
        self.target_focus = current_focus
        self.smoothing = smoothing
    
    def set_target(self, distance):
        self.target_focus = clamp(distance, 0.1, 1000.0)
    
    def update(self):
        difference = self.target_focus - self.current_focus
        
        if abs(difference) < 0.01:
            self.current_focus = self.target_focus
        else:
            step = smoothstep(0.0, 1.0, abs(difference) / 10.0)
            self.current_focus += difference * step * self.smoothing
        
        return self.current_focus

focus = CameraFocus(10.0)
focus.set_target(50.0)

for _ in range(60):
    dist = focus.update()
    print(f"Focus distance: {dist:.2f}")
```

---

## 注意事项

1. **参数顺序**: 注意 lerp 和 smoothstep 的参数顺序相同：from_value, to_value, value。

2. **clamp 用法**: clamp 可以只用 value 参数（默认 min=0, max=1），或使用全部三个参数。

3. **范围外行为**: lerp 支持外推（factor 超出 [0,1]），smoothstep 会将超出范围的值钳制到最近边缘。

4. **精度**: 所有函数都使用 float 类型，精度取决于 Python 的浮点精度。

5. **性能**: 这些函数是纯 Python 实现，适合一般使用。对于性能关键代码，考虑使用 numpy 或 mathutils。