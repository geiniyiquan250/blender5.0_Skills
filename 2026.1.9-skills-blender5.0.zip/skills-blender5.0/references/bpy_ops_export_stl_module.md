# bpy.ops.export_mesh - STL导出操作模块

Blender STL文件导出操作符，用于将网格导出为STL格式。

## 概述

`bpy.ops.export_mesh.stl` 模块提供用于将Blender网格导出为STL格式的功能，支持ASCII和二进制STL格式。

## 核心功能

### 基础导出

```python
import bpy

# 导出选中对象
bpy.ops.export_mesh.stl(
    filepath='//model.stl',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    export_selected=True,
    apply_modifiers=True,
    export_type='MESH'
)

# 导出所有对象
bpy.ops.export_mesh.stl(
    filepath='//all_models.stl',
    export_selected=False
)
```

### 导出选项

```python
# 只导出选中对象
bpy.ops.export_mesh.stl(
    filepath='//selected.stl',
    export_selected=True
)

# 导出所有对象
bpy.ops.export_mesh.stl(
    filepath='//all.stl',
    export_selected=False
)

# 应用修改器
bpy.ops.export_mesh.stl(
    filepath='//applied.stl',
    apply_modifiers=True
)

# 不应用修改器
bpy.ops.export_mesh.stl(
    filepath='//not_applied.stl',
    apply_modifiers=False
)
```

### 导出类型

```python
# 导出为网格
bpy.ops.export_mesh.stl(
    filepath='//model.stl',
    export_type='MESH'
)

# 导出低多边形
bpy.ops.export_mesh.stl(
    filepath='//lowpoly.stl',
    export_type='LOW_POLY'
)

# 导出为CAD
bpy.ops.export_mesh.stl(
    filepath='//cad.stl',
    export_type='CAD'
)
```

### STL格式选项

```python
# 导出为ASCII STL
bpy.ops.export_mesh.stl(
    filepath='//ascii.stl',
    ascii_format=True
)

# 导出为二进制STL
bpy.ops.export_mesh.stl(
    filepath='//binary.stl',
    ascii_format=False
)
```

### 法线和面选项

```python
# 导出法线
bpy.ops.export_mesh.stl(
    filepath='//with_normals.stl',
    export_normals=True
)

# 不导出法线
bpy.ops.export_mesh.stl(
    filepath='//no_normals.stl',
    export_normals=False
)

# 导出面颜色
bpy.ops.export_mesh.stl(
    filepath='//with_colors.stl',
    export_colors=True
)

# 不导出面颜色
bpy.ops.export_mesh.stl(
    filepath='//no_colors.stl',
    export_colors=False
)
```

### 三角化选项

```python
# 三角化网格
bpy.ops.export_mesh.stl(
    filepath='//triangulated.stl',
    export_triangulated_mesh=True
)

# 不三角化
bpy.ops.export_mesh.stl(
    filepath='//not_triangulated.stl',
    export_triangulated_mesh=False
)
```

## 实用函数

```python
def export_selected_for_3d_print(filepath='//print_ready.stl'):
    """导出选中对象用于3D打印"""
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=True,
        ascii_format=False,
        export_triangulated_mesh=True
    )

def export_model_for_cad(filepath='//cad_model.stl'):
    """导出模型用于CAD"""
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=True,
        export_type='CAD',
        ascii_format=False
    )

def export_all_meshes(filepath='//all_meshes.stl'):
    """导出所有网格"""
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        export_selected=False,
        apply_modifiers=True
    )

def batch_export_meshes(output_dir):
    """批量导出网格"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            filepath = os.path.join(output_dir, f'{obj.name}.stl')
            bpy.ops.export_mesh.stl(
                filepath=filepath,
                export_selected=True,
                apply_modifiers=True
            )

def export_with_modifiers(filepath, obj):
    """导出对象及其修改器"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=True
    )

def export_low_poly(filepath, obj):
    """导出低多边形版本"""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    # 添加简模修改器
    mod = obj.modifiers.new(name='Decimate', type='DECIMATE')
    mod.ratio = 0.1
    
    bpy.ops.export_mesh.stl(
        filepath=filepath,
        export_selected=True,
        apply_modifiers=True,
        export_type='LOW_POLY'
    )
    
    # 删除修改器
    obj.modifiers.remove(mod)
```

## 常见问题排查

### 导出文件为空
```python
# 检查选中对象
selected = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
print(f"选中网格: {len(selected)}")

# 检查所有网格
meshes = [obj for obj in bpy.data.objects if obj.type == 'MESH']
print(f"所有网格: {len(meshes)}")

# 检查网格数据
for mesh in meshes:
    print(f"{mesh.name}: 顶点数={len(mesh.data.vertices)}, 面数={len(mesh.data.polygons)}")

# 确保网格可见
for obj in selected:
    obj.hide_viewport = False
```

### 修改器未应用
```python
# 检查修改器
obj = bpy.context.active_object
print(f"修改器数: {len(obj.modifiers)}")

for mod in obj.modifiers:
    print(f"修改器: {mod.type}, 显示={mod.show_viewport}, 渲染={mod.show_render}")

# 显示所有修改器
for mod in obj.modifiers:
    mod.show_viewport = True
    mod.show_render = True

# 手动应用修改器
bpy.ops.object.convert(target='MESH')

# 重新导出
bpy.ops.export_mesh.stl(
    filepath='//applied.stl',
    export_selected=True,
    apply_modifiers=True
)
```

### STL格式问题
```python
# 检查文件格式
print("STL格式选项:")
print("  - ASCII: 文本格式, 可读")
print("  - 二进制: 紧凑, 快速")

# 尝试ASCII格式
bpy.ops.export_mesh.stl(
    filepath='//ascii.stl',
    ascii_format=True
)

# 尝试二进制格式
bpy.ops.export_mesh.stl(
    filepath='//binary.stl',
    ascii_format=False
)

# 检查文件大小
import os
ascii_size = os.path.getsize(bpy.path.abspath('//ascii.stl'))
binary_size = os.path.getsize(bpy.path.abspath('//binary.stl'))
print(f"ASCII大小: {ascii_size} 字节")
print(f"二进制大小: {binary_size} 字节")
```

### 三角化问题
```python
# 检查面类型
mesh = bpy.context.active_object.data
quads = sum(1 for p in mesh.polygons if len(p.vertices) == 4)
tris = sum(1 for p in mesh.polygons if len(p.vertices) == 3)
ngons = sum(1 for p in mesh.polygons if len(p.vertices) > 4)

print(f"四边形: {quads}")
print(f"三角形: {tris}")
print(f"多边形: {ngons}")

# 添加三角化修改器
mod = bpy.context.active_object.modifiers.new(name='Triangulate', type='TRIANGULATE')
mod.show_viewport = True
mod.show_render = True

# 重新导出
bpy.ops.export_mesh.stl(
    filepath='//triangulated.stl',
    export_selected=True,
    apply_modifiers=True,
    export_triangulated_mesh=True
)
```
