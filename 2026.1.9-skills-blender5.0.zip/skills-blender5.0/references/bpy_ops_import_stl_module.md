# bpy.ops.import_mesh - STL导入操作模块

Blender STL文件导入操作符，用于将STL网格文件导入Blender。

## 概述

`bpy.ops.import_mesh.stl` 模块提供用于将STL格式网格文件导入Blender的功能，支持ASCII和二进制STL格式。

## 核心功能

### 基础导入

```python
import bpy

# 导入STL文件
bpy.ops.import_mesh.stl(
    filepath='//model.stl',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    directory='//',
    files=[{'name': 'model.stl'}],
    global_matrix=None,
    use_mesh_validate=True,
    use_facet_normal=False
)

# 导入多个STL文件
bpy.ops.import_mesh.stl(
    filepath='//parts/',
    directory='//parts/',
    files=[{'name': 'part1.stl'}, {'name': 'part2.stl'}, {'name': 'part3.stl'}]
)
```

### 变换设置

```python
# 应用全局矩阵
bpy.ops.import_mesh.stl(
    filepath='//model.stl',
    global_matrix=None
)

# 自定义变换矩阵
import mathutils
matrix = mathutils.Matrix.Rotation(math.radians(45), 4, 'Z')
bpy.ops.import_mesh.stl(
    filepath='//model.stl',
    global_matrix=matrix
)

# 缩放导入
scale_matrix = mathutils.Matrix.Scale(0.01, 4)
bpy.ops.import_mesh.stl(
    filepath='//model.stl',
    global_matrix=scale_matrix
)
```

### 网格验证

```python
# 启用网格验证
bpy.ops.import_mesh.stl(
    filepath='//model.stl',
    use_mesh_validate=True
)

# 禁用网格验证
bpy.ops.import_mesh.stl(
    filepath='//model.stl',
    use_mesh_validate=False
)
```

### 法线设置

```python
# 使用面法线
bpy.ops.import_mesh.stl(
    filepath='//model.stl',
    use_facet_normal=True
)

# 不使用面法线
bpy.ops.import_mesh.stl(
    filepath='//model.stl',
    use_facet_normal=False
)
```

### 批量导入

```python
# 导入目录下所有STL
def import_all_stl_files(directory):
    import os
    stl_files = [f for f in os.listdir(directory) if f.lower().endswith('.stl')]
    stl_files.sort()
    
    if stl_files:
        bpy.ops.import_mesh.stl(
            filepath=os.path.join(directory, stl_files[0]),
            directory=directory,
            files=[{'name': f} for f in stl_files]
        )
    
    return list(bpy.context.selected_objects)

# 导入并合并
def import_and_merge_stl(stl_files, merge=True):
    objects = []
    for stl_file in stl_files:
        bpy.ops.import_mesh.stl(filepath=stl_file)
        imported = bpy.context.active_object
        objects.append(importited)
    
    if merge and len(objects) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = objects[0]
        bpy.ops.object.join()
        return [bpy.context.active_object]
    
    return objects
```

## 实用函数

```python
def import_stl_model(filepath, scale=1.0):
    """导入STL模型"""
    bpy.ops.import_mesh.stl(filepath=filepath)
    obj = bpy.context.active_object
    
    if scale != 1.0:
        obj.scale = (scale, scale, scale)
        bpy.ops.object.transform_apply(scale=True)
    
    return obj

def import_stl_with_transform(filepath, rotation=(0, 0, 0), translation=(0, 0, 0)):
    """导入STL并应用变换"""
    import math
    import mathutils
    
    euler = mathutils.Euler([math.radians(r) for r in rotation], 'XYZ')
    matrix = mathutils.Matrix.Translation(translation) @ euler.to_matrix().to_4x4()
    
    bpy.ops.import_mesh.stl(filepath=filepath, global_matrix=matrix)
    return bpy.context.active_object

def import_stl_parts(directory, merge=True):
    """导入目录下所有STL部件"""
    import os
    
    stl_files = [os.path.join(directory, f) for f in os.listdir(directory) if f.lower().endswith('.stl')]
    stl_files.sort()
    
    all_objects = []
    for stl_file in stl_files:
        bpy.ops.import_mesh.stl(filepath=stl_file)
        obj = bpy.context.active_object
        all_objects.append(obj)
    
    if merge and len(all_objects) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in all_objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = all_objects[0]
        bpy.ops.object.join()
        return [bpy.context.active_object]
    
    return all_objects

def import_stl_and_setup_material(filepath, material_name='STLMaterial'):
    """导入STL并设置材质"""
    bpy.ops.import_mesh.stl(filepath=filepath)
    obj = bpy.context.active_object
    
    # 创建材质
    mat = bpy.data.materials.get(material_name)
    if not mat:
        mat = bpy.data.materials.new(name=material_name)
    
    obj.data.materials.append(mat)
    
    return obj

def batch_import_stl_for_print(stl_files, apply_transforms=True):
    """批量导入STL用于3D打印"""
    objects = []
    
    for stl_file in stl_files:
        bpy.ops.import_mesh.stl(filepath=stl_file)
        obj = bpy.context.active_object
        obj.name = bpy.path.basename(stl_file).replace('.stl', '')
        objects.append(obj)
    
    if apply_transforms:
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.transform_apply(
            location=True,
            rotation=True,
            scale=True
        )
    
    return objects

def import_scaled_stl(filepath, target_size=10.0):
    """导入并缩放到目标大小"""
    bpy.ops.import_mesh.stl(filepath=filepath)
    obj = bpy.context.active_object
    
    # 计算缩放
    max_dim = max(obj.dimensions)
    if max_dim > 0:
        scale = target_size / max_dim
        obj.scale = (scale, scale, scale)
    
    bpy.ops.object.transform_apply(scale=True)
    
    return obj
```

## 常见问题排查

### 导入后模型不可见
```python
# 检查对象
obj = bpy.context.active_object
print(f"对象: {obj.name}")
print(f"类型: {obj.type}")
print(f"顶点数: {len(obj.data.vertices)}")

# 检查隐藏状态
print(f"隐藏: {obj.hide_viewport}")
obj.hide_viewport = False

# 检查显示类型
obj.display_type = 'SOLID'

# 检查渲染属性
print(f"渲染隐藏: {obj.hide_render}")
obj.hide_render = False
```

### 模型方向错误
```python
# 检查方向
obj = bpy.context.active_object
print(f"旋转: {obj.rotation_euler}")
print(f"缩放: {obj.scale}")

# 重置方向
obj.rotation_euler = (0, 0, 0)

# 应用变换
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

# 重新导入带变换
import mathutils
matrix = mathutils.Matrix.Rotation(math.radians(90), 4, 'X')
bpy.ops.import_mesh.stl(filepath='//model.stl', global_matrix=matrix)
```

### 模型比例问题
```python
# 检查尺寸
obj = bpy.context.active_object
print(f"尺寸: {obj.dimensions}")

# 检查单位
print(f"场景单位: {bpy.context.scene.unit_settings.system}")
print(f"比例: {bpy.context.scene.unit_settings.scale_length}")

# 应用正确的缩放
bpy.ops.object.transform_apply(scale=True)

# 重新导入并缩放
bpy.ops.import_mesh.stl(filepath='//model.stl')
obj = bpy.context.active_object
obj.scale = (0.01, 0.01, 0.01)
bpy.ops.object.transform_apply(scale=True)
```

### 网格质量问题
```python
# 检查网格
mesh = bpy.context.active_object.data
print(f"顶点数: {len(mesh.vertices)}")
print(f"面数: {len(mesh.polygons)}")
print(f"边数: {len(mesh.edges)}")

# 检查非流形几何体
non_manifold = 0
for edge in mesh.edges:
    if len(edge.vertices) != 2:
        non_manifold += 1
print(f"非流形边: {non_manifold}")

# 检查孤立顶点
print(f"孤立顶点: {len(mesh.vertices)}")

# 重新导入并验证
bpy.ops.import_mesh.stl(filepath='//model.stl', use_mesh_validate=True)
```
