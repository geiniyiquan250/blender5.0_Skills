# bpy.ops.gizmogroup - Gizmo组操作模块

Blender小工具组操作符，用于管理3D视口中的Gizmo交互控件。

## 概述

`bpy.ops.gizmogroup` 模块提供用于创建、编辑和管理Gizmo组的操作功能。Gizmo是Blender中用于用户交互的小型图形控件，常见于变换手柄、旋转环等。

## 核心功能

### Gizmo组管理

```python
import bpy

# 激活Gizmo组
bpy.ops.gizmogroup.group_pick()

# 创建新的Gizmo组
bpy.ops.gizmogroup.group_add()

# 删除当前Gizmo组
bpy.ops.gizmogroup.group_remove()

# 复制Gizmo组
bpy.ops.gizmogroup.group_copy()

# 粘贴复制的Gizmo组
bpy.ops.gizmogroup.group_paste()

# 选择Gizmo组中的所有Gizmo
bpy.ops.gizmogroup.select_all(action='SELECT')

# 取消选择所有Gizmo
bpy.ops.gizmogroup.select_all(action='DESELECT')

# 反选Gizmo
bpy.ops.gizmogroup.select_all(action='INVERT')

# 链接Gizmo组到活动对象
bpy.ops.gizmogroup.attach_to_active()

# 从活动对象分离Gizmo组
bpy.ops.gizmogroup.detach()

# 显示Gizmo组
bpy.ops.gizmogroup.show()

# 隐藏Gizmo组
bpy.ops.gizmogroup.hide()

# 切换Gizmo组显示状态
bpy.ops.gizmogroup.toggle()
```

### Gizmo操作

```python
# 选择特定的Gizmo
bpy.ops.gizmogroup.select(extend=False, deselect=False, toggle=False)

# 根据类型选择Gizmo
bpy.ops.gizmogroup.select_by_type(type='TRANSLATE')

# 搜索并选择Gizmo
bpy.ops.gizmogroup.search_select(name='gizmo_name')

# 删除选中的Gizmo
bpy.ops.gizmogroup.delete()

# 复制Gizmo
bpy.ops.gizmogroup.duplicate()

# 移动Gizmo到其他组
bpy.ops.gizmogroup.move_to_group(group_name='new_group')

# 重命名Gizmo
bpy.ops.gizmogroup.rename(name='new_gizmo_name')

# 设置Gizmo属性
bpy.ops.gizmogroup.set_property(prop_name='value')

# 获取Gizmo属性
bpy.ops.gizmogroup.get_property(prop_name='prop_name')
```

### Gizmo样式设置

```python
# 设置Gizmo颜色
bpy.ops.gizmogroup.color_set(color=(1.0, 0.0, 0.0, 1.0))

# 设置Gizmo线宽
bpy.ops.gizmogroup.line_width_set(width=2.0)

# 设置Gizmo尺寸
bpy.ops.gizmogroup.scale_set(scale=1.0)

# 重置样式为默认值
bpy.ops.gizmogroup.style_reset()

# 应用预设样式
bpy.ops.gizmogroup.preset_apply(preset='default')

# 保存当前样式为预设
bpy.ops.gizmogroup.preset_save(name='my_preset')

# 删除预设
bpy.ops.gizmogroup.preset_delete(name='my_preset')
```

### Gizmo变换操作

```python
# 变换选中的Gizmo
bpy.ops.gizmogroup.transform(mode='TRANSLATION')

# 平移Gizmo
bpy.ops.gizmogroup.translate(value=(1.0, 0.0, 0.0))

# 旋转Gizmo
bpy.ops.gizmogroup.rotate(angle=45.0, axis='Z')

# 缩放Gizmo
bpy.ops.gizmogroup.scale(value=(1.5, 1.5, 1.5))

# 对齐Gizmo到网格
bpy.ops.gizmogroup.snap_to_grid()

# 对齐Gizmo到原点
bpy.ops.gizmogroup.snap_to_origin()

# 对齐到选中对象
bpy.ops.gizmogroup.snap_to_selected()
```

### Gizmo动画

```python
# 为Gizmo位置插入关键帧
bpy.ops.gizmogroup.insert_keyframe()

# 删除Gizmo关键帧
bpy.ops.gizmogroup.delete_keyframe()

# 清除Gizmo动画
bpy.ops.gizmogroup.clear_keyframe()

# 设置Gizmo驱动
bpy.ops.gizmogroup.driver_add()

# 移除Gizmo驱动
bpy.ops.gizmogroup.driver_remove()
```

### 高级功能

```python
# 绑定Gizmo到对象
bpy.ops.gizmogroup.bind(target_object='Cube')

# 解绑Gizmo
bpy.ops.gizmogroup.unbind()

# 设置Gizmo可见性
bpy.ops.gizmogroup.visibility_set(visible=True)

# 设置Gizmo选择模式
bpy.ops.gizmogroup.select_mode(mode='ALL')

# 分组Gizmo
bpy.ops.gizmogroup.group_objects(objects=['Cube', 'Sphere', 'Cylinder'])

# 取消分组
bpy.ops.gizmogroup.ungroup_objects(objects=['Cube'])

# 应用变换到Gizmo
bpy.ops.gizmogroup.apply_transform()

# 重置Gizmo变换
bpy.ops.gizmogroup.reset_transform()

# 复制Gizmo属性
bpy.ops.gizmogroup.copy_properties(source='gizmo_name')

# 粘贴Gizmo属性
bpy.ops.gizmogroup.paste_properties()
```

## 实用函数

```python
def get_active_gizmo_group():
    """获取当前激活的Gizmo组"""
    return bpy.context.gizmo_group

def get_gizmos_in_group(group):
    """获取组中的所有Gizmo"""
    return list(group.gizmos)

def create_custom_gizmo(name, group_name=None):
    """创建自定义Gizmo"""
    if group_name:
        bpy.ops.gizmogroup.group_pick()
    bpy.ops.gizmogroup.group_add()
    bpy.ops.gizmogroup.rename(name=name)
    return bpy.context.gizmo_group

def hide_all_gizmos():
    """隐藏所有Gizmo"""
    for gizmo_group in bpy.context.scene.gizmo_groups:
        gizmo_group.hide()

def show_all_gizmos():
    """显示所有Gizmo"""
    for gizmo_group in bpy.context.scene.gizmo_groups:
        gizmo_group.show()

def select_gizmos_by_name_prefix(prefix):
    """按名称前缀选择Gizmo"""
    for gizmo in bpy.context.gizmo_group.gizmos:
        if gizmo.name.startswith(prefix):
            gizmo.select_set(True)
```

## 常见问题排查

### Gizmo不显示
```python
# 确保Gizmo组可见
bpy.ops.gizmogroup.show()

# 确保在正确的空间类型
print(bpy.context.space_data.type)

# 检查Gizmo组是否绑定
if bpy.context.gizmo_group:
    print("Gizmo组已绑定")
else:
    print("Gizmo组未绑定")
```

### Gizmo选择问题
```python
# 重置选择状态
bpy.ops.gizmogroup.select_all(action='DESELECT')

# 切换选择模式
bpy.ops.gizmogroup.select_all(action='SELECT')

# 手动选择Gizmo
for gizmo in bpy.context.gizmo_group.gizmos:
    if gizmo.name == "target_gizmo":
        gizmo.select_set(True)
```
