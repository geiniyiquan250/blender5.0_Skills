# freestyle.shaders - 线条着色器模块

freestyle.shaders模块提供了Freestyle线条渲染中的着色器函数，用于控制线条的视觉属性，包括颜色、宽度、不透明度等。

## 概述

着色器是Freestyle样式模块的核心组件之一，它们定义了线条的渲染外观。通过应用不同的着色器，可以创建各种艺术风格的线条效果，如墨水渲染、铅笔画、水彩等。

## 核心功能

### 颜色着色器

```python
from freestyle.shaders import (
    ConstantColorShader,
    GradientColorShader,
    TextureColorShader,
    MaterialColorShader
)

def create_constant_color_shader(color=(0, 0, 0, 1)):
    """创建常量颜色着色器"""
    return ConstantColorShader(color)

def create_gradient_color_shader(
    colors, 
    direction='X', 
    interpolation='LINEAR'
):
    """创建渐变颜色着色器"""
    return GradientColorShader(colors, direction, interpolation)

def create_material_color_shader():
    """创建材质颜色着色器"""
    return MaterialColorShader()

def create_texture_color_shader(texture_image, uv_layer=None):
    """创建纹理颜色着色器"""
    return TextureColorShader(texture_image, uv_layer)
```

### 宽度着色器

```python
from freestyle.shaders import (
    ConstantThicknessShader,
    VariableThicknessShader,
    FwidthThicknessShader,
    CurvatureWidthShader
)

def create_constant_thickness_shader(thickness=2.0):
    """创建常量宽度着色器"""
    return ConstantThicknessShader(thickness)

def create_variable_thickness_shader(
    thickness_base=1.0,
    thickness_min=0.5,
    thickness_max=5.0
):
    """创建可变宽度着色器"""
    return VariableThicknessShader(
        thickness_base, 
        thickness_min, 
        thickness_max
    )

def create_curvature_width_shader(
    base_thickness=1.0,
    curvature_scale=2.0,
    min_thickness=0.5,
    max_thickness=4.0
):
    """创建曲率宽度着色器"""
    return CurvatureWidthShader(
        base_thickness,
        curvature_scale,
        min_thickness,
        max_thickness
    )

def create_fwidth_thickness_shader(thickness_base=2.0):
    """创建Fwidth宽度着色器"""
    return FwidthThicknessShader(thickness_base)
```

### 不透明度着色器

```python
from freestyle.shaders import (
    ConstantAlphaShader,
    GradientAlphaShader,
    CurvatureAlphaShader
)

def create_constant_alpha_shader(alpha=1.0):
    """创建常量不透明度着色器"""
    return ConstantAlphaShader(alpha)

def create_gradient_alpha_shader(
    alphas, 
    direction='X', 
    interpolation='LINEAR'
):
    """创建渐变不透明度着色器"""
    return GradientAlphaShader(alphas, direction, interpolation)

def create_curvature_alpha_shader(
    base_alpha=1.0,
    curvature_scale=1.0,
    min_alpha=0.2,
    max_alpha=1.0
):
    """创建曲率不透明度着色器"""
    return CurvatureAlphaShader(
        base_alpha,
        curvature_scale,
        min_alpha,
        max_alpha
    )
```

## 实用函数

### 着色器链

```python
def chain_shaders(shader1, shader2):
    """链化两个着色器"""
    class ChainedShader:
        def __init__(self, s1, s2):
            self.s1 = s1
            self.s2 = s2
        
        def shade(self, stroke):
            self.s1.shade(stroke)
            self.s2.shade(stroke)
    
    return ChainedShader(shader1, shader2)

def create_stroke_shader_pipeline(shaders):
    """创建着色器管线"""
    def apply_shaders(stroke):
        for shader in shaders:
            shader.shade(stroke)
    return apply_shaders

def apply_multiple_shaders(stroke, shaders):
    """应用多个着色器"""
    for shader in shaders:
        shader.shade(stroke)
```

### 高级着色器

```python
def create_inkscape_shader(
    stroke_color=(0, 0, 0, 1),
    fill_color=(1, 1, 1, 1),
    thickness=2.0
):
    """创建墨水风格着色器"""
    color_shader = ConstantColorShader(stroke_color)
    thickness_shader = ConstantThicknessShader(thickness)
    return chain_shaders(color_shader, thickness_shader)

def create_pencil_shader(
    base_thickness=1.5,
    opacity=0.8,
    jitter_strength=0.3
):
    """创建铅笔风格着色器"""
    thickness_shader = VariableThicknessShader(
        base_thickness * 0.5,
        base_thickness * 0.5,
        base_thickness * 1.5
    )
    alpha_shader = ConstantAlphaShader(opacity)
    return chain_shaders(thickness_shader, alpha_shader)

def create_watercolor_shader(
    wetness=0.5,
    thickness_range=(0.5, 3.0)
):
    """创建水彩风格着色器"""
    from freestyle.shaders import StrokeTextureShader
    
    texture_shader = StrokeTextureShader()
    thickness_shader = VariableThicknessShader(
        thickness_range[0],
        thickness_range[0],
        thickness_range[1]
    )
    return chain_shaders(thickness_shader, texture_shader)
```

### 着色器参数调整

```python
def adjust_shader_parameter(shader, parameter, value):
    """调整着色器参数"""
    if hasattr(shader, parameter):
        setattr(shader, parameter, value)
        return True
    return False

def get_shader_parameters(shader):
    """获取着色器参数"""
    params = {}
    for attr in dir(shader):
        if not attr.startswith('_') and not callable(getattr(shader, attr)):
            params[attr] = getattr(shader, attr)
    return params

def clone_shader(shader):
    """克隆着色器"""
    params = get_shader_parameters(shader)
    shader_class = type(shader)
    return shader_class(**params)
```

## 常见问题排查

### 着色效果不明显

参数范围问题：
- 调整着色器参数范围
- 检查输入数据是否有效
- 确认着色器顺序正确

### 渲染错误

着色器不兼容：
- 确认着色器类型匹配
- 检查参数类型正确
- 验证纹理文件存在

### 性能问题

着色器计算复杂：
- 减少着色器数量
- 简化着色器逻辑
- 使用缓存优化
