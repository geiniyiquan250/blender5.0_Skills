# imbuf.types 模块

imbuf.types 模块定义了图像缓冲类型，用于在 Blender 中处理各种图像格式和像素数据。

## 图像缓冲类型概述

imbuf 模块提供了图像的加载、创建和保存功能，types 子模块定义了相关的类型和常量。

### 何时使用 imbuf 类型

- 创建和处理图像缓冲
- 加载不同格式的图像
- 进行图像格式转换
- 处理像素数据和通道

## 图像缓冲类型

### ImBuf

图像缓冲对象，代表内存中的图像数据。

```python
import bpy
import imbuf

# 创建空白图像缓冲
width = 512
height = 512
channels = 4  # RGBA

# 创建 RGBA 图像缓冲
imb = imbuf.types.ImBuf(width, height, channels)

print(f"图像尺寸: {imb.size}")
print(f"通道数: {imb.channels}")
print(f"宽度: {imbx}")
print(f"高度: {imb.y}")
```

### ImBuf 属性

```python
import imbuf

# 创建图像缓冲
imb = imbuf.types.ImBuf(256, 256, 4)

# 访问属性
print(f"尺寸: {imb.size}")      # (256, 256)
print(f"宽度: {imbx}")           # 256
print(f"高度: {imb.y}")          # 256
print(f"通道数: {imb.channels}") # 4
print(f"文件名: {imb.filepath}") # 文件路径
print(f"位面数: {imb.planes}")   # 位面数
print(f"像素/米: {imb.ppm}")     # 分辨率

# 访问像素数据
pixels = imb.pixels  # 返回像素数组
```

### ImBuf 方法

```python
import imbuf

# 创建图像缓冲
imb = imbuf.types.ImBuf(256, 256, 4)

# 复制图像缓冲
imb_copy = imb.copy()

# 裁剪图像
imb_cropped = imb.crop(50, 50, 200, 200)

# 调整大小
imb_resized = imb.resize(128, 128)

# 缩放图像
imb_scaled = imb.scale(256, 256)

# 旋转图像
imb_rotated = imb.rotate(90)  # 旋转90度

# 释放内存
imb.free()
```

## 图像格式类型

### 支持的格式

```python
import imbuf

# 检查支持的格式
print("支持的读取格式:")
for fmt in imbuf.formats:
    print(f"  {fmt}")

# 常见格式
FORMAT_PNG = 'PNG'
FORMAT_JPEG = 'JPEG'
FORMAT_TARGA = 'TARGA'
FORMAT_OPENEXR = 'OPENEXR'
FORMAT_HDR = 'HDR'
FORMAT_BMP = 'BMP'
FORMAT_DDS = 'DDS'
```

## 实际应用示例

### 图像处理工具

```python
import bpy
import imbuf
import numpy as np
from pathlib import Path

class ImageProcessor:
    """图像处理器"""
    
    def __init__(self):
        self.supported_formats = ['.png', '.jpg', '.jpeg', '.tga', '.bmp', '.exr', '.hdr']
    
    def load_image(self, filepath: str) -> imbuf.types.ImBuf:
        """加载图像"""
        filepath = str(Path(filepath).resolve())
        
        if not Path(filepath).exists():
            raise FileNotFoundError(f"文件不存在: {filepath}")
        
        imb = imbuf.load(filepath)
        
        if imb is None:
            raise ValueError(f"无法加载图像: {filepath}")
        
        print(f"已加载: {filepath} ({imbx}x{imb.y}, {imb.channels} 通道)")
        return imb
    
    def save_image(self, imb: imbuf.types.ImBuf, filepath: str, 
                   format: str = None) -> bool:
        """保存图像"""
        filepath = str(Path(filepath).resolve())
        
        # 自动检测格式
        if format is None:
            suffix = Path(filepath).suffix.upper()
            format = suffix.replace('.', '')
        
        try:
            imbuf.write(imb, filepath, format)
            print(f"已保存: {filepath}")
            return True
        except Exception as e:
            print(f"保存失败: {e}")
            return False
    
    def create_blank_image(self, width: int, height: int, 
                          channels: int = 4, 
                          color: tuple = (0, 0, 0, 255)) -> imbuf.types.ImBuf:
        """创建空白图像"""
        imb = imbuf.types.ImBuf(width, height, channels)
        
        # 填充颜色
        for y in range(height):
            for x in range(width):
                idx = (y * width + x) * channels
                for c in range(channels):
                    imb.pixels[idx + c] = color[c]
        
        return imb
    
    def create_gradient(self, width: int, height: int, 
                       color1: tuple, color2: tuple,
                       direction: str = 'horizontal') -> imbuf.types.ImBuf:
        """创建渐变图像"""
        channels = 4
        imb = imbuf.types.ImBuf(width, height, channels)
        
        for y in range(height):
            for x in range(width):
                if direction == 'horizontal':
                    t = x / (width - 1) if width > 1 else 0
                else:
                    t = y / (height - 1) if height > 1 else 0
                
                color = [
                    color1[i] + (color2[i] - color1[i]) * t
                    for i in range(4)
                ]
                
                idx = (y * width + x) * channels
                for c in range(4):
                    imb.pixels[idx + c] = color[c]
        
        return imb
    
    def create_checkerboard(self, width: int, height: int,
                           color1: tuple, color2: tuple,
                           check_size: int = 32) -> imbuf.types.ImBuf:
        """创建棋盘格图像"""
        channels = 4
        imb = imbuf.types.ImBuf(width, height, channels)
        
        for y in range(height):
            for x in range(width):
                check_x = (x // check_size) % 2
                check_y = (y // check_size) % 2
                color = color1 if (check_x + check_y) % 2 == 0 else color2
                
                idx = (y * width + x) * channels
                for c in range(4):
                    imb.pixels[idx + c] = color[c]
        
        return imb
    
    def resize_image(self, imb: imbuf.types.ImBuf, 
                    new_width: int, new_height: int) -> imbuf.types.ImBuf:
        """调整图像大小"""
        resized = imbuf.types.ImBuf(new_width, new_height, imb.channels)
        
        # 简单的最近邻插值
        for y in range(new_height):
            for x in range(new_width):
                src_x = int(x * imbx / new_width)
                src_y = int(y * imb.y / new_height)
                
                src_idx = (src_y * imbx + src_x) * imb.channels
                dst_idx = (y * new_width + x) * resized.channels
                
                for c in range(imb.channels):
                    resized.pixels[dst_idx + c] = imb.pixels[src_idx + c]
        
        return resized
    
    def rotate_image(self, imb: imbuf.types.ImBuf, 
                    angle: float) -> imbuf.types.ImBuf:
        """旋转图像"""
        # 简化的旋转实现
        import math
        
        radians = math.radians(angle)
        cos_a = math.cos(radians)
        sin_a = math.sin(radians)
        
        new_width = int(abs(imbx * cos_a) + abs(imb.y * sin_a))
        new_height = int(abs(imbx * sin_a) + abs(imb.y * cos_a))
        
        rotated = imbuf.types.ImBuf(new_width, new_height, imb.channels)
        center_x = imbx // 2
        center_y = imb.y // 2
        new_center_x = new_width // 2
        new_center_y = new_height // 2
        
        for y in range(new_height):
            for x in range(new_width):
                # 逆向变换
                src_x = int((x - new_center_x) * cos_a - (y - new_center_y) * sin_a + center_x)
                src_y = int((x - new_center_x) * sin_a + (y - new_center_y) * cos_a + center_y)
                
                if 0 <= src_x < imbx and 0 <= src_y < imb.y:
                    src_idx = (src_y * imbx + src_x) * imb.channels
                    dst_idx = (y * new_width + x) * rotated.channels
                    
                    for c in range(imb.channels):
                        rotated.pixels[dst_idx + c] = imb.pixels[src_idx + c]
        
        return rotated
    
    def convert_color_space(self, imb: imbuf.types.ImBuf,
                           from_space: str, to_space: str) -> imbuf.types.ImBuf:
        """转换色彩空间"""
        # 简化的色彩空间转换
        converted = imbuf.types.ImBuf(imbx, imb.y, imb.channels)
        
        for i in range(0, len(imb.pixels), imb.channels):
            r, g, b = imb.pixels[i], imb.pixels[i+1], imb.pixels[i+2]
            
            # 从 sRGB 到线性
            if from_space == 'sRGB' and to_space == 'Linear':
                r = max(0, (r / 12.92) if r <= 0.04045 else ((r + 0.055) / 1.055) ** 2.4)
                g = max(0, (g / 12.92) if g <= 0.04045 else ((g + 0.055) / 1.055) ** 2.4)
                b = max(0, (b / 12.92) if b <= 0.04045 else ((b + 0.055) / 1.055) ** 2.4)
            
            # 从线性到 sRGB
            elif from_space == 'Linear' and to_space == 'sRGB':
                r = r * 12.92 if r <= 0.0031308 else 1.055 * (r ** (1/2.4)) - 0.055
                g = g * 12.92 if g <= 0.0031308 else 1.055 * (g ** (1/2.4)) - 0.055
                b = b * 12.92 if b <= 0.0031308 else 1.055 * (b ** (1/2.4)) - 0.055
            
            converted.pixels[i] = r
            converted.pixels[i+1] = g
            converted.pixels[i+2] = b
            converted.pixels[i+3] = imb.pixels[i+3]
        
        return converted
    
    def extract_channel(self, imb: imbuf.types.ImBuf, 
                       channel: int) -> imbuf.types.ImBuf:
        """提取单通道"""
        if channel < 0 or channel >= imb.channels:
            raise ValueError(f"无效通道索引: {channel}")
        
        single = imbuf.types.ImBuf(imbx, imb.y, 1)
        
        for i in range(len(imb.pixels) // imb.channels):
            src_idx = i * imb.channels + channel
            dst_idx = i
            single.pixels[dst_idx] = imb.pixels[src_idx]
        
        return single
    
    def merge_channels(self, channels: list) -> imbuf.types.ImBuf:
        """合并通道"""
        if len(channels) == 0:
            raise ValueError("通道列表为空")
        
        width = channels[0].x
        height = channels[0].y
        num_channels = len(channels)
        
        merged = imbuf.types.ImBuf(width, height, num_channels)
        
        for i in range(width * height):
            for c, ch in enumerate(channels):
                merged.pixels[i * num_channels + c] = ch.pixels[i]
        
        return merged


def process_images():
    """处理图像示例"""
    processor = ImageProcessor()
    
    # 创建棋盘格纹理
    checker = processor.create_checkerboard(
        512, 512,
        (255, 255, 255, 255),
        (0, 0, 0, 255),
        check_size=64
    )
    processor.save_image(checker, "checkerboard.png")
    
    # 创建渐变纹理
    gradient = processor.create_gradient(
        512, 256,
        (255, 0, 0, 255),
        (0, 0, 255, 255),
        direction='horizontal'
    )
    processor.save_image(gradient, "gradient.png")
    
    # 加载并处理图像
    try:
        img = processor.load_image("checkerboard.png")
        resized = processor.resize_image(img, 256, 256)
        processor.save_image(resized, "checkerboard_small.png")
        
        # 提取红色通道
        red_channel = processor.extract_channel(img, 0)
        processor.save_image(red_channel, "red_channel.png")
        
        img.free()
        resized.free()
        red_channel.free()
        
    except Exception as e:
        print(f"处理出错: {e}")
```

### 批量图像转换器

```python
import bpy
import imbuf
import os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import threading

class BatchImageConverter:
    """批量图像转换器"""
    
    def __init__(self):
        self.lock = threading.Lock()
        self.converted_count = 0
        self.error_count = 0
    
    def convert_directory(self, input_dir: str, output_dir: str, 
                         output_format: str = 'PNG',
                         max_workers: int = 4) -> dict:
        """批量转换目录中的图像"""
        input_path = Path(input_dir)
        output_path = Path(output_dir)
        
        # 创建输出目录
        output_path.mkdir(parents=True, exist_ok=True)
        
        # 收集图像文件
        image_files = []
        for f in input_path.iterdir():
            if f.is_file() and f.suffix.lower() in ['.png', '.jpg', '.jpeg', 
                                                     '.tga', '.bmp', '.exr']:
                image_files.append(f)
        
        print(f"找到 {len(image_files)} 个图像文件")
        
        # 批量转换
        results = {'success': 0, 'errors': 0}
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = []
            for filepath in image_files:
                futures.append(
                    executor.submit(self._convert_file, filepath, output_path, output_format)
                )
            
            for future in futures:
                result = future.result()
                with self.lock:
                    if result['success']:
                        results['success'] += 1
                    else:
                        results['errors'] += 1
        
        print(f"转换完成: {results['success']} 成功, {results['errors']} 失败")
        return results
    
    def _convert_file(self, input_file: Path, output_dir: Path, 
                     output_format: str) -> dict:
        """转换单个文件"""
        try:
            # 加载图像
            imb = imbuf.load(str(input_file))
            
            if imb is None:
                return {'success': False, 'error': '无法加载图像'}
            
            # 生成输出路径
            output_file = output_dir / (input_file.stem + '.' + output_format.lower())
            
            # 保存图像
            imbuf.write(imb, str(output_file), output_format)
            
            imb.free()
            
            return {'success': True, 'file': str(output_file)}
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def resize_directory(self, input_dir: str, output_dir: str,
                        new_width: int, new_height: int,
                        max_workers: int = 4) -> dict:
        """批量调整图像大小"""
        input_path = Path(input_dir)
        output_path = Path(output_dir)
        
        output_path.mkdir(parents=True, exist_ok=True)
        
        image_files = [f for f in input_path.iterdir() 
                      if f.is_file() and f.suffix.lower() in ['.png', '.jpg']]
        
        results = {'success': 0, 'errors': 0}
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = []
            for filepath in image_files:
                futures.append(
                    executor.submit(self._resize_file, filepath, output_path, 
                                   new_width, new_height)
                )
            
            for future in futures:
                result = future.result()
                with self.lock:
                    if result['success']:
                        results['success'] += 1
                    else:
                        results['errors'] += 1
        
        return results
    
    def _resize_file(self, input_file: Path, output_dir: Path,
                    new_width: int, new_height: int) -> dict:
        """调整单个文件大小"""
        try:
            imb = imbuf.load(str(input_file))
            
            if imb is None:
                return {'success': False, 'error': '无法加载'}
            
            # 调整大小
            resized = imbuf.types.ImBuf(new_width, new_height, imb.channels)
            
            # 简单缩放
            x_ratio = imbx / new_width
            y_ratio = imb.y / new_height
            
            for y in range(new_height):
                for x in range(new_width):
                    src_x = int(x * x_ratio)
                    src_y = int(y * y_ratio)
                    
                    src_idx = (src_y * imbx + src_x) * imb.channels
                    dst_idx = (y * new_width + x) * resized.channels
                    
                    for c in range(imb.channels):
                        resized.pixels[dst_idx + c] = imb.pixels[src_idx + c]
            
            # 保存
            output_file = output_dir / input_file.name
            imbuf.write(resized, str(output_file), input_file.suffix[1:].upper())
            
            imb.free()
            resized.free()
            
            return {'success': True, 'file': str(output_file)}
        
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def generate_mipmaps(self, input_file: str, output_dir: str) -> list:
        """生成多级渐远图"""
        imb = imbuf.load(input_file)
        
        if imb is None:
            print(f"无法加载: {input_file}")
            return []
        
        mipmaps = []
        current = imb
        
        level = 0
        while current.x >= 1 and current.y >= 1:
            output_file = Path(output_dir) / f"mipmap_{level}.png"
            imbuf.write(current, str(output_file), 'PNG')
            mipmaps.append(str(output_file))
            
            level += 1
            
            # 创建下一级
            next_width = max(1, current.x // 2)
            next_height = max(1, current.y // 2)
            
            if next_width == current.x and next_height == current.y:
                break
            
            next_level = imbuf.types.ImBuf(next_width, next_height, current.channels)
            
            for y in range(next_height):
                for x in range(next_width):
                    src_x = x * 2
                    src_y = y * 2
                    
                    if src_x < current.x and src_y < current.y:
                        src_idx = (src_y * current.x + src_x) * current.channels
                        dst_idx = (y * next_width + x) * next_level.channels
                        
                        for c in range(current.channels):
                            next_level.pixels[dst_idx + c] = current.pixels[src_idx + c]
            
            current.free()
            current = next_level
        
        current.free()
        print(f"生成了 {len(mipmaps)} 级渐远图")
        return mipmaps


def batch_convert_images():
    """批量转换图像"""
    converter = BatchImageConverter()
    
    # 转换图像格式
    results = converter.convert_directory(
        "input_images/",
        "output_images/",
        output_format='PNG'
    )
    
    print(f"转换结果: {results}")
    
    # 调整图像大小
    results = converter.resize_directory(
        "input_images/",
        "resized_images/",
        new_width=512,
        new_height=512
    )
    
    print(f"调整大小结果: {results}")
```

### 纹理生成器

```python
import bpy
import imbuf
import numpy as np
import random
from typing import Tuple, List

class TextureGenerator:
    """纹理生成器"""
    
    def __init__(self):
        self.noise_scale = 1.0
    
    def create_perlin_noise(self, width: int, height: int,
                           scale: float = 1.0,
                           octaves: int = 4,
                           persistence: float = 0.5) -> imbuf.types.ImBuf:
        """创建柏林噪声纹理"""
        imb = imbuf.types.ImBuf(width, height, 4)
        
        # 简化的噪声生成
        for y in range(height):
            for x in range(width):
                value = 0
                amplitude = 1
                frequency = scale
                max_value = 0
                
                for _ in range(octaves):
                    # 简化的伪随机噪声
                    nx = x / width * frequency
                    ny = y / height * frequency
                    
                    # 简化的噪声函数
                    noise = (np.sin(nx * 6.28) + np.cos(ny * 6.28)) / 2
                    noise = (noise + 1) / 2  # 归一化到 0-1
                    
                    value += noise * amplitude
                    max_value += amplitude
                    amplitude *= persistence
                    frequency *= 2
                
                value = value / max_value if max_value > 0 else 0
                
                # 设置像素颜色
                idx = (y * width + x) * 4
                imb.pixels[idx] = value       # R
                imb.pixels[idx + 1] = value   # G
                imb.pixels[idx + 2] = value   # B
                imb.pixels[idx + 3] = 1.0     # A
        
        return imb
    
    def create_voronoi(self, width: int, height: int,
                      num_points: int = 20,
                      color_scheme: str = 'random') -> imbuf.types.ImBuf:
        """创建 Voronoi 图纹理"""
        imb = imbuf.types.ImBuf(width, height, 4)
        
        # 生成随机点
        points = []
        for _ in range(num_points):
            px = random.randint(0, width - 1)
            py = random.randint(0, height - 1)
            color = (random.random(), random.random(), random.random(), 1.0)
            points.append((px, py, color))
        
        for y in range(height):
            for x in range(width):
                min_dist = float('inf')
                nearest_color = (1, 1, 1, 1)
                
                for px, py, color in points:
                    dist = ((x - px) ** 2 + (y - py) ** 2) ** 0.5
                    
                    if dist < min_dist:
                        min_dist = dist
                        nearest_color = color
                
                idx = (y * width + x) * 4
                imb.pixels[idx] = nearest_color[0]
                imb.pixels[idx + 1] = nearest_color[1]
                imb.pixels[idx + 2] = nearest_color[2]
                imb.pixels[idx + 3] = nearest_color[3]
        
        return imb
    
    def create_cellular(self, width: int, height: int,
                       cell_size: int = 32,
                       border_width: int = 2) -> imbuf.types.ImBuf:
        """创建细胞纹理"""
        imb = imbuf.types.ImBuf(width, height, 4)
        
        for y in range(height):
            for x in range(width):
                cell_x = x // cell_size
                cell_y = y // cell_size
                
                cell_center_x = cell_x * cell_size + cell_size // 2
                cell_center_y = cell_y * cell_size + cell_size // 2
                
                dist_to_center = ((x - cell_center_x) ** 2 + 
                                  (y - cell_center_y) ** 2) ** 0.5
                
                cell_radius = cell_size // 2 - border_width
                
                if dist_to_center > cell_radius:
                    # 边框
                    color = (0.2, 0.2, 0.2, 1.0)
                else:
                    # 内部渐变
                    t = dist_to_center / cell_radius if cell_radius > 0 else 0
                    color = (
                        0.8 + 0.2 * t,
                        0.8 + 0.2 * t,
                        0.8 + 0.2 * t,
                        1.0
                    )
                
                idx = (y * width + x) * 4
                imb.pixels[idx] = color[0]
                imb.pixels[idx + 1] = color[1]
                imb.pixels[idx + 2] = color[2]
                imb.pixels[idx + 3] = color[3]
        
        return imb
    
    def create_brick(self, width: int, height: int,
                    brick_width: int = 64,
                    brick_height: int = 32,
                    mortar_size: int = 4,
                    brick_color: Tuple[float, float, float] = (0.7, 0.3, 0.2),
                    mortar_color: Tuple[float, float, float] = (0.5, 0.5, 0.5) 
                    ) -> imbuf.types.ImBuf:
        """创建砖块纹理"""
        imb = imbuf.types.ImBuf(width, height, 4)
        
        for y in range(height):
            for x in range(width):
                # 计算当前行是否是奇数行
                row = y // brick_height
                offset = (row % 2) * (brick_width // 2)
                
                # 计算在砖块中的位置
                brick_x = (x - offset) % (brick_width + mortar_size)
                brick_y = y % (brick_height + mortar_size)
                
                # 检查是否是水泥区域
                if brick_x < mortar_size or brick_y < mortar_size:
                    color = (*mortar_color, 1.0)
                else:
                    # 添加一些颜色变化
                    noise = random.random() * 0.1
                    color = (
                        brick_color[0] + noise,
                        brick_color[1] + noise,
                        brick_color[2] + noise,
                        1.0
                    )
                
                idx = (y * width + x) * 4
                imb.pixels[idx] = color[0]
                imb.pixels[idx + 1] = color[1]
                imb.pixels[idx + 2] = color[2]
                imb.pixels[idx + 3] = color[3]
        
        return imb
    
    def create_water(self, width: int, height: int,
                    time: float = 0.0) -> imbuf.types.ImBuf:
        """创建水波纹理"""
        imb = imbuf.types.ImBuf(width, height, 4)
        
        for y in range(height):
            for x in range(width):
                # 创建波纹效果
                nx = x / width - 0.5
                ny = y / height - 0.5
                
                # 简单的正弦波
                wave = np.sin(nx * 20 + time) * np.cos(ny * 20 + time * 0.5)
                wave = (wave + 1) / 2  # 归一化
                
                # 水蓝色
                color = (
                    0.1 + 0.1 * wave,
                    0.5 + 0.3 * wave,
                    0.8 + 0.2 * wave,
                    1.0
                )
                
                idx = (y * width + x) * 4
                imb.pixels[idx] = color[0]
                imb.pixels[idx + 1] = color[1]
                imb.pixels[idx + 2] = color[2]
                imb.pixels[idx + 3] = color[3]
        
        return imb


def generate_textures():
    """生成纹理示例"""
    generator = TextureGenerator()
    
    # 创建噪声纹理
    noise = generator.create_perlin_noise(256, 256, scale=2.0, octaves=4)
    imbuf.write(noise, "perlin_noise.png", 'PNG')
    print("已生成: perlin_noise.png")
    noise.free()
    
    # 创建 Voronoi 纹理
    voronoi = generator.create_voronoi(256, 256, num_points=30)
    imbuf.write(voronoi, "voronoi.png", 'PNG')
    print("已生成: voronoi.png")
    voronoi.free()
    
    # 创建砖块纹理
    brick = generator.create_brick(512, 256)
    imbuf.write(brick, "brick.png", 'PNG')
    print("已生成: brick.png")
    brick.free()
    
    # 创建细胞纹理
    cellular = generator.create_cellular(256, 256, cell_size=32)
    imbuf.write(cellular, "cellular.png", 'PNG')
    print("已生成: cellular.png")
    cellular.free()
```

## 最佳实践

1. **内存管理**：使用完毕后及时调用 free() 方法释放图像缓冲内存
2. **格式选择**：根据用途选择合适的图像格式（PNG 用于无损，JPEG 用于照片）
3. **色彩空间**：处理图像时注意色彩空间转换，特别是线性与 sRGB 之间
4. **批处理优化**：大量图像处理时使用多线程提高效率
5. **错误处理**：添加适当的异常处理，确保程序的健壮性
