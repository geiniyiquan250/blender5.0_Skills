# bpy.ops - Blender Python Operations Module Reference

This document provides an overview of all bpy.ops submodules that have been documented in the skills package.

## Overview

The `bpy.ops` module contains all operator functions in Blender's Python API. Operators are actions that can be performed in Blender, such as creating objects, manipulating data, and executing commands.

## Documented Submodules

### High Priority Modules

1. **[bpy_ops_text_module.md](bpy_ops_text_module.md)** - Text Operations
   - Text object creation and editing
   - Selection and manipulation
   - Style and formatting

2. **[bpy_ops_import_scene_module.md](bpy_ops_import_scene_module.md)** - Scene Import Operations
   - Import FBX, OBJ, and other 3D formats
   - Import settings and options
   - Batch import functionality

3. **[bpy_ops_export_scene_module.md](bpy_ops_export_scene_module.md)** - Scene Export Operations
   - Export to GLTF, FBX, and other formats
   - Export settings and options
   - Batch export functionality

4. **[bpy_ops_font_module.md](bpy_ops_font_module.md)** - Font Operations
   - Text object creation and editing
   - Font selection and properties
   - Text styling and effects

5. **[bpy_ops_uv_module.md](bpy_ops_uv_module.md)** - UV Operations
   - UV selection and editing
   - UV projection and unwrapping
   - UV layout management

### Medium Priority Modules

6. **[bpy_ops_sound_module.md](bpy_ops_sound_module.md)** - Sound Operations
   - Audio playback and control
   - Volume and pitch management
   - Audio sequence editing

7. **[bpy_ops_cachefile_module.md](bpy_ops_cachefile_module.md)** - Cache File Operations
   - Alembic cache import/export
   - Cache management and playback
   - Cache optimization

8. **[bpy_ops_info_module.md](bpy_ops_info_module.md)** - Info Area Operations
   - Report management
   - System diagnostics
   - Information display

9. **[bpy_ops_lattice_module.md](bpy_ops_lattice_module.md)** - Lattice Operations
   - Lattice creation and editing
   - Deformation tools
   - Lattice animation

10. **[bpy_ops_marker_module.md](bpy_ops_marker_module.md)** - Timeline Marker Operations
    - Marker creation and management
    - Scene organization
    - Audio sync tools

11. **[bpy_ops_view2d_module.md](bpy_ops_view2d_module.md)** - 2D View Operations
    - View navigation
    - Text editor tools
    - Image viewer controls

12. **[bpy_ops_palette_module.md](bpy_ops_palette_module.md)** - Palette Operations
    - Color palette management
    - Color manipulation
    - Color scheme creation

13. **[bpy_ops_surface_module.md](bpy_ops_surface_module.md)** - Surface Operations
    - NURBS surface creation
    - Surface modeling tools
    - Curve operations

14. **[bpy_ops_uilist_module.md](bpy_ops_uilist_module.md)** - UI List Operations
    - UI list management
    - Collection management
    - Data block operations

15. **[bpy_ops_script_module.md](bpy_ops_script_module.md)** - Script Operations
    - Python script execution
    - Automation library
    - Batch processing

## Module Categories

### Import/Export Modules
- `bpy.ops.import_scene` - Import 3D formats
- `bpy.ops.export_scene` - Export 3D formats
- `bpy.ops.cachefile` - Cache file operations

### Editor Modules
- `bpy.ops.text` - Text editor
- `bpy.ops.uv` - UV editor
- `bpy.ops.view2d` - 2D views

### Object Modules
- `bpy.ops.font` - Text objects
- `bpy.ops.lattice` - Lattice objects
- `bpy.ops.surface` - Surface objects

### Media Modules
- `bpy.ops.sound` - Audio operations
- `bpy.ops.marker` - Timeline markers

### Utility Modules
- `bpy.ops.palette` - Color palettes
- `bpy.ops.uilist` - UI lists
- `bpy.ops.script` - Python scripts
- `bpy.ops.info` - Information

## Common Patterns

### Operator Execution
```python
import bpy

# Execute operator
bpy.ops.object.add()

# Execute with parameters
bpy.ops.object.delete(confirm=False)

# Check context before execution
if bpy.context.active_object:
    bpy.ops.object.modifier_apply()
```

### Context Handling
```python
# Set context for operation
with bpy.context.temp_override(area=area, region=region):
    bpy.ops.view2d.zoom()
```

### Error Handling
```python
try:
    bpy.ops.object.delete()
except RuntimeError as e:
    print(f"Delete failed: {e}")
```

## Best Practices

1. **Check Context**: Always check if the required context is available
2. **Use temp_override**: Use context temp_override for safe execution
3. **Handle Errors**: Wrap operators in try-except blocks
4. **Use Report**: Use bpy.ops.info.report_* for user feedback
5. **Batch Operations**: Group multiple operations together

## Additional Resources

- Blender Python API Documentation
- Official Blender Operator Reference
- Community Examples and Tutorials

## Notes

This documentation is part of the Blender Python Skills Package and is designed to provide practical examples and workflows for each submodule.

Last Updated: 2024
