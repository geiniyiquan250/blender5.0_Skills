# bpy.ops.workbench - Workbench渲染操作模块

bpy.ops.workbench模块提供了Workbench渲染引擎的操作功能，用于创建和配置高质量的渲染图像。

## 概述

Workbench是Blender的默认实时渲染引擎，专为建模和预览设计。这个模块提供了Workbench特有的渲染设置和输出操作。

## 核心功能

### 渲染操作

```python
import bpy

def render_screenshot(filepath=None):
    """渲染截图"""
    bpy.ops.workbench.render_screenshot(filepath=filepath)

def render_border():
    """渲染边框"""
    bpy.ops.render.render(
        use_viewport=True,
        write_still=True
    )
```

### 引擎设置

```python
def set_engine(engine_type='BLENDER_WORKBENCH'):
    """设置渲染引擎"""
    bpy.context.scene.render.engine = engine_type

def set_samples(samples):
    """设置采样数"""
    bpy.context.scene.eevee.taa_render_samples = samples

def set_resolution(resolution):
    """设置分辨率"""
    bpy.context.scene.render.resolution_x = resolution[0]
    bpy.context.scene.render.resolution_y = resolution[1]
```

## 实用函数

### 显示设置

```content="use_scene_lights",
        use_scene_world=True
    )

def set_material_mode(mode='MATERIAL'):
    """设置材质模式"""
    bpy.context.space_data.shading.type = 'MATERIAL'

def set_color_mode(mode='sRGB'):
    """设置颜色模式"""
    bpy.context.scene.display_settings.display_device = mode

def toggle_overlays():
    """切换叠加层"""
    bpy.context.space_data.overlay.show_overlays = not \
        bpy.context.space_data.overlay.show_overlays
```

### 性能设置

```python
def set_viewport_quality(quality):
    """设置视口质量"""
    bpy.context.scene.render.viewport_quality = quality

def enable_floor():
    """启用地面"""
    bpy.context.space_data.shading.show_floor = True

def set_light_intensity(intensity):
    """设置光照强度"""
    bpy.context.space_data.shading.light = intensity
```

## 常见问题排查

### 渲染问题

画面异常：
- 检查分辨率设置
- 确认光照正确
- 验证材质可用

### 性能问题

渲染慢：
- 降低采样数
- 减少分辨率
- 禁用阴影效果
