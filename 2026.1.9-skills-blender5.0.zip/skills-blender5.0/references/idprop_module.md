# idprop ID属性模块

提供对 Blender ID 属性的类型访问，用于处理自定义属性数据的序列化和反序列化。

## 类

### IDPropertyArray

```python
import bpy

obj = bpy.data.objects[0]
if "custom_array" in obj:
    arr = obj["custom_array"]
    if isinstance(arr, idprop.types.IDPropertyArray):
        print(f"类型代码: {arr.typecode}")
        python_list = arr.to_list()
```

Blender ID 属性数组类型，支持数值数组的存储和操作。

**方法：**

- `to_list()`: 将数组转换为 Python 列表返回。
- `typecode`: 属性，数组数据类型代码，'f' 表示 float，'d' 表示 double，'i' 表示 int，'b' 表示 bool。

---

### IDPropertyGroup

```python
import bpy
import idprop

obj = bpy.data.objects[0]
if "custom_group" in obj:
    group = obj["custom_group"]
    if isinstance(group, idprop.types.IDPropertyGroup):
        print(f"组名: {group.name}")
        keys = group.keys()
        for key in keys:
            print(f"{key}: {group.get(key)}")
```

Blender ID 属性组类型，支持字典-like 的键值对存储。

**方法：**

- `clear()`: 清除组中的所有成员。
- `get(key, default=None)`: 获取指定键的值，如果键不存在则返回默认值。
- `items()`: 返回组中的键值对迭代器。
- `keys()`: 返回组中所有键的列表。
- `pop(key, default)`: 从组中移除指定键并返回其值，如果键不存在则返回默认值。
- `to_dict()`: 将组转换为纯 Python 字典。
- `update(other)`: 使用另一个 IDPropertyGroup 或字典更新当前组。
- `values()`: 返回组中所有值的迭代器。

**属性：**

- `name`: 组的名称。

---

### 迭代器类

用于支持 IDPropertyGroup 的迭代操作。

- `IDPropertyGroupIterItems`: 键值对迭代器。
- `IDPropertyGroupIterKeys`: 键迭代器。
- `IDPropertyGroupIterValues`: 值迭代器。
- `IDPropertyGroupViewItems`: 键值对视图。
- `IDPropertyGroupViewKeys`: 键视图。
- `IDPropertyGroupViewValues`: 值视图。

---

## 使用示例

### 创建 ID 属性组

```python
import bpy

obj = bpy.context.active_object

if "MyCustomProps" not in obj:
    obj["MyCustomProps"] = {}

group = obj["MyCustomProps"]
group["name"] = "Test Object"
group["enabled"] = True
group["count"] = 42
group["scale_factor"] = 1.5
```

### 从 Python 字典创建

```python
import bpy
import idprop
from idprop.types import IDPropertyGroup

data = {
    "string_val": "Hello",
    "int_val": 100,
    "float_val": 3.14,
    "bool_val": False,
}

group = IDPropertyGroup()
group.update(data)

obj = bpy.context.active_object
obj["DynamicProps"] = group
```

### 读取和修改属性

```python
import bpy
import idprop

obj = bpy.context.active_object

if "Settings" in obj:
    settings = obj["Settings"]
    
    if isinstance(settings, idprop.types.IDPropertyGroup):
        old_value = settings.get("intensity", 1.0)
        settings["intensity"] = old_value * 1.5
        
        if "deprecated_key" in settings.keys():
            value = settings.pop("deprecated_key", 0)
            print(f"移除旧属性: {value}")
        
        print("所有设置:")
        for key, value in settings.items():
            print(f"  {key}: {value}")
```

### 导出属性数据

```python
import bpy
import idprop

obj = bpy.context.active_object

if "Config" in obj:
    config = obj["Config"]
    
    if isinstance(config, idprop.types.IDPropertyGroup):
        config_dict = config.to_dict()
        
        import json
        json_str = json.dumps(config_dict, indent=2)
        print(json_str)
```

### 处理数组属性

```python
import bpy
import idprop

obj = bpy.context.active_object

if "VertexColors" in obj:
    colors = obj["VertexColors"]
    
    if isinstance(colors, idprop.types.IDPropertyArray):
        print(f"数组类型: {colors.typecode}")
        
        python_list = colors.to_list()
        print(f"数组长度: {len(python_list)}")
        print(f"前3个元素: {python_list[:3]}")
```

### 属性组嵌套

```python
import bpy
import idprop
from idprop.types import IDPropertyGroup

obj = bpy.context.active_object

outer_group = IDPropertyGroup()
outer_group["name"] = "Outer"

inner_group = IDPropertyGroup()
inner_group["value"] = 123
inner_group["enabled"] = True

outer_group["nested"] = inner_group
obj["ComplexProps"] = outer_group

if "ComplexProps" in obj:
    complex_data = obj["ComplexProps"]
    if isinstance(complex_data, idprop.types.IDPropertyGroup):
        nested = complex_data.get("nested")
        if isinstance(nested, idprop.types.IDPropertyGroup):
            print(f"嵌套值: {nested.get('value')}")
```

### 批量更新属性

```python
import bpy
import idprop

obj = bpy.context.active_object

if "BatchUpdate" in obj:
    batch = obj["BatchUpdate"]
    
    if isinstance(batch, idprop.types.IDPropertyGroup):
        updates = {
            "param1": 10,
            "param2": 20,
            "param3": 30,
        }
        
        batch.update(updates)
        
        print("更新后的键:", batch.keys())
        print("更新后的值:", [batch.get(k) for k in batch.keys()])
```

---

## 注意事项

1. **类型检查**: 使用 isinstance() 检查属性是否为 IDPropertyGroup 或 IDPropertyArray 类型。

2. **数据转换**: to_dict() 方法将 IDPropertyGroup 转换为纯 Python 字典，便于序列化。

3. **数组类型**: IDPropertyArray 的 typecode 属性指示数据类型，'f' 为单精度浮点，'d' 为双精度浮点，'i' 为整型，'b' 为布尔型。

4. **迭代器生命周期**: 迭代器类在遍历过程中使用，注意不要在迭代过程中修改组结构。

5. **属性嵌套**: IDPropertyGroup 可以嵌套其他 IDPropertyGroup，形成复杂的数据结构。

6. **文件保存**: ID 属性会自动随 .blend 文件保存和加载。

7. **Python 表示**: pop() 和 get() 方法返回 Python 原生类型，而不是 ID 属性类型。