# bpy.utils.previews - 预览图工具模块

bpy.utils.previews模块提供了创建和管理预览图集合的功能，用于在UI面板中显示图标和缩略图。

## 概述

预览图工具允许你加载图像文件并将其作为预览图存储在集合中，方便在自定义UI面板中显示图标、缩略图和图像资源。

## 核心功能

### 创建预览集合

```python
import bpy
import os

def create_preview_collection():
    """创建新的预览集合"""
    pcoll = bpy.utils.previews.new()
    return pcoll

def create_named_preview_collection(name):
    """创建指定名称的预览集合"""
    pcoll = bpy.utils.previews.new()
    pcoll.name = name
    return pcoll
```

### 加载预览图

```python
def load_preview_icon(pcoll, name, filepath):
    """加载图标预览"""
    pcoll.load(name, filepath, 'IMAGE')
    return pcoll[name]

def load_preview_thumbnails(pcoll, directory, extension='.png'):
    """批量加载目录中的缩略图"""
    if not os.path.exists(directory):
        return
    for filename in os.listdir(directory):
        if filename.endswith(extension):
            name = os.path.splitext(filename)[0]
            filepath = os.path.join(directory, filename)
            pcoll.load(name, filepath, 'IMAGE')

def load_previews_with_force(pcoll, name, filepath, force_reload=False):
    """加载预览图，可强制重新加载"""
    preview = pcoll.load(name, filepath, 'IMAGE', force_reload=force_reload)
    return preview
```

### 管理预览

```python
def get_preview(pcoll, name):
    """获取指定名称的预览"""
    if name in pcoll:
        return pcoll[name]
    return None

def create_empty_preview(pcoll, name):
    """创建空预览"""
    return pcoll.new(name)

def list_preview_names(pcoll):
    """列出所有预览名称"""
    return list(pcoll.keys())

def clear_previews(pcoll):
    """清空预览集合"""
    for name in list(pcoll.keys()):
        del pcoll[name]
```

## 实用函数

### UI面板集成

```python
class PreviewPanel(bpy.types.Panel):
    """预览图面板示例"""
    bl_label = "图标预览"
    bl_idname = "OBJECT_PT_preview_icons"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    
    def draw(self, context):
        layout = self.layout
        pcoll = custom_previews.get("main_icons")
        if pcoll:
            col = layout.column(align=True)
            for name in pcoll.keys():
                icon_preview = pcoll[name]
                if icon_preview.icon_id:
                    col.template_icon(icon_preview.icon_id, scale=1.0)
                    col.label(text=name)

def register_panel_icons():
    """注册面板使用的图标"""
    global custom_previews
    custom_previews = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    load_preview_thumbnails(custom_previews, icons_dir)

def unregister_panel_icons():
    """注销图标"""
    global custom_previews
    if custom_previews:
        custom_previews.clear()
        bpy.utils.previews.remove(custom_previews)
        custom_previews = None
```

### 动态图标加载

```python
def load_dynamic_icons(operator, context):
    """动态加载操作符图标"""
    pcoll = bpy.utils.previews.new()
    icons_path = operator.bl_icon_path
    if icons_path and os.path.exists(icons_path):
        pcoll.load("op_icon", icons_path, 'IMAGE', force_reload=True)
    return pcoll.get("op_icon")

def reload_icon_on_change(self, context):
    """当属性变化时重新加载图标"""
    if self.icon_file_path:
        if not hasattr(self, '_preview'):
            self._preview = bpy.utils.previews.new()
        self._preview.load("dynamic_icon", self.icon_file_path, 'IMAGE', force_reload=True)
```

### 资源管理

```python
class IconManager:
    """图标管理器类"""
    def __init__(self):
        self.previews = {}
    
    def add_collection(self, name, directory=None):
        """添加预览集合"""
        self.previews[name] = bpy.utils.previews.new()
        if directory:
            self.load_directory(name, directory)
        return self.previews[name]
    
    def load_directory(self, name, directory, extension='.png'):
        """加载目录中的所有图标"""
        if name in self.previews:
            load_preview_thumbnails(self.previews[name], directory, extension)
    
    def get_preview(self, collection_name, icon_name):
        """获取预览"""
        if collection_name in self.previews:
            return self.previews[collection_name].get(icon_name)
        return None
    
    def clear(self, name=None):
        """清空预览集合"""
        if name and name in self.previews:
            self.previews[name].clear()
        else:
            for pcoll in self.previews.values():
                pcoll.clear()
    
    def cleanup(self):
        """清理所有预览"""
        self.clear()
        for pcoll in self.previews.values():
            bpy.utils.previews.remove(pcoll)
        self.previews.clear()
```

## 常见问题排查

### 预览图不显示

图标ID无效：
- 确保已调用load()方法加载图像
- 检查文件路径是否正确
- 确认文件格式被支持

### 加载失败

文件路径问题：
- 使用绝对路径而非相对路径
- 检查文件是否存在且可读
- 确认文件扩展名正确

### 内存问题

预览图过多：
- 及时清理不再使用的预览集合
- 使用remove()方法彻底删除
- 避免在循环中重复创建集合

### 性能问题

加载速度慢：
- 使用force_reload=False避免重复加载缓存
- 批量加载时使用目录加载函数
- 考虑使用较小的图像尺寸
