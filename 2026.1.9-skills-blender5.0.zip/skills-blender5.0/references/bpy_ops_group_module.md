# bpy.ops.group - 组操作模块

Blender对象组操作符，用于创建和管理对象集合组。

## 概述

`bpy.ops.group` 模块提供用于在Blender中创建、编辑和管理对象组的功能。对象组允许您组织和批量操作多个对象。

## 核心功能

### 组创建

```python
import bpy

# 创建新组
bpy.ops.group.create(
    name='MyGroup'
)

# 创建空组
bpy.ops.group.create(
    name='EmptyGroup'
)

# 追加到现有组
bpy.ops.group.objects_add(
    collection='MyGroup'
)

# 从选择创建组
bpy.ops.group.create(
    name='SelectedObjects'
)
```

### 组操作

```python
# 添加选中对象到组
bpy.ops.group.objects_add_active(
    collection='MyGroup'
)

# 从组中移除对象
bpy.ops.group.objects_remove(
    collection='MyGroup'
)

# 移除活动对象
bpy.ops.group.objects_remove_active(
    collection='MyGroup'
)

# 清除所有组
bpy.ops.group.objects_remove_all()

# 链接组到场景
bpy.ops.group.link(
    collection='MyGroup'
)

# 取消链接组
bpy.ops.group.unlink(
    collection='MyGroup'
)
```

### 组管理

```python
# 重命名组
bpy.ops.group.rename(
    name='OldName',
    new_name='NewName'
)

# 删除组
bpy.ops.group.delete(
    unlink=True
)

# 复制组
bpy.ops.group.duplicate(
    collection='MyGroup'
)

# 合并组
bpy.ops.group.merge(
    collection='TargetGroup'
)

# 选择组内对象
bpy.ops.group.select(
    collection='MyGroup'
)

# 反选组内对象
bpy.ops.group.inverse_select(
    collection='MyGroup'
)

# 选择组
bpy.ops.group.select_all(
    collection='MyGroup',
    action='SELECT'
)
```

### 批量组操作

```python
# 创建并填充组
def create_filled_group(group_name, object_names):
    bpy.ops.group.create(name=group_name)
    for obj_name in object_names:
        obj = bpy.data.objects.get(obj_name)
        if obj:
            bpy.context.view_layer.objects.active = obj
            bpy.ops.group.objects_add_active(collection=group_name)

# 批量创建组
def batch_create_groups(base_name, count, prefix=''):
    groups = []
    for i in range(count):
        group_name = f'{base_name}_{i}'
        bpy.ops.group.create(name=group_name)
        groups.append(group_name)
    return groups

# 移动对象到组
def move_to_group(object_name, target_group):
    obj = bpy.data.objects.get(object_name)
    if obj:
        for group in obj.users_group:
            bpy.ops.group.objects_remove(collection=group.name)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.group.objects_add_active(collection=target_group)

# 复制组内容
def duplicate_group_contents(source_group, target_name):
    source = bpy.data.collections.get(source_group)
    if source:
        bpy.ops.group.create(name=target_name)
        for obj in source.objects:
            obj.select_set(True)
        bpy.ops.group.objects_add_active(collection=target_name)
        bpy.ops.object.select_all(action='DESELECT')
```

## 实用函数

```python
def get_group_objects(group_name):
    """获取组内所有对象"""
    group = bpy.data.collections.get(group_name)
    if group:
        return list(group.objects)
    return []

def is_in_group(object_name, group_name):
    """检查对象是否在组中"""
    obj = bpy.data.objects.get(object_name)
    group = bpy.data.collections.get(group_name)
    if obj and group:
        return obj in group.objects
    return False

def get_object_groups(object_name):
    """获取对象所属的所有组"""
    obj = bpy.data.objects.get(object_name)
    if obj:
        return [group.name for group in obj.users_group]
    return []

def create_layer_collection(group_name):
    """为组创建层集合"""
    layer_collection = bpy.context.view_layer.layer_collection
    bpy.ops.collection.create(name=group_name)
    return layer_collection.children.get(group_name)

def link_to_all_scenes(group_name):
    """将组链接到所有场景"""
    group = bpy.data.collections.get(group_name)
    if group:
        for scene in bpy.data.scenes:
            if group.name not in scene.collection.children:
                scene.collection.children.link(group)

def export_group_to_file(group_name, filepath):
    """导出组内容到文件"""
    group = bpy.data.collections.get(group_name)
    if group:
        for obj in group.objects:
            obj.select_set(True)
        bpy.ops.export_scene.fbx(
            filepath=filepath,
            use_selection=True
        )
        bpy.ops.object.select_all(action='DESELECT')

def batch_assign_materials(group_name, material_name):
    """批量为组内对象分配材质"""
    group = bpy.data.collections.get(group_name)
    material = bpy.data.materials.get(material_name)
    if group and material:
        for obj in group.objects:
            if obj.data and hasattr(obj.data, 'materials'):
                obj.data.materials.append(material)
```

## 常见问题排查

### 对象不在组中
```python
# 检查对象所属组
obj = bpy.context.active_object
print(f"对象: {obj.name}")
print(f"所属组: {[g.name for g in obj.users_group]}")

# 检查组内对象
group = bpy.data.collections.get('MyGroup')
print(f"组内对象: {[obj.name for obj in group.objects]}")

# 重新添加对象
bpy.context.view_layer.objects.active = obj
bpy.ops.group.objects_add_active(collection='MyGroup')
```

### 组不可见
```python
# 检查组可见性
group = bpy.data.collections.get('MyGroup')
print(f"隐藏: {group.hide_viewport}")
print(f"渲染隐藏: {group.hide_render}")

# 显示组
group.hide_viewport = False
group.hide_render = False

# 检查层集合
layer_collection = bpy.context.view_layer.layer_collection
for child in layer_collection.children:
    if child.name == group.name:
        print(f"层集合隐藏: {child.hide_viewport}")
        child.hide_viewport = False
```

### 批量操作问题
```python
# 检查所有组
print("所有组:")
for group in bpy.data.collections:
    print(f"  {group.name}: {len(group.objects)} 对象")

# 检查场景中的组
scene = bpy.context.scene
print("场景组:")
for child in scene.collection.children:
    print(f"  {child.name}")

# 同步组和场景
for group in bpy.data.collections:
    if group.name not in scene.collection.children:
        scene.collection.children.link(group)
```
