# bpy_extras.anim_utils - 动画工具模块

bpy_extras.anim_utils模块提供了Blender动画相关的实用工具函数，用于简化动画数据的创建和操作。

## 概述

动画工具模块包含用于创建动画关键帧、驱动路径、权重渐变等动画相关操作的函数。这些函数封装了常见的动画任务，让动画开发更加便捷。

## 核心功能

### 关键帧操作

```python
import bpy
from bpy_extras.anim_utils import (
    animation_step,
    make_weighted_deform_path
)

def insert_keyframe(obj, data_path, frame, value):
    """在指定帧插入关键帧"""
    obj.keyframe_insert(data_path=data_path, frame=frame)
    if data_path in obj:
        obj[data_path] = value

def set_keyframe_at_frame(obj, path, frame, value):
    """在指定帧设置关键帧值"""
    obj.path_from_id(path)
    obj[path] = value
    obj.keyframe_insert(data_path=path, frame=frame)

def batch_insert_keyframes(obj, data_path, keyframes):
    """批量插入关键帧"""
    for frame, value in keyframes:
        obj[data_path] = value
        obj.keyframe_insert(data_path=data_path, frame=frame)

def create_keyframe_anim(obj, property_name, values, frames):
    """创建关键帧动画"""
    if len(values) != len(frames):
        return
    for value, frame in zip(values, frames):
        obj[property_name] = value
        obj.keyframe_insert(data_path=property_name, frame=frame)
```

### 驱动路径

```python
def create_driver_path(obj, target_obj, target_prop, data_path, var_name='var'):
    """创建驱动路径"""
    fcurves = obj.animation_data.drivers
    driver = fcurves.new(data_path=data_path)
    driver.driver.expression = var_name
    var = driver.driver.variables.new()
    var.name = var_name
    var.targets[0].id = target_obj
    var.targets[0].data_path = target_prop
    return driver

def create_distance_driver(obj, target_obj, driver_var='dist'):
    """创建距离驱动"""
    return create_driver_path(
        obj, target_obj, 
        'location', 
        'location',
        driver_var
    )

def create_rotation_driver(obj, target_obj, axis='X', driver_var='rot'):
    """创建旋转驱动"""
    prop_path = f'rotation_euler.{axis.lower()}'
    return create_driver_path(obj, target_obj, prop_path, prop_path, driver_var)

def remove_all_drivers(obj):
    """移除所有驱动"""
    if obj.animation_data and obj.animation_data.drivers:
        for fcurve in list(obj.animation_data.drivers):
            obj.animation_data.drivers.remove(fcurve)
```

### 动画数据管理

```python
def copy_anim_data(source, target, replace=False):
    """复制动画数据"""
    if source.animation_data and source.animation_data.action:
        if not target.animation_data:
            target.animation_data_create()
        if replace or not target.animation_data.action:
            target.animation_data.action = source.animation_data.action.copy()

def merge_animations(target_action, source_action, start_frame=1):
    """合并动画"""
    if not source_action:
        return
    for fcurve in source_action.fcurves:
        for keyframe in fcurve.keyframe_points:
            keyframe.co[0] += start_frame - 1
        target_action.fcurves.new(fcurve.data_path)
        target_action.fcurves[-1].keyframe_points.add(len(fcurve.keyframe_points))
        for i, kp in enumerate(fcurve.keyframe_points):
            target_action.fcurves[-1].keyframe_points[i].co = kp.co
            target_action.fcurves[-1].keyframe_points[i].handle_left = kp.handle_left
            target_action.fcurves[-1].keyframe_points[i].handle_right = kp.handle_right

def clear_anim_data(obj, preserve_actions=True):
    """清除动画数据"""
    if not obj.animation_data:
        return
    if preserve_actions:
        actions = [fc.action for fc in obj.animation_data.drivers]
        for action in actions:
            if action and action.users == 1:
                bpy.data.actions.remove(action)
    obj.animation_data_clear()
```

## 实用函数

### 动画曲线分析

```python
def get_action_range(action):
    """获取动作帧范围"""
    if not action:
        return None, None
    start_frame = float('inf')
    end_frame = float('-inf')
    for fcurve in action.fcurves:
        for keyframe in fcurve.keyframe_points:
            if keyframe.co[0] < start_frame:
                start_frame = keyframe.co[0]
            if keyframe.co[0] > end_frame:
                end_frame = keyframe.co[0]
    return int(start_frame), int(end_frame) if end_frame != float('-inf') else None

def get_anim_length(obj):
    """获取动画长度"""
    action = None
    if obj.animation_data and obj.animation_data.action:
        action = obj.animation_data.action
    elif obj.animation_data and obj.animation_data.nla_tracks:
        for track in obj.animation_data.nla_tracks:
            for strip in track.strips:
                if strip.action:
                    action = strip.action
                    break
    if action:
        return get_action_range(action)
    return None, None

def count_keyframes(obj):
    """统计关键帧数量"""
    count = 0
    if obj.animation_data:
        if obj.animation_data.action:
            for fcurve in obj.animation_data.action.fcurves:
                count += len(fcurve.keyframe_points)
    return count
```

### 权重路径

```python
def create_weighted_deform_path(obj, vertex_group, points, frames, easing='AUTO'):
    """创建加权变形路径"""
    make_weighted_deform_path(
        obj, 
        vertex_group, 
        points, 
        frames, 
        easing=easing
    )

def create_warp_path(obj, vgroup, path_points, start_frame=1):
    """创建变形动画路径"""
    points = [p.co for p in path_points]
    frames = list(range(start_frame, start_frame + len(points)))
    create_weighted_deform_path(obj, vgroup, points, frames)
```

### 动画工具

```python
def bake_action_to_objects(action, objects, frame_start, frame_end):
    """将动作烘焙到多个对象"""
    for obj in objects:
        if not obj.animation_data:
            obj.animation_data_create()
        obj.animation_data.action = action.copy()
        bpy.context.view_layer.objects.active = obj
        bpy.ops.nla.bake(frame_start=frame_start, frame_end=frame_end)

def retarget_action(source_obj, target_obj, target_rig=None):
    """重定向动作"""
    if not source_obj.animation_data or not source_obj.animation_data.action:
        return
    action = source_obj.animation_data.action
    if not target_obj.animation_data:
        target_obj.animation_data_create()
    target_obj.animation_data.action = action.copy()
```

## 常见问题排查

### 关键帧不生效

数据路径错误：
- 确保使用正确的属性路径，如'location'、'rotation_euler'
- 使用obj.path_from_id()验证路径
- 检查属性是否可动画化

### 驱动不更新

依赖关系问题：
- 确保驱动目标对象存在
- 检查目标属性是否正确
- 尝试手动更新：bpy.context.view_layer.update()

### 动画丢失

数据清除问题：
- 在复制操作前检查动画数据是否存在
- 使用copy()而非直接赋值
- 及时保存未使用的数据块
