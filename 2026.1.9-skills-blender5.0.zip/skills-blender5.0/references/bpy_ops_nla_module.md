# bpy.ops.nla 模块

非线性动画操作模块，用于管理动画条、轨道和动画混合。

## 概述

bpy.ops.nla 模块包含用于在非线性动画编辑器中操作动画的运算符。NLA编辑器用于管理多个动画片段的叠加和混合，支持复杂的动画层级结构。

## 常用操作

### 轨道操作

```python
import bpy

# 添加轨道
bpy.ops.nla.track_add()

# 删除轨道
bpy.ops.nla.track_delete()

# 移动轨道
bpy.ops.nla.track_move(direction='UP')
bpy.ops.nla.track_move(direction='DOWN')

# 选择轨道
bpy.ops.nla.track_select(extend=False)

# 取消选择轨道
bpy.ops.nla.tracks_deselect()
```

### 动画条操作

```python
# 添加动画条
bpy.ops.nla.strip_add()

# 删除动画条
bpy.ops.nla.strip_delete()

# 移动动画条
bpy.ops.nla.strip_move(direction='LEFT')
bpy.ops.nla.strip_move(direction='RIGHT')

# 调整动画条大小
bpy.ops.nla.strip_modal()

# 拆分动画条
bpy.ops.nla.strip_split()

# 标记切片
bpy.ops.nla.strip_jump()

# 选择动画条
bpy.ops.nla.select(extend=False)
bpy.ops.nla.select(extend=True, align=True)

# 切换选择
bpy.ops.nla.select_border(extension=False)
```

### 动作操作

```python
# 推行动作到NLA
bpy.ops.nla.push_down()

# 弹出动作
bpy.ops.nla.pop()

# 应用混合
bpy.ops.nla.apply_as()

# 创建动作
bpy.ops.nla.action_new()

# 转换到场景范围
bpy.ops.nla.toscenens()

# 合并动作
bpy.ops.nla.action_sync_length()
```

### 混合操作

```python
# 设置混合类型
bpy.ops.nla.blend_type(type='REPLACE')

# 设置混合强度
bpy.ops.nla.blend_down()

# 混合滑块
bpy.ops.nla.mixdown()

# 混合插值
bpy.ops.nla.mix_interp(type='AUTO')
```

### 关键帧操作

```python
# 插入关键帧
bpy.ops.nla.keyframe_insert(type='ALL')

# 删除关键帧
bpy.ops.nla.keyframe_delete(type='ALL')

# 清除关键帧
bpy.ops.nla.keyframe_clear(type='ALL')

# 添加所有重要关键帧
bpy.ops.nla.keyframe_insert(type='WHOLE_CHARACTER')
```

### 视图操作

```python
# 跳转到前一个关键帧
bpy.ops.nla.previewrange_set()

# 跳转到下一个关键帧
bpy.ops.nla.view_selected()

# 视图所有
bpy.ops.nla.view_all()

# 跳转到开始
bpy.ops.nla.frame_jump()

# 跳转到原点
bpy.ops.nla.origin_set()
```

### 复制粘贴操作

```python
# 复制
bpy.ops.nla.copy()

# 粘贴
bpy.ops.nla.paste()

# 粘贴到选中
bpy.ops.nla.paste(flipped=False)
```

## 实际应用示例

### 创建动画混合系统

```python
def create_animation_blend_system(obj, base_action, overlay_action, blend_frames=10):
    """创建动画混合系统"""
    # 推入基础动作到NLA
    bpy.context.view_layer.objects.active = obj
    obj.animation_data.action = base_action
    bpy.ops.nla.push_down()
    
    # 获取NLA轨道
    nla_tracks = obj.animation_data.nla_tracks
    
    # 创建覆盖动画轨道
    overlay_track = nla_tracks.new()
    overlay_track.name = 'OverlayAnim'
    
    # 设置动作
    obj.animation_data.action = overlay_action
    obj.animation_data.nla_tracks.active = overlay_track
    bpy.ops.nla.push_down()
    
    # 设置混合
    for strip in overlay_track.strips:
        strip.blend_type = 'ADD'
        strip.blend_in = blend_frames
        strip.blend_out = blend_frames
    
    return overlay_track
```

### 创建层级动画系统

```python
def create_layered_animation(obj, layers=3):
    """创建层级动画系统"""
    # 创建NLA轨道层级
    tracks = []
    
    for i in range(layers):
        # 添加轨道
        track = obj.animation_data.nla_tracks.new()
        track.name = f'AnimLayer_{i}'
        tracks.append(track)
        
        # 设置活动轨道
        obj.animation_data.nla_tracks.active = track
    
    return tracks

def add_animation_to_layer(obj, layer_index, action, start_frame=1, end_frame=30):
    """添加动画到指定层"""
    # 获取轨道
    tracks = obj.animation_data.nla_tracks
    if layer_index >= len(tracks):
        return None
    
    track = tracks[layer_index]
    
    # 设置动作
    obj.animation_data.action = action
    
    # 创建动画条
    strip = track.strips.new(action.name, start_frame, action)
    strip.frame_start = start_frame
    strip.frame_end = end_frame
    
    return strip
```

### 创建程序化动画序列

```python
def create_animated_sequence(obj, actions, frame_ranges):
    """创建动画序列"""
    current_frame = 1
    
    for i, action in enumerate(actions):
        # 创建轨道
        track = obj.animation_data.nla_tracks.new()
        track.name = f'Seq_{i}'
        
        # 设置动作
        obj.animation_data.action = action
        
        # 获取帧范围
        start_frame = frame_ranges[i][0]
        end_frame = frame_ranges[i][1]
        
        # 创建动画条
        strip = track.strips.new(action.name, start_frame, action)
        strip.frame_start = start_frame
        strip.frame_end = end_frame
        
        # 设置转换
        if i > 0:
            prev_strip = tracks[i-1].strips[-1]
            prev_strip.blend_out = 5
        
        strip.blend_in = 5
        strip.blend_type = 'REPLACE'
```

### 创建程序化行走循环

```python
def setup_procedural_walk_cycle(character, walk_actions, cycle_count=4):
    """设置程序化行走循环"""
    current_frame = 1
    total_frames = 0
    
    # 计算总帧数
    for action in walk_actions:
        if action.frame_range[1] > total_frames:
            total_frames = action.frame_range[1]
    
    # 创建主轨道
    main_track = character.animation_data.nla_tracks.new()
    main_track.name = 'WalkCycle'
    
    # 添加每个动作
    for i, action in enumerate(walk_actions):
        action_start = current_frame
        action_end = current_frame + (action.frame_range[1] - action.frame_range[0])
        
        # 设置动作
        character.animation_data.action = action
        
        # 创建动画条
        strip = main_track.strips.new(action.name, action_start, action)
        strip.frame_start = action_start
        strip.frame_end = action_end
        strip.repeat = cycle_count
        
        current_frame = action_end + 1
    
    return main_track
```

### 创建动画过渡系统

```python
def create_animation_transitions(obj, actions, transition_length=10):
    """创建动画过渡系统"""
    tracks = obj.animation_data.nla_tracks
    transition_track = tracks.new()
    transition_track.name = 'Transitions'
    
    for i in range(len(actions) - 1):
        current_action = actions[i]
        next_action = actions[i + 1]
        
        # 创建过渡动画条
        start_frame = int(current_action.frame_range[1])
        end_frame = start_frame + transition_length
        
        # 设置过渡动作
        obj.animation_data.action = current_action
        bpy.ops.nla.push_down()
        
        # 设置混合
        for strip in transition_track.strips:
            if strip.name == current_action.name:
                strip.blend_out = transition_length
        
        obj.animation_data.action = next_action
        bpy.ops.nla.push_down()
        
        for strip in transition_track.strips:
            if strip.name == next_action.name:
                strip.blend_in = transition_length
                strip.blend_type = 'ADD'
```

### 创建随机动画选择器

```python
def create_random_animation_selector(obj, actions, select_frame=1):
    """创建随机动画选择器"""
    tracks = obj.animation_data.nla_tracks
    
    # 创建随机选择轨道
    selector_track = tracks.new()
    selector_track.name = 'RandomSelector'
    
    # 添加所有动作到轨道
    for i, action in enumerate(actions):
        # 设置动作
        obj.animation_data.action = action
        
        # 随机起始帧
        import random
        random_start = random.randint(1, int(action.frame_range[1]))
        
        # 创建动画条
        strip = selector_track.strips.new(
            action.name,
            select_frame + i * 10,
            action
        )
        
        # 设置条件
        strip.use_reverse = False
        strip.repeat = 1
    
    return selector_track
```

## 使用场景

- **角色动画**：管理复杂的角色动画系统
- **动画混合**：混合多个动画片段
- **动画序列**：创建动画播放列表
- **动画分层**：创建动画层级系统
- **程序化动画**：程序化生成复杂动画
- **动画过渡**：创建平滑的动画过渡

## 注意事项

- NLA操作需要正确的活动对象
- 动画条不能重叠
- 混合类型影响最终动画效果
- 轨道顺序影响动画叠加
- 关键帧插入需要正确的时间范围
- 动作推入会创建新的动画条
