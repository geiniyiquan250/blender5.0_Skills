# bpy.ops.export_scene - USD导出操作模块

Blender USD文件导出操作符，用于将场景导出为USD（Universal Scene Description）格式。

## 概述

`bpy.ops.export_scene.usd` 模块提供用于将Blender场景导出为USD格式的功能，支持几何体、材质、动画和高级渲染设置的导出。

## 核心功能

### 基础导出

```python
import bpy

# 导出USD文件
bpy.ops.export_scene.usd(
    filepath='//model.usd',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    export_selected=False,
    usd_format='USD',
    export_materials=True,
    export_cameras=True,
    export_lights=True,
    export_curves=True,
    export_particles=True,
    use_instance_attributes=True,
    use_visible=True,
    use_active_objects=False,
    export_uv=True,
    export_normals=True,
    export_colors=True,
    export_meshes=True,
    export_lods='NONE',
    export_image_format='NONE',
    export_thumbnail=True,
    export_procedural='NONE',
    export_custom_properties=True,
    export_preview=True,
    apply_subdiv=False,
    export_anim=True,
    export_anim_use_frame_range=True,
    export_anim_use_nla_strips=True,
    export_anim_armature=True,
    export_anim_shape_keys=True,
    export_anim_smooth_curves=True,
    export_anim_always_sample=True,
    export_anim_including_final=False,
    export_anim_step=1.0,
    export_anim_simplify_factor=0.0,
    export_parents=True,
    export_material_variant='CURRENT',
    default_uv='UVMap',
    default_material='Principled BSDF',
    path_mode='RELATIVE',
    export_format='EXPORT',
    rescale_double_sided=True,
    export_transformation_type='壹致',
    export_level_of_detail=True,
    export_compact_usd=False
)
```

### USD格式选择

```python
# 导出为USD格式
bpy.ops.export_scene.usd(
    filepath='//model.usd',
    usd_format='USD'
)

# 导出为USDZ格式
bpy.ops.export_scene.usd(
    filepath='//model.usdz',
    usd_format='USDZ'
)

# 导出为USDA格式
bpy.ops.export_scene.usd(
    filepath='//model.usda',
    usd_format='USDA'
)
```

### 导出范围

```python
# 只导出选中对象
bpy.ops.export_scene.usd(
    filepath='//selected.usd',
    export_selected=True
)

# 导出所有对象
bpy.ops.export_scene.usd(
    filepath='//all.usd',
    export_selected=False
)
```

### 几何体导出

```python
# 导出网格
bpy.ops.export_scene.usd(
    filepath='//meshes.usd',
    export_meshes=True
)

# 不导出网格
bpy.ops.export_scene.usd(
    filepath='//no_meshes.usd',
    export_meshes=False
)

# 导出UV
bpy.ops.export_scene.usd(
    filepath='//uv.usd',
    export_uv=True
)

# 不导出UV
bpy.ops.export_scene.usd(
    filepath='//no_uv.usd',
    export_uv=False
)

# 导出法线
bpy.ops.export_scene.usd(
    filepath='//normals.usd',
    export_normals=True
)

# 不导出法线
bpy.ops.export_scene.usd(
    filepath='//no_normals.usd',
    export_normals=False
)

# 导出颜色
bpy.ops.export_scene.usd(
    filepath='//colors.usd',
    export_colors=True
)

# 不导出颜色
bpy.ops.export_scene.usd(
    filepath='//no_colors.usd',
    export_colors=False
)
```

### 曲线和粒子

```python
# 导出曲线
bpy.ops.export_scene.usd(
    filepath='//curves.usd',
    export_curves=True
)

# 不导出曲线
bpy.ops.export_scene.usd(
    filepath='//no_curves.usd',
    export_curves=False
)

# 导出粒子
bpy.ops.export_scene.usd(
    filepath='//particles.usd',
    export_particles=True
)

# 不导出粒子
bpy.ops.export_scene.usd(
    filepath='//no_particles.usd',
    export_particles=False
)
```

### 相机和灯光

```python
# 导出相机
bpy.ops.export_scene.usd(
    filepath='//cameras.usd',
    export_cameras=True
)

# 不导出相机
bpy.ops.export_scene.usd(
    filepath='//no_cameras.usd',
    export_cameras=False
)

# 导出灯光
bpy.ops.export_scene.usd(
    filepath='//lights.usd',
    export_lights=True
)

# 不导出灯光
bpy.ops.export_scene.usd(
    filepath='//no_lights.usd',
    export_lights=False
)
```

### 材质导出

```python
# 导出材质
bpy.ops.export_scene.usd(
    filepath='//materials.usd',
    export_materials=True
)

# 不导出材质
bpy.ops.export_scene.usd(
    filepath='//no_materials.usd',
    export_materials=False
)

# 设置默认材质
bpy.ops.export_scene.usd(
    filepath='//model.usd',
    default_material='Principled BSDF'
)
```

### 可见性设置

```python
# 导出可见对象
bpy.ops.export_scene.usd(
    filepath='//visible.usd',
    use_visible=True
)

# 导出活动对象
bpy.ops.export_scene.usd(
    filepath='//active.usd',
    use_active_objects=True
)

# 使用实例属性
bpy.ops.export_scene.usd(
    filepath='//instances.usd',
    use_instance_attributes=True
)
```

### LOD设置

```python
# 不导出LOD
bpy.ops.export_scene.usd(
    filepath='//model.usd',
    export_lods='NONE'
)

# 导出所有LOD
bpy.ops.export_scene.usd(
    filepath='//lods.usd',
    export_lods='ALL'
)
```

### 图像导出

```python
# 图像格式
bpy.ops.export_scene.usd(
    filepath='//images.usd',
    export_image_format='PNG'
)

# 不导出图像
bpy.ops.export_scene.usd(
    filepath='//no_images.usd',
    export_image_format='NONE'
)

# 导出缩略图
bpy.ops.export_scene.usd(
    filepath='//thumb.usd',
    export_thumbnail=True
)

# 不导出缩略图
bpy.ops.export_scene.usd(
    filepath='//no_thumb.usd',
    export_thumbnail=False
)
```

### 程序化导出

```python
# 不使用程序化
bpy.ops.export_scene.usd(
    filepath='//model.usd',
    export_procedural='NONE'
)

# 导出为程序化
bpy.ops.export_scene.usd(
    filepath='//procedural.usd',
    export_procedural='EXPORT'
)
```

### 自定义属性

```python
# 导出自定义属性
bpy.ops.export_scene.usd(
    filepath='//props.usd',
    export_custom_properties=True
)

# 不导出自定义属性
bpy.ops.export_scene.usd(
    filepath='//no_props.usd',
    export_custom_properties=False
)
```

### 预览设置

```python
# 导出预览
bpy.ops.export_scene.usd(
    filepath='//preview.usd',
    export_preview=True
)

# 不导出预览
bpy.ops.export_scene.usd(
    filepath='//no_preview.usd',
    export_preview=False
)
```

### 细分设置

```python
# 应用细分
bpy.ops.export_scene.usd(
    filepath='//subdiv.usd',
    apply_subdiv=True
)

# 不应用细分
bpy.ops.export_scene.usd(
    filepath='//no_subdiv.usd',
    apply_subdiv=False
)
```

### 动画设置

```python
# 导出动画
bpy.ops.export_scene.usd(
    filepathd',
    export='//anim.us_anim=True
)

# 不导出动画
bpy.ops.export_scene.usd(
    filepath='//static.usd',
    export_anim=False
)

# 使用帧范围
bpy.ops.export_scene.usd(
    filepath='//range.usd',
    export_anim=True,
    export_anim_use_frame_range=True
)

# 使用NLA轨道
bpy.ops.export_scene.usd(
    filepath='//nla.usd',
    export_anim=True,
    export_anim_use_nla_strips=True
)

# 导出骨骼动画
bpy.ops.export_scene.usd(
    filepath='//armature.usd',
    export_anim=True,
    export_anim_armature=True
)

# 导出形态键动画
bpy.ops.export_scene.usd(
    filepath='//shapekey.usd',
    export_anim=True,
    export_anim_shape_keys=True
)
```

### 父对象设置

```python
# 导出父对象
bpy.ops.export_scene.usd(
    filepath='//parents.usd',
    export_parents=True
)

# 不导出父对象
bpy.ops.export_scene.usd(
    filepath='//no_parents.usd',
    export_parents=False
)
```

### 路径模式

```python
# 相对路径
bpy.ops.export_scene.usd(
    filepath='//model.usd',
    path_mode='RELATIVE'
)

# 绝对路径
bpy.ops.export_scene.usd(
    filepath='//model.usd',
    path_mode='ABSOLUTE'
)
```

### 变换类型

```python
# 一致变换
bpy.ops.export_scene.usd(
    filepath='//model.usd',
    export_transformation_type='壹致'
)

# 矩阵变换
bpy.ops.export_scene.usd(
    filepath='//matrix.usd',
    export_transformation_type='矩阵'
)
```

### LOD设置

```python
# 导出LOD
bpy.ops.export_scene.usd(
    filepath='//lod.usd',
    export_level_of_detail=True
)

# 不导出LOD
bpy.ops.export_scene.usd(
    filepath='//no_lod.usd',
    export_level_of_detail=False
)
```

### 紧凑USD

```python
# 紧凑USD
bpy.ops.export_scene.usd(
    filepath='//compact.usd',
    export_compact_usd=True
)

# 不紧凑USD
bpy.ops.export_scene.usd(
    filepath='//no_compact.usd',
    export_compact_usd=False
)
```

## 实用函数

```python
def export_usd_model(filepath, apply_modifiers=True):
    """导出USD模型"""
    bpy.ops.export_scene.usd(
        filepath=filepath,
        export_selected=True,
        export_meshes=True,
        export_uv=True,
        export_normals=True,
        export_materials=True,
        export_cameras=True,
        export_lights=True,
        export_anim=False
    )

def export_usd_animation(filepath, start_frame=None, end_frame=None):
    """导出USD动画"""
    if start_frame is not None:
        bpy.context.scene.frame_start = start_frame
    if end_frame is not None:
        bpy.context.scene.frame_end = end_frame
    
    bpy.ops.export_scene.usd(
        filepath=filepath,
        export_selected=True,
        export_meshes=True,
        export_uv=True,
        export_normals=True,
        export_materials=True,
        export_anim=True,
        export_anim_use_frame_range=True,
        export_anim_use_nla_strips=True
    )

def export_usd_for_unreal(filepath):
    """导出USD用于Unreal"""
    bpy.ops.export_scene.usd(
        filepath=filepath,
        export_selected=True,
        export_meshes=True,
        export_uv=True,
        export_normals=True,
        export_materials=True,
        export_cameras=True,
        export_lights=True,
        export_anim=True,
        export_anim_use_frame_range=True,
        export_anim_use_nla_strips=True,
        export_anim_armature=True,
        export_anim_shape_keys=True,
        export_parents=True,
        export_format='EXPORT'
    )

def export_usd_for_maya(filepath):
    """导出USD用于Maya"""
    bpy.ops.export_scene.usd(
        filepath=filepath,
        export_selected=True,
        export_meshes=True,
        export_uv=True,
        export_normals=True,
        export_materials=True,
        export_cameras=True,
        export_lights=True,
        export_curves=True,
        export_particles=True,
        export_anim=True,
        export_anim_use_frame_range=True,
        export_anim_armature=True,
        export_anim_shape_keys=True
    )

def export_usdz_for_ar(filepath):
    """导出USDZ用于AR"""
    bpy.ops.export_scene.usd(
        filepath=filepath,
        export_selected=True,
        export_meshes=True,
        export_uv=True,
        export_normals=True,
        export_materials=True,
        export_cameras=True,
        export_lights=True,
        export_anim=False,
        usd_format='USDZ'
    )

def batch_export_usd_by_collection(output_dir):
    """按集合批量导出USD"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for collection in bpy.data.collections:
        bpy.ops.object.select_all(action='DESELECT')
        
        for obj in collection.objects:
            obj.select_set(True)
        
        if bpy.context.selected_objects:
            bpy.context.view_layer.active_layer_collection = bpy.context.layer_collection.children[collection.name]
            filepath = os.path.join(output_dir, f'{collection.name}.usd')
            bpy.ops.export_scene.usd(
                filepath=filepath,
                export_selected=True,
                export_meshes=True,
                export_uv=True,
                export_normals=True,
                export_materials=True
            )
```

## 常见问题排查

### 导出文件无法打开
```python
# 检查文件路径
filepath = '//model.usd'
print(f"文件存在: {bpy.path.exists(filepath)}")

# 检查USD格式
print(f"USD格式: {bpy.context.scene.usd_export_}

# 确保使用正确的扩展名
if not filepath.endswith(('.usd', '.usdz', '.usda')):
    filepath += '.usd'

# 尝试不同的格式
bpy.ops.export_scene.usd(
    filepath='//model.usda',
    usd_format='USDA'
)
```

### 材质丢失
```python
# 检查材质
obj = bpy.context.active_object
print(f"材质数: {len(obj.data.materials) if obj.data else 0}")

# 确保导出材质
bpy.ops.export_scene.usd(
    filepath='//mat.usd',
    export_selected=True,
    export_materials=True
)

# 检查默认材质
print(f"默认材质: {bpy.context.scene.usd_export_principled BSDF}")
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 确保导出动画
bpy.ops.export_scene.usd(
    filepath='//anim.usd',
    export_selected=True,
    export_anim=True,
    export_anim_use_frame_range=True,
    export_anim_use_nla_strips=True
)

# 检查帧范围
print(f"帧范围: {bpy.context.scene.frame_start} - {bpy.context.scene.frame_end}")
```

### 性能问题
```python
# 检查对象数
print(f"对象数: {len(bpy.context.selected_objects)}")

# 减少导出内容
bpy.ops.export_scene.usd(
    filepath='//optimized.usd',
    export_selected=True,
    export_meshes=True,
    export_uv=True,
    export_normals=True,
    export_materials=True,
    export_cameras=False,
    export_lights=False,
    export_curves=False,
    export_particles=False,
    export_anim=False,
    export_custom_properties=False
)

# 使用紧凑USD
bpy.ops.export_scene.usd(
    filepath='//compact.usd',
    export_selected=True,
    export_compact_usd=True
)
```

### 坐标轴问题
```python
# 检查USD坐标轴设置
print(f"USD前向: {bpy.context.scene.usd_export_}")
print(f"USD上向: {bpy.context.scene.usd_export_}")

# USD默认使用Y轴向上
# 在导入软件中检查方向
# 如果需要，使用变换修改器调整
```

### 纹理路径问题
```python
# 检查路径模式
print(f"路径模式: {bpy.context.scene.usd_export_path_mode}")

# 使用绝对路径
bpy.ops.export_scene.usd(
    filepath='//model.usd',
    path_mode='ABSOLUTE'
)

# 检查纹理引用
# 在USD文件中检查纹理路径是否正确
```
