# bpy_extras Module Reference

bpy_extras 模块提供 Blender Python API 的扩展工具函数，包括节点、对象、网格、图像和资源的实用工具。

## bpy_extras 概述

bpy_extras 包含多个子模块，每个子模块提供特定领域的实用函数：
- node_utils: 节点工具
- object_utils: 对象工具
- mesh_utils: 网格工具
- image_utils: 图像工具
- asset_utils: 资源工具
- anim_utils: 动画工具
- view3d_utils: 3D 视图工具

### 何时使用 bpy_extras

- 查找节点输入输出
- 坐标转换
- 网格分析
- 图像处理
- 资源管理

## node_utils - 节点工具

### find_node_input

查找节点的输入插槽。

```python
from bpy_extras import node_utils

# 查找输入插槽
input_socket = node_utils.find_node_input(node, identifier)

# 参数
# node: 目标节点
# identifier: 插槽标识符（如 'Surface', 'Color'）

# 返回值
# NodeSocket: 找到的输入插槽，未找到返回 None
```

### find_node_output

查找节点的输出插槽。

```python
from bpy_extras import node_utils

# 查找输出插槽
output_socket = node_utils.find_node_output(node, identifier)

# 参数
# node: 目标节点
# identifier: 插槽标识符

# 返回值
# NodeSocket: 找到的输出插槽
```

### socket_id_to_index

将插槽 ID 转换为索引。

```python
from bpy_extras import node_utils

# 转换为索引
index = node_utils.socket_id_to_index(node, identifier, is_input)

# 参数
# node: 目标节点
# identifier: 插槽标识符
# is_input: 是否为输入插槽

# 返回值
# int: 插槽索引
```

### socket_index_to_id

将插槽索引转换为 ID。

```python
from bpy_extras import node_utils

# 转换为 ID
identifier = node_utils.socket_index_to_id(node, index, is_input)

# 参数
# node: 目标节点
# index: 插槽索引
# is_input: 是否为输入插槽

# 返回值
# str: 插槽标识符
```

## object_utils - 对象工具

### object_data_add

将数据添加到对象。

```python
from bpy_extras import object_utils

# 添加网格数据
mesh = bpy.data.meshes.new("MyMesh")
object_utils.object_data_add(bpy.context, mesh)

# 添加曲线数据
curve = bpy.data.curves.new("MyCurve", type='CURVE')
object_utils.object_data_add(bpy.context, curve)
```

### object_data_link

将数据链接到对象。

```python
from bpy_extras import object_utils

# 链接数据
object_utils.object_data_link(data, scene, collection, object_name)
```

### add_object_align_init

初始化对象对齐。

```python
from bpy_extras import object_utils

# 初始化对齐
init_matrix = object_utils.add_object_align_init(
    bpy.context,
    operator,
    align_type='WORLD'
)

# 参数
# context: 上下文
# operator: 操作符
# align_type: 对齐类型 ('WORLD', 'VIEW', 'CURSOR')
```

### world_to_camera_view

将世界坐标转换为相机视图坐标。

```python
from bpy_extras import object_utils

# 转换坐标
x, y = object_utils.world_to_camera_view(
    bpy.context,
    scene,
    camera_obj,
    world_co
)

# 参数
# context: 上下文
# scene: 场景
# camera: 相机对象
# world_co: 世界坐标 (Vector)

# 返回值
# x, y: 视图坐标 (0-1 范围)
```

### camera_view_to_world

将相机视图坐标转换为世界坐标。

```python
from bpy_extras import object_utils

# 转换坐标
world_co, direction = object_utils.camera_view_to_world(
    scene,
    camera_obj,
    x,
    y,
    distance
)

# 参数
# scene: 场景
# camera: 相机对象
# x, y: 视图坐标 (0-1 范围)
# distance: 距离

# 返回值
# world_co: 世界坐标
# direction: 方向向量
```

## mesh_utils - 网格工具

### mesh_linked_uv_islands

获取链接的 UV 岛屿。

```python
from bpy_extras import mesh_utils

# 获取 UV 岛屿
uv_islands = mesh_utils.mesh_linked_uv_islands(mesh)

# 参数
# mesh: 网格对象

# 返回值
# list: UV 岛屿列表，每个岛屿是顶点索引列表
```

### mesh_linked_uv_islands_to_mesh

将 UV 岛屿转换为独立网格。

```python
from bpy_extras import mesh_utils

# 转换为网格
island_meshes = mesh_utils.mesh_linked_uv_islands_to_mesh(mesh)

# 参数
# mesh: 源网格

# 返回值
# list: 独立网格列表
```

## image_utils - 图像工具

### load_image

加载图像文件。

```python
from bpy_extras import image_utils

# 加载图像
image = image_utils.load_image(image_path)

# 参数
# image_path: 图像文件路径

# 返回值
# Image: 加载的图像对象
```

### load_image_sequence

加载图像序列。

```python
from bpy_extras import image_utils

# 加载图像序列
images = image_utils.load_image_sequence(
    base_path,
    base_name,
    start_frame,
    end_frame,
    extension
)

# 参数
# base_path: 基础路径
# base_name: 基础名称
# start_frame: 起始帧
# end_frame: 结束帧
# extension: 文件扩展名

# 返回值
# list: 图像对象列表
```

### new_image

创建新图像。

```python
from bpy_extras import image_utils

# 创建图像
image = image_utils.new_image(
    name,
    width,
    height,
    alpha=False,
    float_buffer=False,
    stereo3d=False
)

# 参数
# name: 图像名称
# width: 宽度
# height: 高度
# alpha: 是否包含 Alpha 通道
# float_buffer: 是否使用浮点缓冲区
# stereo3d: 是否为立体图像

# 返回值
# Image: 创建的图像对象
```

## asset_utils - 资源工具

### SpaceAssetInfo

资源信息空间。

```python
from bpy_extras import asset_utils

# 获取资源信息
asset_info = asset_utils.SpaceAssetInfo

# 属性
# active_index: 活动资源索引
# catalog_id: 目录 ID
# filter_type: 筛选类型
# sort_method: 排序方法
```

### activate_asset_by_id

按 ID 激活资源。

```python
from bpy_extras import asset_utils

# 激活资源
asset_utils.activate_asset_by_id(
    asset_identifier,
    library_id=None,
    deferred=False
)

# 参数
# asset_identifier: 资源标识符
# library_id: 库 ID
# deferred: 是否延迟激活
```

### asset_mark

标记资源。

```python
from bpy_extras import asset_utils

# 标记资源
asset_utils.asset_mark(asset_identifier, library_id=None)
```

### asset_unmark

取消标记资源。

```python
from bpy_extras import asset_utils

# 取消标记
asset_utils.asset_unmark(asset_identifier, library_id=None)
```

## anim_utils - 动画工具

### get_fcurve_channels

获取 F-Curve 通道。

```python
from bpy_extras import anim_utils

# 获取通道
channels = anim_utils.get_fcurve_channels(action, data_path)

# 参数
# action: 动作
# data_path: 数据路径

# 返回值
# list: F-Curve 通道列表
```

### get_action_groups

获取动作组。

```python
from bpy_extras import anim_utils

# 获取组
groups = anim_utils.get_action_groups(action)

# 参数
# action: 动作

# 返回值
# list: 动作组列表
```

## view3d_utils - 3D 视图工具

### location_3d_to_region_2d

将 3D 坐标转换为区域 2D 坐标。

```python
from bpy_extras import view3d_utils

# 转换坐标
region_co = view3d_utils.location_3d_to_region_2d(
    region,
    region_3d,
    coord
)

# 参数
# region: 区域
# region_3d: 3D 区域
# coord: 3D 坐标

# 返回值
# Vector: 2D 区域坐标
```

### location_3d_to_region_2d_with_depth

将 3D 坐标转换为区域 2D 坐标（带深度）。

```python
from bpy_extras import view3d_utils

# 转换坐标
region_co, depth = view3d_utils.location_3d_to_region_2d_with_depth(
    region,
    region_3d,
    coord
)

# 返回值
# region_co: 2D 区域坐标
# depth: 深度值
```

### region_2d_to_location_3d

将区域 2D 坐标转换为 3D 坐标。

```python
from bpy_extras import view3d_utils

# 转换坐标
world_co = view3d_utils.region_2d_to_location_3d(
    region,
    region_3d,
    coord,
    depth_location
)

# 参数
# region: 区域
# region_3d: 3D 区域
# coord: 2D 坐标
# depth_location: 深度位置

# 返回值
# Vector: 3D 世界坐标
```

### region_2d_to_origin_3d

将区域 2D 坐标转换为 3D 原点。

```python
from bpy_extras import view3d_utils

# 转换原点
origin, direction = view3d_utils.region_2d_to_origin_3d(
    region,
    region_3d,
    coord
)

# 返回值
# origin: 3D 原点
# direction: 方向向量
```

### region_2d_to_vector_3d

将区域 2D 向量转换为 3D 向量。

```python
from bpy_extras import view3d_utils

# 转换向量
vector_3d = view3d_utils.region_2d_to_vector_3d(
    region,
    region_3d,
    coord_a,
    coord_b
)

# 参数
# coord_a: 起始 2D 坐标
# coord_b: 结束 2D 坐标

# 返回值
# Vector: 3D 向量
```

## 完整示例

### 查找节点连接

```python
import bpy
from bpy_extras import node_utils

def find_bsdf_input(mat):
    """查找材质的 BSDF 输入"""
    if not mat.use_nodes:
        return None
    
    node_tree = mat.node_tree
    output = node_tree.nodes.get("Material Output")
    
    if output:
        return node_utils.find_node_input(output, "Surface")
    
    return None

# 使用示例
mat = bpy.data.materials.get("MyMaterial")
if mat:
    input_socket = find_bsdf_input(mat)
    if input_socket:
        print(f"Found input: {input_socket.name}")
```

### 世界坐标转相机视图

```python
import bpy
from bpy_extras import object_utils

def get_object_screen_position(obj, camera):
    """获取对象在相机视图中的屏幕位置"""
    scene = bpy.context.scene
    
    # 获取对象中心的世界坐标
    world_co = obj.location
    
    # 转换为视图坐标
    x, y = object_utils.world_to_camera_view(
        bpy.context,
        scene,
        camera,
        world_co
    )
    
    # 获取视口尺寸
    viewport = bpy.context.region
    screen_x = int(x * viewport.width)
    screen_y = int(y * viewport.height)
    
    return screen_x, screen_y

# 使用示例
camera = bpy.context.scene.camera
obj = bpy.context.active_object
if camera and obj:
    pos = get_object_screen_position(obj, camera)
    print(f"Screen position: {pos}")
```

### UV 岛屿分析

```python
import bpy
from bpy_extras import mesh_utils

def analyze_uv_islands(mesh):
    """分析网格的 UV 岛屿"""
    if not mesh.uv_layers:
        return []
    
    uv_layer = mesh.uv_layers.active
    
    # 获取 UV 岛屿
    islands = mesh_utils.mesh_linked_uv_islands(mesh)
    
    result = []
    for i, island in enumerate(islands):
        # 计算岛屿面积
        area = 0.0
        for loop_idx in island:
            uv = uv_layer.data[loop_idx].uv
            area += uv.x  # 简化计算
        
        result.append({
            'index': i,
            'vertex_count': len(island),
            'area': area
        })
    
    return result

# 使用示例
obj = bpy.context.active_object
if obj and obj.type == 'MESH':
    islands = analyze_uv_islands(obj.data)
    for island in islands:
        print(f"Island {island['index']}: {island['vertex_count']} vertices")
```

### 射线投射

```python
import bpy
from bpy_extras import view3d_utils

def raycast_from_mouse(mouse_x, mouse_y):
    """从鼠标位置发射射线"""
    region = bpy.context.region
    region_3d = bpy.context.space_data.region_3d
    
    # 坐标归一化
    coord = (mouse_x / region.width, mouse_y / region.height)
    
    # 获取射线
    origin, direction = view3d_utils.region_2d_to_origin_3d(
        region, region_3d, coord
    )
    
    # 射线检测
    result, location, normal, index, object_, matrix = bpy.context.scene.ray_cast(
        origin, direction
    )
    
    if result:
        return {
            'location': location,
            'normal': normal,
            'object': object_,
            'hit': True
        }
    
    return {'hit': False}

# 使用示例
# mouse_x, mouse_y = 400, 300
# hit = raycast_from_mouse(mouse_x, mouse_y)
```

### 加载图像序列

```python
import bpy
from bpy_extras import image_utils

def load_image_sequence_opengl():
    """加载 OpenGL 渲染的图像序列"""
    base_path = "//render/output_"
    base_name = "frame_"
    start_frame = 1
    end_frame = 100
    extension = ".png"
    
    images = image_utils.load_image_sequence(
        base_path,
        base_name,
        start_frame,
        end_frame,
        extension
    )
    
    return images

# 创建图像序列编辑器条
def create_image_strip(images):
    seq_editor = bpy.context.scene.sequence_editor
    
    for i, image in enumerate(images):
        strip = seq_editor.sequences.new_image(
            name=f"Frame {i + 1}",
            filepath=image.filepath,
            channel=1,
            frame_start=i + 1
        )
    
    return True
```

## 最佳实践

1. **错误处理**：工具函数可能返回 None，检查返回值
2. **上下文要求**：某些函数需要有效的上下文
3. **坐标空间**：注意区分世界坐标、视图坐标和屏幕坐标
4. **性能优化**：大量操作时使用批处理
5. **兼容性**：检查 Blender 版本兼容性
