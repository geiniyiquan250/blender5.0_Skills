# bpy.ops.image - Image Operations Module

Blender 图像编辑器操作符，用于图像编辑、UV 编辑和纹理处理。

## Overview

`bpy.ops.image` 模块包含图像编辑器中的所有操作命令，包括图像加载、保存、编辑和 UV 映射操作。

## 核心功能

### 图像管理

```python
import bpy
import os

# 新建图像
bpy.ops.image.new(name="Untitled", width=1024, height=1024, color=(1, 1, 1, 1), alpha=True)

# 打开图像文件
bpy.ops.image.open(filepath="//textures/model.png", directory="//textures/", files=[{"name": "model.png", "name": "model.png"}], relative=True)

# 打开图像序列
bpy.ops.image.open(filepath="//render/frame_001.png", directory="//render/", files=[{"name": "frame_001.png", "name": "frame_001.png"}, {"name": "frame_002.png", "name": "frame_002.png"}], relative=True)

# 重新加载当前图像
bpy.ops.image.reload()

# 保存图像
bpy.ops.image.save()

# 另存为
bpy.ops.image.save_as(filepath="//exports/texture.png", copy=True)

# 外部保存
bpy.ops.image.external_save(filepath="//exports/texture.png")

# 外部编辑（用外部程序打开）
bpy.ops.image.external_edit(filepath="//textures/model.png")
```

### 图像编辑

```python
# 切换到绘画模式
bpy.ops.image.paint()

# 切换到 UV 编辑模式
bpy.ops.image.uv_sculpt()

# 切换到遮罩模式
bpy.ops.image.view_mask()

# 切换到样条线模式
bpy.ops.image.view_curve()

# 反转图像颜色
bpy.ops.image.invert(invert_r=False, invert_g=False, invert_b=False, invert_a=False)

# 调整图像大小
bpy.ops.image.resize(size=(2048, 2048), interpolation='BICUBIC')

# 裁剪图像
bpy.ops.image.crop(x=0, y=0, width=1024, height=1024)

# 旋转图像
bpy.ops.image.rotate(angle=1.570796, interpolation='BICUBIC')

# 平移图像
bpy.ops.image.offset(x=100, y=50)

# 清除图像
bpy.ops.image.clear()
```

### 图像填充

```python
# 用颜色填充
bpy.ops.image.fill(color=(1.0, 0.0, 0.0, 1.0), threshold=0, paint_mode='COLOR', channel='COLOR')

# 用渐变填充
bpy.ops.image.gradient_fill(gradient_type='DIAGONAL', steps=5, color1=(0, 0, 0, 1), color2=(1, 1, 1, 1), angle=0, width=1)

# 用检查板图案填充
bpy.ops.image.checker_fill(distance=10, intensity1=1, intensity2=0)
```

### 图像绘制

```python
# 绘制点
bpy.ops.image.draw_cursor_set(x=100, y=100)
bpy.ops.image.draw_brush(size=20, x=100, y=100, stroke=[{"name": "", "location": (0, 0), "pressure": 1, "time": 0, "pen_flip": False}])

# 绘制线条
bpy.ops.image.draw_brush(stroke=[{"name": "", "location": (0, 0), "pressure": 1, "time": 0, "pen_flip": False}, {"name": "", "location": (100, 100), "pressure": 1, "time": 0.1, "pen_flip": False}])

# 绘制曲线
bpy.ops.image.draw_curve(curve_mode='FREE', stroke=[{"name": "", "location": (0, 0), "pressure": 1, "time": 0, "pen_flip": False}])

# 绘制圆
bpy.ops.image.draw_brush(size=30, x=100, y=100)

# 绘制矩形
bpy.ops.image.draw_brush(size=30, x=100, y=100)
```

### 图像滤镜

```python
# 高斯模糊
bpy.ops.image.filter_gaussian(threshold=0.5)

# 模糊
bpy.ops.image.filter_blur(factor=1.0)

# 锐化
bpy.ops.image.filter_sharpen(factor=1.0)

# 边缘检测
bpy.ops.image.filter_sobel()

# Laplacian 滤镜
bpy.ops.image.filter_laplacian()

#  emboss 滤镜
bpy.ops.image.filter_emboss(factor=1.0)

# 发现的边缘
bpy.ops.image.filter_sobel()

# 自定义滤镜
bpy.ops.image.filter_custom(use=True)
bpy.ops.image.filter_custom_cancel()

# 应用滤镜
bpy.ops.image.filter_apply()
bpy.ops.image.filter_apply_next()
```

### 图像混合

```python
# 混合
bpy.ops.image.blend_color(color=(1.0, 0.0, 0.0, 1.0))

# 混合因子
bpy.ops.image.curves_point_set(curve_index=0, value=0.5)

# 色阶调整
bpy.ops.image.levels(min=0.0, max=1.0, gamma=1.0)

# 色相/饱和度调整
bpy.ops.image.hue_rotate(hue=0.0)

# 亮度/对比度调整
bpy.ops.image.brightness_contrast(brightness=0, contrast=0)
```

### 图像插图

```python
# 切换插图显示
bpy.ops.image.cycle_uv_tiles()

# 渲染插图
bpy.ops.image.render_border(xmin=0, xmax=100, ymin=0, ymax=100)

# 清除插图
bpy.ops.image.clear_render_border()
```

### 采样

```python
# 采样颜色
bpy.ops.image.sample(x=100, y=100)

# 采样线性
bpy.ops.image.sample_line(xstart=0, ystart=0, xend=100, yend=100, cursor=1002)

# 绘制样本
bpy.ops.image.sample_brush(size=20, x=100, y=100)
```

### 选择操作

```python
# 全选
bpy.ops.image.select_all(action='SELECT')

# 全不选
bpy.ops.image.select_all(action='DESELECT')

# 反选
bpy.ops.image.select_all(action='INVERT')

# 选择边框
bpy.ops.image.select_border(xmin=0, xmax=100, ymin=0, ymax=100, extend=True)

# 选择圆圈
bpy.ops.image.select_circle(x=100, y=100, radius=20, gesture_mode=0)

# 选择套索
bpy.ops.image.select_lasso(path=[(0, 0), (100, 0), (100, 100), (0, 100)], deselect=False, extend=True)
```

### 图像变换

```python
# 变换
bpy.ops.image.transform(mode='TRANSLATE', value=(10.0, 0.0))

# 旋转
bpy.ops.image.transform(mode='ROTATE', value=0.785398)

# 缩放
bpy.ops.image.transform(mode='SCALE', value=(1.5, 1.5))

# 裁剪
bpy.ops.image.transform(mode='CROP', value=(0, 0, 100, 100))

# 变形
bpy.ops.image.transform(mode='WARP', value=(0, 0))
```

### 图像投影

```python
# 投影相机
bpy.ops.image.project_edit(camera=None)

# 投影相机清除
bpy.ops.image.project_view_all()
```

### 图像模板

```python
# 新建模板
bpy.ops.image.new_color(name="Template", width=1024, height=1024, color=(0, 0, 0, 1), alpha=True)

# 编辑模板
bpy.ops.image.save_dirty()
```

## 实际应用示例

### 批量处理纹理

```python
import bpy
import os

def process_textures(input_dir, output_dir, operation='resize', size=(1024, 1024)):
    """批量处理纹理"""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for filename in os.listdir(input_dir):
        if filename.endswith(('.png', '.jpg', '.jpeg', '.tga')):
            filepath = os.path.join(input_dir, filename)
            
            # 打开图像
            bpy.ops.image.open(filepath=filepath, img = bpy relative=True)
           .context.active_image
            
            if img:
                if operation == 'resize':
                    # 调整大小
                    bpy.ops.image.resize(size=size)
                elif operation == 'crop':
                    # 裁剪到中心
                    width = img.size[0]
                    height = img.size[1]
                    min_dim = min(width, height)
                    x = (width - min_dim) // 2
                    y = (height - min_dim) // 2
                    bpy.ops.image.crop(x=x, y=y, width=min_dim, height=min_dim)
                elif operation == 'invert':
                    # 反转颜色
                    bpy.ops.image.invert(invert_r=True, invert_g=True, invert_b=True)
                
                # 保存
                output_path = os.path.join(output_dir, filename)
                bpy.ops.image.save_as(filepath=output_path, copy=True)
                
                print(f"处理完成: {filename}")

# 使用示例
# process_textures("//textures/input", "//textures/output", 'resize', (2048, 2048))
```

### 创建 UV 贴图

```python
import bpy

def create_uv_map_texture(obj, texture_name="UVMap"):
    """为对象创建 UV 贴图纹理"""
    if not obj.data.uv_layers:
        bpy.ops.mesh.uv_texture_add()
    
    uv_layer = obj.data.uv_layers.active
    
    # 获取 UV 坐标
    uv_coords = []
    for poly in obj.data.polygons:
        for loop_idx in poly.loop_indices:
            uv_coord = obj.data.uv_layers.active.data[loop_idx].uv
            uv_coords.append(uv_coord)
    
    # 创建新图像
    bpy.ops.image.new(name=texture_name, width=1024, height=1024, color=(0.5, 0.5, 0.5, 1.0))
    img = bpy.context.active_image
    
    # 将图像添加到材质
    mat = bpy.data.materials.new(name=f"{obj.name}_UV")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    
    # 创建图像节点
    img_node = nodes.new(type='ShaderNodeTexImage')
    img_node.image = img
    img_node.width_hidden = 200
    
    # 获取主原理 BSDF
    principled = nodes.get("Principled BSDF")
    if principled:
        links.new(img_node.outputs[0], principled.inputs["Base Color"])
    
    # 添加到对象
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)
    
    return img

# 使用示例
# obj = bpy.context.active_object
# img = create_uv_map_texture(obj)
```

### 图像序列动画

```python
import bpy
import os

class ImageSequenceOperator(bpy.types.Operator):
    """图像序列操作符"""
    bl_idname = "image.sequence_animation"
    bl_label = "创建图像序列动画"
    
    directory: bpy.props.StringProperty(subtype="FILE_PATH")
    image_extension: bpy.props.StringProperty(default=".png")
    
    def execute(self, context):
        # 获取目录中的所有图像文件
        files = [f for f in os.listdir(self.directory) 
                 if f.endswith(self.image_extension)]
        files.sort()
        
        if not files:
            self.report({'WARNING'}, "未找到图像文件")
            return {'CANCELLED'}
        
        # 创建图像列表
        image_list = []
        for filename in files:
            filepath = os.path.join(self.directory, filename)
            bpy.ops.image.open(filepath=filepath, relative=True)
            image_list.append(bpy.context.active_image)
        
        # 设置活动图像为第一张
        if image_list:
            context.space_data.image = image_list[0]
            print(f"已加载 {len(image_list)} 张图像")
        
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
```

### 图像批处理操作器

```python
class ImageBatchProcessor(bpy.types.Operator):
    """图像批处理器"""
    bl_idname = "image.batch_processor"
    bl_label = "批处理图像"
    
    operation: bpy.props.EnumProperty(
        name="操作",
        items=[
            ('RESIZE', "调整大小", "调整图像大小"),
            ('CROP', "裁剪", "裁剪图像"),
            ('INVERT', "反色", "反转图像颜色"),
            ('BLUR', "模糊", "应用高斯模糊"),
        ]
    )
    
    width: bpy.props.IntProperty(name="宽度", default=1024, min=1, max=8192)
    height: bpy.props.IntProperty(name="高度", default=1024, min=1, max=8192)
    blur_amount: bpy.props.FloatProperty(name="模糊量", default=0.5, min=0.0, max=10.0)
    
    def execute(self, context):
        # 获取选中的图像
        selected_images = []
        for img in bpy.data.images:
            if img.users > 0:
                selected_images.append(img)
        
        if not selected_images:
            self.report({'WARNING'}, "未找到使用的图像")
            return {'CANCELLED'}
        
        original_image = context.space_data.image
        
        for img in selected_images:
            context.space_data.image = img
            
            if self.operation == 'RESIZE':
                bpy.ops.image.resize(size=(self.width, self.height))
            elif self.operation == 'CROP':
                bpy.ops.image.crop(x=0, y=0, width=self.width, height=self.height)
            elif self.operation == 'INVERT':
                bpy.ops.image.invert(invert_r=True, invert_g=True, invert_b=True)
            elif self.operation == 'BLUR':
                bpy.ops.image.filter_gaussian(threshold=self.blur_amount)
        
        # 恢复活动图像
        context.space_data.image = original_image
        
        self.report({'INFO'}, f"已处理 {len(selected_images)} 张图像")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "operation")
        
        if self.operation == 'RESIZE':
            layout.prop(self, "width")
            layout.prop(self, "height")
        elif self.operation == 'BLUR':
            layout.prop(self, "blur_amount")
```

### UV 编辑面板

```python
class UVEditPanel(bpy.types.Panel):
    """UV 编辑面板"""
    bl_label = "UV 编辑工具"
    bl_idname = "IMAGE_PT_uv_tools"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = '工具'
    
    def draw(self, context):
        layout = self.layout
        space = context.space_data
        
        # UV 层管理
        row = layout.row()
        row.operator("uv.uv_texture_add", text="添加 UV 层")
        row.operator("uv.uv_texture_remove", text="移除 UV 层")
        
        # UV 选择模式
        layout.label(text="选择模式:")
        row = layout.row(heading="模式")
        row.prop_enum(space, "uv_select_mode", 'VERTEX')
        row.prop_enum(space, "uv_select_mode", 'EDGE')
        row.prop_enum(space, "uv_select_mode", 'FACE')
        row.prop_enum(space, "uv_select_mode", 'ISLAND')
        
        # 对齐工具
        layout.separator()
        layout.label(text="对齐工具:")
        row = layout.row(align=True)
        row.operator("uv.align", text="左对齐").align='LEFT'
        row.operator("uv.align", text="水平居中").align='CENTER_X'
        row.operator("uv.align", text="右对齐").align='RIGHT'
        
        row = layout.row(align=True)
        row.operator("uv.align", text="底对齐").align='BOTTOM'
        row.operator("uv.align", text="垂直居中").align='CENTER_Y'
        row.operator("uv.align", text="顶对齐").align='TOP'
        
        # 分布工具
        layout.separator()
        layout.label(text="分布工具:")
        row = layout.row(align=True)
        row.operator("uv.distribute", text="水平分布").distribute='DISTRIBUTE'
        row.operator("uv.distribute", text="垂直分布").distribute='DISTRIBUTEY'
        
        # 缝合工具
        layout.separator()
        layout.label(text="缝合工具:")
        row = layout.row(align=True)
        row.operator("uv.stitch", text="缝合")
        row.operator("uv.snap_selected_to_cursor", text="到光标")
```

## 最佳实践

### 1. 图像资源管理

```python
def manage_image_resources():
    """管理图像资源"""
    # 查找未使用的图像
    unused_images = [img for img in bpy.data.images if img.users == 0]
    
    # 清理未使用的图像
    for img in unused_images:
        bpy.data.images.remove(img)
        print(f"已清理: {img.name}")
    
    # 打印统计
    print(f"总图像数: {len(bpy.data.images)}")
    print(f"使用中: {len(bpy.data.images) - len(unused_images)}")
```

### 2. 图像路径处理

```python
def relink_images(new_base_dir):
    """重新链接图像"""
    for img in bpy.data.images:
        if img.filepath and not os.path.exists(bpy.path.abspath(img.filepath)):
            # 尝试在新目录中查找
            filename = os.path.basename(img.filepath)
            new_path = os.path.join(new_base_dir, filename)
            
            if os.path.exists(new_path):
                img.filepath = bpy.path.relpath(new_path)
                print(f"已重新链接: {img.name}")
```

### 3. 图像尺寸优化

```python
def optimize_images(max_size=2048):
    """优化图像尺寸"""
    for img in bpy.data.images:
        if img.size[0] > max_size or img.size[1] > max_size:
            # 计算新尺寸
            scale = min(max_size / img.size[0], max_size / img.size[1])
            new_size = (int(img.size[0] * scale), int(img.size[1] * scale))
            
            # 保存原始尺寸
            original_size = img.size
            
            # 调整大小
            bpy.context.space_data.image = img
            bpy.ops.image.resize(size=new_size)
            
            print(f"优化 {img.name}: {original_size} -> {new_size}")
```

## 常见问题

### Q: 图像不显示
A: 检查图像是否已加载，确认 UV 编辑器中选择了正确的图像。

### Q: UV 映射丢失
A: 确保网格有 UV 层，使用 `uv_texture_add` 添加。

### Q: 图像编辑不保存
A: 使用 `save()` 或 `save_as()` 保存更改。

## 相关模块

- [bpy.ops](bpy_ops_detailed_module.md) - Blender 操作符
- [bpy.data](bpy_data_module.md) - 数据访问
- [imbuf](imbuf_module.md) - 图像缓冲操作
- [bpy_extras](bpy_extras_module.md) - 额外工具函数
