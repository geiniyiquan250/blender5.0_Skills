# bpy.ops.dpaint - 动态绘画操作模块

Blender动态绘画操作符，用于设置和管理动态绘画效果。

## 概述

`bpy.ops.dpaint` 模块提供用于操作动态绘画系统的功能，包括画布设置、笔刷设置、初始化和烘焙操作。

## 核心功能

### 动态绘画初始化

```python
import bpy

# 初始化动态绘画
bpy.ops.dpaint.canvas_init()

# 为选中对象初始化动态绘画
bpy.ops.dpaint.canvas_init(
    object='ACTIVE'
)

# 为所有对象初始化动态绘画
bpy.ops.dpaint.canvas_init(
    object='ALL'
)

# 清除动态绘画
bpy.ops.dpaint.canvas_clear()

# 清除特定类型
bpy.ops.dpaint.canvas_clear(
    type='COLOR'
)

# 重置动态绘画
bpy.ops.dpaint.canvas_reset()
```

### 画布操作

```python
# 创建新画布
bpy.ops.dpaint.canvas_add(
    type='IMAGE'
)

# 创建基于对象的画布
bpy.ops.dpaint.canvas_add_object(
    object='Cube'
)

# 创建基于网格的画布
bpy.ops.dpaint.canvas_add_mesh(
    mesh='Suzanne'
)

# 创建基于曲面的画布
bpy.ops.dpaint.canvas_add_surface(
    surface='Surface'
)

# 创建基于粒子的画布
bpy.ops.dpaint.canvas_add_particle(
    particle='ParticleSettings'
)

# 删除画布
bpy.ops.dpaint.canvas_remove()

# 复制画布
bpy.ops.dpaint.canvas_duplicate()
```

### 笔刷操作

```python
# 添加笔刷
bpy.ops.dpaint.brush_add(
    type='DAMP'
)

# 添加侵蚀笔刷
bpy.ops.dpaint.brush_add(
    type='ERODE'
)

# 添加扩散笔刷
bpy.ops.dpaint.brush_add(
    type='SPREAD'
)

# 复制笔刷
bpy.ops.dpaint.brush_copy()

# 重命名笔刷
bpy.ops.dpaint.brush_rename(
    name='MyBrush'
)

# 删除笔刷
bpy.ops.dpaint.brush_remove()

# 重置笔刷
bpy.ops.dpaint.brush_reset()
```

### 纹理操作

```python
# 添加纹理
bpy.ops.dpaint.texture_add()

# 清除纹理
bpy.ops.dpaint.texture_clear()

# 更新纹理
bpy.ops.dpaint.texture_update()

# 刷新纹理
bpy.ops.dpaint.texture_refresh()
```

### 笔触操作

```python
# 开始笔触
bpy.ops.dpaint.stroke_begin()

# 结束笔触
bpy.ops.dpaint.stroke_end()

# 取消笔触
bpy.ops.dpaint.stroke_cancel()

# 应用笔触
bpy.ops.dpaint.stroke_apply()

# 清除笔触历史
bpy.ops.dpaint.stroke_history_clear()
```

### 序列帧操作

```python
# 开始序列帧
bpy.ops.dpaint.write_cache_start()

# 结束序列帧
bpy.ops.dpaint.write_cache_end()

# 清除序列帧
bpy.ops.dpaint.write_cache_clear()

# 刷新序列帧
bpy.ops.dpaint.write_cache_refresh()
```

### 烘焙操作

```python
# 烘焙所有效果
bpy.ops.dpaint.bake()

# 烘焙颜色
bpy.ops.dpaint.bake(
    type='COLOR'
)

# 烘焙法线
bpy.ops.dpaint.bake(
    type='NORMAL'
)

# 烘焙粗糙度
bpy.ops.dpaint.bake(
    type='ROUGHNESS'
)

# 烘焙环境遮蔽
bpy.ops.dpaint.bake(
    type='AO'
)

# 烘焙高度
bpy.ops.dpaint.bake(
    type='HEIGHT'
)

# 烘焙浓度
bpy.ops.dpaint.bake(
    type='DENSITY'
)

# 烘焙速度
bpy.ops.dpaint.bake(
    type='VELOCITY'
)

# 烘焙温度
bpy.ops.dpaint.bake(
    type='TEMPERATURE'
)

# 烘焙湿气
bpy.ops.dpaint.bake(
    type='WETNESS'
)

# 烘焙流动
bpy.ops.dpaint.bake(
    type='FLOW'
)

# 烘焙压力
bpy.ops.dpaint.bake(
    type='PRESSURE'
)

# 取消烘焙
bpy.ops.dpaint.bake_cancel()

# 烘焙所有
bpy.ops.dpaint.bake_all()
```

### 导出操作

```python
# 导出画布
bpy.ops.dpaint.export(
    filepath='//dpaint_result.exr'
)

# 导出所有画布
bpy.ops.dpaint.export_all(
    filepath='//dpaint_results'
)

# 导出为图像序列
bpy.ops.dpaint.export_images(
    filepath='//dpaint_images/image_',
    format='PNG'
)

# 导出为视频
bpy.ops.dpaint.export_video(
    filepath='//dpaint_video.mp4'
)
```

### 笔刷模式操作

```python
# 设置笔刷模式
bpy.ops.dpaint.set_brush_mode(
    mode='DAMP'
)

# 切换侵蚀模式
bpy.ops.dpaint.set_brush_mode(
    mode='ERODE'
)

# 切换扩散模式
bpy.ops.dpaint.set_brush_mode(
    mode='SPREAD'
)

# 切换颜色模式
bpy.ops.dpaint.set_brush_mode(
    mode='COLOR'
)

# 切换水模式
bpy.ops.dpaint.set_brush_mode(
    mode='LIQUID'
)

# 切换蒸发模式
bpy.ops.dpaint.set_brush_mode(
    mode='EVAPORATE'
)
```

### 时间设置

```python
# 设置开始帧
bpy.ops.dpaint.start_frame_set(
    frame=1
)

# 设置结束帧
bpy.ops.dpaint.end_frame_set(
    frame=250
)

# 设置时间范围
bpy.ops.dpaint.time_range_set(
    start=1,
    end=250
)

# 重置时间范围
bpy.ops.dpaint.time_range_reset()
```

### 高级效果设置

```python
# 设置侵蚀效果
bpy.ops.dpaint.erosion_settings(
    type='SURFACE_EROSION',
    flow_factor=1.0,
    hardness=0.5
)

# 设置扩散效果
bpy.ops.dpaint.spread_settings(
    type='SURFACE_SPREAD',
    spread_speed=0.5,
    drip_speed=0.3
)

# 设置干燥效果
bpy.ops.dpaint.dry_settings(
    dry_speed=0.1,
    infrared_cooling=0.5
)

# 设置流动效果
bpy.ops.dpaint.flow_settings(
    flow_speed=0.5,
    gravity_factor=0.3
)
```

## 实用函数

```python
def get_active_canvas():
    """获取当前激活的画布"""
    return bpy.context.active_object.data

def create_dpaint_canvas(obj, canvas_type='IMAGE'):
    """为对象创建动态绘画画布"""
    bpy.context.view_layer.objects.active = obj
    bpy.ops.dpaint.canvas_add_object(object=obj.name)
    return obj.data

def bake_all_canvases(start_frame=1, end_frame=250):
    """烘焙所有画布"""
    bpy.ops.dpaint.start_frame_set(frame=start_frame)
    bpy.ops.dpaint.end_frame_set(frame=end_frame)
    bpy.ops.dpaint.bake_all()

def export_dpaint_results(output_dir):
    """导出所有动态绘画结果"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    bpy.ops.dpaint.export_all(filepath=output_dir)

def reset_brush_settings():
    """重置所有笔刷设置"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    brush = space.dpaint.brush
                    brush.reset()

def setup_damp_brush(brush_name, strength=1.0):
    """设置阻尼笔刷"""
    bpy.ops.dpaint.brush_add(type='DAMP')
    brush = bpy.context.active_brush
    brush.name = brush_name
    brush.strength = strength
    return brush

def setup_erosion_brush(brush_name, flow=1.0):
    """设置侵蚀笔刷"""
    bpy.ops.dpaint.brush_add(type='ERODE')
    brush = bpy.context.active_brush
    brush.name = brush_name
    brush.flow_factor = flow
    return brush

def create_color_canvas(obj, color=(1, 0, 0, 1)):
    """创建颜色画布"""
    bpy.context.view_layer.objects.active = obj
    bpy.ops.dpaint.canvas_add_object(object=obj.name)
    canvas = obj.data
    canvas.dpaint.color = color
    return canvas
```

## 常见问题排查

### 画布不显示
```python
# 检查动态绘画是否启用
obj = bpy.context.active_object
print(f"动态绘画类型: {obj.data.dpaint.type}")

# 检查显示设置
space = bpy.context.space_data
if space:
    print(f"显示动态绘画: {space.dpaint.show_view}")

# 启用显示
if space:
    space.dpaint.show_view = True

# 检查笔刷是否设置
brush = bpy.context.active_brush
print(f"当前笔刷: {brush}")

# 重新初始化
bpy.ops.dpaint.canvas_init()
```

### 烘焙失败
```python
# 检查帧范围
print(f"开始帧: {bpy.context.scene.dpaint.start_frame}")
print(f"结束帧: {bpy.context.scene.dpaint.end_frame}")

# 检查画布是否有效
print(f"画布数: {len(bpy.context.scene.dpaint.canvases)}")

# 检查内存
print(f"使用内存: {bpy.context.scene.dpaint.memory_limit} MB")

# 清除缓存后重试
bpy.ops.dpaint.write_cache_clear()
bpy.ops.dpaint.bake()

# 逐个烘焙
for canvas in bpy.context.scene.dpaint.canvases:
    bpy.ops.dpaint.bake(type=canvas.type)
```

### 笔刷效果不明显
```python
# 检查笔刷强度
brush = bpy.context.active_brush
print(f"笔刷强度: {brush.strength}")

# 增加强度
brush.strength = 1.0

# 检查笔刷类型
print(f"笔刷类型: {brush.dpaint.type}")

# 切换笔刷类型
bpy.ops.dpaint.set_brush_mode(mode='ERODE')

# 检查时间步长
print(f"时间步长: {bpy.context.scene.dpaint.time_scale}")

# 增加时间步长
bpy.context.scene.dpaint.time_scale = 2.0
```
