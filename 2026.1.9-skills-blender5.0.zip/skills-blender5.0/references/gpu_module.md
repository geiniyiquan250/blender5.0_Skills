# GPU Module Reference

GPU 模块提供 GPU 编程功能，用于创建自定义着色器和效果。

## GPU 概述

GPU 模块允许直接访问 Blender 的 GPU 功能，用于创建高性能的自定义渲染效果。

### 何时使用 GPU 模块

- 创建自定义着色器
- 实现高性能的视觉效果
- 绘制自定义几何体
- 创建 GPU 加速的工具

## gpu.types

GPU 类型定义。

### GPUOffScreen

离屏渲染缓冲区。

```python
import gpu

# 创建离屏缓冲区
offscreen = gpu.types.GPUOffScreen(512, 512)

# 获取纹理
texture = offscreen.color_texture

# 绑定离屏缓冲区
offscreen.bind()

# 解绑离屏缓冲区
offscreen.unbind()

# 释放离屏缓冲区
offscreen.free()
```

### GPUShader

GPU 着色器。

```python
import gpu

# 创建着色器
shader = gpu.types.GPUShader(
    vertex_shader="""
        uniform mat4 modelMatrix;
        uniform mat4 viewMatrix;
        uniform mat4 projectionMatrix;

        in vec3 position;
        in vec2 texCoord;

        out vec2 vTexCoord;

        void main()
        {
            vTexCoord = texCoord;
            gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);
        }
    """,
    fragment_shader="""
        uniform sampler2D image;
        in vec2 vTexCoord;
        out vec4 fragColor;

        void main()
        {
            fragColor = texture(image, vTexCoord);
        }
    """
)

# 绑定着色器
shader.bind()

# 设置 uniform
shader.uniform_float("modelMatrix", model_matrix)
shader.uniform_float("viewMatrix", view_matrix)
shader.uniform_float("projectionMatrix", projection_matrix)
shader.uniform_int("image", 0)

# 解绑着色器
shader.unbind()
```

### GPUTexture

GPU 纹理。

```python
import gpu

# 从图像创建纹理
texture = gpu.types.GPUTexture((512, 512))

# 绑定纹理
texture.bind(0)

# 解绑纹理
texture.unbind()

# 释放纹理
texture.free()
```

## gpu.shader

着色器工具函数。

### create_from_info

从 GPUShaderCreateInfo 创建着色器。

```python
import gpu

# 创建着色器信息
shader_info = gpu.types.GPUShaderCreateInfo()

# 添加着色器代码
shader_info.vertex_in(0, 'vec3', 'position')
shader_info.vertex_out(0, 'vec2', 'texCoord')

# 创建着色器
shader = gpu.shader.create_from_info(shader_info)
```

### from_builtin

获取内置着色器。

```python
import gpu

# 获取内置着色器
shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')

# 使用裁剪平面配置
shader_clipped = gpu.shader.from_builtin('3D_UNIFORM_COLOR', config='CLIPPED')
```

### unbind

解绑当前绑定的着色器。

```python
import gpu

# 解绑着色器
gpu.shader.unbind()
```

## gpu.state

GPU 状态管理。

### active_framebuffer_get

获取当前活动的帧缓冲区。

```python
import gpu

# 获取当前帧缓冲区
framebuffer = gpu.state.active_framebuffer_get()
```

### blend_set

设置混合模式。

```python
import gpu

# 启用混合
gpu.state.blend_set('ALPHA')

# 禁用混合
gpu.state.blend_set('NONE')
```

### depth_test_set

设置深度测试。

```python
import gpu

# 启用深度测试
gpu.state.depth_test_set('LESS')

# 禁用深度测试
gpu.state.depth_test_set('NONE')
```

### viewport_set

设置视口。

```python
import gpu

# 设置视口大小
gpu.state.viewport_set(0, 0, 800, 600)
```

## gpu.matrix

矩阵操作工具。

### load_identity

加载单位矩阵。

```python
import gpu

# 加载单位矩阵
gpu.matrix.load_identity()
```

### load_matrix

加载矩阵。

```python
import gpu
import mathutils

# 创建变换矩阵
matrix = mathutils.Matrix.Identity(4)

# 加载矩阵
gpu.matrix.load_matrix(matrix)
```

### push_matrix / pop_matrix

矩阵堆栈操作。

```python
import gpu

# 保存当前矩阵
gpu.matrix.push_matrix()

# 应用变换
gpu.matrix.translate((1, 0, 0))

# 恢复矩阵
gpu.matrix.pop_matrix()
```

### translate / rotate / scale

变换操作。

```python
import gpu

# 平移
gpu.matrix.translate((1, 2, 3))

# 旋转
gpu.matrix.rotate(mathutils.Quaternion((1, 0, 0), math.radians(45)))

# 缩放
gpu.matrix.scale((2, 2, 2))
```

## gpu.texture

纹理工具函数。

### from_image

从图像创建纹理。

```python
import gpu
import bpy

# 从图像创建纹理
image = bpy.data.images.get('texture.png')
if image:
    texture = gpu.texture.from_image(image)
```

## gpu.capabilities

GPU 能力检测。

### compute_shader_support_get

检查计算着色器支持。

```python
import gpu

# 检查计算着色器支持
has_compute = gpu.capabilities.compute_shader_support_get()
```

### extensions_get

获取支持的扩展列表。

```python
import gpu

# 获取扩展列表
extensions = gpu.capabilities.extensions_get()
```

## 使用示例

### 自定义着色器绘制

```python
import gpu
import bgl

# 创建自定义着色器
vertex_shader = '''
    uniform mat4 ModelViewProjectionMatrix;
    in vec3 pos;
    void main() {
        gl_Position = ModelViewProjectionMatrix * vec4(pos, 1.0);
    }
'''

fragment_shader = '''
    uniform vec4 color;
    out vec4 fragColor;
    void main() {
        fragColor = color;
    }
'''

shader = gpu.types.GPUShader(vertex_shader, fragment_shader)

# 绘制三角形
vertices = [(-1, -1, 0), (1, -1, 0), (0, 1, 0)]

shader.bind()
shader.uniform_float('color', (1, 0, 0, 1))

gpu.draw.batch(shader, 'TRIS', {'pos': vertices})
```

### 离屏渲染

```python
import gpu

# 创建离屏缓冲区
offscreen = gpu.types.GPUOffScreen(512, 512)

# 绑定离屏缓冲区
offscreen.bind()

# 设置视口
gpu.state.viewport_set(0, 0, 512, 512)

# 清除缓冲区
gpu.state.clear(color=(0, 0, 0, 1))

# 绘制内容
# ...

# 解绑离屏缓冲区
offscreen.unbind()

# 获取纹理
texture = offscreen.color_texture
```

## 性能优化建议

- 尽量减少着色器切换
- 批量绘制调用
- 重用纹理和缓冲区对象
- 使用实例化渲染
- 避免每帧创建和销毁GPU资源
image = bpy.data.images.get("MyImage")
texture = gpu.types.GPUTexture(image.size, data=image.pixels)

# 从数据创建纹理
texture = gpu.types.GPUTexture((512, 512), data=pixels)

# 绑定纹理
texture.bind(0)

# 解绑纹理
texture.unbind()

# 更新纹理
texture.update(data=new_pixels)

# 释放纹理
texture.free()
```

### GPUFrameBuffer

GPU 帧缓冲区。

```python
import gpu

# 创建帧缓冲区
framebuffer = gpu.types.GPUFrameBuffer(
    color_slots=(gpu.types.GPUTexture((512, 512)),),
    depth_slot=gpu.types.GPUTexture((512, 512))
)

# 绑定帧缓冲区
framebuffer.bind()

# 解绑帧缓冲区
framebuffer.unbind()

# 释放帧缓冲区
framebuffer.free()
```

## gpu.shader

着色器操作。

### 内置着色器

```python
import gpu

# 2D 平面着色器
shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')

# 2D 图像着色器
shader = gpu.shader.from_builtin('2D_IMAGE')

# 2D 平滑颜色着色器
shader = gpu.shader.from_builtin('2D_SMOOTH_COLOR')

# 2D 平滑线条着色器
shader = gpu.shader.from_builtin('2D_SMOOTH_LINE')

# 3D 平面着色器
shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')

# 3D 平滑颜色着色器
shader = gpu.shader.from_builtin('3D_SMOOTH_COLOR')

# 3D 平滑线条着色器
shader = gpu.shader.from_builtin('3D_SMOOTH_LINE')

# 3D 多边形线条着色器
shader = gpu.shader.from_builtin('3D_POLYLINE_FLAT_COLOR')

# 3D 多边形线条平滑颜色着色器
shader = gpu.shader.from_builtin('3D_POLYLINE_SMOOTH_COLOR')

# 点着色器
shader = gpu.shader.from_builtin('POINTS')

# 线着色器
shader = gpu.shader.from_builtin('LINE')
```

### 着色器 uniform

```python
import gpu

shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
shader.bind()

# 设置颜色
shader.uniform_float("color", (1.0, 0.0, 0.0, 1.0))

# 设置矩阵
shader.uniform_float("modelViewMatrix", model_view_matrix)
shader.uniform_float("projectionMatrix", projection_matrix)

# 设置纹理
shader.uniform_int("image", 0)
```

## gpu.state

GPU 状态管理。

### 状态设置

```python
import gpu

# 设置混合模式
gpu.state.blend_set('ALPHA')
gpu.state.blend_set('ADDITIVE')
gpu.state.blend_set('SUBTRACT')
gpu.state.blend_set('REVERSE_SUBTRACT')
gpu.state.blend_set('MULTIPLY')
gpu.state.blend_set('PREMULTIPLIED')
gpu.state.blend_set('INVERT')
gpu.state.blend_set('NONE')

# 设置深度测试
gpu.state.depth_test_set('LESS')
gpu.state.depth_test_set('LESS_EQUAL')
gpu.state.depth_test_set('GREATER')
gpu.state.depth_test_set('GREATER_EQUAL')
gpu.state.depth_test_set('EQUAL')
gpu.state.depth_test_set('NOTEQUAL')
gpu.state.depth_test_set('ALWAYS')
gpu.state.depth_test_set('NONE')

# 设置写入掩码
gpu.state.depth_mask_set(True)
gpu.state.depth_mask_set(False)

# 设置线宽
gpu.state.line_width_set(2.0)

# 设置点大小
gpu.state.point_size_set(5.0)

# 设置面剔除
gpu.state.face_culling_set('BACK')
gpu.state.face_culling_set('FRONT')
gpu.state.face_culling_set('NONE')
```

## gpu.matrix

矩阵操作。

### 矩阵管理

```python
import gpu
import mathutils

# 获取模型视图矩阵
model_view_matrix = gpu.matrix.get_model_view_matrix()

# 获取投影矩阵
projection_matrix = gpu.matrix.get_projection_matrix()

# 设置模型视图矩阵
gpu.matrix.set_model_view_matrix(model_view_matrix)

# 设置投影矩阵
gpu.matrix.set_projection_matrix(projection_matrix)

# 推入矩阵栈
gpu.matrix.push()

# 弹出矩阵栈
gpu.matrix.pop()

# 重置矩阵
gpu.matrix.reset()

# 乘以矩阵
gpu.matrix.multiply_matrix(matrix)

# 平移
gpu.matrix.translate((1.0, 2.0, 3.0))

# 旋转
gpu.matrix.rotate(mathutils.Euler((0.0, 0.0, math.radians(45))))

# 缩放
gpu.matrix.scale((2.0, 2.0, 2.0))
```

## gpu.select

选择操作。

### 选择查询

```python
import gpu

# 开始选择
gpu.select.begin(mode='ALL')

# 加载选择 ID
gpu.select.load_id(id)

# 结束选择
hits = gpu.select.end()

# 获取命中结果
for hit in hits:
    print(f"Hit ID: {hit.id}, Depth: {hit.depth}")
```

## gpu.extras

额外的 GPU 工具。

### 批量绘制

```python
import gpu
import gpu_extras.batch

# 创建顶点数据
vertices = (
    (-1.0, -1.0),
    (1.0, -1.0),
    (0.0, 1.0),
)

# 创建批量绘制对象
batch = gpu_extras.batch.batch_for_shader(
    shader,
    'TRIS',
    {"pos": vertices}
)

# 绘制
batch.draw(shader)
```

### 绘制 2D 线条

```python
import gpu
import gpu_extras

# 创建线条数据
coords = (
    (0.0, 0.0),
    (100.0, 100.0),
)

# 创建批量绘制对象
batch = gpu_extras.batch.batch_for_shader(
    gpu.shader.from_builtin('2D_UNIFORM_COLOR'),
    'LINES',
    {"pos": coords}
)

# 绘制
batch.draw()
```

### 绘制 3D 线条

```python
import gpu
import gpu_extras
import mathutils

# 创建线条数据
coords = (
    (0.0, 0.0, 0.0),
    (1.0, 1.0, 1.0),
)

# 创建批量绘制对象
batch = gpu_extras.batch.batch_for_shader(
    gpu.shader.from_builtin('3D_UNIFORM_COLOR'),
    'LINES',
    {"pos": coords}
)

# 绘制
batch.draw()
```

### 绘制 2D 图像

```python
import gpu
import gpu_extras

# 创建图像数据
image = bpy.data.images.get("MyImage")
coords = (
    (0.0, 0.0),
    (image.size[0], 0.0),
    (image.size[0], image.size[1]),
    (0.0, image.size[1]),
)

# 创建批量绘制对象
batch = gpu_extras.batch.batch_for_shader(
    gpu.shader.from_builtin('2D_IMAGE'),
    'TRI_FAN',
    {
        "pos": coords,
        "texCoord": ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),
    }
)

# 绘制
batch.draw()
```

## 完整示例

### 绘制 2D 矩形

```python
import gpu
import gpu_extras.batch

def draw_callback():
    # 创建着色器
    shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    shader.bind()

    # 设置颜色
    shader.uniform_float("color", (1.0, 0.0, 0.0, 1.0))

    # 创建矩形顶点
    coords = (
        (100, 100),
        (200, 100),
        (200, 200),
        (100, 200),
    )

    # 创建批量绘制对象
    batch = gpu_extras.batch.batch_for_shader(
        shader,
        'TRI_FAN',
        {"pos": coords}
    )

    # 绘制
    batch.draw()

# 注册绘制回调
handle = bpy.types.SpaceView3D.draw_handler_add(draw_callback, (), 'WINDOW', 'POST_PIXEL')

# 注销绘制回调
bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
```

### 绘制 3D 立方体

```python
import gpu
import gpu_extras.batch
import mathutils

def draw_callback():
    # 创建着色器
    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    shader.bind()

    # 设置颜色
    shader.uniform_float("color", (0.0, 1.0, 0.0, 1.0))

    # 创建立方体顶点
    coords = (
        (-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1),
        (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1),
    )

    # 创建索引
    indices = (
        (0, 1, 2), (2, 3, 0),
        (4, 5, 6), (6, 7, 4),
        (0, 1, 5), (5, 4, 0),
        (2, 3, 7), (7, 6, 2),
        (0, 3, 7), (7, 4, 0),
        (1, 2, 6), (6, 5, 1),
    )

    # 创建批量绘制对象
    batch = gpu_extras.batch.batch_for_shader(
        shader,
        'TRIS',
        {"pos": coords},
        indices=indices
    )

    # 绘制
    batch.draw()

# 注册绘制回调
handle = bpy.types.SpaceView3D.draw_handler_add(draw_callback, (), 'WINDOW', 'POST_VIEW')

# 注销绘制回调
bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
```

### 自定义着色器

```python
import gpu
import gpu_extras.batch

# 创建自定义着色器
shader = gpu.types.GPUShader(
    vertex_shader="""
        uniform mat4 modelViewMatrix;
        uniform mat4 projectionMatrix;

        in vec3 position;
        in vec3 color;

        out vec3 vColor;

        void main()
        {
            vColor = color;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
    """,
    fragment_shader="""
        in vec3 vColor;
        out vec4 fragColor;

        void main()
        {
            fragColor = vec4(vColor, 1.0);
        }
    """
)

# 创建顶点数据
vertices = (
    (-1.0, -1.0, 0.0),
    (1.0, -1.0, 0.0),
    (0.0, 1.0, 0.0),
)

colors = (
    (1.0, 0.0, 0.0),
    (0.0, 1.0, 0.0),
    (0.0, 0.0, 1.0),
)

# 创建批量绘制对象
batch = gpu_extras.batch.batch_for_shader(
    shader,
    'TRIS',
    {
        "position": vertices,
        "color": colors,
    }
)

# 绘制
shader.bind()
batch.draw()
```

### 离屏渲染

```python
import gpu
import gpu_extras.batch

# 创建离屏缓冲区
offscreen = gpu.types.GPUOffScreen(512, 512)

# 绑定离屏缓冲区
offscreen.bind()

# 清除缓冲区
gpu.state.depth_mask_set(True)
gpu.state.depth_test_set('LESS')
gpu.state.depth_mask_set(False)

# 创建着色器
shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
shader.bind()

# 设置颜色
shader.uniform_float("color", (1.0, 0.0, 0.0, 1.0))

# 创建矩形顶点
coords = (
    (100, 100),
    (200, 100),
    (200, 200),
    (100, 200),
)

# 创建批量绘制对象
batch = gpu_extras.batch.batch_for_shader(
    shader,
    'TRI_FAN',
    {"pos": coords}
)

# 绘制
batch.draw()

# 解绑离屏缓冲区
offscreen.unbind()

# 获取纹理
texture = offscreen.color_texture

# 释放离屏缓冲区
offscreen.free()
```
