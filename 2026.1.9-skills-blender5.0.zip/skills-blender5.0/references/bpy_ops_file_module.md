# bpy.ops.file 模块

文件操作模块，用于在文件浏览器中管理文件和目录。

## 概述

bpy.ops.file 模块包含用于在文件浏览器中执行文件操作、管理目录和执行外部程序的运算符。这些运算符控制文件的读取、写入、执行和路径管理。

## 常用操作

### 文件操作

```python
import bpy

# 刷新
bpy.ops.file.refresh()

# 选择所有
bpy.ops.file.select_all(action='SELECT')
bpy.ops.file.select_all(action='DESELECT')
bpy.ops.file.select_all(action='INVERT')

# 边界框选择
bpy.ops.file.select_border(gesture_mode=0, extend=False)

# 套索选择
bpy.ops.file.select_lasso(path=None, mode='SET')

# 选择书签
bpy.ops.file.select_bookmark(dir='NEXT')

# 取消选择书签
bpy.ops.file.select_bookmark(dir='PREV')
```

### 目录操作

```python
# 创建目录
bpy.ops.file.make_directory()

# 删除文件
bpy.ops.file.delete()

# 重命名文件
bpy.ops.file.rename()

# 复制文件
bpy.ops.file.copy(filepath='//destination/file.ext')

# 移动文件
bpy.ops.file.move(filepath='//new_location/file.ext')

# 执行文件
bpy.ops.file.execute()

# 取消文件执行
bpy.ops.file.cancel()

# 重试文件执行
bpy.ops.file.retry()
```

### 目录导航

```python
# 上一级目录
bpy.ops.file.parent()

# 刷新当前目录
bpy.ops.file.refresh()

# 跳转到路径
bpy.ops.file.directory_new()

# 创建新目录
bpy.ops.file.directory_new()

# 历史记录
bpy.ops.file.history()
```

### 书签操作

```python
# 添加书签
bpy.ops.file.bookmark_add(name='MyBookmark')

# 切换书签
bpy.ops.file.bookmark_toggle()

# 删除书签
bpy.ops.file.bookmark_delete()
```

### 过滤操作

```python
# 设置文件过滤
bpy.ops.file.filter(extension='.blend')

# 显示所有文件
bpy.ops.file.filter(extension='*')

# 只显示Blend文件
bpy.ops.file.filter(extension='.blend')

# 显示隐藏文件
bpy.ops.file.show_hidden()
```

### 路径操作

```python
# 复制路径
bpy.ops.file.copy_filepath()

# 复制绝对路径
bpy.ops.file.copy_filepath()

# 复制相对路径
bpy.ops.file.copy_filepath(filepath='//relative/path')

# 粘贴路径
bpy.ops.file.paste_filepath()

# 重命名
bpy.ops.file.rename()
```

### 外部程序

```python
# 打开文件
bpy.ops.file.open_recent()

# 打开外部编辑器
bpy.ops.file.external_edit()

# 执行脚本
bpy.ops.file.run_python_script()

# 执行系统命令
bpy.ops.file.run_system_command()
```

## 实际应用示例

### 批量重命名文件

```python
def batch_rename_files(directory, pattern, replacement):
    """批量重命名文件"""
    import os
    import re
    
    files = os.listdir(directory)
    
    for filename in files:
        if re.search(pattern, filename):
            new_name = re.sub(pattern, replacement, filename)
            old_path = os.path.join(directory, filename)
            new_path = os.path.join(directory, new_name)
            
            os.rename(old_path, new_path)
    
    # 刷新文件浏览器
    bpy.ops.file.refresh()
```

### 清理旧备份

```python
def cleanup_old_backups(directory, keep_count=5):
    """清理旧备份文件"""
    import os
    import glob
    
    # 获取所有备份文件
    backup_files = glob.glob(os.path.join(directory, 'backup_*.blend'))
    backup_files.sort(key=os.path.getmtime)
    
    # 删除旧备份
    if len(backup_files) > keep_count:
        for old_file in backup_files[:-keep_count]:
            os.remove(old_file)
            print(f"已删除: {old_file}")
    
    # 刷新
    bpy.ops.file.refresh()
```

### 复制项目文件

```python
def copy_project_files(source_dir, dest_dir, file_patterns=['*.blend', '*.py', '*.json']):
    """复制项目文件"""
    import os
    import shutil
    
    # 创建目标目录
    os.makedirs(dest_dir, exist_ok=True)
    
    for pattern in file_patterns:
        source_files = glob.glob(os.path.join(source_dir, '**', pattern), recursive=True)
        
        for file_path in source_files:
            rel_path = os.path.relpath(file_path, source_dir)
            dest_path = os.path.join(dest_dir, rel_path)
            
            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            shutil.copy2(file_path, dest_path)
            print(f"已复制: {rel_path}")
    
    bpy.ops.file.refresh()
```

### 同步资产目录

```python
def sync_assets_directory(source_dir, dest_dir):
    """同步资产目录"""
    import os
    import shutil
    
    # 复制所有文件
    for root, dirs, files in os.walk(source_dir):
        rel_path = os.path.relpath(root, source_dir)
        dest_root = os.path.join(dest_dir, rel_path)
        
        os.makedirs(dest_root, exist_ok=True)
        
        for file in files:
            source_file = os.path.join(root, file)
            dest_file = os.path.join(dest_root, file)
            
            # 如果源文件更新则复制
            if not os.path.exists(dest_file) or \
               os.path.getmtime(source_file) > os.path.getmtime(dest_file):
                shutil.copy2(source_file, dest_file)
    
    bpy.ops.file.refresh()
```

### 创建项目结构

```python
def create_project_structure(base_path, structure):
    """创建标准项目结构"""
    import os
    
    for name, substructure in structure.items():
        current_path = os.path.join(base_path, name)
        os.makedirs(current_path, exist_ok=True)
        
        if isinstance(substructure, dict):
            create_project_structure(current_path, substructure)
        elif isinstance(substructure, list):
            for subdir in substructure:
                subdir_path = os.path.join(current_path, subdir)
                os.makedirs(subdir_path, exist_ok=True)
    
    # 刷新
    bpy.ops.file.refresh()
    
    return base_path

# 示例用法
project_structure = {
    'assets': {
        'models': [],
        'textures': [],
        'materials': [],
        'animations': []
    },
    'scenes': [],
    'scripts': [],
    'reference': [],
    'exports': []
}
```

### 清理临时文件

```python
def cleanup_temp_files(directory, extensions=['.blend1', '.blend2', '~']):
    """清理临时文件"""
    import os
    import glob
    
    for ext in extensions:
        temp_files = glob.glob(os.path.join(directory, f'*{ext}'))
        
        for temp_file in temp_files:
            try:
                os.remove(temp_file)
                print(f"已删除临时文件: {temp_file}")
            except Exception as e:
                print(f"无法删除 {temp_file}: {e}")
    
    bpy.ops.file.refresh()
```

### 创建资源归档

```python
def create_assets_archive(source_dir, archive_path, formats=['.blend', '.fbx', '.obj']):
    """创建资源归档"""
    import os
    import zipfile
    
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            for file in files:
                if any(file.endswith(fmt) for fmt in formats):
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, source_dir)
                    zipf.write(file_path, arcname)
                    print(f"已添加: {arcname}")
    
    return archive_path
```

## 使用场景

- **文件管理**：在文件浏览器中管理文件
- **目录操作**：创建、重命名、移动文件
- **批量操作**：批量重命名、清理文件
- **项目组织**：创建项目目录结构
- **资产管理**：同步和备份资产
- **外部集成**：执行外部程序

## 注意事项

- 文件操作是不可逆的
- 确认后再删除文件
- 路径使用相对路径更灵活
- 批量操作前先备份
- 注意文件权限问题
- 同步操作可能覆盖文件
