# bpy.ops.buttons - 按钮操作模块

Blender按钮操作符，用于在属性面板中操作各种按钮和控件。

## 概述

`bpy.ops.buttons` 模块提供用于在Blender属性面板、编辑器面板和其他UI区域中操作按钮和控件的功能。这对于UI自动化测试和批处理操作非常有用。

## 核心功能

### 属性面板按钮操作

```python
import bpy

# 刷新属性面板
bpy.ops.buttons.refresh()

# 更新所有属性
bpy.ops.buttons.update()

# 应用所有修改
bpy.ops.buttons.apply()

# 重置所有属性
bpy.ops.buttons.reset()

# 撤销属性修改
bpy.ops.buttons.undo()

# 重做属性修改
bpy.ops.buttons.redo()
```

### 数值按钮操作

```python
# 增加数值
bpy.ops.buttons.increment(
    delta=1
)

# 减少数值
bpy.ops.buttons.decrement(
    delta=-1
)

# 设置精确值
bpy.ops.buttons.set_value(
    value=1.5
)

# 拖动滑块
bpy.ops.buttons.drag(
    value=0.0,
    delta=1.0
)

# 循环数值
bpy.ops.buttons.cycle(
    reverse=False
)

# 反向循环
bpy.ops.buttons.cycle(
    reverse=True
)
```

### 复选框操作

```python
# 切换复选框
bpy.ops.buttons.toggle()

# 启用
bpy.ops.buttons.set_boolean(
    value=True
)

# 禁用
bpy.ops.buttons.set_boolean(
    value=False
)
```

### 颜色按钮操作

```python
# 设置颜色
bpy.ops.buttons.color_picker(
    color=(1.0, 0.0, 0.0, 1.0)
)

# 设置RGB颜色
bpy.ops.buttons.color_picker(
    color=(1.0, 0.0, 0.0)
)

# 设置HSV颜色
bpy.ops.buttons.color_picker(
    color=(0.0, 1.0, 1.0),
    color_mode='HSV'
)

# 切换颜色通道
bpy.ops.buttons.cycle_color()

# 切换颜色模式
bpy.ops.buttons.cycle_color_mode()

# 恢复默认颜色
bpy.ops.buttons.color_reset()
```

### 枚举按钮操作

```python
# 设置枚举值
bpy.ops.buttons.enum_set(
    value='OPTION_A'
)

# 循环枚举值
bpy.ops.buttons.enum_next()

# 反向循环枚举值
bpy.ops.buttons.enum_prev()

# 搜索枚举值
bpy.ops.buttons.enum_search(
    query='search_term'
)
```

### 字符串按钮操作

```python
# 设置字符串
bpy.ops.buttons.string_set(
    value='new_string'
)

# 清空字符串
bpy.ops.buttons.string_clear()

# 撤销字符串修改
bpy.ops.buttons.string_undo()

# 重做字符串修改
bpy.ops.buttons.string_redo()
```

### 向量按钮操作

```python
# 设置向量值
bpy.ops.buttons.vector_set(
    value=(1.0, 2.0, 3.0)
)

# 设置向量X分量
bpy.ops.buttons.vector_set_x(
    value=1.0
)

# 设置向量Y分量
bpy.ops.buttons.vector_set_y(
    value=2.0
)

# 设置向量Z分量
bpy.ops.buttons.vector_set_z(
    value=3.0
)

# 循环向量分量
bpy.ops.buttons.vector_cycle()
```

### 文件路径按钮操作

```python
# 选择文件
bpy.ops.buttons.file_browse(
    filepath='//textures/material.png',
    filter_blender=True,
    filter_image=True,
    filter_movie=False,
    filter_python=False,
    filter_font=True,
    filter_sound=False,
    filter_text=False,
    filter_archive=False
)

# 选择目录
bpy.ops.buttons.directory_browse(
    directory='//textures/'
)

# 选择图像
bpy.ops.buttons.file_browse(
    filepath='//image.png',
    filter_image=True
)

# 清除文件路径
bpy.ops.buttons.file_clear()

# 相对路径切换
bpy.ops.buttons.path_relative_toggle()
```

### ID选择按钮操作

```python
# 选择ID数据块
bpy.ops.buttons.id_select(
    id_name='Material',
    id_type='MATERIAL'
)

# 选择材质
bpy.ops.buttons.id_select(
    id_name='MyMaterial',
    id_type='MATERIAL'
)

# 选择纹理
bpy.ops.buttons.id_select(
    id_name='MyTexture',
    id_type='TEXTURE'
)

# 选择对象
bpy.ops.buttons.id_select(
    id_name='MyObject',
    id_type='OBJECT'
)

# 新建ID数据块
bpy.ops.buttons.id_new(
    id_type='MATERIAL',
    name='NewMaterial'
)

# 删除ID数据块
bpy.ops.buttons.id_delete()

# 复制ID数据块
bpy.ops.buttons.id_copy()

# 粘贴ID数据块
bpy.ops.buttons.id_paste()
```

### 数组按钮操作

```python
# 增加数组元素
bpy.ops.buttons.array_add()

# 移除数组元素
bpy.ops.buttons.array_remove()

# 移动数组元素
bpy.ops.buttons.array_move(
    from_index=0,
    to_index=1
)

# 重新排序数组
bpy.ops.buttons.array_reorder()
```

### 颜色渐变按钮操作

```python
# 添加渐变色标
bpy.ops.buttons.gradient_add(
    position=0.5,
    color=(1.0, 0.0, 0.0, 1.0)
)

# 移除渐变色标
bpy.ops.buttons.gradient_remove(
    index=0
)

# 选择渐变色标
bpy.ops.buttons.gradient_select(
    index=0
)

# 移动渐变色标
bpy.ops.buttons.gradient_move(
    from_index=0,
    to_index=1
)

# 设置渐变类型
bpy.ops.buttons.gradient_type(
    type='LINEAR'
)

# 循环渐变
bpy.ops.buttons.gradient_cycle()
```

### 关键帧按钮操作

```python
# 插入关键帧
bpy.ops.buttons.keyframe_insert()

# 删除关键帧
bpy.ops.buttons.keyframe_delete()

# 清除关键帧
bpy.ops.buttons.keyframe_clear()

# 复制关键帧
bpy.ops.buttons.keyframe_copy()

# 粘贴关键帧
bpy.ops.buttons.keyframe_paste()

# 跳转关键帧
bpy.ops.buttons.keyframe_jump(
    direction='NEXT'
)

# 关键帧类型切换
bpy.ops.buttons.keyframe_type()
```

## 实用函数

```python
def get_button_value(prop_path):
    """获取属性值"""
    props = bpy.context
    for attr in prop_path.split('.'):
        props = getattr(props, attr)
    return props

def set_material_color(mat_name, color):
    """设置材质颜色"""
    mat = bpy.data.materials.get(mat_name)
    if mat:
        bpy.context.active_object.active_material = mat
        bpy.ops.buttons.color_picker(color=color)

def toggle_shading_mode(mode):
    """切换着色模式"""
    bpy.context.space_data.shading.type = mode

def set_render_engine(engine_name):
    """设置渲染引擎"""
    bpy.context.scene.render.engine = engine_name

def toggle_viewport_overlays():
    """切换视口叠加层"""
    space = bpy.context.space_data
    space.overlay.show_overlays = not space.overlay.show_overlays

def cycle_display_mode():
    """循环显示模式"""
    modes = ['WIREFRAME', 'SOLID', 'MATERIAL', 'RENDERED']
    space = bpy.context.space_data
    current = modes.index(space.shading.type)
    space.shading.type = modes[(current + 1) % len(modes)]

def select_all_in_panel():
    """全选面板中的所有属性"""
    for area in bpy.context.screen.areas:
        if area.type == 'PROPERTIES':
            for region in area.regions:
                if region.type == 'WINDOW':
                    for ui_item in region.ui_items:
                        ui_item.select = True

def get_panel_properties(panel_id):
    """获取面板中的所有属性"""
    properties = []
    panel = eval(panel_id)
    if panel:
        for prop in panel.bl_rna.properties:
            if not prop.is_hidden:
                properties.append(prop.identifier)
    return properties
```

## 常见问题排查

### 按钮操作无响应
```python
# 检查是否在正确的上下文
print(f"当前区域类型: {bpy.context.area.type if bpy.context.area else 'None'}")

# 检查属性面板区域
for area in bpy.context.screen.areas:
    if area.type == 'PROPERTIES':
        print(f"属性面板区域: {area}")

# 确保面板已展开
bpy.ops.buttons.refresh()

# 尝试重新初始化上下文
import bpy
bpy.ops.buttons.update()
```

### 属性值不更新
```python
# 检查属性是否存在
prop_path = 'scene.render.engine'
try:
    value = eval(f'bpy.{prop_path}')
    print(f"属性值: {value}")
except:
    print(f"属性不存在: {prop_path}")

# 手动触发更新
bpy.ops.buttons.update()

# 检查属性是否可编辑
obj = bpy.context.active_object
print(f"可编辑: {not obj.library}")

# 检查ID块是否链接
print(f"库: {obj.library}")
```

### 颜色按钮问题
```python
# 检查颜色空间
space = bpy.context.space_data
if space:
    print(f"颜色管理: {space.used_view_map.color_management}")

# 检查材质
mat = bpy.context.active_object.active_material
if mat:
    print(f"材质使用节点: {mat.use_nodes}")

# 检查节点着色器
if mat.use_nodes:
    bsdf = mat.node_tree.nodes.get('Principled BSDF')
    if bsdf:
        print(f"基础颜色: {bsdf.inputs['Base Color'].default_value}")

# 重置颜色
bpy.ops.buttons.color_reset()
```
