# bpy.ops.speaker - 扬声器操作模块

Blender扬声器操作符，用于管理音频扬声器对象和音频播放设置。

## 概述

`bpy.ops.speaker` 模块提供用于操作Blender中扬声器对象的功能，包括添加、编辑和配置音频扬声器属性。

## 核心功能

### 扬声器创建

```python
import bpy

# 添加扬声器
bpy.ops.object.speaker_add(
    location=(0, 0, 0),
    rotation=(0, 0, 0)
)

# 在指定位置添加扬声器
bpy.ops.object.speaker_add(
    location=(5.0, 3.0, 2.0)
)

# 复制扬声器
bpy.ops.object.duplicate(
    linked=False,
    mode='DUPLICATE'
)
```

### 扬声器属性设置

```python
# 设置扬声器名称
speaker = bpy.context.active_object
speaker.name = 'MainSpeaker'

# 设置音量
speaker.data.volume = 0.8

# 设置音高
speaker.data.pitch = 1.0

# 设置距离模型
speaker.data.distance_model = 'INVERSE'
speaker.data.distance_model = 'LINEAR'
speaker.data.distance_model = 'EXPONENT'

# 设置参考距离
speaker.data.distance_reference = 1.0

# 设置最大距离
speaker.data.distance_max = 100.0

# 设置衰减因子
speaker.data.attenuation = 1.0
```

### 音频播放控制

```python
# 加载音频文件
speaker.data.sound = bpy.data.sounds.load('//audio.mp3')

# 播放音频
bpy.ops.sound.play()

# 暂停音频
bpy.ops.sound.pause()

# 停止音频
bpy.ops.sound.stop()

# 循环播放
speaker.data.sound.use_loop = True

# 自动播放
speaker.data.sound.use_auto_play = True
```

### 扬声器空间设置

```python
# 设置声锥角度
speaker.data.cone_angle_outer = 60.0
speaker.data.cone_angle_inner = 30.0

# 设置声锥衰减
speaker.data.cone_volume_outer = 0.0

# 设置立体声角度
speaker.data.pan = 0.0

# 启用/禁用低音增强
speaker.data.low_pass_filter = 0.0
```

## 实用函数

```python
def create_speaker(name, location, volume=1.0):
    """创建扬声器并设置基本属性"""
    bpy.ops.object.speaker_add(location=location)
    speaker = bpy.context.active_object
    speaker.name = name
    speaker.data.volume = volume
    return speaker

def load_audio_to_speaker(speaker, audio_path):
    """加载音频到扬声器"""
    speaker.data.sound = bpy.data.sounds.load(audio_path)

def setup_spatial_audio(speaker, ref_dist=1.0, max_dist=100.0, model='INVERSE'):
    """设置空间音频参数"""
    speaker.data.distance_reference = ref_dist
    speaker.data.distance_max = max_dist
    speaker.data.distance_model = model

def setup_directional_speaker(speaker, outer_angle, inner_angle):
    """设置指向性扬声器"""
    speaker.data.cone_angle_outer = outer_angle
    speaker.data.cone_angle_inner = inner_angle
```

## 常见问题排查

### 音频不播放
```python
# 检查音频文件
speaker = bpy.context.active_object
print(f"音频: {speaker.data.sound}")
print(f"音量: {speaker.data.volume}")

# 检查静音状态
print(f"静音: {speaker.data.sound.use_mute if speaker.data.sound else 'N/A'}")
```

### 空间音频不工作
```python
# 检查距离模型
print(f"距离模型: {speaker.data.distance_model}")

# 检查参考距离
print(f"参考距离: {speaker.data.distance_reference}")

# 检查最大距离
print(f"最大距离: {speaker.data.distance_max}")
```
