# bpy.ops.mball 模块

元球操作模块，用于创建和管理元球。

## 概述

bpy.ops.mball 模块包含用于创建、编辑和操作元球的运算符。这些元球是程序化定义的曲面，可用于创建有机形状和流体效果。

## 常用操作

### 元球创建

```python
import bpy

# 添加球体元球
bpy.ops.mesh.primitive_uv_sphere_add(radius=1.0, location=(0, 0, 0))

# 添加胶囊元球
bpy.ops.mesh.primitive_capule_add(radius=0.5, depth=1.0)

# 转换为元球
bpy.ops.object.convert(target='META')

# 添加元球数据
bpy.ops.object.metaball_add(type='BALL', radius=1.0)

# 添加平面元球
bpy.ops.object.metaball_add(type='PLANE', radius=1.0)

# 添加椭圆体元球
bpy.ops.object.metaball_add(type='ELLIPSOID', radius=1.0)

# 添加立方体元球
bpy.ops.object.metaball_add(type='CUBE', radius=1.0)
```

### 元球类型

```python
# 添加球体
bpy.ops.object.metaball_add(type='BALL')

# 添加平面
bpy.ops.object.metaball_add(type='PLANE')

# 添加椭圆体
bpy.ops.object.metaball_add(type='ELLIPSOID')

# 添加立方体
bpy.ops.object.metaball_add(type='CUBE')

# 添加圆柱体
bpy.ops.object.metaball_add(type='CYLINDER')
```

### 元球编辑

```python
# 复制元球
bpy.ops.object.duplicate()

# 删除元球
bpy.ops.object.delete()

# 重命名元球
bpy.ops.object.rename(name='Metaball')

# 设置分辨率
bpy.ops.object.metaball_add(type='BALL', resolution=0.5)

# 更新元球
bpy.ops.object.update()
```

### 选择操作

```python
# 全选
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.select_all(action='DESELECT')
bpy.ops.object.select_all(action='INVERT')

# 选择同类型
bpy.ops.object.select_same_type()
```

### 元球设置

```python
# 设置阈值
bpy.ops.object.metaball_add(type='BALL', threshold=1.0)

# 设置半径
bpy.ops.object.metaball_add(type='BALL', radius=1.0)

# 设置刚度
bpy.ops.object.metaball_add(type='BALL', stiffness=0.5)

# 设置副本
bpy.ops.object.metaball_add(type='BALL', copy_radius=False)
```

### 元球转换

```python
# 转换为网格
bpy.ops.object.convert(target='MESH')

# 转换为曲线
bpy.ops.object.convert(target='CURVE')

# 转换为曲面
bpy.ops.object.convert(target='SURFACE')
```

## 实际应用示例

### 创建基础元球

```python
def create_basic_metaball(name='BasicMetaball'):
    """创建基础元球"""
    bpy.ops.object.metaball_add(type='BALL', radius=1.0, location=(0, 0, 0))
    metaball = bpy.context.active_object
    metaball.name = name
    
    # 设置分辨率
    metaball.data.resolution = 0.2
    
    return metaball
```

### 创建程序化水滴

```python
def create_dripping_effect(count=10, center=(0, 0, 0), radius=1.0):
    """创建水滴效果"""
    import random
    import math
    
    # 创建中心元球
    bpy.ops.object.metaball_add(type='BALL', radius=radius, location=center)
    center_ball = bpy.context.active_object
    center_ball.name = 'DripCenter'
    
    # 添加滴落元球
    for i in range(count):
        x = center[0] + random.uniform(-2, 2)
        y = center[1] + random.uniform(-2, 2)
        z = center[2] + random.uniform(-1, 3)
        
        bpy.ops.object.metaball_add(
            type='BALL',
            radius=random.uniform(0.2, 0.5),
            location=(x, y, z)
        )
        
        ball = bpy.context.active_object
        ball.name = f'Drip_{i}'
    
    return bpy.context.active_object
```

### 创建有机形状

```python
def create_organic_shape(seed=42):
    """创建有机形状"""
    import random
    random.seed(seed)
    
    # 创建主元球
    bpy.ops.object.metaball_add(type='ELLIPSOID', radius=2.0, location=(0, 0, 0))
    main_ball = bpy.context.active_object
    main_ball.name = 'OrganicMain'
    
    # 添加子元球
    for i in range(15):
        x = random.uniform(-3, 3)
        y = random.uniform(-3, 3)
        z = random.uniform(-3, 3)
        
        radius = random.uniform(0.3, 1.0)
        
        bpy.ops.object.metaball_add(
            type='BALL',
            radius=radius,
            location=(x, y, z)
        )
        
        ball = bpy.context.active_object
        ball.name = f'OrganicPart_{i}'
    
    # 设置阈值
    main_ball.data.threshold = 1.0
    
    return main_ball
```

### 创建细胞结构

```python
def create_cell_structure(cells=20, cluster_centers=3):
    """创建细胞结构"""
    import random
    
    # 创建聚类中心
    centers = []
    for i in range(cluster_centers):
        centers.append((
            random.uniform(-5, 5),
            random.uniform(-5, 5),
            random.uniform(-5, 5)
        ))
    
    # 创建元球
    for i in range(cells):
        center = random.choice(centers)
        
        x = center[0] + random.uniform(-2, 2)
        y = center[1] + random.uniform(-2, 2)
        z = center[2] + random.uniform(-2, 2)
        
        radius = random.uniform(0.3, 0.8)
        
        bpy.ops.object.metaball_add(
            type='BALL',
            radius=radius,
            location=(x, y, z)
        )
        
        cell = bpy.context.active_object
        cell.name = f'Cell_{i}'
    
    return bpy.context.active_object
```

### 创建流体球效果

```python
def create_fluid_balls(ball_count=8, container_size=3):
    """创建流体球效果"""
    import random
    
    for i in range(ball_count):
        x = random.uniform(-container_size, container_size)
        y = random.uniform(-container_size, container_size)
        z = random.uniform(-container_size, container_size)
        
        radius = random.uniform(0.5, 1.5)
        
        bpy.ops.object.metaball_add(
            type='BALL',
            radius=radius,
            location=(x, y, z)
        )
        
        ball = bpy.context.active_object
        ball.name = f'Fluid_{i}'
    
    return bpy.context.active_object
```

### 创建复杂拓扑

```python
def create_complex_topology():
    """创建复杂拓扑元球"""
    import math
    
    # 创建中心椭圆体
    bpy.ops.object.metaball_add(type='ELLIPSOID', radius=2.0, location=(0, 0, 0))
    center = bpy.context.active_object
    center.data.stiffness = 0.8
    
    # 创建环形元球
    ring_count = 12
    ring_radius = 3.0
    
    for i in range(ring_count):
        angle = (i / ring_count) * 2 * math.pi
        x = ring_radius * math.cos(angle)
        y = ring_radius * math.sin(angle)
        
        bpy.ops.object.metaball_add(
            type='BALL',
            radius=0.5,
            location=(x, y, 0)
        )
        
        ball = bpy.context.active_object
        ball.name = f'Ring_{i}'
    
    # 创建垂直元球
    for i in range(4):
        z = (i - 1.5) * 2
        bpy.ops.object.metaball_add(
            type='BALL',
            radius=0.6,
            location=(0, 0, z)
        )
    
    return center
```

### 创建元球动画

```python
def create_metaball_animation(metaball_obj, frames=60, amplitude=1.0):
    """创建元球动画"""
    import math
    
    # 设置帧范围
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = frames
    
    # 动画参数
    for frame in range(1, frames + 1):
        bpy.context.scene.frame_set(frame)
        
        t = (frame - 1) / frames * 2 * math.pi
        
        # 脉动效果
        scale = 1.0 + amplitude * math.sin(t)
        metaball_obj.scale = (scale, scale, scale)
        metaball_obj.keyframe_insert(data_path='scale')
    
    return metaball_obj
```

### 将元球转换为网格

```python
def convert_metaball_to_mesh(metaball_obj, name='MetaballMesh'):
    """将元球转换为网格"""
    # 选择元球
    bpy.ops.object.select_all(action='DESELECT')
    metaball_obj.select_set(True)
    bpy.context.view_layer.objects.active = metaball_obj
    
    # 转换为网格
    bpy.ops.object.convert(target='MESH')
    
    # 重命名
    mesh_obj = bpy.context.active_object
    mesh_obj.name = name
    
    return mesh_obj
```

## 使用场景

- **有机形状**：创建自然有机的形状
- **水滴效果**：创建流体和液体效果
- **细胞结构**：模拟生物细胞
- **软体效果**：创建软体和变形效果
- **程序化动画**：创建动态变化的有机形状
- **拓扑生成**：生成复杂表面

## 注意事项

- 元球需要转换为网格才能渲染
- 分辨率影响质量和性能
- 阈值控制融合效果
- 刚度控制形状硬度
- 大量元球影响性能
- 元球不支持细分曲面
