# bpy.ops.import_scene - Alembic导入操作模块

Blender Alembic文件导入操作符，用于将Alembic（.abc）格式文件导入Blender。

## 概述

`bpy.ops.import_scene.abc` 模块提供用于将Alembic格式文件导入Blender的功能，支持几何体、动画和材质的高保真导入。

## 核心功能

### 基础导入

```python
import bpy

# 导入Alembic文件
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    directory='//',
    files=[{'name': 'model.abc'}],
    ui_tab='MAIN',
    global_scale=1.0,
    unit_scale=1.0,
    use_custom_normals=True,
    use_uv=True,
    use_selection=False,
    visible_objects_only=False,
    import_guide=False,
    import_cameras=True,
    import_lights=True,
    import_materials=True,
    import_subdiv=False,
    import_anim=True,
    import_anim_named_stashes=False,
    import_anim_use_default=True,
    import_anim_range=True,
    fabrik_solve=False,
    reload=True
)
```

### 几何体导入

```python
# 导入UV
bpy.ops.import_scene.abc(
    filepath='//uv.abc',
    use_uv=True
)

# 不导入UV
bpy.ops.import_scene.abc(
    filepath='//no_uv.abc',
    use_uv=False
)

# 使用自定义法线
bpy.ops.import_scene.abc(
    filepath='//normals.abc',
    use_custom_normals=True
)

# 不使用自定义法线
bpy.ops.import_scene.abc(
    filepath='//no_normals.abc',
    use_custom_normals=False
)
```

### 缩放设置

```python
# 设置全局缩放
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    global_scale=1.0
)

# 设置单位缩放
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    unit_scale=1.0
)
```

### 选择导入

```python
# 导入选中对象
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    use_selection=True
)

# 导入所有对象
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    use_selection=False
)
```

### 可见性设置

```python
# 只导入可见对象
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    visible_objects_only=True
)

# 导入所有对象
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    visible_objects_only=False
)
```

### 引导设置

```python
# 导入引导
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    import_guide=True
)

# 不导入引导
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    import_guide=False
)
```

### 相机和灯光

```python
# 导入相机
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    import_cameras=True
)

# 不导入相机
bpy.ops.import_scene.abc(
    filepath='//no_cameras.abc',
    import_cameras=False
)

# 导入灯光
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    import_lights=True
)

# 不导入灯光
bpy.ops.import_scene.abc(
    filepath='//no_lights.abc',
    import_lights=False
)
```

### 材质导入

```python
# 导入材质
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    import_materials=True
)

# 不导入材质
bpy.ops.import_scene.abc(
    filepath='//no_materials.abc',
    import_materials=False
)
```

### 细分设置

```python
# 导入细分
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    import_subdiv=True
)

# 不导入细分
bpy.ops.import_scene.abc(
    filepath='//no_subdiv.abc',
    import_subdiv=False
)
```

### 动画导入

```python
# 导入动画
bpy.ops.import_scene.abc(
    filepath='//anim.abc',
    import_anim=True
)

# 不导入动画
bpy.ops.import_scene.abc(
    filepath='//static.abc',
    import_anim=False
)

# 导入命名缓存
bpy.ops.import_scene.abc(
    filepath='//stashes.abc',
    import_anim=True,
    import_anim_named_stashes=True
)

# 使用默认动画
bpy.ops.import_scene.abc(
    filepath='//anim.abc',
    import_anim=True,
    import_anim_use_default=True
)

# 使用帧范围
bpy.ops.import_scene.abc(
    filepath='//anim.abc',
    import_anim=True,
    import_anim_range=True
)
```

### FABRIK设置

```python
# 使用FABRIK求解
bpy.ops.import_scene.abc(
    filepath='//fabrik.abc',
    fabrik_solve=True
)

# 不使用FABRIK
bpy.ops.import_scene.abc(
    filepath='//no_fabrik.abc',
    fabrik_solve=False
)
```

### 重载设置

```python
# 启用重载
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    reload=True
)

# 禁用重载
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    reload=False
)
```

## 实用函数

```python
def import_abc_model(filepath, scale=1.0):
    """导入Alembic模型"""
    bpy.ops.import_scene.abc(
        filepath=filepath,
        global_scale=scale,
        use_custom_normals=True,
        use_uv=True,
        import_cameras=True,
        import_lights=True,
        import_materials=True,
        import_anim=False
    )
    return list(bpy.context.selected_objects)

def import_abc_with_animations(filepath, scale=1.0):
    """导入Alembic带动画"""
    bpy.ops.import_scene.abc(
        filepath=filepath,
        global_scale=scale,
        use_custom_normals=True,
        use_uv=True,
        import_cameras=True,
        import_lights=True,
        import_materials=True,
        import_anim=True,
        import_anim_use_default=True
    )
    return list(bpy.context.selected_objects)

def import_abc_for_editing(filepath):
    """导入Alembic用于编辑"""
    bpy.ops.import_scene.abc(
        filepath=filepath,
        global_scale=1.0,
        use_custom_normals=True,
        use_uv=True,
        import_cameras=False,
        import_lights=False,
        import_materials=False,
        import_anim=False
    )
    return list(bpy.context.selected_objects)

def import_abc_character(filepath):
    """导入Alembic角色"""
    bpy.ops.import_scene.abc(
        filepath=filepath,
        global_scale=1.0,
        use_custom_normals=True,
        use_uv=True,
        import_cameras=True,
        import_lights=True,
        import_materials=True,
        import_anim=True,
        import_anim_use_default=True,
        import_anim_range=True
    )
    return list(bpy.context.selected_objects)

def batch_import_abc_files(abc_files, scale=1.0):
    """批量导入Alembic文件"""
    all_objects = []
    for filepath in abc_files:
        bpy.ops.import_scene.abc(
            filepath=filepath,
            global_scale=scale
        )
        imported = list(bpy.context.selected_objects)
        all_objects.extend(imported)
    return all_objects

def import_abc_and_merge(filepath):
    """导入Alembic并合并"""
    bpy.ops.import_scene.abc(
        filepath=filepath,
        global_scale=1.0,
        use_custom_normals=True
    )
    
    objects = list(bpy.context.selected_objects)
    if len(objects) > 1:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = objects[0]
        bpy.ops.object.join()
        return [bpy.context.active_object]
    
    return objects
```

## 常见问题排查

### 导入后模型不可见
```python
# 检查选中对象
selected = bpy.context.selected_objects
print(f"导入对象数: {len(selected)}")

# 检查对象类型
for obj in selected:
    print(f"{obj.name}: 类型={obj.type}")

# 检查隐藏状态
for obj in selected:
    print(f"{obj.name}: 隐藏={obj.hide_viewport}")
    obj.hide_viewport = False

# 检查显示类型
for obj in selected:
    obj.display_type = 'SOLID'
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 检查骨骼动画
if obj.type == 'ARMATURE':
    print(f"骨骼数: {len(obj.data.bones)}")

# 重新导入带动画
bpy.ops.import_scene.abc(
    filepath='//anim.abc',
    import_anim=True,
    import_anim_use_default=True
)
```

### 材质丢失
```python
# 检查材质
print(f"材质数: {len(bpy.data.materials)}")

# 检查纹理
print(f"纹理数: {len(bpy.data.textures)}")

# 重新导入带材质
bpy.ops.import_scene.abc(
    filepath='//mat.abc',
    import_materials=True,
    import_anim=False
)
```

### 比例问题
```python
# 检查导入比例
obj = bpy.context.active_object
print(f"尺寸: {obj.dimensions}")

# 检查单位设置
print(f"场景单位: {bpy.context.scene.unit_settings.system}")

# 重新导入带正确比例
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    global_scale=0.01,
    unit_scale=1.0
)
```

### 性能问题
```python
# 检查对象数
print(f"对象数: {len(bpy.context.selected_objects)}")

# 减少导入内容
bpy.ops.import_scene.abc(
    filepath='//model.abc',
    use_selection=True,
    visible_objects_only=True,
    import_cameras=False,
    import_lights=False,
    import_anim=False
)

# 导入后优化
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.join()
```
