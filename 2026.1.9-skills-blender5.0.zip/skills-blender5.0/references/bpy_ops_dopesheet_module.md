# bpy.ops.dopesheet - 动画摄影表操作模块

bpy.ops.dopesheet模块提供了动画摄影表（ dope sheet）编辑器中的操作功能，用于管理和编辑关键帧动画数据。

## 概述

动画摄影表是Blender中用于查看和编辑动画数据的重要编辑器。这个模块提供了在摄影表环境中进行选择、编辑和时间管理的操作。

## 核心功能

### 关键帧选择

```python
import bpy

def select_all_keyframes():
    """选择所有关键帧"""
    bpy.ops.dopesheet.select_all(action='SELECT')

def deselect_all_keyframes():
    """取消选择所有关键帧"""
    bpy.ops.dopesheet.select_all(action='DESELECT')

def select_keyframes_in_range(start_frame, end_frame):
    """选择范围内的关键帧"""
    bpy.context.scene.frame_start = start_frame
    bpy.context.scene.frame_end = end_frame
    bpy.ops.dopsheet.select_border(region_filter=('DOPESHEET',))
```

### 关键帧编辑

```python
def delete_selected_keyframes():
    """删除选中的关键帧"""
    bpy.ops.dopesheet.delete()

def duplicate_keyframes():
    """复制关键帧"""
    bpy.ops.dopesheet.duplicate()

def copy_keyframes():
    """复制关键帧"""
    bpy.ops.dopesheet.copy()

def paste_keyframes():
    """粘贴关键帧"""
    bpy.ops.dopesheet.paste()
```

### 时间操作

```python
def set_preview_range(start, end):
    """设置预览范围"""
    bpy.context.scene.frame_preview_start = start
    bpy.context.scene.frame_preview_end = end

def jump_to_frame(frame):
    """跳转到指定帧"""
    bpy.context.scene.frame_current = frame

def frame_jump(end=True):
    """帧跳转"""
    bpy.ops.dopesheet.frame_jump(end=end)

def frame_ping_pong():
    """帧往复"""
    bpy.ops.dopesheet.ping_pong()
```

## 实用函数

### 通道操作

```python
def expand_all_channels():
    """展开所有通道"""
    bpy.ops.dopesheet.channels_expand()

def collapse_all_channels():
    """折叠所有通道"""
    bpy.ops.dopesheet.channels_collapse()

def select_channel_hierarchy():
    """选择通道层级"""
    bpy.ops.dopesheet.select_hierarchy(direction='CHILDREN')
```

### 关键帧操作

```python
def set_keyframe_on_selected():
    """在选中属性上设置关键帧"""
    bpy.ops.dopesheet.keyframe_insert()

def delete_keyframe_at_cursor():
    """在光标处删除关键帧"""
    bpy.ops.dopesheet.keyframe_delete()

def clean_keyframes():
    """清理关键帧"""
    bpy.ops.dopesheet.clean()
```

## 常见问题排查

### 选择问题

选择不工作：
- 确认编辑器为激活状态
- 检查是否有可选择对象
- 验证选择模式设置

### 复制粘贴问题

剪贴板为空：
- 先执行复制操作
- 检查目标位置是否有效
- 确认动画数据类型匹配
