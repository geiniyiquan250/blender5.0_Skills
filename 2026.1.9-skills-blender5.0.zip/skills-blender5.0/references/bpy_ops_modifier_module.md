# bpy.ops.modifier 模块

修饰器操作模块，用于创建和管理物体修饰器。

## 概述

bpy.ops.modifier 模块包含用于在物体上添加、编辑和应用修饰器的运算符。修饰器是非破坏性修改物体几何体的工具，包括细分、表面细分、布尔运算、阵列等。

## 常用操作

### 修饰器添加

```python
import bpy

# 添加修饰器到选中物体
bpy.ops.object.modifier_add(type='SUBSURF')

# 添加指定类型的修饰器
bpy.ops.object.modifier_add(type='ARRAY')
bpy.ops.object.modifier_add(type='BOOLEAN')
bpy.ops.object.modifier_add(type='BEVEL')
bpy.ops.object.modifier_add(type='MIRROR')
bpy.ops.object.modifier_add(type='DECIMATE')
bpy.ops.object.modifier_add(type='REMESH')
bpy.ops.object.modifier_add(type='WIREFRAME')
bpy.ops.object.modifier_add(type='DISPLACE')
bpy.ops.object.modifier_add(type='SMOOTH')
bpy.ops.object.modifier_add(type='SIMPLE_DEFORM')
bpy.ops.object.modifier_add(type='CAST')
bpy.ops.object.modifier_add(type='LATTICE')
```

### 修饰器类型

```python
# 表面细分
bpy.ops.object.modifier_add(type='SUBSURF')
bpy.ops.object.modifier_add(type='SUBSURF', levels=2, render_levels=3)

# 阵列修饰器
bpy.ops.object.modifier_add(type='ARRAY')
bpy.ops.object.modifier_add(type='ARRAY', use_relative_offset=False, use_constant_offset=True)

# 布尔修饰器
bpy.ops.object.modifier_add(type='BOOLEAN')
bpy.ops.object.modifier_add(type='BOOLEAN', operation='DIFFERENCE', object='Cube_001')

# 倒角修饰器
bpy.ops.object.modifier_add(type='BEVEL')
bpy.ops.object.modifier_add(type='BEVEL', width=0.1, segments=3, limit_method='ANGLE')

# 镜像修饰器
bpy.ops.object.modifier_add(type='MIRROR')
bpy.ops.object.modifier_add(type='MIRROR', axis={'X'}, use_mirror_merge=True)

# 精简修饰器
bpy.ops.object.modifier_add(type='DECIMATE')
bpy.ops.object.modifier_add(type='DECIMATE', ratio=0.5, decimate_type='COLLAPSE')

# 重构修饰器
bpy.ops.object.modifier_add(type='REMESH')
bpy.ops.object.modifier_add(type='REMESH', mode='VOXEL', voxel_size=0.1)

# 线框修饰器
bpy.ops.object.modifier_add(type='WIREFRAME')
bpy.ops.object.modifier_add(type='WIREFRAME', thickness=0.05, use_replace=True)

# 置换修饰器
bpy.ops.object.modifier_add(type='DISPLACE')
bpy.ops.object.modifier_add(type='DISPLACE', texture='CloudTexture', strength=0.5)

# 平滑修饰器
bpy.ops.object.modifier_add(type='SMOOTH')
bpy.ops.object.modifier_add(type='SMOOTH', factor=1.0, iterations=5)

# 简单变形修饰器
bpy.ops.object.modifier_add(type='SIMPLE_DEFORM')
bpy.ops.object.modifier_add(type='SIMPLE_DEFORM', deform_method='TWIST', angle=3.14159)

# 铸造修饰器
bpy.ops.object.modifier_add(type='CAST')
bpy.ops.object.modifier_add(type='CAST', cast_type='SPHERE', factor=1.0)

# 晶格修饰器
bpy.ops.object.modifier_add(type='LATTICE')
bpy.ops.object.modifier_add(type='LATTICE', object='LatticeObject')

# 体积转网格修饰器
bpy.ops.object.modifier_add(type='VOLUME_TO_MESH')
bpy.ops.object.modifier_add(type='VOLUME_TO_MESH', resolution=0.1)

# 法线编辑修饰器
bpy.ops.object.modifier_add(type='NORMAL_EDIT')
bpy.ops.object.modifier_add(type='NORMAL_EDIT', mode='RADIAL', factor=1.0)

# 加权法线修饰器
bpy.ops.object.modifier_add(type='WEIGHTED_NORMAL')
bpy.ops.object.modifier_add(type='WEIGHTED_NORMAL', weight=1.0)

# 数据传输修饰器
bpy.ops.object.modifier_add(type='DATA_TRANSFER')
bpy.ops.object.modifier_add(type='DATA_TRANSFER', object='SourceObject', use_reverse_transfer=True)
```

### 修饰器操作

```python
# 选中修饰器
bpy.ops.object.modifier_select(modifier='Subsurf')

# 移动修饰器
bpy.ops.object.modifier_move_up(modifier='Subsurf')
bpy.ops.object.modifier_move_down(modifier='Subsurf')

# 删除修饰器
bpy.ops.object.modifier_remove(modifier='Subsurf')

# 应用修饰器
bpy.ops.object.modifier_apply(modifier='Subsurf')
bpy.ops.object.modifier_apply_as='DATA_TRANSFER', modifier='Boolean')

# 应用为形状键
bpy.ops.object.modifier_apply_as_shapekey(modifier='Subsurf', suffix='Subsurf')

# 复制修饰器
bpy.ops.object.modifier_copy(modifier='Subsurf')

# 转换所有修饰器为网格
bpy.ops.object.convert_to_thresholded()

# 转换所有修饰器为实时细分
bpy.ops.object.convert_to_realistic()
```

## 实际应用示例

### 创建程序化建筑

```python
def create_modern_building(base_size=(10, 10, 20), segments=4):
    """创建现代建筑模型"""
    # 创建基础立方体
    bpy.ops.mesh.primitive_cube_add(size=1)
    building = bpy.context.active_object
    building.name = 'ModernBuilding'
    
    # 设置基础大小
    building.scale = (base_size[0], base_size[1], base_size[2])
    
    # 添加镜像修饰器
    mirror = building.modifiers.new(name='Mirror', type='MIRROR')
    mirror.use_x = True
    mirror.use_y = True
    mirror.use_mirror_merge = True
    
    # 添加细分修饰器
    subsurf = building.modifiers.new(name='Subsurf', type='SUBSURF')
    subsurf.levels = 2
    subsurf.render_levels = 3
    
    # 添加倒角修饰器
    bevel = building.modifiers.new(name='Bevel', type='BEVEL')
    bevel.width = 0.2
    bevel.segments = 3
    bevel.limit_method = 'ANGLE'
    bevel.angle_limit = 0.523599
    
    return building
```

### 创建程序化地形

```python
def create_terrain(size=100, subdivisions=5):
    """创建程序化地形"""
    # 创建平面
    bpy.ops.mesh.primitive_plane_add(size=size)
    terrain = bpy.context.active_object
    terrain.name = 'ProceduralTerrain'
    
    # 细分平面
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.subdivide(number_cuts=subdivisions)
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 添加置换修饰器
    displace = terrain.modifiers.new(name='Displace', type='DISPLACE')
    
    # 创建程序化纹理
    tex = bpy.data.textures.new('TerrainNoise', type='CLOUDS')
    tex.noise_scale = 2.0
    tex.noise_depth = 2
    displace.texture = tex
    displace.strength = 5.0
    
    # 添加平滑修饰器
    smooth = terrain.modifiers.new(name='Smooth', type='SMOOTH')
    smooth.factor = 0.5
    smooth.iterations = 3
    
    # 添加权重法线修饰器
    weighted_normal = terrain.modifiers.new(name='WeightedNormal', type='WEIGHTED_NORMAL')
    weighted_normal.weight = 1.0
    
    return terrain
```

### 创建程序化晶格结构

```python
def create_lattice_structure(obj, repetitions=(3, 3, 3)):
    """创建晶格结构"""
    # 创建晶格
    bpy.ops.object.lattice_add()
    lattice = bpy.context.active_object
    lattice.name = 'LatticeStructure'
    
    # 设置晶格分辨率
    lattice.data.points_u = repetitions[0] * 2
    lattice.data.points_v = repetitions[1] * 2
    lattice.data.points_w = repetitions[2] * 2
    
    # 调整晶格大小
    lattice.scale = obj.scale
    
    # 清除目标物体
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    # 添加晶格修饰器
    lattice_mod = obj.modifiers.new(name='Lattice', type='LATTICE')
    lattice_mod.object = lattice
    
    return lattice
```

### 创建程序化瓦片阵列

```python
def create_tile_array(tile_obj, count=(10, 10), spacing=1.5):
    """创建瓦片阵列"""
    tiles = []
    
    for i in range(count[0]):
        for j in range(count[1]):
            # 复制瓦片
            bpy.ops.object.select_all(action='DESELECT')
            tile_obj.select_set(True)
            bpy.ops.object.duplicate()
            
            new_tile = bpy.context.active_object
            new_tile.name = f'Tile_{i}_{j}'
            
            # 定位
            x = (i - count[0] / 2) * spacing
            y = (j - count[1] / 2) * spacing
            new_tile.location = (x, y, 0)
            
            tiles.append(new_tile)
    
    # 选中所有瓦片
    bpy.ops.object.select_all(action='SELECT')
    
    # 添加阵列修饰器
    for tile in tiles:
        bpy.context.view_layer.objects.active = tile
        
        # X方向阵列
        array_x = tile.modifiers.new(name='ArrayX', type='ARRAY')
        array_x.count = 1
        array_x.use_relative_offset = False
        array_x.use_constant_offset = True
        array_x.constant_offset_displace = (spacing, 0, 0)
        
        # Y方向阵列
        array_y = tile.modifiers.new(name='ArrayY', type='ARRAY')
        array_y.count = 1
        array_y.use_relative_offset = False
        array_y.use_constant_offset = True
        array_y.constant_offset_displace = (0, spacing, 0)
    
    return tiles
```

### 创建程序化布尔运算

```python
def create_boolean_difference(base_obj, cutter_obj):
    """创建布尔减法运算"""
    # 选中基础物体
    bpy.ops.object.select_all(action='DESELECT')
    base_obj.select_set(True)
    bpy.context.view_layer.objects.active = base_obj
    
    # 添加布尔修饰器
    bool_mod = base_obj.modifiers.new(name='Boolean', type='BOOLEAN')
    bool_mod.operation = 'DIFFERENCE'
    bool_mod.object = cutter_obj
    
    return bool_mod

def create_boolean_union(objects):
    """创建布尔并集运算"""
    # 确保所有物体被选中
    bpy.ops.object.select_all(action='SELECT')
    
    # 以第一个物体为目标
    target = objects[0]
    bpy.context.view_layer.objects.active = target
    
    # 合并其他物体
    for obj in objects[1:]:
        # 添加布尔并集
        bool_mod = target.modifiers.new(name='BooleanUnion', type='BOOLEAN')
        bool_mod.operation = 'UNION'
        bool_mod.object = obj
    
    return target

def create_boolean_intersection(base_obj, intersect_obj):
    """创建布尔交集运算"""
    # 选中基础物体
    bpy.ops.object.select_all(action='DESELECT')
    base_obj.select_set(True)
    bpy.context.view_layer.objects.active = base_obj
    
    # 添加布尔修饰器
    bool_mod = base_obj.modifiers.new(name='Boolean', type='BOOLEAN')
    bool_mod.operation = 'INTERSECT'
    bool_mod.object = intersect_obj
    
    return bool_mod
```

## 使用场景

- **建模**：非破坏性修改网格几何体
- **程序化生成**：创建复杂的程序化模型
- **地形生成**：使用噪声和置换创建地形
- **建筑建模**：使用阵列和镜像创建建筑元素
- **特效制作**：使用布尔运算创建复杂形状
- **角色建模**：使用细分和倒角创建有机形状

## 注意事项

- 修饰器按顺序执行，后添加的修饰器影响前面的效果
- 高细分等级会影响性能
- 布尔运算需要物体有正确的法线方向
- 应用修饰器会永久修改网格
- 某些修饰器需要特定的网格结构才能正常工作
