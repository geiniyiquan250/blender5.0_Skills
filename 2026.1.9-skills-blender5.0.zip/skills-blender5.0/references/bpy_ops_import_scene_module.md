# bpy.ops.import_scene - Scene Import Operations Module

Blender 场景导入操作符，用于将各种格式的 3D 场景文件导入到 Blender 中。

## Overview

`bpy.ops.import_scene` 模块包含场景导入操作命令，支持多种 3D 格式的导入，包括 FBX、OBJ、3DS、GLTF 等常用格式。这个模块提供了灵活的导入参数配置。

## 核心功能

### 导入格式支持

```python
import bpy

# 导入 FBX 格式
bpy.ops.import_scene.fbx(
    filepath="C:/models/character.fbx",
    axis_forward='-Z',
    axis_up='Y',
    apply_unit_scale=True,
    apply_transform=True,
    use_custom_normals=True,
    use_animations=True,
    use_anim_action_all=True,
    batch_mode='OFF',
    use_subset_collection=False
)

# 导入 OBJ 格式
bpy.ops.import_scene.obj(
    filepath="C:/models/model.obj",
    axis_forward='-Z',
    axis_up='Y',
    use_edges=True,
    use_smooth_groups=True,
    use_split_objects=True,
    use_split_groups=True,
    use_groups_as_vgroups=False,
    use_image_search=True,
    split_mode='OFF'
)

# 导入 GLTF/GLB 格式
bpy.ops.import_scene.gltf(
    filepath="C:/models/scene.glb",
    export_format='GLB',
    import_pack_images=True,
    use_eps=False,
    legacy_import_vectors=False,
    export_copyright="",
    export_image_format='AUTO'
)
```

### FBX 导入选项

```python
def import_fbx(filepath, import_animations=True):
    """导入 FBX 文件"""
    bpy.ops.import_scene.fbx(
        filepath=filepath,
        axis_forward='-Z',
        axis_up='Y',
        apply_unit_scale=True,
        apply_transform=True,
        use_custom_normals=True,
        use_animations=import_animations,
        use_anim_action_all=True,
        batch_mode='OFF'
    )
    print(f"已导入: {filepath}")
    return bpy.context.selected_objects

def import_fbx_with_options(
    filepath,
    scale=1.0,
    import_anim=True,
    import_materials=True
):
    """带选项的 FBX 导入"""
    bpy.ops.import_scene.fbx(
        filepath=filepath,
        axis_forward='-Z',
        axis_up='Y',
        use_unit_scale=scale,
        use_custom_normals=True,
        use_animations=import_anim,
        use_anim_action_all=True,
        force_connect_children=False,
        automatic_bone_orientation=True
    )
    return bpy.context.selected_objects
```

### OBJ 导入选项

```python
def import_obj(filepath, split_by_material=True):
    """导入 OBJ 文件"""
    bpy.ops.import_scene.obj(
        filepath=filepath,
        axis_forward='-Z',
        axis_up='Y',
        use_edges=True,
        use_smooth_groups=True,
        use_split_objects=not split_by_material,
        use_split_groups=split_by_material,
        use_groups_as_vgroups=False,
        use_image_search=True,
        split_mode='OFF'
    )
    print(f"已导入 OBJ: {filepath}")
    return bpy.context.selected_objects

def import_obj_with_materials(filepath):
    """导入 OBJ 并处理材质"""
    bpy.ops.import_scene.obj(
        filepath=filepath,
        axis_forward='-Z',
        axis_up='Y',
        use_edges=True,
        use_smooth_groups=True,
        use_split_objects=True,
        use_groups_as_vgroups=False,
        use_image_search=True,
        createMaterials=True,
        mtl_path="",  # 自动查找同名 .mtl 文件
        split_mode='OFF'
    )
    return bpy.context.selected_objects
```

### GLTF 导入选项

```python
def import_gltf(filepath, pack_images=True):
    """导入 GLTF/GLB 文件"""
    bpy.ops.import_scene.gltf(
        filepath=filepath,
        import_pack_images=pack_images,
        export_format='GLB',
        # 其他选项使用默认值
    )
    print(f"已导入 GLTF: {filepath}")
    return bpy.context.selected_objects

def import_gltf_animations(filepath):
    """导入 GLTF 动画"""
    bpy.ops.import_scene.gltf(
        filepath=filepath,
        import_pack_images=True,
        export_format='GLB',
        export_animations=True,
        export_frame_range=True,
        export_nla_strips=True
    )
    return bpy.context.selected_objects
```

### 3DS 导入选项

```python
# 导入 3DS 格式
bpy.ops.import_scene.autodesk_3ds(
    filepath="C:/models/model.3ds",
    axis_forward='-Z',
    axis_up='Y',
    use_unit_scale=True,
    use_image_search=True,
    resolve_lib_collections=True
)

def import_3ds(filepath):
    """导入 3DS 文件"""
    bpy.ops.import_scene.autodesk_3ds(
        filepath=filepath,
        axis_forward='-Z',
        axis_up='Y',
        use_unit_scale=True,
        use_image_search=True
    )
    print(f"已导入 3DS: {filepath}")
    return bpy.context.selected_objects
```

### LWO 导入选项

```python
# 导入 LightWave 格式
bpy.ops.import_scene.lwo(
    filepath="C:/models/model.lwo",
    axis_forward='-Z',
    axis_up='Y',
    use_unit_scale=True,
    use_image_search=True
)

def import_lwo(filepath):
    """导入 LWO 文件"""
    bpy.ops.import_scene.lwo(
        filepath=filepath,
        axis_forward='-Z',
        axis_up='Y',
        use_unit_scale=True
    )
    return bpy.context.selected_objects
```

### X3D 导入选项

```python
# 导入 X3D 格式
bpy.ops.import_scene.x3d(
    filepath="C:/models/scene.x3d",
    axis_forward='-Z',
    axis_up='Y',
    use_unit_scale=True,
    use_triangulated_mesh=False,
    use_normals=True,
    use_compression=True
)

def import_x3d(filepath):
    """导入 X3D 文件"""
    bpy.ops.import_scene.x3d(
        filepath=filepath,
        axis_forward='-Z',
        axis_up='Y',
        use_unit_scale=True
    )
    return bpy.context.selected_objects
```

## 实际应用示例

### 批量导入管理器

```python
import bpy
import os
from pathlib import Path

class BatchImportManager:
    """批量导入管理器"""
    
    def __init__(self):
        self.imported_files = []
        self.failed_files = []
    
    def detect_format(self, filepath):
        """检测文件格式"""
        ext = Path(filepath).suffix.lower()
        format_map = {
            '.fbx': 'fbx',
            '.obj': 'obj',
            '.gltf': 'gltf',
            '.glb': 'gltf',
            '.3ds': '3ds',
            '.lwo': 'lwo',
            '.x3d': 'x3d',
            '.dae': 'collada'
        }
        return format_map.get(ext, 'unknown')
    
    def import_file(self, filepath, options=None):
        """导入单个文件"""
        if options is None:
            options = {}
        
        format_type = self.detect_format(filepath)
        
        try:
            if format_type == 'fbx':
                bpy.ops.import_scene.fbx(filepath=filepath, **options)
            elif format_type == 'obj':
                bpy.ops.import_scene.obj(filepath=filepath, **options)
            elif format_type == 'gltf':
                bpy.ops.import_scene.gltf(filepath=filepath, **options)
            elif format_type == '3ds':
                bpy.ops.import_scene.autodesk_3ds(filepath=filepath, **options)
            elif format_type == 'lwo':
                bpy.ops.import_scene.lwo(filepath=filepath, **options)
            elif format_type == 'x3d':
                bpy.ops.import_scene.x3d(filepath=filepath, **options)
            else:
                print(f"未知格式: {filepath}")
                self.failed_files.append(filepath)
                return None
            
            self.imported_files.append(filepath)
            return bpy.context.selected_objects
        except Exception as e:
            print(f"导入失败: {filepath} - {e}")
            self.failed_files.append(filepath)
            return None
    
    def import_directory(self, directory, extensions=None, recursive=True):
        """导入目录中的所有文件"""
        if extensions is None:
            extensions = ['.fbx', '.obj', '.gltf', '.glb']
        
        path = Path(directory)
        imported = []
        
        if recursive:
            files = path.rglob("*")
        else:
            files = path.glob("*")
        
        for file_path in files:
            if file_path.is_file() and file_path.suffix.lower() in extensions:
                result = self.import_file(str(file_path))
                if result:
                    imported.append(str(file_path))
        
        return imported
    
    def get_import_report(self):
        """获取导入报告"""
        return {
            'successful': len(self.imported_files),
            'failed': len(self.failed_files),
            'imported_files': self.imported_files.copy(),
            'failed_files': self.failed_files.copy()
        }


def batch_import_models(directory):
    """批量导入模型"""
    manager = BatchImportManager()
    
    print(f"开始导入目录: {directory}")
    imported = manager.import_directory(
        directory,
        extensions=['.fbx', '.obj', '.glb']
    )
    
    report = manager.get_import_report()
    print(f"\n导入完成:")
    print(f"  成功: {report['successful']} 个文件")
    print(f"  失败: {report['failed']} 个文件")
    
    return manager
```

### 导入场景设置器

```python
import bpy

class ImportSceneSetup:
    """导入场景设置器"""
    
    def setup_after_import(self, collection_name=None):
        """导入后的场景设置"""
        # 创建集合
        if collection_name:
            if collection_name not in bpy.data.collections:
                bpy.ops.object.collection_add(name=collection_name)
            collection = bpy.data.collections[collection_name]
        
        # 整理对象
        for obj in bpy.context.selected_objects:
            obj.select_set(True)
            
            # 重置变换
            obj.location = (0, 0, 0)
            obj.rotation_euler = (0, 0, 0)
            obj.scale = (1, 1, 1)
            
            # 添加到集合
            if collection_name:
                bpy.context.view_layer.active_layer_collection.collection.objects.link(obj)
                bpy.data.collections[collection_name].objects.unlink(obj)
        
        # 应用所有变换
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        
        # 设置渲染引擎
        bpy.context.scene.render.engine = 'CYCLES'
        
        # 设置渲染分辨率
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
        
        return bpy.context.selected_objects
    
    def import_with_setup(self, filepath, collection_name="Imported"):
        """导入并设置场景"""
        # 清除现有对象
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.delete()
        
        # 导入文件
        result = bpy.ops.import_scene.gltf(filepath=filepath)
        
        if 'FINISHED' in result:
            return self.setup_after_import(collection_name)
        
        return None
    
    def create_import_preset(self, name, settings):
        """创建导入预设"""
        preset = {
            'name': name,
            'settings': settings
        }
        return preset


def import_and_prepare_scene(filepath, collection_name="Imported"):
    """导入并准备场景"""
    setup = ImportSceneSetup()
    return setup.import_with_setup(filepath, collection_name)
```

### 材质和纹理处理

```python
import bpy
import os

class MaterialProcessor:
    """材质处理器"""
    
    def __init__(self):
        self.materials_created = 0
        self.textures_found = 0
    
    def find_textures_in_directory(self, directory, extensions=None):
        """查找目录中的纹理文件"""
        if extensions is None:
            extensions = ['.jpg', '.jpeg', '.png', '.tga', '.tif', '.tiff']
        
        textures = {}
        for root, dirs, files in os.walk(directory):
            for file in files:
                if any(file.lower().endswith(ext) for ext in extensions):
                    name = os.path.splitext(file)[0]
                    if name not in textures:
                        textures[name] = []
                    textures[name].append(os.path.join(root, file))
        
        self.textures_found = sum(len(paths) for paths in textures.values())
        return textures
    
    def apply_texture_to_material(self, material_name, texture_path):
        """将纹理应用到材质"""
        if material_name not in bpy.data.materials:
            return False
        
        mat = bpy.data.materials[material_name]
        mat.use_nodes = True
        
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        # 创建纹理节点
        tex_node = nodes.new(type='ShaderNodeTexImage')
        tex_node.location = (-300, 0)
        
        # 加载图像
        if os.path.exists(texture_path):
            image = bpy.data.images.load(texture_path)
            tex_node.image = image
        
        # 连接到原理化 BSDF
        principled = nodes.get('Principled BSDF')
        if principled:
            links.new(tex_node.outputs['Color'], principled.inputs['Base Color'])
        
        return True
    
    def create_material_from_texture(self, texture_path, material_name=None):
        """从纹理创建材质"""
        if material_name is None:
            material_name = os.path.splitext(os.path.basename(texture_path))[0]
        
        # 创建材质
        mat = bpy.data.materials.new(name=material_name)
        mat.use_nodes = True
        
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        # 获取原理化 BSDF
        principled = nodes.get('Principled BSDF')
        if not principled:
            principled = nodes.new(type='ShaderNodeBsdfPrincipled')
        
        # 创建纹理节点
        tex_node = nodes.new(type='ShaderNodeTexImage')
        tex_node.location = (-400, 0)
        
        if os.path.exists(texture_path):
            image = bpy.data.images.load(texture_path)
            tex_node.image = image
        
        # 连接节点
        links.new(tex_node.outputs['Color'], principled.inputs['Base Color'])
        
        self.materials_created += 1
        return mat
    
    def process_imported_materials(self, base_path):
        """处理导入的材质"""
        textures = self.find_textures_in_directory(base_path)
        materials = {}
        
        for name, paths in textures.items():
            if paths:
                mat = self.create_material_from_texture(paths[0], name)
                materials[name] = mat
        
        return materials


def setup_materials_for_imported_objects(base_path):
    """为导入的对象设置材质"""
    processor = MaterialProcessor()
    materials = processor.process_imported_materials(base_path)
    
    print(f"创建了 {processor.materials_created} 个材质")
    print(f"找到 {processor.textures_found} 个纹理")
    
    return materials
```
