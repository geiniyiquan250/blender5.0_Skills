# bpy.ops.export_scene - X3D导出操作模块

Blender X3D文件导出操作符，用于将场景导出为X3D格式。

## 概述

`bpy.ops.export_scene.x3d` 模块提供用于将Blender场景导出为X3D格式的功能，支持Web3D应用和交互式3D内容的创建。

## 核心功能

### 基础导出

```python
import bpy

# 导出X3D文件
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    filter_blender=False,
    filter_image=False,
    filter_movie=False,
    filter_python=False,
    filter_font=False,
    filter_sound=False,
    filter_text=False,
    filter_archive=False,
    export_selected=False,
    use_triangles=True,
    use_compression=True,
    use_normals=True,
    use_uv=True,
    use_mesh_modifiers=True,
    use_materials=True,
    use_textures=True,
    use_lights=True,
    use_cameras=True,
    use_yup=True,
    use_selection=False,
    export_defines=True,
    export_cameras=True,
    export_animations=True,
    export_lamps=True,
    export_face_materials=False,
    export_inlines=True,
    export_original_icosphere=True,
    export_lod=True,
    export_normals=True,
    export_ptc=True,
    export_normals_mode='FAST',
    export_color=True,
    export_embedded=True,
    export_blender_player=True,
    x3d_naming='BLENDER',
    export_appname=True,
    export_format='X3D',
    global_matrix=None,
    copy_textures=False,
    export_image_format='NAME',
    tesselated_normals=True
)
```

### 导出范围

```python
# 只导出选中对象
bpy.ops.export_scene.x3d(
    filepath='//selected.x3d',
    export_selected=True
)

# 导出所有对象
bpy.ops.export_scene.x3d(
    filepath='//all.x3d',
    export_selected=False
)
```

### 几何体导出

```python
# 三角化
bpy.ops.export_scene.x3d(
    filepath='//triangulated.x3d',
    use_triangles=True
)

# 不三角化
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    use_triangles=False
)

# 导出法线
bpy.ops.export_scene.x3d(
    filepath='//normals.x3d',
    use_normals=True
)

# 不导出法线
bpy.ops.export_scene.x3d(
    filepath='//no_normals.x3d',
    use_normals=False
)

# 导出UV
bpy.ops.export_scene.x3d(
    filepath='//uv.x3d',
    use_uv=True
)

# 不导出UV
bpy.ops.export_scene.x3d(
    filepath='//no_uv.x3d',
    use_uv=False
)
```

### 修改器设置

```python
# 应用网格修改器
bpy.ops.export_scene.x3d(
    filepath='//modifiers.x3d',
    use_mesh_modifiers=True
)

# 不应用修改器
bpy.ops.export_scene.x3d(
    filepath='//no_modifiers.x3d',
    use_mesh_modifiers=False
)
```

### 材质导出

```python
# 导出材质
bpy.ops.export_scene.x3d(
    filepath='//materials.x3d',
    use_materials=True
)

# 不导出材质
bpy.ops.export_scene.x3d(
    filepath='//no_materials.x3d',
    use_materials=False
)

# 导出纹理
bpy.ops.export_scene.x3d(
    filepath='//textures.x3d',
    use_textures=True
)

# 不导出纹理
bpy.ops.export_scene.x3d(
    filepath='//no_textures.x3d',
    use_textures=False
)

# 导出面材质
bpy.ops.export_scene.x3d(
    filepath='//face_mats.x3d',
    export_face_materials=True
)

# 导出颜色
bpy.ops.export_scene.x3d(
    filepath='//color.x3d',
    export_color=True
)
```

### 相机和灯光

```python
# 导出相机
bpy.ops.export_scene.x3d(
    filepath='//cameras.x3d',
    use_cameras=True
)

# 不导出相机
bpy.ops.export_scene.x3d(
    filepath='//no_cameras.x3d',
    use_cameras=False
)

# 导出灯光
bpy.ops.export_scene.x3d(
    filepath='//lamps.x3d',
    export_lamps=True
)

# 不导出灯光
bpy.ops.export_scene.x3d(
    filepath='//no_lamps.x3d',
    export_lamps=False
)

# 使用灯光
bpy.ops.export_scene.x3d(
    filepath='//lights.x3d',
    use_lights=True
)
```

### 动画导出

```python
# 导出动画
bpy.ops.export_scene.x3d(
    filepath='//anim.x3d',
    export_animations=True
)

# 不导出动画
bpy.ops.export_scene.x3d(
    filepath='//static.x3d',
    export_animations=False
)
```

### 坐标轴设置

```python
# Y轴向上
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    use_yup=True
)

# Z轴向上
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    use_yup=False
)
```

### 压缩设置

```python
# 使用压缩
bpy.ops.export_scene.x3d(
    filepath='//compressed.x3d',
    use_compression=True
)

# 不使用压缩
bpy.ops.export_scene.x3d(
    filepath='//uncompressed.x3d',
    use_compression=False
)
```

### 内联设置

```python
# 导出内联
bpy.ops.export_scene.x3d(
    filepath='//inlines.x3d',
    export_inlines=True
)

# 不导出内联
bpy.ops.export_scene.x3d(
    filepath='//no_inlines.x3d',
    export_inlines=False
)
```

### LOD设置

```python
# 导出LOD
bpy.ops.export_scene.x3d(
    filepath='//lod.x3d',
    export_lod=True
)

# 不导出LOD
bpy.ops.export_scene.x3d(
    filepath='//no_lod.x3d',
    export_lod=False
)
```

### 命名设置

```python
# Blender命名
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    x3d_naming='BLENDER'
)

# X3D原生命名
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    x3d_naming='X3D'
)
```

### 导出格式

```python
# X3D格式
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    export_format='X3D'
)

# VRML格式
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    export_format='VRML97'
)
```

### 应用程序名称

```python
# 导出应用程序名
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    export_appname=True
)

# 不导出应用程序名
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    export_appname=False
)
```

### 嵌入设置

```python
# 嵌入纹理
bpy.ops.export_scene.x3d(
    filepath='//embedded.x3d',
    export_embedded=True
)

# 不嵌入纹理
bpy.ops.export_scene.x3d(
    filepath='//no_embedded.x3d',
    export_embedded=False
)

# 复制纹理
bpy.ops.export_scene.x3d(
    filepath='//copied.x3d',
    copy_textures=True
)
```

### 法线模式

```python
# 快速法线
bpy.ops.export_scene.x3d(
    filepath='//fast.x3d',
    export_normals_mode='FAST'
)

# 精确法线
bpy.ops.export_scene.x3d(
    filepath='//exact.x3d',
    export_normals_mode='EXACT'
)

# 细分法线
bpy.ops.export_scene.x3d(
    filepath='//tessellated.x3d',
    tesselated_normals=True
)
```

### 点云设置

```python
# 导出点云
bpy.ops.export_scene.x3d(
    filepath='//pointcloud.x3d',
    export_ptc=True
)

# 不导出点云
bpy.ops.export_scene.x3d(
    filepath='//no_ptc.x3d',
    export_ptc=False
)
```

### 球体设置

```python
# 使用原始二十面体
bpy.ops.export_scene.x3d(
    filepath='//icosphere.x3d',
    export_original_icosphere=True
)

# 不使用原始二十面体
bpy.ops.export_scene.x3d(
    filepath='//no_icosphere.x3d',
    export_original_icosphere=False
)
```

### Blender播放器

```python
# 导出Blender播放器
bpy.ops.export_scene.x3d(
    filepath='//blender_player.x3d',
    export_blender_player=True
)

# 不导出Blender播放器
bpy.ops.export_scene.x3d(
    filepath='//no_player.x3d',
    export_blender_player=False
)
```

## 实用函数

```python
def export_x3d_model(filepath, apply_modifiers=True):
    """导出X3D模型"""
    bpy.ops.export_scene.x3d(
        filepath=filepath,
        export_selected=True,
        use_triangles=True,
        use_normals=True,
        use_uv=True,
        use_mesh_modifiers=apply_modifiers,
        use_materials=True,
        use_textures=True,
        use_lights=True,
        use_cameras=True,
        export_animations=False
    )

def export_x3d_web_model(filepath):
    """导出X3D Web模型"""
    bpy.ops.export_scene.x3d(
        filepath=filepath,
        export_selected=True,
        use_triangles=True,
        use_normals=True,
        use_uv=True,
        use_mesh_modifiers=True,
        use_materials=True,
        use_textures=True,
        use_lights=True,
        use_cameras=True,
        export_animations=True,
        use_compression=True,
        export_embedded=True
    )

def export_x3d_for_vrml_viewer(filepath):
    """导出X3D用于VRML查看器"""
    bpy.ops.export_scene.x3d(
        filepath=filepath,
        export_selected=True,
        use_triangles=True,
        use_normals=True,
        use_uv=True,
        use_mesh_modifiers=True,
        use_materials=True,
        use_textures=True,
        use_lights=True,
        use_cameras=True,
        export_animations=True,
        export_format='VRML97'
    )

def export_x3d_compressed(filepath):
    """导出压缩X3D"""
    bpy.ops.export_scene.x3d(
        filepath=filepath,
        export_selected=True,
        use_triangles=True,
        use_normals=True,
        use_uv=True,
        use_mesh_modifiers=True,
        use_materials=True,
        use_textures=True,
        use_compression=True,
        export_embedded=True
    )

def export_x3d_with_animation(filepath):
    """导出X3D带动画"""
    bpy.ops.export_scene.x3d(
        filepath=filepath,
        export_selected=True,
        use_triangles=True,
        use_normals=True,
        use_uv=True,
        use_mesh_modifiers=True,
        use_materials=True,
        use_textures=True,
        use_lights=True,
        use_cameras=True,
        export_animations=True,
        use_yup=True
    )

def batch_export_x3d_by_collection(output_dir):
    """按集合批量导出X3D"""
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for collection in bpy.data.collections:
        bpy.ops.object.select_all(action='DESELECT')
        
        for obj in collection.objects:
            obj.select_set(True)
        
        if bpy.context.selected_objects:
            bpy.context.view_layer.active_layer_collection = bpy.context.layer_collection.children[collection.name]
            filepath = os.path.join(output_dir, f'{collection.name}.x3d')
            bpy.ops.export_scene.x3d(
                filepath=filepath,
                export_selected=True,
                use_triangles=True,
                use_normals=True,
                use_uv=True,
                use_mesh_modifiers=True,
                use_materials=True
            )
```

## 常见问题排查

### 导出文件无法打开
```python
# 检查文件路径
filepath = '//model.x3d'
print(f"文件存在: {bpy.path.exists(filepath)}")

# 检查文件大小
import os
file_size = os.path.getsize(bpy.path.abspath(filepath))
print(f"文件大小: {file_size} 字节")

# 尝试不同的导出格式
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    export_format='X3D'
)

bpy.ops.export_scene.x3d(
    filepath='//model.wrl',
    export_format='VRML97'
)
```

### 材质丢失
```python
# 检查材质
obj = bpy.context.active_object
print(f"材质数: {len(obj.data.materials) if obj.data else 0}")

# 确保导出材质和纹理
bpy.ops.export_scene.x3d(
    filepath='//mat.x3d',
    export_selected=True,
    use_materials=True,
    use_textures=True
)

# 检查纹理路径
print(f"纹理目录: {bpy.path.abspath('//textures/')}")

# 嵌入纹理
bpy.ops.export_scene.x3d(
    filepath='//embedded.x3d',
    export_selected=True,
    use_materials=True,
    use_textures=True,
    export_embedded=True
)
```

### 动画丢失
```python
# 检查动画数据
obj = bpy.context.active_object
print(f"动画数据: {obj.animation_data}")

if obj.animation_data:
    print(f"动作: {obj.animation_data.action}")

# 确保导出动画
bpy.ops.export_scene.x3d(
    filepath='//anim.x3d',
    export_selected=True,
    export_animations=True
)

# 检查骨骼动画
if obj.type == 'ARMATURE':
    print(f"骨骼数: {len(obj.data.bones)}")
```

### 坐标轴问题
```python
# 检查轴向
print(f"Y轴向上: {bpy.context.scene.unit_settings.system}")

# 尝试不同轴向
bpy.ops.export_scene.x3d(
    filepath='//yup.x3d',
    use_yup=True
)

bpy.ops.export_scene.x3d(
    filepath='//zup.x3d',
    use_yup=False
)

# 在X3D查看器中检查方向
```

### 性能问题
```python
# 检查对象数
print(f"对象数: {len(bpy.context.selected_objects)}")

# 减少导出内容
bpy.ops.export_scene.x3d(
    filepath='//optimized.x3d',
    export_selected=True,
    use_triangles=True,
    use_normals=True,
    use_uv=True,
    use_mesh_modifiers=True,
    use_materials=True,
    use_textures=False,
    use_lights=False,
    use_cameras=False,
    export_animations=False
)

# 使用压缩
bpy.ops.export_scene.x3d(
    filepath='//compressed.x3d',
    export_selected=True,
    use_compression=True,
    export_embedded=True
)
```

### 纹理路径问题
```python
# 检查路径模式
print(f"路径模式: {bpy.context.scene.x3d_export_path_mode}")

# 使用相对路径
bpy.ops.export_scene.x3d(
    filepath='//model.x3d',
    copy_textures=True
)

# 嵌入纹理
bpy.ops.export_scene.x3d(
    filepath='//embedded.x3d',
    export_embedded=True
)

# 检查纹理引用
# 在X3D文件中检查纹理路径是否正确
```

### 法线问题
```python
# 检查法线导出模式
print(f"法线模式: {bpy.context.scene.x3d_export_normals_mode}")

# 使用快速法线
bpy.ops.export_scene.x3d(
    filepath='//fast.x3d',
    export_normals_mode='FAST'
)

# 使用精确法线
bpy.ops.export_scene.x3d(
    filepath='//exact.x3d',
    export_normals_mode='EXACT'
)

# 细分法线
bpy.ops.export_scene.x3d(
    filepath='//tessellated.x3d',
    tesselated_normals=True
)
```
