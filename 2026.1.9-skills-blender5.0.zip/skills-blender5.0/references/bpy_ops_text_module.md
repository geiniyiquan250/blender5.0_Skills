# bpy.ops.text - Text Operations Module

Blender 文本操作符，用于在文本编辑器中创建、编辑和管理文本数据块。

## Overview

`bpy.ops.text` 模块包含文本编辑器中的所有操作命令，涵盖文本的创建、编辑、选择、查找替换等核心功能。这个模块主要用于处理 Blender 的文本数据块和脚本文件。

## 核心功能

### 文本选择操作

```python
import bpy

# 全选
bpy.ops.text.select_all(select='SELECT')

# 全不选
bpy.ops.text.select_all(select='DESELECT')

# 反选
bpy.ops.text.select_all(select='INVERT')

# 选择行
bpy.ops.text.select_line()

# 移动光标到文件开头
bpy.ops.text.move(btype='LINE_BEGIN', select=False)

# 移动光标到文件末尾
bpy.ops.text.move(btype='LINE_END', select=False)

# 向上移动
bpy.ops.text.move(btype='PREVIOUS_LINE', select=False)

# 向下移动
bpy.ops.text.move(btype='NEXT_LINE', select=False)

# 移动到上一个字符
bpy.ops.text.move(btype='PREVIOUS_CHARACTER', select=False)

# 移动到下一个字符
bpy.ops.text.move(btype='NEXT_CHARACTER', select=False)

# 移动到上一个单词
bpy.ops.text.move(btype='PREVIOUS_WORD', select=False)

# 移动到下一个单词
bpy.ops.text.move(btype='NEXT_WORD', select=False)

# 跳转到指定行
bpy.ops.text.jump(line_number=10)

# 滚动到光标位置
bpy.ops.text.scroll(lines=-5)

def select_all_text():
    """全选文本"""
    text = bpy.context.space_data.text
    if text:
        bpy.ops.text.select_all(select='SELECT')
        return text.as_string()
    return ""

def select_current_line():
    """选择当前行"""
    bpy.ops.text.select_line()
    text = bpy.context.space_data.text
    if text and text.current_line:
        return text.current_line.body
    return ""

def go_to_line(line_num):
    """跳转到指定行"""
    text = bpy.context.space_data.text
    if text and 1 <= line_num <= len(text.lines):
        bpy.ops.text.jump(line_number=line_num)
        return True
    return False
```

### 文本编辑操作

```python
# 剪切选中文本
bpy.ops.text.cut()

# 复制选中文本
bpy.ops.text.copy()

# 粘贴文本
bpy.ops.text.paste()

# 删除选中文本
bpy.ops.text.delete(type='DELETE')

# 删除前一个字符
bpy.ops.text.delete(type='PREVIOUS_CHARACTER')

# 删除到行末
bpy.ops.text.delete(type='NEXT_CHARACTER')

# 插入新行
bpy.ops.text.insert()

# 缩进
bpy.ops.text.indent()

# 取消缩进
bpy.ops.text.unindent()

# 注释
bpy.ops.text.comment()

# 取消注释
bpy.ops.text.uncomment()

# 转换为大写
bpy.ops.text.case(case='UPPER')

# 转换为小写
bpy.ops.text.case(case='LOWER')

# 首字母大写
bpy.ops.text.case(case='TITLE')

# 反转大小写
bpy.ops.text.case(case='SWAP')

def insert_text(text_obj, content):
    """在光标位置插入文本"""
    bpy.context.space_data.text = text_obj
    bpy.ops.text.insert(text=content)

def delete_selection():
    """删除选中的文本"""
    bpy.ops.text.delete(type='DELETE')

def comment_lines(line_start, line_end):
    """注释指定范围的行"""
    bpy.ops.text.select_line()
    # 注意：实际实现需要更复杂的逻辑
    bpy.ops.text.comment()
```

### 文本查找替换

```python
# 查找文本
bpy.ops.text.find(find_text="def ", flags=REGEX=False, wrap=True)

# 查找并替换
bpy.ops.text.find_replace(find_text="old_text", replace_text="new_text", 
                          flags=REGEX, all=True)

# 清除查找高亮
bpy.ops.text.find_set_cursor(flag=False)

def find_all_occurrences(text_obj, search_text):
    """查找所有匹配项"""
    bpy.context.space_data.text = text_obj
    results = []
    for i, line in enumerate(text_obj.lines):
        if search_text in line.body:
            results.append({
                'line_number': i + 1,
                'content': line.body
            })
    return results

def replace_all(text_obj, old_text, new_text):
    """替换所有匹配项"""
    bpy.context.space_data.text = text_obj
    bpy.ops.text.find_replace(
        find_text=old_text,
        replace_text=new_text,
        flags=REGEX,
        all=True
    )
```

### 文本运行操作

```python
# 运行脚本
bpy.ops.text.run_script()

# 运行选中的脚本
bpy.ops.text.run_script()

# 检查语法
bpy.ops.text.check_globals()

# 自动格式化
bpy.ops.text.auto_indent(action='INSERT', type='SPACE')

def execute_script():
    """执行当前文本块中的脚本"""
    text = bpy.context.space_data.text
    if text:
        bpy.ops.text.run_script()

def execute_selection():
    """执行选中的代码"""
    bpy.ops.text.copy()
    # 执行复制的代码
    exec(bpy.context.window_manager.clipboard)
```

### 文本块操作

```python
# 新建文本块
bpy.ops.text.new(filepath="")

# 打开文本文件
bpy.ops.text.open(filepath="C:/path/to/script.py")

# 保存文本块
bpy.ops.text.save()

# 另存为
bpy.ops.text.save_as(filepath="C:/path/to/save_as.py")

# 重新加载
bpy.ops.text.reload()

# 拆分文本块
bpy.ops.text.split()

# 合并文本块
bpy.ops.text.merge()

def create_new_script(name, content=""):
    """创建新的脚本文件"""
    bpy.ops.text.new(filepath="")
    text = bpy.context.space_data.text
    text.name = name
    if content:
        bpy.ops.text.insert(text=content)
    return text

def save_script(text_obj, filepath):
    """保存脚本到文件"""
    bpy.context.space_data.text = text_obj
    bpy.ops.text.save_as(filepath=filepath)

def load_script(filepath):
    """加载脚本文件"""
    bpy.ops.text.open(filepath=filepath)
    return bpy.context.space_data.text
```

## 实际应用示例

### 脚本管理器

```python
import bpy
import os

class ScriptManager:
    """脚本管理器"""
    
    def __init__(self):
        self.script_dir = bpy.app.tempdir
    
    def create_script(self, name, code):
        """创建脚本"""
        bpy.ops.text.new(filepath="")
        text = bpy.context.space_data.text
        text.name = name
        bpy.ops.text.insert(text=code)
        return text
    
    def load_script(self, filepath):
        """加载脚本"""
        if os.path.exists(filepath):
            bpy.ops.text.open(filepath=filepath)
            return bpy.context.space_data.text
        return None
    
    def save_script(self, text, filepath=None):
        """保存脚本"""
        bpy.context.space_data.text = text
        if filepath:
            bpy.ops.text.save_as(filepath=filepath)
        else:
            bpy.ops.text.save()
    
    def run_script(self, text):
        """运行脚本"""
        bpy.context.space_data.text = text
        bpy.ops.text.run_script()
    
    def list_scripts(self):
        """列出所有文本块"""
        return [text.name for text in bpy.data.texts]
    
    def delete_script(self, name):
        """删除脚本"""
        if name in bpy.data.texts:
            bpy.data.texts.remove(bpy.data.texts[name])
    
    def duplicate_script(self, name, new_name):
        """复制脚本"""
        if name in bpy.data.texts:
            old_text = bpy.data.texts[name]
            bpy.ops.text.new(filepath="")
            new_text = bpy.context.space_data.text
            new_text.name = new_name
            new_text.write(old_text.as_string())
            return new_text
        return None


def create_script_library():
    """创建脚本库"""
    manager = ScriptManager()
    
    # 创建常用脚本
    manager.create_script("utils.py", '''
def hello_world():
    print("Hello, World!")

def calculate_area(width, height):
    return width * height
''')
    
    manager.create_script("setup_scene.py", '''
import bpy

def setup_basic_scene():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete()
    
    # 创建相机
    bpy.ops.object.camera_add(location=(0, -10, 5))
    camera = bpy.context.active_object
    camera.rotation_euler = (1.2, 0, 0)
    bpy.context.scene.camera = camera
    
    # 创建光源
    bpy.ops.object.light_add(location=(5, -5, 10))
    light = bpy.context.active_object
    light.data.energy = 1000
    
    return camera, light
''')
    
    print("脚本库创建完成")
    print(f"脚本列表: {manager.list_scripts()}")
    return manager
```

### 代码片段库

```python
import bpy

class CodeSnippetLibrary:
    """代码片段库"""
    
    snippets = {
        "create_cube": '''
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0))
cube = bpy.context.active_object
cube.name = "MyCube"
''',
        "create_sphere": '''
bpy.ops.mesh.primitive_uv_sphere_add(radius=1, location=(0, 0, 0))
sphere = bpy.context.active_object
sphere.name = "MySphere"
''',
        "create_material": '''
mat = bpy.data.materials.new(name="NewMaterial")
mat.use_nodes = True
obj.active_material = mat
''',
        "add_driver": '''
def add_driver(source, prop, target, path):
    driver = source.driver_add(prop)
    var = driver.variables.new()
    var.targets[0].id = target
    var.targets[0].data_path = path
    driver.modifiers[0].mode = 'Averaged'
'''
    }
    
    def __init__(self, library_name="Snippets"):
        self.library_name = library_name
        self._ensure_library()
    
    def _ensure_library(self):
        """确保库存在"""
        if self.library_name not in bpy.data.texts:
            bpy.ops.text.new(filepath="")
            text = bpy.context.space_data.text
            text.name = self.library_name
    
    def add_snippet(self, name, code):
        """添加代码片段"""
        self.snippets[name] = code
        text = bpy.data.texts[self.library_name]
        text.write(f"\n# {name}\n{code}\n")
    
    def insert_snippet(self, name):
        """插入代码片段"""
        if name in self.snippets:
            bpy.ops.text.insert(text=self.snippets[name])
            return True
        return False
    
    def get_snippet(self, name):
        """获取代码片段"""
        return self.snippets.get(name, "")
    
    def list_snippets(self):
        """列出所有代码片段"""
        return list(self.snippets.keys())
    
    def load_snippets_from_text(self, text_name):
        """从文本块加载代码片段"""
        if text_name in bpy.data.texts:
            text = bpy.data.texts[text_name]
            content = text.as_string()
            # 解析代码片段（假设格式为 # snippet_name\ncode）
            lines = content.split('\n')
            current_name = None
            current_code = []
            
            for line in lines:
                if line.startswith('# '):
                    if current_name and current_code:
                        self.snippets[current_name] = '\n'.join(current_code)
                    current_name = line[2:].strip()
                    current_code = []
                elif current_name:
                    current_code.append(line)
            
            if current_name and current_code:
                self.snippets[current_name] = '\n'.join(current_code)
    
    def save_snippets_to_text(self, text_name):
        """保存代码片段到文本块"""
        if text_name not in bpy.data.texts:
            bpy.ops.text.new(filepath="")
            text = bpy.context.space_data.text
            text.name = text_name
        else:
            bpy.context.space_data.text = bpy.data.texts[text_name]
            bpy.ops.text.select_all(select='SELECT')
            bpy.ops.text.delete(type='DELETE')
        
        for name, code in self.snippets.items():
            bpy.ops.text.insert(text=f"# {name}\n{code}\n")


def setup_snippet_library():
    """设置代码片段库"""
    library = CodeSnippetLibrary("CodeSnippets")
    
    print("代码片段库已创建")
    print(f"可用片段: {library.list_snippets()}")
    
    return library
```
