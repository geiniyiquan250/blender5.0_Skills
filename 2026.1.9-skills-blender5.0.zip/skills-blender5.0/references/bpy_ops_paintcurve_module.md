# bpy.ops.paintcurve - 绘制曲线操作模块

Blender绘制曲线操作符，用于管理绘画曲线预设和工作流程。

## 概述

`bpy.ops.paintcurve` 模块提供用于创建、编辑和应用绘制曲线预设的功能。绘制曲线用于控制绘画工具的笔触特性，如笔刷大小、不透明度等。

## 核心功能

### 曲线选择操作

```python
import bpy

# 全选绘制曲线
bpy.ops.paintcurve.select_all(action='SELECT')

# 全不选
bpy.ops.paintcurve.select_all(action='DESELECT')

# 反选
bpy.ops.paintcurve.select_all(action='INVERT')

# 选择激活的绘制曲线
bpy.ops.paintcurve.select_active()

# 根据名称选择
bpy.ops.paintcurve.select_by_name(name='curve_name')

# 选择相似的绘制曲线
bpy.ops.paintcurve.select_similar(type='CURVE')
```

### 绘制曲线创建

```python
# 创建新的绘制曲线
bpy.ops.paintcurve.new(name='New Paint Curve')

# 从曲线创建
bpy.ops.paintcurve.duplicate()

# 复制绘制曲线
bpy.ops.paintcurve.copy()

# 粘贴绘制曲线
bpy.ops.paintcurve.paste()

# 从默认曲线创建
bpy.ops.paintcurve.reset_to_default()

# 创建对称曲线
bpy.ops.paintcurve.symmetrize()
```

### 绘制曲线编辑

```python
# 删除绘制曲线
bpy.ops.paintcurve.delete()

# 重命名绘制曲线
bpy.ops.paintcurve.rename(name='new_name')

# 编辑绘制曲线
bpy.ops.paintcurve.edit()

# 应用绘制曲线
bpy.ops.paintcurve.apply()

# 重置绘制曲线
bpy.ops.paintcurve.reset()

# 反转曲线
bpy.ops.paintcurve.invert()

# 翻转曲线
bpy.ops.paintcurve.flip()

# 平滑曲线
bpy.ops.paintcurve.smooth(iterations=5)

# 简化曲线点
bpy.ops.paintcurve.simplify(threshold=0.01)
```

### 曲线点操作

```python
# 添加曲线点
bpy.ops.paintcurve.add_point(x=0.5, y=0.5)

# 删除曲线点
bpy.ops.paintcurve.delete_point()

# 选择曲线点
bpy.ops.paintcurve.select_point(index=0)

# 移动曲线点
bpy.ops.paintcurve.move_point(index=0, x=0.6, y=0.6)

# 设置曲线点句柄
bpy.ops.paintcurve.set_handle(index=0, handle_type='AUTO')

# 设置切线
bpy.ops.paintcurve.set_tangent(index=0, angle=45.0)
```

### 曲线变换

```python
# 移动曲线
bpy.ops.paintcurve.translate(x=0.1, y=0.1)

# 缩放曲线
bpy.ops.paintcurve.scale(factor=1.5)

# 旋转曲线
bpy.ops.paintcurve.rotate(angle=45.0))

# 曲线重采样
bpy.ops.paintcurve.resample(number_points=10))

# 曲线插值
bpy.ops.paintcurve.interpolate(type='BEZIER')
```

### 绘制曲线类型

```python
# 设置为线性曲线
bpy.ops.paintcurve.set_type(type='LINEAR')

# 设置为贝塞尔曲线
bpy.ops.paintcurve.set_type(type='BEZIER')

# 设置为自定义曲线
bpy.ops.paintcurve.set_type(type='CUSTOM')

# 设置插值模式
bpy.ops.paintcurve.set_interpolation(mode='LINEAR')

# 设置平滑模式
bpy.ops.paintcurve.set_smoothing(mode='CARDINAL')
```

### 导出导入

```python
# 导出绘制曲线
bpy.ops.paintcurve.export(filepath='//paintcurve.json')

# 导入绘制曲线
bpy.ops.paintcurve.import_(filepath='//paintcurve.json')

# 导出所有曲线
bpy.ops.paintcurve.export_all(filepath='//all_curves.json')

# 批量导入
bpy.ops.paintcurve.import_batch(filepaths=['//curve1.json', '//curve2.json'])
```

### 预设管理

```python
# 应用预设
bpy.ops.paintcurve.preset_apply(preset='Soft Brush')

# 保存为预设
bpy.ops.paintcurve.preset_save(name='My Preset')

# 删除预设
bpy.ops.paintcurve.preset_delete(name='My Preset')

# 重置预设
bpy.ops.paintcurve.preset_reset()

# 列出所有预设
bpy.ops.paintcurve.preset_list()
```

### 绘制曲线应用

```python
# 应用到当前笔刷
bpy.ops.paintcurve.apply_to_brush()

# 应用到所有笔刷
bpy.ops.paintcurve.apply_to_all_brushes()

# 从笔刷读取
bpy.ops.paintcurve.read_from_brush()

# 设置笔刷曲线
bpy.ops.paintcurve.set_brush_curve(curve_name='curve_name')

# 清除笔刷曲线
bpy.ops.paintcurve.clear_brush_curve()
```

## 实用函数

```python
def get_all_paint_curves():
    """获取所有绘制曲线"""
    return list(bpy.data.paint_curves)

def get_paint_curve_by_name(name):
    """根据名称获取绘制曲线"""
    return bpy.data.paint_curves.get(name)

def get_active_paint_curve():
    """获取当前激活的绘制曲线"""
    return bpy.context.paint_curve

def save_curve_to_file(curve, filepath):
    """保存曲线到文件"""
    bpy.ops.paintcurve.select_all(action='DESELECT')
    curve.select = True
    bpy.context.paint_curve = curve
    bpy.ops.paintcurve.export(filepath=filepath)

def load_curve_from_file(filepath):
    """从文件加载曲线"""
    bpy.ops.paintcurve.import_(filepath=filepath)
    return bpy.context.paint_curve

def copy_curve_settings(source, target):
    """复制曲线设置"""
    target.data = source.data.copy()
    target.name = target.name or source.name

def create_brush_curve(brush_name, curve_type='SOFT'):
    """为笔刷创建预设曲线"""
    brush = bpy.data.brushes.get(brush_name)
    if not brush:
        return None
    
    if curve_type == 'SOFT':
        points = [(0.0, 0.0), (0.2, 0.1), (0.5, 0.5), (0.8, 0.9), (1.0, 1.0)]
    elif curve_type == 'HARD':
        points = [(0.0, 0.0), (0.0, 1.0), (1.0, 1.0)]
    else:
        points = [(0.0, 0.0), (0.5, 0.5), (1.0, 1.0)]
    
    curve = bpy.data.paint_curves.new(name=f"{brush_name}_Curve")
    curve.data = points
    return curve

def batch_apply_curve_to_brushes(curve, brush_names):
    """批量应用曲线到多个笔刷"""
    for brush_name in brush_names:
        brush = bpy.data.brushes.get(brush_name)
        if brush:
            bpy.ops.paintcurve.select_all(action='DESELECT')
            curve.select = True
            bpy.context.paint_curve = curve
            bpy.ops.paintcurve.apply_to_brush()

def compare_curves(curve1, curve2):
    """比较两条曲线是否相同"""
    if len(curve1.data) != len(curve2.data):
        return False
    return all(abs(p1 - p2) < 0.001 
               for p1, p2 in zip(curve1.data, curve2.data))
```

## 常见问题排查

### 曲线不生效
```python
# 检查曲线是否激活
print(f"当前曲线: {bpy.context.paint_curve}")

# 检查笔刷设置
brush = bpy.context.brush
print(f"笔刷曲线: {brush.curve}")

# 重新应用曲线
bpy.ops.paintcurve.apply_to_brush()

# 检查曲线类型
print(f"曲线类型: {bpy.context.paint_curve.type}")
```

### 曲线点编辑问题
```python
# 确保在编辑模式
print(f"当前模式: {bpy.context.paint_curve_editor}")

# 重置曲线
bpy.ops.paintcurve.reset()

# 重新创建
bpy.ops.paintcurve.new(name='Reset Curve')

# 手动设置点
curve = bpy.context.paint_curve
curve.data = [(0.0, 0.0), (0.5, 0.5), (1.0, 1.0)]
```

### 导出导入问题
```python
# 检查文件路径
import os
print(f"文件存在: {os.path.exists('//paintcurve.json')}")

# 尝试不同的导出格式
bpy.ops.paintcurve.export(filepath='//paintcurve.json', format='JSON')

# 检查数据完整性
curve = bpy.context.paint_curve
print(f"曲线点数: {len(curve.data)}")
print(f"曲线类型: {curve.type}")
```
