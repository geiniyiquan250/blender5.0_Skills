# bpy_extras.mesh_utils - 网格工具模块

bpy_extras.mesh_utils模块提供了网格数据操作、几何分析和网格转换的实用工具函数。

## 概述

网格工具模块封装了常见的网格处理任务，包括顶点查找、边面操作、网格分析和几何变换等。适用于开发网格处理工具和几何分析插件。

## 核心功能

### 顶点操作

```python
import bpy
import bmesh
from mathutils import Vector
from bpy_extras.mesh_utils import (
    mesh_linked_tri_lookup,
    edge_face_count
)

def get_vertex_neighbors(mesh, vert_index):
    """获取顶点的相邻顶点"""
    vert = mesh.vertices[vert_index]
    neighbors = []
    for edge in vert.link_edges:
        for v in edge.verts:
            if v.index != vert_index:
                neighbors.append(v.index)
    return list(set(neighbors))

def get_vertex_faces(mesh, vert_index):
    """获取顶点的关联面"""
    vert = mesh.vertices[vert_index]
    faces = []
    for loop in vert.link_loops:
        faces.append(loop.face.index)
    return list(set(faces))

def find_vertex_by_co(mesh, co, tolerance=0.001):
    """通过坐标查找顶点"""
    for vert in mesh.vertices:
        if (vert.co - co).length < tolerance:
            return vert
    return None

def find_vertices_in_sphere(mesh, center, radius):
    """查找球体内的顶点"""
    vertices = []
    for vert in mesh.vertices:
        if (vert.co - center).length <= radius:
            vertices.append(vert)
    return vertices

def sort_vertices_by_distance(mesh, center):
    """按距离排序顶点"""
    verts = [(v, (v.co - center).length) for v in mesh.vertices]
    return [v for v, d in sorted(verts, key=lambda x: x[1])]
```

### 边操作

```python
def get_edge_vertices(mesh, edge_index):
    """获取边的两个顶点"""
    edge = mesh.edges[edge_index]
    return edge.vertices[0], edge.vertices[1]

def get_edge_length(mesh, edge_index):
    """获取边长度"""
    v1, v2 = get_edge_vertices(mesh, edge_index)
    return (mesh.vertices[v1].co - mesh.vertices[v2].co).length

def get_edge_faces(mesh, edge_index):
    """获取边关联的面"""
    edge = mesh.edges[edge_index]
    faces = []
    for poly in mesh.polygons:
        if edge_index in [e for e in poly.edge_keys]:
            faces.append(poly.index)
    return faces

def find_short_edges(mesh, threshold):
    """查找短边"""
    short_edges = []
    for i, edge in enumerate(mesh.edges):
        if get_edge_length(mesh, i) < threshold:
            short_edges.append(i)
    return short_edges

def find_long_edges(mesh, threshold):
    """查找长边"""
    long_edges = []
    for i, edge in enumerate(mesh.edges):
        if get_edge_length(mesh, i) > threshold:
            long_edges.append(i)
    return long_edges
```

### 面操作

```python
def get_face_vertices(mesh, face_index):
    """获取面的顶点索引"""
    face = mesh.polygons[face_index]
    return list(face.vertices)

def get_face_edges(mesh, face_index):
    """获取面的边索引"""
    face = mesh.polygons[face_index]
    return list(face.edge_indices)

def get_face_center(mesh, face_index):
    """获取面中心"""
    verts = get_face_vertices(mesh, face_index)
    center = Vector((0, 0, 0))
    for v_idx in verts:
        center += mesh.vertices[v_idx].co
    return center / len(verts)

def get_face_normal(mesh, face_index):
    """获取面法线"""
    return mesh.polygons[face_index].normal

def get_face_area(mesh, face_index):
    """获取面面积"""
    return mesh.polygons[face_index].area

def find_large_faces(mesh, threshold):
    """查找大面积面"""
    large_faces = []
    for i in range(len(mesh.polygons)):
        if get_face_area(mesh, i) > threshold:
            large_faces.append(i)
    return large_faces

def find_small_faces(mesh, threshold):
    """查找小面积面"""
    small_faces = []
    for i in range(len(mesh.polygons)):
        if get_face_area(mesh, i) < threshold:
            small_faces.append(i)
    return small_faces
```

## 实用函数

### 网格分析

```python
def calculate_mesh_volume(mesh):
    """计算网格体积"""
    volume = 0.0
    for poly in mesh.polygons:
        verts = [mesh.vertices[v].co for v in poly.vertices]
        if len(verts) >= 3:
            v0 = verts[0]
            for v1, v2 in zip(verts[1:-1], verts[2:]):
                volume += v0.cross(v1).dot(v2)
    return abs(volume) / 6.0

def calculate_surface_area(mesh):
    """计算表面积"""
    area = 0.0
    for poly in mesh.polygons:
        area += poly.area
    return area

def get_bounding_box(mesh):
    """获取包围盒"""
    min_co = Vector((float('inf'), float('inf'), float('inf')))
    max_co = Vector((float('-inf'), float('-inf'), float('-inf')))
    for vert in mesh.vertices:
        for i in range(3):
            if vert.co[i] < min_co[i]:
                min_co[i] = vert.co[i]
            if vert.co[i] > max_co[i]:
                max_co[i] = vert.co[i]
    return min_co, max_co

def get_mesh_dimensions(mesh):
    """获取网格尺寸"""
    min_co, max_co = get_bounding_box()
    return max_co - min_co

def analyze_mesh_topology(mesh):
    """分析网格拓扑"""
    stats = {
        'vertices': len(mesh.vertices),
        'edges': len(mesh.edges),
        'faces': len(mesh.polygons),
        'face_vertices_distribution': {},
        'ngons': 0
    }
    for poly in mesh.polygons:
        num_verts = len(poly.vertices)
        stats['face_vertices_distribution'][num_verts] = \
            stats['face_vertices_distribution'].get(num_verts, 0) + 1
        if num_verts > 4:
            stats['ngons'] += 1
    return stats
```

### 网格转换

```python
def triangulate_mesh(mesh):
    """三角化网格"""
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.triangulate(bm, faces=bm.faces)
    result = bpy.data.meshes.new(mesh.name + '_tri')
    bm.to_mesh(result)
    bm.free()
    return result

def quadify_mesh(mesh):
    """四边形化网格"""
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.tris_convert_to_quads(bm, faces=bm.faces)
    result = bpy.data.meshes.new(mesh.name + '_quad')
    bm.to_mesh(result)
    bm.free()
    return result

def subdivide_mesh(mesh, cuts=1):
    """细分网格"""
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.subdivide_edges(
        bm, 
        edges=bm.edges, 
        cuts=cuts, 
        use_grid_fill=True
    )
    result = bpy.data.meshes.new(mesh.name + '_sub')
    bm.to_mesh(result)
    bm.free()
    return result

def decimate_mesh(mesh, ratio):
    """简化网格"""
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.decimate(
        bm, 
        geom=bm.faces + bm.edges + bm.verts, 
        face_dest=len(bm.faces) * ratio
    )
    result = bpy.data.meshes.new(mesh.name + '_dec')
    bm.to_mesh(result)
    bm.free()
    return result
```

### 网格数据

```python
def get_uv_coordinates(mesh, face_index):
    """获取面的UV坐标"""
    if not mesh.uv_layers:
        return []
    uv_layer = mesh.uv_layers.active.data
    face = mesh.polygons[face_index]
    return [uv_layer[loop_index].uv for loop_index in face.loop_indices]

def get_vertex_colors(mesh, face_index):
    """获取面的顶点颜色"""
    if not mesh.vertex_colors:
        return []
    color_layer = mesh.vertex_colors.active.data
    face = mesh.polygons[face_index]
    return [color_layer[loop_index].color for loop_index in face.loop_indices]

def create_attribute(mesh, name, data, domain='POINT'):
    """创建属性"""
    if domain == 'POINT':
        mesh.attributes.new(name=name, type='FLOAT', domain='POINT')
        attr = mesh.attributes[name].data
        for i, value in enumerate(data):
            attr[i].value = value if isinstance(value, (int, float)) else value[0]
```

## 常见问题排查

### 顶点查找失败

坐标不精确：
- 使用适当的容差值
- 考虑网格变换
- 检查坐标系是否一致

### 网格操作缓慢

数据量过大：
- 使用bmesh进行批量操作
- 分块处理大型网格
- 减少不必要的遍历

### 网格变形异常

变换顺序问题：
- 应用所有变换
- 考虑局部和世界坐标系
- 使用正确的矩阵变换
