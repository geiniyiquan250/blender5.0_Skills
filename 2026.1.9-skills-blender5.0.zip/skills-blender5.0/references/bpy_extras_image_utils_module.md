# bpy_extras.image_utils - 图像工具模块

bpy_extras.image_utils模块提供了图像文件加载、图像序列处理和图像转换的实用工具函数。

## 概述

图像工具模块封装了常见的图像处理任务，包括加载图像、生成缩略图、图像序列管理等。适用于开发材质浏览器、纹理管理工具和图像批处理插件。

## 核心功能

### 图像加载

```python
import bpy
import os
from bpy_extras.image_utils import load_image

def load_single_image(filepath, force_reload=False):
    """加载单个图像"""
    img = bpy.data.images.load(filepath, force_reload=force_reload)
    return img

def load_image_check(filepath):
    """加载图像并检查是否存在"""
    img = bpy.data.images.get(filepath)
    if img is None:
        img = bpy.data.images.load(filepath)
    return img

def load_image_with_name(filepath, name=None):
    """加载图像并指定名称"""
    img = bpy.data.images.load(filepath)
    if name:
        img.name = name
    return img

def load_image_relative(filepath, base_path):
    """从相对路径加载图像"""
    if os.path.isabs(filepath):
        full_path = filepath
    else:
        full_path = os.path.join(base_path, filepath)
    if os.path.exists(full_path):
        return load_single_image(full_path)
    return None
```

### 图像序列

```python
def load_image_sequence(directory, file_pattern, start_frame=1, end_frame=None):
    """加载图像序列"""
    images = []
    if end_frame is None:
        files = sorted(os.listdir(directory))
        end_frame = len(files)
    
    for frame in range(start_frame, end_frame + 1):
        filename = file_pattern % frame
        filepath = os.path.join(directory, filename)
        if os.path.exists(filepath):
            img = load_single_image(filepath)
            images.append(img)
    return images

def load_image_strip(filepath, num_images, name=None):
    """加载图像条"""
    img = bpy.data.images.load(filepath)
    if name:
        img.name = name
    img.source = 'STRIP'
    img.frame_start = 0
    img.frame_end = num_images - 1
    return img

def generate_image_sequence(preview_directory):
    """生成图像序列"""
    if not os.path.exists(preview_directory):
        os.makedirs(preview_directory)
    files = sorted(os.listdir(preview_directory))
    return [os.path.join(preview_directory, f) for f in files if f.endswith(('.png', '.jpg', '.jpeg'))]
```

### 缩略图生成

```python
def create_thumbnail(image, size=(128, 128)):
    """创建缩略图"""
    img = image.copy()
    img.scale(size)
    return img

def generate_thumbnails(source_dir, output_dir, size=(128, 128)):
    """批量生成缩略图"""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for filename in os.listdir(source_dir):
        if filename.endswith(('.png', '.jpg', '.jpeg')):
            filepath = os.path.join(source_dir, filename)
            img = load_single_image(filepath)
            thumb = create_thumbnail(img, size)
            thumb.filepath_raw = os.path.join(output_dir, f"thumb_{filename}")
            thumb.file_format = 'PNG'
            thumb.save()
            img.user_clear()
    return output_dir
```

## 实用函数

### 图像管理

```python
def find_image_by_name(name):
    """通过名称查找图像"""
    return bpy.data.images.get(name)

def find_images_by_pattern(pattern):
    """通过模式查找图像"""
    results = []
    for img in bpy_data.images:
        if pattern in img.name:
            results.append(img)
    return results

def find_images_by_size(min_width=0, min_height=0):
    """按尺寸查找图像"""
    results = []
    for img in bpy.data.images:
        if img.size[0] >= min_width and img.size[1] >= min_height:
            results.append(img)
    return results

def cleanup_unused_images():
    """清理未使用的图像"""
    unused = [img for img in bpy.data.images if img.users == 0]
    for img in unused:
        bpy.data.images.remove(img)
    return len(unused)

def group_images_by_size():
    """按尺寸分组图像"""
    groups = {}
    for img in bpy.data.images:
        size_key = (img.size[0], img.size[1])
        if size_key not in groups:
            groups[size_key] = []
        groups[size_key].append(img)
    return groups
```

### 图像处理

```python
def resize_image(image, width, height):
    """调整图像大小"""
    image.scale((width, height))
    return image

def crop_image(image, x, y, width, height):
    """裁剪图像"""
    if hasattr(image, 'crop'):
        image.crop((x, y, x + width, y + height))
    return image

def rotate_image(image, angle):
    """旋转图像"""
    if hasattr(image, 'rotate'):
        image.rotate(angle)
    return image

def convert_image_format(image, target_format='PNG'):
    """转换图像格式"""
    image.file_format = target_format
    return image

def duplicate_image(source, name=None):
    """复制图像"""
    new_img = source.copy()
    if name:
        new_img.name = name
    bpy.data.images.append(new_img)
    return new_img
```

### 批处理工具

```python
class ImageBatchProcessor:
    """图像批处理器"""
    def __init__(self):
        self.images = []
        self.errors = []
    
    def add_from_directory(self, directory, extensions=('.png', '.jpg', '.jpeg')):
        """从目录添加图像"""
        for filename in os.listdir(directory):
            if filename.endswith(extensions):
                filepath = os.path.join(directory, filename)
                try:
                    img = load_single_image(filepath)
                    self.images.append(img)
                except Exception as e:
                    self.errors.append((filename, str(e)))
    
    def add_by_pattern(self, pattern):
        """按模式添加图像"""
        for img in bpy.data.images:
            if pattern in img.name:
                self.images.append(img)
    
    def resize_all(self, width, height):
        """批量调整大小"""
        for img in self.images:
            resize_image(img, width, height)
    
    def convert_all(self, target_format):
        """批量转换格式"""
        for img in self.images:
            convert_image_format(img, target_format)
    
    def export_all(self, output_dir, format='PNG'):
        """批量导出"""
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        for img in self.images:
            filename = os.path.splitext(img.name)[0] + f'.{format.lower()}'
            filepath = os.path.join(output_dir, filename)
            export_image(img, filepath, format)
    
    def clear(self):
        """清空处理器"""
        self.images.clear()
        self.errors.clear()
```

## 常见问题排查

### 图像加载失败

文件路径问题：
- 确认文件路径正确且存在
- 检查文件权限
- 验证图像文件格式被支持

### 内存占用过高

图像数据过大：
- 及时清理未使用的图像
- 使用缩略图替代大图像
- 限制同时加载的图像数量

### 图像序列不同步

帧范围不匹配：
- 确保所有图像尺寸一致
- 检查帧编号连续性
- 验证文件命名模式正确
