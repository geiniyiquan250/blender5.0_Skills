# bpy.ops.view3d - 标尺测量操作模块

Blender 3D视口标尺测量操作符，用于在3D视图中测量距离和角度。

## 概述

`bpy.ops.view3d.ruler` 模块提供用于在Blender 3D视图中进行距离和角度测量的功能，支持精确的尺寸标注和角度计算。

## 核心功能

### 标尺工具

```python
import bpy

# 切换标尺工具
bpy.ops.view3d.ruler(
    mode='RULER',
    xmin=0,
    xmax=0,
    ymin=0,
    ymax=0,
    cursor_transform=False,
    texture_space_correction=True,
    remove_on_action=True
)

# 开始测量
bpy.ops.view3d.ruler(
    mode='RULER',
    xmin=100,
    ymin=100
)

# 添加测量点
bpy.ops.view3d.ruler(
    mode='RULER',
    xmin=200,
    ymin=200
)
```

### 角度测量

```python
# 切换到角度测量
bpy.ops.view3d.ruler(
    mode='ANGULAR'
)

# 测量角度
bpy.ops.view3d.ruler(
    mode='ANGULAR',
    xmin=100,
    ymin=100
)
```

### 删除测量

```python
# 删除测量
bpy.ops.view3d.ruler(
    mode='DELETE'
)

# 删除所有测量
def clear_all_measurements():
    # 清除所有标注对象
    for obj in bpy.data.objects:
        if obj.type == 'FONT':
            bpy.data.objects.remove(obj, do_unlink=True)
    
    # 清除所有线条对象
    for obj in bpy.data.objects:
        if obj.type == 'CURVE':
            if 'ruler' in obj.name.lower() or 'measurement' in obj.name.lower():
                bpy.data.objects.remove(obj, do_unlink=True)
```

### 测量模式

```python
# 距离测量模式
bpy.ops.view3d.ruler(
    mode='RULER'
)

# 角度测量模式
bpy.ops.view3d.ruler(
    mode='ANGULAR'
)

# 面积测量模式
bpy.ops.view3d.ruler(
    mode='AREA'
)
```

## 实用函数

```python
def start_measurement():
    """开始测量"""
    bpy.ops.view3d.ruler(mode='RULER')

def start_angle_measurement():
    """开始角度测量"""
    bpy.ops.view3d.ruler(mode='ANGULAR')

def clear_measurements():
    """清除所有测量"""
    bpy.ops.view3d.ruler(mode='DELETE')

def measure_distance(point1, point2):
    """测量两点距离"""
    import math
    
    x1, y1, z1 = point1
    x2, y2, z2 = point2
    
    distance = math.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)
    return distance

def measure_object_dimensions(obj):
    """测量对象尺寸"""
    if obj.type == 'MESH':
        # 获取边界框尺寸
        dimensions = obj.dimensions
        print(f"对象 {obj.name} 尺寸:")
        print(f"  X: {dimensions.x:.4f}")
        print(f"  Y: {dimensions.y:.4f}")
        print(f"  Z: {dimensions.z:.4f}")
        return dimensions
    else:
        print(f"对象 {obj.name} 不是网格类型")
        return None

def measure_selection_bounds():
    """测量选中对象边界"""
    # 获取选中对象的并集边界框
    min_x = min_y = min_z = float('inf')
    max_x = max_y = max_z = float('-inf')
    
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            # 获取世界坐标边界框
            bbox_corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
            
            for corner in bbox_corners:
                min_x = min(min_x, corner.x)
                min_y = min(min_y, corner.y)
                min_z = min(min_z, corner.z)
                max_x = max(max_x, corner.x)
                max_y = max(max_y, corner.y)
                max_z = max(max_z, corner.z)
    
    if min_x != float('inf'):
        width = max_x - min_x
        depth = max_y - min_y
        height = max_z - min_z
        
        print(f"选中对象边界:")
        print(f"  宽度: {width:.4f}")
        print(f"  深度: {depth:.4f}")
        print(f"  高度: {height:.4f}")
        print(f"  总体积: {width * depth * height:.4f}")
        
        return (width, depth, height)
    
    return None

def measure_vertex_distance(obj, vert_index1, vert_index2):
    """测量顶点间距离"""
    if obj.type == 'MESH':
        v1 = obj.data.vertices[vert_index1]
        v2 = obj.data.vertices[vert_index2]
        
        # 获取世界坐标
        p1 = obj.matrix_world @ v1.co
        p2 = obj.matrix_world @ v2.co
        
        distance = (p1 - p2).length
        print(f"顶点 {vert_index1} 到 {vert_index2}: {distance:.4f}")
        return distance
    
    return None

def measure_edge_length(obj, edge_index):
    """测量边长"""
    if obj.type == 'MESH':
        edge = obj.data.edges[edge_index]
        v1 = obj.data.vertices[edge.vertices[0]]
        v2 = obj.data.vertices[edge.vertices[1]]
        
        p1 = obj.matrix_world @ v1.co
        p2 = obj.matrix_world @ v2.co
        
        length = (p1 - p2).length
        print(f"边 {edge_index} 长度: {length:.4f}")
        return length
    
    return None

def measure_face_area(obj, face_index):
    """测量面面积"""
    if obj.type == 'MESH':
        face = obj.data.polygons[face_index]
        area = face.area
        print(f"面 {face_index} 面积: {area:.4f}")
        return area
    
    return None

def measure_total_surface_area(obj):
    """测量总表面积"""
    if obj.type == 'MESH':
        total_area = sum(face.area for face in obj.data.polygons)
        print(f"对象 {obj.name} 总表面积: {total_area:.4f}")
        return total_area
    
    return None

def measure_volume(obj):
    """测量体积"""
    if obj.type == 'MESH':
        volume = obj.volume
        print(f"对象 {obj.name} 体积: {volume:.4f}")
        return volume
    
    return None

def calculate_angle(v1, v2):
    """计算两个向量之间的角度"""
    import math
    
    dot = v1.dot(v2)
    length1 = v1.length
    length2 = v2.length
    
    if length1 > 0 and length2 > 0:
        cos_angle = dot / (length1 * length2)
        angle = math.degrees(math.acos(max(-1, min(1, cos_angle))))
        print(f"角度: {angle:.2f}度")
        return angle
    
    return None
```

## 常见问题排查

### 标尺工具不工作
```python
# 检查区域类型
print(f"区域类型: {bpy.context.area.type}")

# 确保在3D视图中
if bpy.context.area.type != 'VIEW_3D':
    print("请切换到3D视图使用标尺工具")

# 检查工具设置
space = bpy.context.area.spaces.active
print(f"工具: {space.show_measure_panel}")

# 启用测量面板
space.show_measure_panel = True
```

### 测量结果不准确
```python
# 检查单位设置
print(f"单位系统: {bpy.context.scene.unit_settings.system}")
print(f"比例: {bpy.context.scene.unit_settings.scale_length}")

# 检查测量精度
print(f"小数位数: {bpy.context.scene.unit_settings.system_precision}")

# 确保正确的单位
if bpy.context.scene.unit_settings.system != 'METRIC':
    bpy.context.scene.unit_settings.system = 'METRIC'

# 设置正确的比例
bpy.context.scene.unit_settings.scale_length = 1.0
```

### 测量单位问题
```python
# 检查当前单位
print(f"长度单位: {bpy.context.scene.unit_settings.length_unit}")

# 设置单位
bpy.context.scene.unit_settings.length_unit = 'METERS'

# 转换测量值
def convert_distance(distance, from_unit, to_unit):
    """转换距离单位"""
    conversions = {
        'METERS': 1.0,
        'CENTIMETERS': 0.01,
        'MILLIMETERS': 0.001,
        'FEET': 0.3048,
        'INCHES': 0.0254
    }
    
    if from_unit in conversions and to_unit in conversions:
        return distance * conversions[from_unit] / conversions[to_unit]
    
    return distance
```

### 标注不显示
```python
# 检查标注对象
print(f"对象数: {len(bpy.data.objects)}")

# 检查标注类型
annotation_count = 0
for obj in bpy.data.objects:
    if obj.type == 'FONT':
        annotation_count += 1
        print(f"标注: {obj.name}")

# 检查标注可见性
for obj in bpy.context.scene.objects:
    if obj.type == 'FONT':
        print(f"{obj.name}: 隐藏={obj.hide_viewport}")
        obj.hide_viewport = False

# 检查渲染设置
space = bpy.context.area.spaces.active
print(f"标注显示: {space.show_annotation}")
```

### 角度测量问题
```python
# 检查角度测量模式
bpy.ops.view3d.ruler(mode='ANGULAR')

# 测量三点角度
def measure_three_point_angle(point1, point2, point3):
    """测量三点形成的角度"""
    from mathutils import Vector
    
    v1 = point2 - point1
    v2 = point3 - point2
    
    return calculate_angle(v1, v2)

# 测量面法线角度
def measure_face_normal_angle(obj, face_index):
    """测量面法线角度"""
    from mathutils import Vector
    
    if obj.type == 'MESH':
        face = obj.data.polygons[face_index]
        normal = Vector(face.normal)
        
        # 计算与Z轴的角度
        z_axis = Vector((0, 0, 1))
        angle = calculate_angle(normal, z_axis)
        
        return angle
    
    return None
```
