# bpy.ops.curve 模块

曲线操作模块，用于创建和编辑Bézier曲线和NURBS曲线。

## 概述

bpy.ops.curve 模块包含用于创建、编辑和操作各种类型曲线的运算符。这些运算符支持Bézier曲线、NURBS曲线和路径的创建与修改。

## 常用操作

### 曲线创建

```python
import bpy

# 添加Bézier圆
bpy.ops.primitive_bezier_circle_add(radius=1.0, location=(0, 0, 0))

# 添加Bézier曲线
bpy.ops.primitive_bezier_curve_add(radius=1.0, location=(0, 0, 0))

# 添加NURBS圆
bpy.ops.primitive_nurbs_circle_add(radius=1.0, location=(0, 0, 0))

# 添加NURBS路径
bpy.ops.primitive_nurbs_path_add(radius=1.0, location=(0, 0, 0))

# 添加NURBS曲线
bpy.ops.primitive_nurbs_curve_add(radius=1.0, location=(0, 0, 0))
```

### 曲线编辑

```python
# 细分曲线
bpy.ops.curve.subdivide(number_cuts=1)

# 倒角
bpy.ops.curve.bevel_depth_set()

# 设置倒角深度
bpy.ops.curve.bevel_depth_set()

# 设置分辨率
bpy.ops.curve.resolution_u_set()

# 清除倒角
bpy.ops.curve.bevel_depth_clear()

# 平滑曲线
bpy.ops.curve.smooth()
```

### 选择操作

```python
# 全选
bpy.ops.curve.select_all(action='SELECT')
bpy.ops.curve.select_all(action='DESELECT')
bpy.ops.curve.select_all(action='INVERT')

# 选择同类型
bpy.ops.curve.select_same_type()

# 选择连接
bpy.ops.curve.select_linked()

# 选择相似
bpy.ops.curve.select_similar(type='TYPE', compare='EQUAL')
```

### 曲线操作

```python
# 复制曲线
bpy.ops.curve.duplicate()

# 删除曲线
bpy.ops.curve.delete(type='SEGMENT')

# 删除首段
bpy.ops.curve.delete(type='VERT')

# 删除选中点
bpy.ops.curve.delete(type='EDGE')

# 分离曲线
bpy.ops.curve.separate()

# 连接曲线
bpy.ops.curve.make_regular()

# 闭合曲线
bpy.ops.curve.cyclic_toggle(direction='CYCLIC_U')

# 切换循环
bpy.ops.curve.cyclic_toggle(direction='CYCLIC_V')
```

### 点操作

```python
# 添加点
bpy.ops.curve.subdivide(number_cuts=1)

# 删除点
bpy.ops.curve.delete(type='VERT')

# 移动点
bpy.ops.transform.translate(value=(0, 0, 0))

# 旋转点
bpy.ops.transform.rotate(value=0)

# 缩放点
bpy.ops.transform.resize(value=(1, 1, 1))

# 滑动点
bpy.ops.curve.slide()
```

### 曲线类型

```python
# 设置曲线类型
bpy.ops.curve.curve_type_set(type='POLY')
bpy.ops.curve.curve_type_set(type='BEZIER')
bpy.ops.curve.curve_type_set(type='NURBS')

# 转换为多段线
bpy.ops.curve.curve_type_set(type='POLY')

# 转换为Bézier
bpy.ops.curve.curve_type_set(type='BEZIER')

# 转换为NURBS
bpy.ops.curve.curve_type_set(type='NURBS')
```

### 曲线变形

```python
# 细分
bpy.ops.curve.subdivide(number_cuts=1)

# 倒角
bpy.ops.curve.bevel_start_set()

# 结束倒角
bpy.ops.curve.bevel_end_set()

# 倒角深度
bpy.ops.curve.bevel_depth_set()

# 倒角分辨率
bpy.ops.curve.bevel_resolution_set()
```

### 曲线投射

```python
# 投射到网格
bpy.ops.curve.project()

# 投射到曲面
bpy.ops.curve.project()

# 曲线间插值
bpy.ops.curve.interpolate()
```

## 实际应用示例

### 创建程序化圆环

```python
def create_procedural_torus_curve(major_radius=2.0, minor_radius=0.5, resolution=64):
    """创建程序化圆环曲线"""
    import math
    
    # 创建Bézier圆
    bpy.ops.primitive_bezier_circle_add(radius=major_radius)
    torus = bpy.context.active_object
    torus.name = 'TorusCurve'
    
    # 获取曲线数据
    curve = torus.data
    
    # 设置分辨率
    curve.resolution_u = resolution
    
    # 添加细分
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.curve.subdivide(number_cuts=resolution * 2)
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return torus
```

### 创建程序化螺旋

```python
def create_spiral_curve(turns=5, radius=1.0, height=3.0, points=100):
    """创建螺旋曲线"""
    import math
    
    # 创建NURBS路径
    bpy.ops.primitive_nurbs_path_add(radius=1.0)
    spiral = bpy.context.active_object
    spiral.name = 'SpiralCurve'
    
    # 获取曲线数据
    curve = spiral.data
    
    # 清理默认点
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.curve.select_all(action='SELECT')
    bpy.ops.curve.delete(type='VERT')
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 添加螺旋点
    for i in range(points):
        t = i / (points - 1)
        angle = t * turns * 2 * math.pi
        current_radius = radius * (1 - t * 0.5)
        x = current_radius * math.cos(angle)
        y = current_radius * math.sin(angle)
        z = height * t - height / 2
        
        curve.points.add(1)
        curve.points[-1].co = (x, y, z, 1)
    
    return spiral
```

### 创建文字路径

```python
def create_text_path(text, font_obj=None, resolution=12):
    """将文字转换为曲线"""
    # 创建文字对象
    bpy.ops.object.text_add()
    text_obj = bpy.context.active_object
    text_obj.data.body = text
    
    # 设置分辨率
    text_obj.data.resolution_u = resolution
    
    # 转换为曲线
    bpy.ops.object.convert(target='CURVE')
    
    return text_obj
```

### 创建程序化形状键曲线

```python
def create_curve_shape_keys(curve_obj, key_names, key_data):
    """为曲线创建形状键"""
    # 切换到对象模式
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 添加形状键基础
    basis_key = curve_obj.shape_key_add(name='Basis')
    
    # 创建每个形状键
    for key_name, data in zip(key_names, key_data):
        key = curve_obj.shape_key_add(name=key_name)
        
        # 设置关键帧
        for i, point in enumerate(data):
            key.data[i].co = point
    
    return curve_obj.shape_key_blocks
```

### 创建路径动画

```python
def create_path_animation(obj, curve_obj, frames=100):
    """创建沿路径动画"""
    # 添加跟随路径约束
    constraint = obj.constraints.new(type='FOLLOW_PATH')
    constraint.target = curve_obj
    
    # 设置曲线
    constraint.use_curve_follow = True
    constraint.up_axis = 'UP_Y'
    constraint.forward_axis = 'FORWARD_X'
    
    # 约束路径
    bpy.ops.constraint.followpath_path_animate(
        constraint='Follow Path',
        owner='OBJECT',
        frame_start=1,
        length=frames
    )
    
    return obj
```

### 创建程序化齿轮曲线

```python
def create_gear_curve(teeth=12, outer_radius=1.0, inner_radius=0.8, resolution=24):
    """创建齿轮形状曲线"""
    import math
    
    # 创建Bézier曲线
    bpy.ops.primitive_bezier_curve_add(radius=1.0)
    gear = bpy.context.active_object
    gear.name = 'GearCurve'
    
    curve = gear.data
    
    # 计算齿轮点
    points = []
    for i in range(teeth * 2):
        angle = (i / (teeth * 2)) * 2 * math.pi
        is_outer = i % 2 == 0
        
        radius = outer_radius if is_outer else inner_radius
        x = radius * math.cos(angle)
        y = radius * math.sin(angle)
        points.append((x, y, 0))
    
    # 设置点
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.curve.select_all(action='SELECT')
    bpy.ops.curve.delete(type='VERT')
    
    for point in points:
        curve.points.add(1)
        curve.points[-1].co = (*point, 1)
    
    # 闭合曲线
    bpy.ops.curve.cyclic_toggle(direction='CYCLIC_U')
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return gear
```

### 创建程序化花形曲线

```python
def create_flower_curve(petals=5, radius=1.0, resolution=100):
    """创建花瓣形状曲线"""
    import math
    
    # 创建Bézier曲线
    bpy.ops.primitive_bezier_curve_add(radius=1.0)
    flower = bpy.context.active_object
    flower.name = 'FlowerCurve'
    
    curve = flower.data
    
    # 清理默认点
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.curve.select_all(action='SELECT')
    bpy.ops.curve.delete(type='VERT')
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 计算花瓣点
    for i in range(resolution):
        t = i / (resolution - 1)
        angle = t * 2 * math.pi
        
        # 花瓣公式
        r = radius * (0.5 + 0.5 * math.sin(petals * angle))
        
        x = r * math.cos(angle)
        y = r * math.sin(angle)
        
        curve.points.add(1)
        curve.points[-1].co = (x, y, 1, 1)
    
    # 闭合曲线
    bpy.ops.curve.cyclic_toggle(direction='CYCLIC_U')
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return flower
```

### 创建程序化心形曲线

```python
def create_heart_curve(size=1.0, resolution=100):
    """创建心形曲线"""
    import math
    
    # 创建Bézier曲线
    bpy.ops.primitive_bezier_curve_add(radius=1.0)
    heart = bpy.context.active_object
    heart.name = 'HeartCurve'
    
    curve = heart.data
    
    # 清理默认点
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.curve.select_all(action='SELECT')
    bpy.ops.curve.delete(type='VERT')
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # 计算心形点
    for i in range(resolution):
        t = i / (resolution - 1) * 2 * math.pi
        
        # 心形公式
        x = 16 * math.pow(math.sin(t), 3)
        y = -(13 * math.cos(t) - 5 * math.cos(2*t) - 2 * math.cos(3*t) - math.cos(4*t))
        
        x = x * size / 16
        y = y * size / 16
        
        curve.points.add(1)
        curve.points[-1].co = (x, y, 0, 1)
    
    # 闭合曲线
    bpy.ops.curve.cyclic_toggle(direction='CYCLIC_U')
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    return heart
```

## 使用场景

- **路径动画**：创建沿路径的运动
- **程序化形状**：创建数学定义的曲线
- **文字转换**：将文字转为曲线
- **模型生成**：从曲线生成管状模型
- **装饰设计**：创建装饰性曲线
- **机械设计**：创建齿轮等机械形状

## 注意事项

- 曲线需要足够的点来表达形状
- NURBS曲线需要控制点
- Bézier曲线有句柄
- 曲线可以转换为网格
- 路径动画需要正确设置
- 曲线分辨率影响平滑度
