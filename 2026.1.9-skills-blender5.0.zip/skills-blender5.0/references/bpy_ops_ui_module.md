# bpy.ops.ui - 用户界面操作模块

Blender用户界面操作符，用于控制UI元素的显示和交互。

## 概述

`bpy.ops.ui` 模块提供用于操作Blender用户界面的功能，包括面板控制、菜单操作和UI元素管理。

## 核心功能

### 面板操作

```python
import bpy

# 展开所有面板
bpy.ops.ui.expanded_toggle(
    all=True
)

# 收起所有面板
bpy.ops.ui.expanded_toggle(
    all=True
)

# 切换面板展开
bpy.ops.ui.expanded_toggle(
    all=False
)

# 重置面板布局
bpy.ops.ui.reset_default(
    release=True
)
```

### 数值输入

```python
# 数值输入
bpy.ops.ui.copy_as_driver()

# 复制为驱动
bpy.ops.ui.copy_as_driver()

# 粘贴驱动
bpy.ops.ui.paste_driver()

# 数值弹窗
bpy.ops.ui.数值_input(
    data_path='scale',
    data_path_index=0
)
```

### 搜索功能

```python
# 搜索操作符
bpy.ops.ui.search_menu()

# 搜索菜单
bpy.ops.ui.search_menu(
    menu='SEARCH_MT '
)

# 打开搜索
bpy.ops.ui.search_menu()
```

### 属性操作

```python
# 复制属性
bpy.ops.ui.copy_property()

# 粘贴属性
bpy.ops.ui.paste_property()

# 重置属性
bpy.ops.ui.reset_property()

# 应用到所有
bpy.ops.ui.apply_property()
```

### 颜色选择

```python
# 颜色选择
bpy.ops.ui.color_picker(
    data_path='color'
)

# 颜色选择器操作
bpy.ops.ui.color_picker(
    data_path='active_material.diffuse_color',
    data_path_index=0,
    color=(1.0, 0.5, 0.25, 1.0)
)
```

### 快捷键操作

```python
# 添加快捷键
bpy.ops.ui.add_shortcut()

# 编辑快捷键
bpy.ops.ui.edit_shortcut()

# 删除快捷键
bpy.ops.ui.remove_shortcut()

# 重置快捷键
bpy.ops.ui.reset_shortcut()
```

## 实用函数

```python
def collapse_all_panels():
    """收起所有面板"""
    bpy.ops.ui.expanded_toggle(all=True)

def expand_all_panels():
    """展开所有面板"""
    bpy.ops.ui.expanded_toggle(all=False)

def reset_ui_layout():
    """重置UI布局"""
    bpy.ops.ui.reset_default(release=True)

def copy_property_to_driver(data_path, index=0):
    """复制属性为驱动"""
    bpy.ops.ui.copy_as_driver()
    # 在目标属性上右键粘贴

def search_menu_items(search_text):
    """搜索菜单项"""
    bpy.ops.ui.search_menu()
    # 在搜索框中输入文本

def reset_active_property():
    """重置活动属性"""
    bpy.ops.ui.reset_property()

def apply_property_to_all():
    """应用属性到所有"""
    bpy.ops.ui.apply_property()
```

## 常见问题排查

### 面板不响应
```python
# 检查面板状态
print(f"面板展开: {bpy.context.preferences.system.view.use_expanded_panels}")

# 重置UI
bpy.ops.ui.reset_default(release=True)

# 刷新UI
bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
```

### 属性无法编辑
```python
# 检查属性锁定
data_path = 'active_object.location'
# 检查该属性是否被锁定
print(f"属性可编辑: {not getattr(bpy.context.active_object, 'lock_location', [False, False, False])[0]}")

# 解除锁定
bpy.context.active_object.lock_location = (False, False, False)
bpy.context.active_object.lock_rotation = (False, False, False)
bpy.context.active_object.lock_scale = (False, False, False)
```

### 搜索菜单不工作
```python
# 检查区域类型
print(f"区域类型: {bpy.context.area.type}")

# 确保在支持搜索的区域
if bpy.context.area.type in ['PROPERTIES', 'DOPESHEET_EDITOR']:
    print("支持搜索菜单")
else:
    print("当前区域不支持搜索菜单")

# 尝试快捷键搜索
# 按F3打开搜索菜单
```

### UI显示问题
```python
# 检查UI缩放
print(f"UI缩放: {bpy.context.preferences.system.ui_scale}")

# 重启UI
bpy.ops.wm.read_homefile()

# 检查显示设置
print(f"主题: {bpy.context.preferences.ui.theme}")
```
