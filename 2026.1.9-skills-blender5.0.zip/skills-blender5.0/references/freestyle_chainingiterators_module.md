# freestyle.chainingiterators - 线条链化迭代器模块

freestyle.chainingiterators模块提供了Freestyle线条渲染中的链化迭代器，用于决定如何将相邻的边连接成连续的线条。

## 概述

链化迭代器是Freestyle线条渲染的核心组件之一。它们定义了从一条边到相邻边的连接规则，决定了最终生成线条的走向和连续性。不同的链化策略会产生不同风格的线条效果。

## 核心功能

### 基础迭代器

```python
from freestyle.chainingiterators import (
    ChainSilhouetteIterator,
    ChainBoundaryIterator,
    ChainCreaseAngleIterator,
    ChainContourIterator,
    ChainUVSinuousIterator
)

def create_silhouette_iterator(predicate=None):
    """创建轮廓链化迭代器"""
    return ChainSilhouetteIterator(predicate)

def create_boundary_iterator(predicate=None):
    """创建边界链化迭代器"""
    return ChainBoundaryIterator(predicate)

def create_crease_angle_iterator(angle_threshold=math.radians(45)):
    """创建折痕角度链化迭代器"""
    return ChainCreaseAngleIterator(angle_threshold)

def create_contour_iterator(view_map, predicate=None):
    """创建轮廓链化迭代器"""
    return ChainContourIterator(view_map, predicate)
```

### 迭代器配置

```python
def configure_silhouette_iterator(
    iterator,
    chaining_distance=10,
    initial_chaining_distance=10,
    orientation_flag=True,
    prob_flag=True
):
    """配置轮廓链化迭代器"""
    iterator.chaining_distance = chaining_distance
    iterator.initial_chaining_distance = initial_chaining_distance
    iterator.orientation_flag = orientation_flag
    iterator.prob_flag = prob_flag
    return iterator

def configure_crease_iterator(
    iterator,
    angle_threshold=math.radians(30),
    absolute=False
):
    """配置折痕链化迭代器"""
    iterator.angle_threshold = angle_threshold
    iterator.absolute = absolute
    return iterator
```

### 自定义迭代器

```python
class CustomChainingIterator:
    """自定义链化迭代器"""
    def __init__(self, predicate=None):
        self.predicate = predicate
        self.chaining_distance = 10
    
    def iterate(self, edge, stroke):
        """迭代方法"""
        pass
    
    def reset(self):
        """重置迭代器"""
        pass

def create_custom_iterator(predicate=None):
    """创建自定义链化迭代器"""
    return CustomChainingIterator(predicate)
```

## 实用函数

### 线条生成

```python
def generate_strokes(view_map, chain_iterator, predicate=None):
    """生成线条"""
    from freestyle import stroke
    
    strokes = []
    chain_iterator.reset()
    
    for stroke in chain_iterator.iterate():
        if stroke:
            strokes.append(stroke)
    
    return strokes

def generate_silhouette_strokes(view_map, predicate=None):
    """生成轮廓线条"""
    iterator = ChainSilhouetteIterator(predicate)
    return generate_strokes(view_map, iterator)

def generate_contour_strokes(view_map, predicate=None):
    """生成轮廓线条"""
    iterator = ChainContourIterator(view_map, predicate)
    return generate_strokes(view_map, iterator)
```

### 迭代器组合

```python
def chain_iterators(iter1, iter2):
    """组合两个迭代器"""
    class ChainedIterator:
        def __init__(self, it1, it2):
            self.it1 = it1
            self.it2 = it2
        
        def iterate(self, edge, stroke):
            result = self.it1.iterate(edge, stroke)
            if not result:
                result = self.it2.iterate(edge, stroke)
            return result
    
    return ChainedIterator(iter1, iter2)

def priority_chaining(iterator, priority_edges):
    """优先链化"""
    class PriorityIterator:
        def __init__(self, iterator, priorities):
            self.iterator = iterator
            self.priorities = priorities
        
        def iterate(self, edge, stroke):
            for edge_type in self.priorities:
                if edge.type == edge_type:
                    return self.iterator.iterate(edge, stroke)
            return None
    
    return PriorityIterator(iterator, priority_edges)
```

### 性能优化

```python
def optimize_chaining(strokes, max_length=100):
    """优化链化长度"""
    for stroke in strokes:
        while len(stroke.points) > max_length:
            stroke.points = stroke.points[:max_length]
    return strokes

def merge_short_strokes(strokes, min_length=5):
    """合并短线条"""
    merged = []
    current_stroke = None
    
    for stroke in strokes:
        if stroke.length() < min_length:
            if current_stroke:
                current_stroke.extend(stroke.points)
        else:
            if current_stroke:
                merged.append(current_stroke)
            current_stroke = stroke
    
    if current_stroke:
        merged.append(current_stroke)
    
    return merged
```

## 常见问题排查

### 线条不连续

链化规则问题：
- 调整链化距离参数
- 检查谓词过滤条件
- 尝试不同的迭代器类型

### 性能问题

线条数量过多：
- 增加链化距离减少线条数量
- 使用谓词过滤不必要的边
- 限制最大线条长度

### 线条丢失

视图映射问题：
- 确认view_map正确构建
- 检查迭代器初始化参数
- 验证场景对象可见性
