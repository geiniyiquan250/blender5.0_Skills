# bpy.context 模块

## 模块概述

bpy.context 模块提供对 Blender 当前上下文的访问接口，通过该模块可以获取当前用户界面状态、选中的对象、活动元素以及各种编辑状态。该模块是编写交互式脚本和操作符的基础，几乎所有需要与用户操作交互的代码都需要通过它来获取当前状态。上下文信息是动态的，会根据用户的选择和操作实时变化，因此在编写插件和脚本时需要特别注意上下文的使用时机。

上下文对象是一个特殊的字典-like 对象，它聚合了多个层面的信息。顶层属性提供最常用的对象和数据的快速访问，如 scene、object、active_object 等核心属性。区域特定属性则根据当前激活的区域返回对应的数据，如 view_layer、region、area、space_data 等。这些属性在不同类型的编辑器窗口中可能返回不同的值，例如在 3D 视图中 space_data 返回 SpaceView3D，而在图像编辑器中返回 SpaceImageEditor。

在多窗口和多屏幕的工作环境中，同一个 Blender 实例可能存在多个上下文窗口。bpy.context 总是返回当前执行上下文窗口的状态，这与 bpy.data 的全局数据不同，后者包含的是整个 .blend 文件的数据。因此，当编写需要在多个窗口中正确运行的代码时，需要特别注意上下文的动态特性。

## 核心属性

### 活动对象属性

活动对象属性提供对当前编辑焦点对象的快速访问，这些属性是编写操作脚本时最常使用的信息来源。active_object 属性返回当前活动的物体，该物体通常带有操作焦点，如变换操作的目标。object 属性是 active_object 的别名，两者在功能上完全相同。active_object_base 属性返回活动物体所在的集合基元，这在处理复杂场景层次时特别有用。

在物体模式下，active_object 返回当前选中的单个物体。在编辑模式下，active_object 返回正在编辑的物体，而 active_editable_object 则返回当前可编辑的物体，这在多选编辑时尤为重要。selected_objects 列表包含所有当前选中的物体，无论这些物体处于什么模式。selected_editable_objects 列表则只包含可编辑的选中物体，过滤掉被保护或锁定的物体。

```python
import bpy

# 获取当前活动物体
obj = bpy.context.active_object
if obj:
    print(f"活动物体: {obj.name}")
    print(f"物体类型: {obj.type}")
    print(f"物体位置: {obj.location}")

# 获取所有选中物体
for obj in bpy.context.selected_objects:
    print(f"选中物体: {obj.name}")

# 检查当前是否处于编辑模式
if bpy.context.active_object and bpy.context.active_object.mode == 'EDIT':
    print("当前处于编辑模式")
    # 获取编辑选中的顶点
    edit_obj = bpy.context.active_object
    mesh = edit_obj.data
    if mesh.total_vert_sel > 0:
        print(f"选中了 {mesh.total_vert_sel} 个顶点")
```

### 场景相关属性

scene 属性返回当前场景对象，这是访问场景级别数据的入口点。通过 scene 属性可以访问场景中的所有物体、集合、相机、灯光等元素。view_layer 属性返回当前视图层，视图层用于组织场景中的物体可见性和渲染设置。在 Blender 2.8 之后的版本中，view_layer 取代了原来的 layer 属性，提供了更灵活的层管理功能。

window 属性返回当前窗口管理器对象，screen 属性返回当前屏幕对象。area 属性返回当前激活的区域，region 属性返回当前区域中的特定区域（如 3D 视口中的面板区域）。这些属性在编写需要精确定位界面元素的脚本时非常有用。

```python
import bpy

# 获取当前场景
scene = bpy.context.scene

# 访问场景物体
print(f"场景中的物体数量: {len(scene.objects)}")

# 获取当前视图层
view_layer = bpy.context.view_layer

# 获取当前选中的集合
active_layer_collection = bpy.context.layer_collection
print(f"当前集合: {active_layer_collection.name}")

# 访问当前屏幕和区域
screen = bpy.context.screen
area = bpy.context.area
print(f"当前区域类型: {area.type if area else '无'}")

# 遍历屏幕区域
for region in screen.areas[0].regions:
    if region.type == 'WINDOW':
        print(f"窗口区域: {region.type}")
```

### 编辑器区域属性

space_data 属性返回当前活动空间的数据，具体类型取决于当前激活的区域类型。在 3D 视图中，它返回 SpaceView3D 对象，包含视图视角、渲染属性等信息。在图像编辑器中，它返回 SpaceImageEditor 对象，包含图像显示和编辑相关的信息。在节点编辑器中，它返回 SpaceNodeEditor 对象，包含节点树和合成设置的信息。

region_3d 属性返回当前 3D 区域的数据，这是一个 RegionView3D 对象，包含视图的相机变换、透视/正交设置等信息。当需要在 3D 视图中进行坐标计算或视图操作时，这个属性是必不可少的。

```python
import bpy
from mathutils import Vector

# 获取 3D 视图信息
space = bpy.context.space_data
if space and hasattr(space, 'region_3d'):
    r3d = space.region_3d
    print(f"视图类型: {'透视' if r3d.is_perspective else '正交'}")
    print(f"视图旋转: {r3d.view_rotation}")
    print(f"视图距离: {r3d.view_distance}")

    # 获取视图矩阵
    view_matrix = r3d.view_matrix
    print(f"视图矩阵:\n{view_matrix}")

    # 将世界坐标转换为视图坐标
    world_point = Vector((1.0, 2.0, 3.0))
    view_point = world_point @ r3d.view_matrix.inverted()
    print(f"世界点 {world_point} 在视图中的位置: {view_point}")
```

### 工具设置属性

tool_settings 属性返回当前工具的设置，这是一个 ToolSettings 对象，包含各种编辑工具的共享设置。不同的编辑模式有不同的工具设置，如编辑顶点时的吸附设置、变换时的变换轴心点设置等。这些设置可以用于在脚本中模拟用户的工具操作行为。

```python
import bpy

# 获取工具设置
tool_settings = bpy.context.tool_settings

# 获取变换设置
transform = tool_settings.transform_pivot_point
print(f"变换轴心点: {transform}")

# 获取吸附设置
snap = tool_settings.use_snap
print(f"吸附启用: {snap}")
if snap:
    snap_target = tool_settings.snap_target
    print(f"吸附目标: {snap_target}")

# 获取雕刻设置（如果处于雕刻模式）
if bpy.context.mode.startswith('SCULPT'):
    sculpt = tool_settings.sculpt
    print(f"雕刻工具: {sculpt.current_tool}")
    print(f"雕刻笔刷大小: {sculpt.brush.size}")
```

### 偏好设置属性

preferences 属性返回用户偏好设置对象，这是一个 PreferencesPreferences 对象，包含 Blender 的各种用户配置。这些设置影响整个应用程序的行为，包括主题颜色、快捷键、默认文件路径等。在编写需要访问用户配置的脚本时，可以通过这个属性获取相关设置。

```python
import bpy

# 获取偏好设置
prefs = bpy.context.preferences

# 获取文件路径设置
file_paths = prefs.filepaths
print(f"默认保存目录: {file_paths.default_directory}")
print(f"最近文件数量: {file_paths.recent_files}")

# 获取主题设置
theme = prefs.themes['Default']
print(f"主题背景颜色: {theme.view_3d.space.colors.back}")

# 获取编辑偏好
edits = prefs.editPreferences
print(f"撤销步数: {edits.undo_steps}")
print(f"自动保存间隔: {edits.auto_save_time}")
```

## 上下文方法

### 复制属性方法

copy 方法用于复制当前上下文中的属性字典，返回一个包含所有上下文属性的字典。这个方法在需要保存和恢复上下文状态时非常有用，例如在操作前后保存当前选择状态和活动物体，操作完成后再恢复。

```python
import bpy

# 保存当前上下文状态
saved_context = bpy.context.copy()

# 执行一些操作
bpy.ops.object.select_all(action='SELECT')

# 恢复上下文状态
for key, value in saved_context.items():
    try:
        bpy.context[key] = value
    except (KeyError, TypeError):
        pass  # 某些属性可能无法设置，忽略错误

print("上下文状态已恢复")
```

### 深度复制属性方法

deep_copy 方法是 copy 方法的深拷贝版本，它会递归复制所有嵌套的对象。这个方法比 copy 更消耗资源，但在需要完整隔离原始数据的情况下是必要的。例如，当需要修改上下文中的对象而不影响原始状态时，应该使用 deep_copy。

```python
import bpy

# 使用深度复制保存完整上下文
saved_context = bpy.context.deep_copy()

# 修改活动物体的位置
if bpy.context.active_object:
    bpy.context.active_object.location.x += 1.0

# 深度复制的内容不会受到修改影响
original_obj = saved_context['active_object']
print(f"原始物体位置: {original_obj.location.x}")
print(f"当前物体位置: {bpy.context.active_object.location.x}")
```

## 常用上下文模式

### 物体模式

物体模式是 Blender 的默认编辑模式，在此模式下可以对整个物体进行操作，包括选择、移动、旋转、缩放等变换操作。bpy.context.mode 返回 'OBJECT' 字符串。selected_objects 列表包含所有选中的物体，active_object 是活动物体。

```python
import bpy

def process_object_mode():
    """处理物体模式下的操作"""
    if bpy.context.mode != 'OBJECT':
        print("不在物体模式下")
        return

    # 获取选中的网格物体
    mesh_objects = [obj for obj in bpy.context.selected_objects
                   if obj.type == 'MESH']

    print(f"选中的网格物体数量: {len(mesh_objects)}")

    for obj in mesh_objects:
        # 计算物体包围盒中心
        if obj.bound_box:
            center = sum((Vector(b) for b in obj.bound_box), Vector((0, 0, 0))) / 8
            world_center = obj.matrix_world @ center
            print(f"物体 {obj.name} 的世界中心: {world_center}")

    # 设置活动物体
    if mesh_objects:
        bpy.context.view_layer.objects.active = mesh_objects[0]
        print(f"设置 {mesh_objects[0].name} 为活动物体")
```

### 编辑模式

编辑模式允许直接编辑物体的几何数据，根据编辑对象类型的不同，可以进一步分为顶点编辑、边编辑和面编辑三种子模式。bpy.context.mode 返回 'EDIT'，而 bpy.context.tool_settings.mesh_select_mode 返回一个布尔元组，表示当前启用的选择模式（顶点、边、面）。

在编辑模式下，active_object 返回正在编辑的物体，edit_object 是其别名。selected_editable_objects 返回当前可编辑的选中物体列表。edit_object.data 返回物体的网格数据，包含所有几何信息。

```python
import bpy

def process_edit_mode():
    """处理编辑模式下的操作"""
    if bpy.context.mode != 'EDIT':
        print("不在编辑模式下")
        return

    obj = bpy.context.active_object
    mesh = obj.data

    # 检查当前选择模式
    select_mode = bpy.context.tool_settings.mesh_select_mode
    print(f"选择模式 - 顶点: {select_mode[0]}, 边: {select_mode[1]}, 面: {select_mode[2]}")

    if select_mode[0]:  # 顶点选择模式
        selected_verts = [v for v in mesh.vertices if v.select]
        print(f"选中的顶点数量: {len(selected_verts)}")

        # 计算选中顶点的平均位置
        if selected_verts:
            avg_pos = sum((v.co for v in selected_verts), Vector((0, 0, 0))) / len(selected_verts)
            print(f"选中顶点的平均位置: {avg_pos}")

    if select_mode[2]:  # 面选择模式
        selected_faces = [p for p in mesh.polygons if p.select]
        print(f"选中的面数量: {len(selected_faces)}")

        # 计算选中面的总面积
        total_area = sum(p.area for p in selected_faces)
        print(f"选中面的总面积: {total_area:.2f}")
```

### 雕刻模式

雕刻模式提供数字雕刻工具，用于对网格进行细节雕刻。bpy.context.mode 返回 'SCULPT'。sculpt 属性提供对雕刻工具设置的访问，包括当前工具、笔刷、大小、强度等参数。

```python
import bpy

def process_sculpt_mode():
    """处理雕刻模式下的操作"""
    if not bpy.context.mode.startswith('SCULPT'):
        print("不在雕刻模式下")
        return

    sculpt = bpy.context.tool_settings.sculpt

    # 获取当前雕刻工具信息
    print(f"当前工具: {sculpt.current_tool}")
    print(f"当前笔刷: {sculpt.brush.name}")

    # 获取笔刷设置
    brush = sculpt.brush
    print(f"笔刷大小: {brush.size}")
    print(f"笔刷强度: {brush.strength}")
    print(f"笔刷角度: {brush.angle}")

    # 获取雕刻模式设置
    print(f"镜像雕刻: {sculpt.use_symmetry}")
    print(f"Dyntopo 启用: {sculpt.dyntopo.detail}")
```

### 顶点绘画模式

顶点绘画模式用于直接对网格顶点应用颜色，bpy.context.mode 返回 'PAINT_VERTEX'。vertex_paint 属性提供对顶点绘画工具设置的访问。

```python
import bpy

def process_vertex_paint_mode():
    """处理顶点绘画模式下的操作"""
    if bpy.context.mode != 'PAINT_VERTEX':
        print("不在顶点绘画模式下")
        return

    vp = bpy.context.tool_settings.vertex_paint

    # 获取顶点绘画设置
    print(f"当前笔刷: {vp.brush.name}")
    print(f"混合模式: {vp.brush.blend}")

    # 获取当前颜色
    color = vp.brush.color
    print(f"当前颜色: RGB({color[0]:.2f}, {color[1]:.2f}, {color[2]:.2f})")
```

### 纹理绘画模式

纹理绘画模式允许直接在网格表面绘制纹理，bpy.context.mode 返回 'PAINT_TEXTURE'。image_paint 属性提供对纹理绘画工具的访问，包括笔刷、蒙版、图像等设置。

```python
import bpy

def process_texture_paint_mode():
    """处理纹理绘画模式下的操作"""
    if bpy.context.mode != 'PAINT_TEXTURE':
        print("不在纹理绘画模式下")
        return

    ip = bpy.context.tool_settings.image_paint

    # 获取纹理绘画设置
    print(f"当前笔刷: {ip.brush.name}")
    print(f"镜像绘画: {ip.brush.use_rake}")
    print(f"角度锁定: {ip.brush.use_angle}")

    # 获取当前图像
    if ip.canvas:
        print(f"当前画布图像: {ip.canvas.name}")
        print(f"图像尺寸: {ip.canvas.size[0]} x {ip.canvas.size[1]}")
```

### 权重绘画模式

权重绘画模式用于为网格顶点分配顶点组权重，bpy.context.mode 返回 'PAINT_WEIGHT'。weight_paint 属性提供对权重绘画工具的访问。

```python
import bpy

def process_weight_paint_mode():
    """处理权重绘画模式下的操作"""
    if bpy.context.mode != 'PAINT_WEIGHT':
        print("不在权重绘画模式下")
        return

    wp = bpy.context.tool_settings.weight_paint

    # 获取权重绘画设置
    print(f"当前笔刷: {wp.brush.name}")
    print(f"权重: {wp.brush.weight}")

    # 获取活动顶点组
    obj = bpy.context.active_object
    if obj.vertex_groups.active:
        print(f"活动顶点组: {obj.vertex_groups.active.name}")
```

## 上下文与数据访问

### 实时获取选中状态

在编写操作脚本时，经常需要实时获取当前的选中状态。由于上下文是动态变化的，每次访问 selected_objects 等属性都会返回最新的状态。因此，在执行操作前应该先获取需要的信息，而不是依赖之前保存的状态。

```python
import bpy

def get_selected_mesh_info():
    """获取当前选中的网格物体信息"""
    selected_meshes = []

    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            mesh_info = {
                'name': obj.name,
                'location': obj.location.copy(),
                'rotation': obj.rotation_euler.copy(),
                'scale': obj.scale.copy(),
                'vertex_count': len(obj.data.vertices),
                'edge_count': len(obj.data.edges),
                'face_count': len(obj.data.polygons)
            }
            selected_meshes.append(mesh_info)

    return selected_meshes

# 使用示例
infos = get_selected_mesh_info()
for info in infos:
    print(f"物体: {info['name']}")
    print(f"  顶点数: {info['vertex_count']}")
    print(f"  面数: {info['face_count']}")
```

### 获取活动元素

活动元素包括活动物体、活动材质、活动纹理、活动图像等。这些元素通常用于确定操作的目标，例如在材质槽中设置材质时，操作的是活动材质槽中的材质。

```python
import bpy

def get_active_elements():
    """获取当前活动的各种元素"""
    elements = {}

    # 活动物体
    elements['object'] = bpy.context.active_object

    # 活动材质
    if elements['object'] and elements['object'].active_material:
        elements['material'] = elements['object'].active_material

    # 活动纹理（如果存在）
    if elements.get('material') and elements['material'].active_texture:
        elements['texture'] = elements['material'].active_texture

    # 活动图像
    if 'texture' in elements and elements['texture'].type == 'IMAGE':
        elements['image'] = elements['texture'].image

    # 活动节点（如果在节点编辑器中）
    if bpy.context.area and bpy.context.area.type == 'NODE_EDITOR':
        space = bpy.context.space_data
        if space.edit_tree:
            elements['node_tree'] = space.edit_tree

    return elements

# 使用示例
elements = get_active_elements()
for key, value in if value:
        elements.items():
    print(f"活动{key}: {value.name if hasattr(value, 'name') else value}")
```

### 上下文切换

虽然 Blender 的操作符通常会自动切换到适当的上下文，但有时需要手动切换上下文模式。bpy.ops.object.mode_set 操作符可以用于切换模式。

```python
import bpy

def switch_to_edit_mode():
    """切换到编辑模式"""
    bpy.ops.object.mode_set(mode='EDIT')
    print("已切换到编辑模式")

def switch_to_object_mode():
    """切换到物体模式"""
    bpy.ops.object.mode_set(mode='OBJECT')
    print("已切换到物体模式")

def switch_to_sculpt_mode():
    """切换到雕刻模式"""
    bpy.ops.object.mode_set(mode='SCULPT')
    print("已切换到雕刻模式")

def ensure_object_mode(func):
    """确保在物体模式下执行函数的装饰器"""
    def wrapper(*args, **kwargs):
        if bpy.context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        return func(*args, **kwargs)
    return wrapper

@ensure_object_mode
def delete_selected_objects():
    """删除选中的物体（确保在物体模式下执行）"""
    bpy.ops.object.delete(use_global=False)
    print("已删除选中的物体")
```

## 实践示例

### 批量重命名选中物体

这个示例展示了如何使用上下文信息批量重命名选中的物体，结合选中的数量自动编号。

```python
import bpy

def batch_rename_selected(prefix="Cube", start=1):
    """批量重命名选中的物体"""
    selected = bpy.context.selected_objects

    if not selected:
        print("没有选中的物体")
        return

    for i, obj in enumerate(selected):
        new_name = f"{prefix}_{start + i:03d}"
        obj.name = new_name
        print(f"已将 {obj.name} 重命名为 {new_name}")

    print(f"共重命名 {len(selected)} 个物体")

# 使用示例
# batch_rename_selected("Cube", 1)
```

### 选中物体导出信息

这个示例展示了如何收集选中物体的详细信息并输出为报告格式。

```python
import bpy

def export_selected_report():
    """导出选中物体的报告"""
    selected = bpy.context.selected_objects
    report = []

    report.append("=" * 50)
    report.append("选中物体报告")
    report.append("=" * 50)
    report.append(f"选中数量: {len(selected)}")
    report.append("-" * 50)

    for i, obj in enumerate(selected, 1):
        report.append(f"[{i}] {obj.name}")
        report.append(f"    类型: {obj.type}")
        report.append(f"    位置: {obj.location.to_tuple()}")
        report.append(f"    旋转: {obj.rotation_euler.to_tuple()}")
        report.append(f"    缩放: {obj.scale.to_tuple()}")

        if obj.type == 'MESH':
            report.append(f"    顶点数: {len(obj.data.vertices)}")
            report.append(f"    边数: {len(obj.data.edges)}")
            report.append(f"    面数: {len(obj.data.polygons)}")

        report.append("")

    report_text = "\n".join(report)
    print(report_text)

    return report_text

# 使用示例
# export_selected_report()
```

### 快速选择同类物体

这个示例展示了如何根据条件快速选择场景中的同类物体。

```python
import bpy

def select_objects_by_type(obj_type, clear_first=True):
    """选择指定类型的所有物体"""
    if clear_first:
        bpy.ops.object.select_all(action='DESELECT')

    scene = bpy.context.scene

    for obj in scene.objects:
        if obj.type == obj_type:
            obj.select_set(True)
            print(f"已选中: {obj.name}")

    # 确保至少有一个物体被选中（保持活动物体）
    matching = [obj for obj in scene.objects if obj.type == obj_type]
    if matching:
        bpy.context.view_layer.objects.active = matching[0]
        print(f"共选中 {len(matching)} 个 {obj_type} 类型物体")

# 使用示例
# select_objects_by_type('MESH')
# select_objects_by_type('LIGHT')
# select_objects_by_type('CAMERA')
```

## 注意事项

### 上下文时效性

bpy.context 返回的上下文信息是实时变化的，在脚本执行过程中上下文可能因为用户操作或其他脚本而改变。因此，在关键操作前应该重新获取上下文信息，而不是依赖之前保存的状态。对于需要保存上下文以便后续恢复的场景，应该使用 deep_copy 方法。

### 区域依赖性

某些上下文属性依赖于当前激活的区域类型。例如，space_data 在 3D 视图中返回 SpaceView3D，在节点编辑器中返回 SpaceNodeEditor。在编写通用脚本时，应该先检查区域的类型再访问对应的属性。

### 模式依赖性

不同的编辑模式有不同的可用属性和操作。在编辑模式下可以访问网格的几何数据，而在物体模式下则不能。编写模式相关的脚本时，应该先检查当前模式再执行相应的操作。

### 多窗口环境

在多窗口环境中，bpy.context 返回当前执行上下文窗口的状态。如果脚本需要在所有窗口中都能正确运行，需要特别注意上下文的使用，必要时应该遍历所有窗口分别处理。