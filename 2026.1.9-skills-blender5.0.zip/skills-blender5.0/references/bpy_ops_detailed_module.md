# bpy.ops - Blender Operations Reference

Blender 操作符完整参考，涵盖所有可用的操作命令和调用方式。

## Overview

`bpy.ops` 模块包含 Blender 的所有操作符（Operators），用于执行各种操作如创建对象、编辑网格、渲染场景等。操作符是 Blender 命令系统的核心。

## 操作符分类

### 网格操作 (mesh)

```python
import bpy

# 创建几何体
bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0))
bpy.ops.mesh.primitive_cube_add(size=1)  # 在原点创建立方体

bpy.ops.mesh.primitive_uv_sphere_add(radius=1, segments=32, ring_count=16)
bpy.ops.mesh.primitive_cylinder_add(radius=1, depth=2, vertices=32)
bpy.ops.mesh.primitive_cone_add(radius1=1, depth=2, vertices=32)
bpy.ops.mesh.primitive_torus_add(major_radius=1, minor_radius=0.25, major_segments=48, minor_segments=12)
bpy.ops.mesh.primitive_circle_add(radius=1, fill_type='NGON', vertices=32)
bpy.ops.mesh.primitive_grid_add(x_subdivisions=10, y_subdivisions=10, size=2)
bpy.ops.mesh.primitive_monkey_add()

# 网格编辑操作
bpy.ops.mesh.select_all(action='SELECT')      # 全选
bpy.ops.mesh.select_all(action='DESELECT')    # 全不选
bpy.ops.mesh.select_all(action='INVERT')      # 反选
bpy.ops.mesh.select_all(action='TOGGLE')      # 切换选择

bpy.ops.mesh.delete(type='VERT')              # 删除顶点
bpy.ops.mesh.delete(type='EDGE')              # 删除边
bpy.ops.mesh.delete(type='FACE')              # 删除面
bpy.ops.mesh.delete(type='EDGE_FACE')         # 删除边和面
bpy.ops.mesh.delete(type='ONLY_FACE')         # 仅删除面

bpy.ops.mesh.subdivide(number_cuts=1)         # 细分
bpy.ops.mesh.subdivide(number_cuts=2, smoothness=1.0)

bpy.ops.mesh.merge(type='CENTER')             # 合并
bpy.ops.mesh.merge(type='CURSOR')             # 合并到光标
bpy.ops.mesh.merge(type='COLLAPSE')           # 折叠

bpy.ops.mesh.edge_face_add()                  # 添加边/面
bpy.ops.mesh.fill()                           # 填充
bpy.ops.mesh.bevel(offset=0.1, segments=3)    # 倒角

# 变换操作
bpy.ops.transform.translate(value=(1, 0, 0))  # 移动
bpy.ops.transform.rotate(value=0.785)         # 旋转
bpy.ops.transform.resize(value=(1.5, 1.5, 1.5))  # 缩放

# 切变和扭曲
bpy.ops.transform.shear(value=(0, 1, 0))
bpy.ops.transform.distort(type='SPHERE')

# 网格清理
bpy.ops.mesh.decimate(ratio=0.5)              # 三角化简化
bpy.ops.mesh.dissolve_verts()                 # 溶解顶点
bpy.ops.mesh.dissolve_edges()                 # 溶解边
bpy.ops.mesh.dissolve_faces()                 # 溶解面
bpy.ops.mesh.dissolve_limited(angle_limit=0.1)  # 有限角度溶解

# 法线和材质
bpy.ops.mesh.normals_make_consistent(inside=False)
bpy.ops.mesh.flip_normals()
bpy.ops.mesh.set_normals_from_faces()

# 分离和连接
bpy.ops.mesh.separate(type='SELECTED')        # 分离选定
bpy.ops.mesh.separate(type='MATERIAL')        # 按材质分离
bpy.ops.mesh.separate(type='LOOSE')           # 分离 loose 部分
bpy.ops.mesh.join()                           # 连接

# 挤出和内缩
bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value":(0, 0, 1)})
bpy.ops.mesh.extrude_edges_move(TRANSFORM_OT_translate={"value":(0, 0, 1)})
bpy.ops.mesh.inset_individual(use_individual=True)
bpy.ops.mesh.inset_use_outset(False)
```

### 对象操作 (object)

```python
# 对象创建
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.select_all(action='DESELECT')
bpy.ops.object.select_all(action='INVERT')

bpy.ops.object.delete(use_global=False)       # 删除对象

# 复制
bpy.ops.object.duplicate(linked=False, mode='TRANSLATION')
bpy.ops.object.duplicate(linked=True)         # 关联复制

# 变换
bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

# 变换模式
bpy.ops.object.mode_set(mode='OBJECT')
bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.object.mode_set(mode='SCULPT')
bpy.ops.object.mode_set(mode='VERTEX_PAINT')
bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
bpy.ops.object.mode_set(mode='TEXTURE_PAINT')

# 变换操作
bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')

# 对齐
bpy.ops.object.align(objects=[], align_mode='OPT_1', align_axis='X')

# 父子关系
bpy.ops.object.parent_set()
bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
bpy.ops.object.parent_clear(type='CLEAR')

# 约束
bpy.ops.object.constraint_add(type='COPY_LOCATION')
bpy.ops.object.constraint_add(type='COPY_ROTATION')
bpy.ops.object.constraint_add(type='COPY_SCALE')
bpy.ops.object.constraint_add(type='LOOK_AT')
bpy.ops.object.constraint_add(type='TRACK_TO')
bpy.ops.object.constraint_add(type='IK')
bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')

# 修改器
bpy.ops.object.modifier_add(type='SUBSURF')
bpy.ops.object.modifier_add(type='ARMATURE')
bpy.ops.object.modifier_add(type='MIRROR')
bpy.ops.object.modifier_add(type='ARRAY')
bpy.ops.object.modifier_add(type='BEVEL')
bpy.ops.object.modifier_add(type='BOOLEAN')
bpy.ops.object.modifier_add(type='DECIMATE')
bpy.ops.object.modifier_add(type='DISPLACE')
bpy.ops.object.modifier_add(type='SOLIDIFY')
bpy.ops.object.modifier_remove(modifier="Subsurf")

# 应用修改器
bpy.ops.object.modifier_apply(modifier="Subsurf")
bpy.ops.object.modifier_apply_as_shapekey(modifier="Subsurf")

# 集合操作
bpy.ops.object.collection_link(collection=bpy.data.collections[0])
bpy.ops.object.collection_unlink(collection=bpy.data.collections[0])

# 可见性
bpy.ops.object.hide_view_set(unselected=False)
bpy.ops.object.hide_view_clear()
bpy.ops.object.hide_select_set(unselected=False)
```

### 曲线操作 (curve)

```python
# 创建曲线
bpy.ops.curve.primitive_bezier_curve_add(radius=1)
bpy.ops.curve.primitive_bezier_circle_add(radius=1)
bpy.ops.curve.primitive_nurbs_path_add(points=4)
bpy.ops.curve.primitive_nurbs_circle_add()
bpy.ops.curve.primitive_nurbs_curve_add()

# 曲线编辑
bpy.ops.curve.subdivide(number_cuts=1)
bpy.ops.curve.delete(type='VERT')
bpy.ops.curve.duplicate()

# 曲线类型
bpy.ops.curve.cycloid_offset()
bpy.ops.curve.cycloid_offset_add(lower=True)

# 倒角
bpy.ops.curve.bevel_depth_set(0.1)
bpy.ops.curve.bevel_profile(path='Vertex')

# 曲线到网格
bpy.ops.curve.reveal()
bpy.ops.curve.hide(unselected=False)
```

###  armature 操作

```python
# 创建骨骼
bpy.ops.armature.simple_add(length=1)

# 骨骼选择
bpy.ops.armature.select_all(action='SELECT')
bpy.ops.armature.select_hierarchy(direction='PARENT', extend=False)
bpy.ops.armature.select_hierarchy(direction='CHILD', extend=True)

# 骨骼操作
bpy.ops.armature.delete()
bpy.ops.armature.duplicate()
bpy.ops.armature.subdivide(number_cuts=1)

# 骨骼变换
bpy.ops.transform.translate()
bpy.ops.transform.rotate()
bpy.ops.transform.resize()

# 骨骼设置
bpy.ops.armature.autoside_names(axis='XAXIS')
bpy.ops.armature.flip_names()

# 命名规范
bpy.armature.data.bones[0].name = "Bone"
```

### 材质操作 (material)

```python
# 创建材质
bpy.ops.material.new()
bpy.ops.object.material_slot_add()
bpy.ops.object.material_slot_remove()

# 分配材质
bpy.ops.object.material_slot_assign()
bpy.ops.object.material_slot_select()
bpy.ops.object.material_slot_deselect()

# 材质预览
bpy.ops.material.preview_refresh()
```

### 纹理操作 (texture)

```python
# 创建纹理
bpy.ops.texture.new()

# 纹理预览
bpy.ops.texture.preview_refresh()
```

### 渲染操作 (render)

```python
# 渲染
bpy.ops.render.render(write_still=False, use_viewport=False)
bpy.ops.render.render(write_still=True)  # 保存图像

# 动画渲染
bpy.ops.render.render(animation=True)

# 区域渲染
bpy.ops.render.render_border(xmin=0, xmax=100, ymin=0, ymax=100)

# 渲染设置
bpy.ops.render.open_render(filepath="//render.png")

# 视口渲染
bpy.ops.render.view_show()
bpy.ops.render.render(write_still=False, use_viewport=True)
```

### 场景操作 (scene)

```python
# 场景管理
bpy.ops.scene.new(type='EMPTY')
bpy.ops.scene.new(type='LINK_COPY')
bpy.ops.scene.new(type='FULL_COPY')

# 删除场景
bpy.ops.scene.delete()

# 场景设置
bpy.ops.scene.unit_system_assume()

# 清理
bpy.ops.scene.remove_empty()
```

### 文件操作 (file)

```python
# 保存
bpy.ops.wm.save_mainfile(filepath="//test.blend")
bpy.ops.wm.save_as_mainfile(filepath="//test.blend")
bpy.ops.wm.revert_mainfile()

# 导入
bpy.ops.wm.import_mesh(filepath="//model.obj")
bpy.ops.wm.import_curve(filepath="//model.svg")
bpy.ops.wm.import_scene(filepath="//model.fbx")

# 导出
bpy.ops.wm.export_mesh(filepath="//model.obj")
bpy.ops.wm.export_curve(filepath="//model.svg")
bpy.ops.wm.export_scene(filepath="//model.fbx")
```

### 节点操作 (node)

```python
# 节点编辑
bpy.ops.node.select_all(action='SELECT')
bpy.ops.node.select_all(action='DESELECT')
bpy.ops.node.select_all(action='INVERT')

# 节点操作
bpy.ops.node.delete()
bpy.ops.node.duplicate()
bpy.ops.node.copy()

# 链接操作
bpy.ops.node.links_detach()
bpy.ops.node.links_mute(data_path='//')

# 视图操作
bpy.ops.node.view_all()
bpy.ops.node.view_selected()
```

### 动画操作 (anim)

```python
# 关键帧
bpy.ops.keyframe_insert(type='Location')
bpy.ops.keyframe_insert(type='Rotation')
bpy.ops.keyframe_insert(type='Scaling')
bpy.ops.keyframe_insert(type='ALL')

# 删除关键帧
bpy.ops.keyframe_delete(type='Location')
bpy.ops.keyframe_delete(type='ALL')

# 播放控制
bpy.ops.screen.frame_jump(end=False)
bpy.ops.screen.frame_offset(delta=1)
bpy.ops.screen.animation_play()

# NLA 操作
bpy.ops.nla.action_push_down()
bpy.ops.nla.tracks_add()
bpy.ops.nla.tracks_delete()
```

### 3D 视图操作 (view3d)

```python
# 视图导航
bpy.ops.view3d.view_axis(axis='TOP', align_quaternion=(1, 0, 0, 0))
bpy.ops.view3d.view_axis(axis='FRONT')
bpy.ops.view3d.view_axis(axis='RIGHT')

# 相机视图
bpy.ops.view3d.camera_to_view()
bpy.ops.view3d.view_camera()

# 视口设置
bpy.ops.view3d.view_persportho()
bpy.ops.view3d.localview(frame_selected=False)

# 区域选择
bpy.ops.view3d.select_border(xmin=0, xmax=100, ymin=0, ymax=100, extend=False)
bpy.ops.view3d.select_circle(x=100, y=100, radius=10, mode='SET')

# 栅格和吸附
bpy.ops.view3d.snap_cursor_to_selected()
bpy.ops.view3d.snap_cursor_to_center()
bpy.ops.view3d.snap_selected_to_grid()
bpy.ops.view3d.snap_selected_to_cursor()
```

### UI 操作 (ui)

```python
# 撤销/重做
bpy.ops.ed.undo()
bpy.ops.ed.redo()
bpy.ops.ed.undo_history(item=0)

# 复制粘贴
bpy.ops.ui.copy_buffer()
bpy.ops.ui.paste_buffer()

# 自动保存
bpy.ops.ui.auto_repeat_undo()
```

### 文本操作 (text)

```python
# 文本编辑器
bpy.ops.text.new()
bpy.ops.text.open(filepath="//script.py")
bpy.ops.text.save()
bpy.ops.text.save_as(filepath="//script_copy.py")

# 文本编辑
bpy.ops.text.move(type='LINE_BEGIN')
bpy.ops.text.move(type='LINE_END')
bpy.ops.text.delete(type='NEXT_CHARACTER')

# 运行脚本
bpy.ops.text.run_script()
```

### 2D 视图操作 (view2d)

```python
# 2D 视图导航
bpy.ops.view2d.scroller_activate()
bpy.ops.view2d.scroll_left(delta=1)
bpy.ops.view2d.scroll_down(delta=1)

# 视图缩放
bpy.ops.view2d.zoom(delta=1)
bpy.ops.view2d.zoom_in()
bpy.ops.view2d.zoom_out()
```

## 操作符调用模式

### 基本调用

```python
import bpy

# 简单调用
bpy.ops.mesh.primitive_cube_add()

# 带参数调用
bpy.ops.mesh.primitive_uv_sphere_add(radius=2, segments=64, ring_count=32)

# 使用字典传递参数
bpy.ops.transform.translate({"value": (1.0, 0.0, 0.0)})
```

### 返回值处理

```python
result = bpy.ops.mesh.primitive_cube_add()
print(f"结果: {result}")

# 检查是否成功
if result == {'FINISHED'}:
    print("操作成功")
elif result == {'CANCELLED'}:
    print("操作取消")
elif result == {'RUNNING_MODAL'}:
    print("操作正在运行")

# 处理可能的错误
try:
    bpy.ops.object.delete()
except Exception as e:
    print(f"删除失败: {e}")
```

### 操作上下文

```python
# 使用操作符上下文
with bpy.context.temp_override(
    active_object=obj,
    selected_objects=[obj1, obj2]
):
    bpy.ops.object.join()
```

## 常用操作符组合

### 创建并设置对象

```python
def create_configured_cube(name, location, size, material=None):
    """创建配置好的立方体"""
    bpy.ops.mesh.primitive_cube_add(size=size, location=location)
    obj = bpy.context.active_object
    obj.name = name
    
    if material:
        obj.data.materials.append(material)
    
    return obj
```

### 批量处理对象

```python
def batch_transform_objects(translation=(0, 0, 1)):
    """批量变换对象"""
    bpy.ops.object.select_all(action='DESELECT')
    
    for obj in bpy.context.scene.objects:
        if obj.select_get():
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj
            bpy.ops.transform.translate(value=translation)
    
    bpy.ops.object.select_all(action='DESELECT')
```

## 最佳实践

### 1. 正确设置活动对象
```python
bpy.context.view_layer.objects.active = obj
obj.select_set(True)
```

### 2. 使用适当的选择模式
```python
bpy.ops.object.select_all(action='DESELECT')
for obj in target_objects:
    obj.select_set(True)
```

### 3. 处理操作符返回值
```python
result = bpy.ops.mesh.subdivide()
if 'FINISHED' not in result:
    print(f"操作失败: {result}")
```

### 4. 使用 bpy.ops 的注意事项
- bpy.ops 是 Blender 命令的包装器
- 操作符调用会改变上下文状态
- 频繁调用可能影响性能
- 复杂操作考虑使用 bmesh API

## 相关模块

- [bpy.context](bpy_context_module.md) - 上下文访问
- [bpy.types](bpy_types_detailed_module.md) - 数据类型
- [bpy.data](bpy_data_module.md) - 数据访问
