# bpy.ops.cachefile - Cachefile Operations Module

缓存文件操作模块，用于加载和管理几何缓存文件。

## 概述

`bpy.ops.cachefile` 模块提供了Blender几何缓存系统的操作功能，支持打开Alembic（.abc）、USD（.usd）等格式的缓存文件。该模块主要用于动画数据的导入和播放，支持多缓存文件的层叠管理。

## 核心功能

### 文件打开操作

```python
import bpy

# 打开缓存文件
bpy.ops.cachefile.open(
    filepath='',
    hide_props_region=True,
    check_existing=False,
    filter_alembic=True,
    filter_usd=True,
    relative_path=True
)

# 重新加载缓存文件
bpy.ops.cachefile.reload()
```

### 缓存层管理

```python
# 添加缓存层
bpy.ops.cachefile.layer_add(
    filepath='',
    hide_props_region=True,
    check_existing=False,
    filter_alembic=True,
    filter_usd=True,
    relative_path=True
)

# 移动缓存层
bpy.ops.cachefile.layer_move(direction='UP')

# 移除缓存层
bpy.ops.cachefile.layer_remove()
```

## 实用函数

```python
# 加载Alembic缓存文件
def load_alembic_cache(filepath):
    bpy.ops.cachefile.open(
        filepath=filepath,
        filter_alembic=True,
        filter_usd=False,
        relative_path=True
    )

# 加载USD缓存文件
def load_usd_cache(filepath):
    bpy.ops.cachefile.open(
        filepath=filepath,
        filter_alembic=False,
        filter_usd=True,
        relative_path=True
    )

# 切换缓存层顺序
def move_cache_layer(layer_index, direction):
    # 先选中对应的缓存层
    # 然后移动
    bpy.ops.cachefile.layer_move(direction=direction)

# 移除所有缓存层
def remove_all_layers():
    # 获取缓存文件对象
    cachefile = bpy.context.active_object
    if cachefile and cachefile.type == 'CACHE_FILE':
        # 逐个移除层
        while cachefile.cache_layers:
            bpy.ops.cachefile.layer_remove()
```

## 常见问题排查

**问题：缓存文件无法打开**

- 确认文件格式是否受支持（Alembic或USD）
- 检查文件路径是否正确且可访问
- 验证是否安装了相应的插件

**问题：缓存动画不播放**

- 确保对象已正确绑定到缓存
- 检查时间轴范围设置
- 尝试重新加载缓存：`bpy.ops.cachefile.reload()`

**问题：多层缓存冲突**

- 调整缓存层的渲染顺序
- 检查每层的相对路径设置
- 确保不同层的对象名称不冲突

**问题：缓存文件过大导致卡顿**

- 考虑使用分层加载策略
- 优化Alembic/USD导出设置
- 使用`bpy.ops.cachefile.layer_remove()`移除不需要的层

**问题：相对路径失效**

- 检查项目路径设置
- 确保.blend文件已保存
- 验证相对路径的基准位置
