# bpy.ops.view3d 模块

3D视图操作模块，用于控制3D视口显示和交互。

## 概述

bpy.ops.view3d 模块包含用于控制3D视口显示、视角切换、视图导航和交互式操作的运算符。这些运算符控制3D视口的显示方式和用户交互。

## 常用操作

### 视图切换

```python
import bpy

# 切换到顶视图
bpy.ops.view3d.view_axis(type='TOP', align_active=False)

# 切换到底视图
bpy.ops.view3d.view_axis(type='BOTTOM', align_active=False)

# 切换到前视图
bpy.ops.view3d.view_axis(type='FRONT', align_active=False)

# 切换到后视图
bpy.ops.view3d.view_axis(type='BACK', align_active=False)

# 切换到左视图
bpy.ops.view3d.view_axis(type='LEFT', align_active=False)

# 切换到右视图
bpy.ops.view3d.view_axis(type='RIGHT', align_active=False)

# 切换到相机视图
bpy.ops.view3d.view_camera()

# 正交/透视切换
bpy.ops.view3d.view_persportho()
```

### 视图导航

```python
# 缩放
bpy.ops.view3d.zoom(delta=1)

# 放大
bpy.ops.view3d.zoom_in()

# 缩小
bpy.ops.view3d.zoom_out()

# 平移
bpy.ops.view3d.view_pan(type='PANLEFT')
bpy.ops.view3d.view_pan(type='PANRIGHT')
bpy.ops.view3d.view_pan(type='PANUP')
bpy.ops.view3d.view_pan(type='PANDOWN')

# 环绕旋转
bpy.ops.view3d.rotate()

# 旋转视角
bpy.ops.view3d.view_roll(angle=0.7854)

# 聚焦到选中物体
bpy.ops.view3d.view_selected()

# 聚焦到光标位置
bpy.ops.view3d.view_center_cursor()

# 聚焦到原点
bpy.ops.view3d.view_center_lock()

# 平滑缩放
bpy.ops.view3d.zoom_camera_1_to_1()
```

### 视口显示

```python
# 切换X射线显示
bpy.ops.view3d.toggle_xray()

# 切换轮廓线
bpy.ops.view3d.toggle_render_border()

# 切换对称显示
bpy.ops.view3d.toggle_symmetry()

# 切换线框显示
bpy.ops.view3d.toggle_wireframe()

# 切换物体/编辑模式
bpy.ops.view3d.mode_set(mode='EDIT')

# 切换到物体模式
bpy.ops.view3d.mode_set(mode='OBJECT')

# 设置着色方式
bpy.ops.view3d.shade(selected_wire=False)

# 线框着色
bpy.ops.view3d.shade(type='WIREFRAME')

# 实体着色
bpy.ops.view3d.shade(type='SOLID')

# 材质预览
bpy.ops.view3d.shade(type='MATERIAL')
```

### 栅格和参考平面

```python
# 切换栅格显示
bpy.ops.view3d.toggle_grid()

# 切换主栅格线
bpy.ops.view3d.toggle_main_grid()

# 栅格细分级别
bpy.ops.view3d.grid_lines(lines=16)

# 栅格底座
bpy.ops.view3d.toggle_floor()
```

### 3D游标操作

```python
# 设置3D游标位置
bpy.ops.view3d.cursor3d(
    orientation='WORLD',
    use_depth=True
)

# 将选中物体对齐到游标
bpy.ops.view3d.snap_selected_to_cursor(use_offset=True)
bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

# 将游标对齐到选中物体
bpy.ops.view3d.snap_cursor_to_selected()

# 将游标对齐到原点
bpy.ops.view3d.snap_cursor_to_origin()

# 将游标对齐到中心
bpy.ops.view3d.snap_cursor_to_active()

# 游标旋转
bpy.ops.view3d.rotate_cursor_rotate()

# 游标滑动
bpy.ops.view3d.cursor_warp()
```

## 实际应用示例

### 自动聚焦系统

```python
def focus_on_object(obj, zoom_factor=1.0):
    """聚焦到指定物体"""
    # 选中物体
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    
    # 聚焦到选中物体
    bpy.ops.view3d.view_selected(use_all_regions=False)
    
    # 调整缩放
    if zoom_factor != 1.0:
        for _ in range(abs(int(zoom_factor))):
            if zoom_factor > 0:
                bpy.ops.view3d.zoom_in()
            else:
                bpy.ops.view3d.zoom_out()

def focus_cycle(objects):
    """循环聚焦到多个物体"""
    current_index = 0
    
    for i, obj in enumerate(objects):
        if obj.select_get():
            current_index = i
            break
    
    # 移动到下一个
    next_index = (current_index + 1) % len(objects)
    focus_on_object(objects[next_index])
```

### 视图预设保存

```python
def save_view_preset(name, area=None):
    """保存当前视图为预设"""
    if area is None:
        area = bpy.context.area
    
    # 获取当前3D区域的空间
    space = None
    for space in area.spaces:
        if space.type == 'VIEW_3D':
            break
    
    preset = {
        'name': name,
        'pivot_point': str(space.pivot_point),
        'view_matrix': list(space.view_matrix),
        'lens': space.lens,
        'clip_start': space.clip_start,
        'clip_end': space.clip_end,
    }
    
    return preset

def apply_view_preset(preset, area=None):
    """应用视图预设"""
    if area is None:
        area = bpy.context.area
    
    space = None
    for s in area.spaces:
        if s.type == 'VIEW_3D':
            space = s
            break
    
    if space and preset:
        space.pivot_point = preset.get('pivot_point', 'BOUNDING_BOX_CENTER')
        space.lens = preset.get('lens', 50.0)
        space.clip_start = preset.get('clip_start', 0.1)
        space.clip_end = preset.get('clip_end', 1000.0)
```

### 批量视图调整

```python
def set_all_viewports_solid():
    """将所有3D视口设置为实体着色"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    bpy.ops.view3d.shade(type='SOLID')

def reset_all_viewports():
    """重置所有视口设置"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    space.pivot_point = 'BOUNDING_BOX_CENTER'
                    space.lens = 50.0
                    space.clip_start = 0.1
                    space.clip_end = 1000.0
```

## 使用场景

- **视图导航**：缩放、平移、旋转3D视口
- **视角管理**：保存和恢复视图预设
- **视口显示**：切换着色模式、显示选项
- **3D游标控制**：精确定位和对齐
- **自动化操作**：在脚本中控制视图行为
- **多视口编辑**：同时管理多个3D视口

## 注意事项

- 某些操作需要先激活3D视口区域
- 视图矩阵操作可能影响导航体验
- 着色模式影响显示性能
- 3D游标位置影响许多操作的行为
