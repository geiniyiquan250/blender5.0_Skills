# bpy.ops.outliner 模块

大纲视图操作模块，用于管理场景数据块的层级结构。

## 概述

bpy.ops.outliner 模块包含用于在大纲视图中操作和管理场景数据块的运算符。大纲视图显示场景中所有物体的层级结构，包括物体、集合、材质、纹理等数据块。

## 常用操作

### 选择操作

```python
import bpy

# 选中大纲视图中的项目
bpy.ops.outliner.select(extend=False)

# 扩展选择
bpy.ops.outliner.select(extend=True)

# 选中子项
bpy.ops.outliner.select(walk=True, item='CHILD')

# 选中父项
bpy.ops.outliner.select(walk=True, item='PARENT')

# 全选
bpy.ops.outliner.select_all(action='SELECT')

# 取消全选
bpy.ops.outliner.select_all(action='DESELECT')

# 反选
bpy.ops.outliner.select_all(action='INVERT')

# 选择可渲染物体
bpy.ops.outliner.select_all(action='SELECT')
```

### 展开折叠操作

```python
# 展开选中项
bpy.ops.outliner.expanded_toggle(expand=True)

# 折叠选中项
bpy.ops.outliner.expanded_toggle(expand=False)

# 展开所有
bpy.ops.outliner.expand_tree()

# 折叠所有
bpy.ops.outliner.collapse_tree()

# 递归展开
bpy.ops.outliner.show_hierarchy()
```

### 显示隐藏操作

```python
# 隐藏选中项
bpy.ops.outliner.hide(clear=False)

# 显示选中项
bpy.ops.outliner.hide(clear=True)

# 切换可见性
bpy.ops.outliner.visibility_toggle()

# 设置为可渲染
bpy.ops.outliner.render_toggle()

# 设置为不可渲染
bpy.ops.outliner.render_toggle(clear=True)

# 切换选择状态
bpy.ops.outliner.selectability_toggle()
```

### 删除操作

```python
# 删除选中项
bpy.ops.outliner.delete()

# 删除未使用的数据
bpy.ops.outliner.orphans_purge()

# 清除未链接数据
bpy.ops.outliner.unused_data_id()
```

### 搜索过滤操作

```python
# 搜索
bpy.ops.outliner.search(name='Cube')

# 清除搜索
bpy.ops.outliner.search(clear=True)

# 设置过滤模式
bpy.ops.outliner.filter_set(name='MESH')

# 切换过滤器
bpy.ops.outliner.toggle_filter()
```

### 拖拽操作

```python
# 拖拽到集合
bpy.ops.outliner.drag_and_drop(osource_path=())

# 移动到集合
bpy.ops.outliner.collection_drop(clear=False)
```

### 复制粘贴操作

```python
# 复制
bpy.ops.outliner.copy_rna_path()

# 粘贴
bpy.ops.outliner.paste_rna_path(action='COPY')
```

## 实际应用示例

### 清理未使用数据

```python
def purge_unused_data():
    """清理所有未使用的数据块"""
    # 清除未链接的数据
    bpy.ops.outliner.orphans_purge()
    
    # 清除未使用的图像
    for img in bpy.data.images:
        if not img.users:
            bpy.data.images.remove(img)
    
    # 清除未使用的材质
    for mat in bpy.data.materials:
        if not mat.users:
            bpy.data.materials.remove(mat)
    
    # 清除未使用的纹理
    for tex in bpy.data.textures:
        if not tex.users:
            bpy.data.textures.remove(tex)
    
    # 清除未使用的网格
    for mesh in bpy.data.meshes:
        if not mesh.users:
            bpy.data.meshes.remove(mesh)
```

### 批量显示隐藏集合

```python
def toggle_collections_visibility(visible=True):
    """批量设置集合可见性"""
    for collection in bpy.data.collections:
        collection.hide_viewport = not visible
        collection.hide_render = not visible

def hide_all_except(collection_names):
    """隐藏除指定集合外的所有集合"""
    for collection in bpy.data.collections:
        if collection.name in collection_names:
            collection.hide_viewport = False
            collection.hide_render = False
        else:
            collection.hide_viewport = True
            collection.hide_render = True
```

### 展开完整层级结构

```python
def expand_full_hierarchy():
    """展开完整的大纲层级结构"""
    bpy.ops.outliner.expand_tree()

def collapse_to_level(max_depth=2):
    """折叠到指定层级"""
    # 先展开所有
    bpy.ops.outliner.expand_tree()
    
    # 遍历所有集合并折叠深层级
    def collapse_recursive(collection, current_depth):
        if current_depth >= max_depth:
            for child in collection.children:
                for obj in child.objects:
                    pass
            return
        
        for child in collection.children:
            collapse_recursive(child, current_depth + 1)
    
    for collection in bpy.data.collections:
        collapse_recursive(collection, 0)
```

### 搜索特定类型物体

```python
def search_objects_by_type(obj_type='MESH'):
    """搜索特定类型的物体"""
    # 设置过滤器
    bpy.ops.outliner.filter_set(name=obj_type)
    
    # 执行搜索
    results = []
    for obj in bpy.context.scene.objects:
        if obj.type == obj_type:
            results.append(obj)
    
    return results

def search_materials_by_name(keyword):
    """按名称搜索材质"""
    bpy.ops.outliner.filter_set(name='MATERIAL')
    
    results = []
    for mat in bpy.data.materials:
        if keyword.lower() in mat.name.lower():
            results.append(mat)
    
    return results
```

### 管理场景层级结构

```python
def organize_scene_hierarchy():
    """组织场景层级结构"""
    # 创建主集合
    main_col = bpy.ops.collection.create(name='SceneMain')[1]
    
    # 按类型分组
    type_groups = {}
    for obj in bpy.context.scene.objects:
        if obj.type not in type_groups:
            type_col = bpy.ops.collection.create(name=f'Type_{obj.type}')[1]
            type_groups[obj.type] = type_col
            main_col.children.link(type_col)
        
        # 从其他集合移除
        for col in obj.users_collection:
            col.objects.unlink(obj)
        
        # 链接到类型集合
        type_groups[obj.type].objects.link(obj)
    
    return main_col
```

### 重命名层级项目

```python
def rename_with_prefix(prefix):
    """为选中物体添加前缀"""
    bpy.ops.outliner.select(extend=True)
    
    for obj in bpy.context.selected_objects:
        if not obj.name.startswith(prefix):
            obj.name = f'{prefix}_{obj.name}'

def rename_with_suffix(suffix):
    """为选中物体添加后缀"""
    bpy.ops.outliner.select(extend=True)
    
    for obj in bpy.context.selected_objects:
        if not obj.name.endswith(suffix):
            obj.name = f'{obj.name}_{suffix}'
```

## 使用场景

- **场景管理**：组织和清理场景数据
- **层级导航**：在大纲视图中导航复杂的层级结构
- **数据清理**：删除未使用的数据块
- **批量操作**：批量显示/隐藏、选择物体
- **搜索查找**：快速找到特定的物体或数据块
- **集合管理**：管理集合层级结构

## 注意事项

- 大纲视图操作需要正确的上下文
- 删除操作不可逆
- 过滤器设置会影响可见项目
- 层级展开/折叠状态会保存到文件
- 搜索结果受过滤器影响
- 拖拽操作需要正确的拖拽目标
