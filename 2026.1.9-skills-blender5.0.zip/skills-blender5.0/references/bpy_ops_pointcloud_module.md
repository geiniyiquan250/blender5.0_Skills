# bpy.ops.pointcloud 模块

点云操作模块，用于处理和操作3D点云数据。

## 概述

bpy.ops.pointcloud 模块包含用于处理点云数据的运算符。点云是由大量离散点组成的三维数据，常用于三维扫描、激光雷达数据和科学可视化等领域。

## 常用操作

### 点云创建

```python
import bpy

# 从网格创建点云
bpy.ops.object.pointcloud_add_from_mesh()

# 添加空点云
bpy.ops.object.pointcloud_add()

# 从文件导入点云
bpy.ops.import_mesh.pointcloud(filepath="path/to/file.ply")
```

### 点云编辑

```python
# 选择所有点
bpy.ops.pointcloud.select_all(action='SELECT')

# 取消选择
bpy.ops.pointcloud.select_all(action='DESELECT')

# 反选
bpy.ops.pointcloud.select_all(action='INVERT')

# 删除选中点
bpy.ops.pointcloud.delete()

# 复制点云
bpy.ops.pointcloud.duplicate()
```

### 点选择

```python
# 框选点
bpy.ops.pointcloud.select_border(gesture_mode=0, xmin=100, xmax=200, ymin=50, ymax=150)

# 选择随机点
bpy.ops.pointcloud.select_random(percent=50)

# 选择法向一致点
bpy.ops.pointcloud.select_normal()

# 选择最近点
bpy.ops.pointcloud.select_nearest()

# 扩展选择
bpy.ops.pointcloud.select_expand()
```

### 点属性

```python
# 设置点颜色
bpy.ops.pointcloud.color_set(color=(1, 0, 0, 1))

# 设置点大小
bpy.ops.pointcloud.set_radius(radius=0.01)

# 设置点法向
bpy.ops.pointcloud.set_normal(vector=(0, 0, 1))

# 重新计算法向
bpy.ops.pointcloud.recalc_normals()
```

### 过滤器

```python
# 应用统计过滤器
bpy.ops.pointcloud.statistical_outlier_filter(mean_k=10, std_dev=2.0)

# 应用半径过滤器
bpy.ops.pointcloud.radius_outlier_filter(min_points=10, radius=0.05)

# 应用Voxel网格过滤器
bpy.ops.pointcloud.voxel_grid_filter(voxel_size=0.01)
```

## 实际应用示例

### 从网格创建点云

```python
def create_pointcloud_from_mesh(mesh_obj, point_count=10000):
    """从网格创建点云"""
    # 选中网格对象
    bpy.context.view_layer.objects.active = mesh_obj
    mesh_obj.select_set(True)
    
    # 创建点云
    bpy.ops.object.pointcloud_add_from_mesh(
        mesh_obj.name,
        point_count=point_count
    )
    
    # 获取点云对象
    pointcloud_obj = bpy.context.active_object
    pointcloud_obj.name = f'{mesh_obj.name}_PointCloud'
    
    return pointcloud_obj
```

### 创建随机点云

```python
def create_random_pointcloud(count=1000, bounds=((-1, -1, -1), (1, 1, 1))):
    """创建随机点云"""
    import random
    
    # 创建空点云对象
    bpy.ops.object.pointcloud_add()
    pc_obj = bpy.context.active_object
    pc_obj.name = 'RandomPointCloud'
    
    # 添加点数据
    pc = pc_obj.data
    pc.points.add(count)
    
    # 设置随机点位置
    for i in range(count):
        x = random.uniform(bounds[0][0], bounds[1][0])
        y = random.uniform(bounds[0][1], bounds[1][1])
        z = random.uniform(bounds[0][2], bounds[1][2])
        pc.points[i].co = (x, y, z)
    
    return pc_obj
```

### 创建球形点云

```python
def create_spherical_pointcloud(radius=1.0, point_count=1000, hollow=False):
    """创建球形点云"""
    import math
    import random
    
    # 创建空点云
    bpy.ops.object.pointcloud_add()
    pc_obj = bpy.context.active_object
    pc_obj.name = 'SphericalPointCloud'
    
    # 添加点数据
    pc = pc_obj.data
    pc.points.add(point_count)
    
    # 生成球面点
    for i in range(point_count):
        # 均匀分布在球面上
        phi = random.uniform(0, 2 * math.pi)
        costheta = random.uniform(-1, 1)
        theta = math.acos(costheta)
        
        if hollow:
            # 实心球体
            r = radius * random.random() ** (1/3)
        else:
            r = radius
        
        x = r * math.sin(theta) * math.cos(phi)
        y = r * math.sin(theta) * math.sin(phi)
        z = r * math.cos(theta)
        
        pc.points[i].co = (x, y, z)
    
    return pc_obj
```

### 创建圆柱形点云

```python
def create_cylindrical_pointcloud(height=2.0, radius=1.0, point_count=1000):
    """创建圆柱形点云"""
    import math
    import random
    
    # 创建空点云
    bpy.ops.object.pointcloud_add()
    pc_obj = bpy.context.active_object
    pc_obj.name = 'CylindricalPointCloud'
    
    # 添加点数据
    pc = pc_obj.data
    pc.points.add(point_count)
    
    for i in range(point_count):
        theta = random.uniform(0, 2 * math.pi)
        r = radius * math.sqrt(random.random())
        z = random.uniform(-height/2, height/2)
        
        x = r * math.cos(theta)
        y = r * math.sin(theta)
        
        pc.points[i].co = (x, y, z)
    
    return pc_obj
```

### 点云着色

```python
def color_pointcloud_by_height(pc_obj):
    """根据高度着色点云"""
    pc = pc_obj.data
    
    # 获取高度范围
    min_z = min(p.co[2] for p in pc.points)
    max_z = max(p.co[2] for p in pc.points)
    z_range = max_z - min_z or 1
    
    # 设置颜色渐变
    for point in pc.points:
        z = point.co[2]
        ratio = (z - min_z) / z_range
        
        # 蓝色到红色渐变
        point.color = (
            ratio,           # R
            0,               # G
            1 - ratio,       # B
            1.0              # A
        )
```

### 点云着色

```python
def color_pointcloud_by_distance(pc_obj, center=(0, 0, 0)):
    """根据距离着色点云"""
    pc = pc_obj.data
    
    # 计算最大距离
    max_dist = 0
    for point in pc.points:
        dist = ((point.co[0] - center[0])**2 +
                (point.co[1] - center[1])**2 +
                (point.co[2] - center[2])**2)**0.5
        max_dist = max(max_dist, dist)
    
    max_dist = max_dist or 1
    
    # 设置颜色渐变
    for point in pc.points:
        dist = ((point.co[0] - center[0])**2 +
                (point.co[1] - center[1])**2 +
                (point.co[2] - center[2])**2)**0.5
        ratio = dist / max_dist
        
        point.color = (
            ratio,
            1 - ratio,
            0.5,
            1.0
        )
```

### 点云下采样

```python
def downsample_pointcloud(pc_obj, ratio=0.1):
    """点云下采样"""
    pc = pc_obj.data
    
    # 随机选择保留的点
    import random
    total_points = len(pc.points)
    keep_count = int(total_points * ratio)
    
    keep_indices = set(random.sample(range(total_points), keep_count))
    
    # 删除其他点
    for i in range(total_points - 1, -1, -1):
        if i not in keep_indices:
            pc.points.remove(pc.points[i])
```

### 点云过滤

```python
def filter_points_by_bounds(pc_obj, bounds_min, bounds_max):
    """根据边界过滤点云"""
    pc = pc_obj.data
    
    for i in range(len(pc.points) - 1, -1, -1):
        point = pc.points[i]
        
        # 检查是否在边界内
        if (point.co[0] < bounds_min[0] or point.co[0] > bounds_max[0] or
            point.co[1] < bounds_min[1] or point.co[1] > bounds_max[1] or
            point.co[2] < bounds_min[2] or point.co[2] > bounds_max[2]):
            pc.points.remove(point)
```

### 点云转换为网格

```python
def pointcloud_to_mesh(pc_obj):
    """点云转换为网格"""
    # 选中点云对象
    bpy.context.view_layer.objects.active = pc_obj
    pc_obj.select_set(True)
    
    # 转换为网格
    bpy.ops.object.convert(target='MESH')
    
    # 返回新网格对象
    return bpy.context.active_object
```

### 创建点云动画

```python
def create_pointcloud_animation(pc_obj, frame_count=60):
    """创建点云动画"""
    pc = pc_obj.data
    
    for frame in range(frame_count):
        # 设置当前帧
        bpy.context.scene.frame_set(frame)
        
        # 更新点位置
        for i, point in enumerate(pc.points):
            # 简单的波动效果
            x = point.co.x + 0.01 * math.sin(frame * 0.1 + i * 0.1)
            y = point.co.y + 0.01 * math.cos(frame * 0.1 + i * 0.1)
            point.co = (x, y, point.co.z)
        
        # 插入关键帧
        pc.points.foreach_keyframe_insert(data_path='co', frame=frame)
```

### 点云配准模拟

```python
def simulate_pointcloud_registration(pc_static, pc_moving, steps=10):
    """模拟点云配准"""
    # 初始变换
    current_matrix = pc_moving.matrix_world.copy()
    
    for step in range(steps):
        # 计算变换（简化版）
        bpy.context.scene.frame_set(step)
        
        # 简单的插值变换
        progress = step / steps
        new_matrix = current_matrix.copy()
        
        # 这里应该是实际的配准算法
        # 简化示例：逐渐对齐到静态点云位置
        new_matrix.translation = current_matrix.translation * (1 - progress)
        
        # 应用变换
        pc_moving.matrix_world = new_matrix
        
        # 插入关键帧
        pc_moving.matrix_world.keyframe_insert(data_path='location', frame=step)
        pc_moving.matrix_world.keyframe_insert(data_path='rotation_euler', frame=step)
        pc_moving.matrix_world.keyframe_insert(data_path='scale', frame=step)
```

## 使用场景

- **3D扫描数据处理**：处理激光扫描获得的点云数据
- **激光雷达可视化**：处理和可视化LiDAR数据
- **科学数据可视化**：显示三维测量数据
- **计算机视觉**：点云分割和识别
- **逆向工程**：从实物创建数字模型
- **地形建模**：创建地形表面点云
- **建筑测量**：建筑和基础设施测量
- **文化遗产保护**：文物数字化记录

## 注意事项

- 点云数据量可能很大，注意内存使用
- 渲染大量点可能影响性能
- 正确的点大小设置对可视化很重要
- 法向计算影响光照效果
- 定期保存工作进度
- 导入导出时注意文件格式
- 大规模点云需要分块处理
- 注意数据精度和噪声处理
- 配准前需要预处理数据
- 选择合适的过滤器优化数据
