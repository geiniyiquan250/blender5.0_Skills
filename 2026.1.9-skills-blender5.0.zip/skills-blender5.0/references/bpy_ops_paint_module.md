# bpy.ops.paint 模块

纹理绘制操作模块，用于在顶点绘制、权重绘制和纹理绘制模式下进行绘制操作。

## 概述

bpy.ops.paint 模块包含用于在各种绘制模式下执行绘制操作的运算符。这些运算符支持顶点颜色绘制、权重绘制和图像纹理绘制。

## 常用操作

### 通用绘制操作

```python
import bpy

# 执行绘制笔触
bpy.ops.paint.brush_stroke(
    stroke=stroke_data,
    mode='NORMAL',
    ignore_background_click=False
)

# 笔触数据格式
stroke_data = [
    {"name": "", "location": (x, y, z), "mouse": (mx, my), "pressure": 1.0, "time": 0.0, "pen_flip": False, "active": True},
]
```

### 顶点颜色绘制

```python
# 切换到顶点颜色绘制模式
bpy.ops.paint.vertex_paint_toggle()

# 设置顶点颜色
bpy.ops.paint.vertex_color_set()

# 反转顶点颜色
bpy.ops.paint.vertex_color_symmetry_totrace()

# 混合顶点颜色
bpy.ops.paint.vertex_color_from_weight()

# 显示顶点颜色
bpy.ops.paint.vertex_paint_dof(
    mode='SHOW'
)

# 隐藏顶点颜色
bpy.ops.paint.vertex_paint_dof(
    mode='HIDE'
)
```

### 权重绘制

```python
# 切换到权重绘制模式
bpy.ops.paint.weight_paint_toggle()

# 设置权重值
bpy.ops.paint.weight_set()

# 从顶点组名称设置权重
bpy.ops.paint.weight_paint_from_bone_envelopes()

# 对称权重
bpy.ops.paint.weight_symmetry_totrace()

# 清理权重
bpy.ops.paint.weight_clean(threshold=0.01)

# 归一化权重
bpy.ops.paint.normalize_weight_groups()

# 混合权重
bpy.ops.paint.blend_from_mesh()
```

### 图像绘制

```python
# 切换到图像绘制模式
bpy.ops.paint.image_paint_toggle()

# 克隆源设置
bpy.ops.paint.clone_location()
bpy.ops.paint.clone_image_add()

# 投影绘制
bpy.ops.paint.project_image(image_id=0)

# 绘制到岛屿
bpy.ops.paint.image_paint_with_image_id(image_id=0)

# 清除绘制
bpy.ops.paint.image_paint_stroke(
    stroke=stroke_data,
    mode='NORMAL'
)
```

### 选择操作

```python
# 顶点选择
bpy.ops.paint.select_all(action='SELECT')
bpy.ops.paint.select_all(action='DESELECT')
bpy.ops.paint.select_all(action='INVERT')

# 选择连接
bpy.ops.paint.select_linked()
bpy.ops.paint.select_linked_pick(unselected=False)

# 选择更多/更少
bpy.ops.paint.select_more()
bpy.ops.paint.select_less()

# 框选
bpy.ops.paint.border_select()
bpy.ops.paint.circle_select()

# 路径选择
bpy.ops.paint.gradient_select()
```

### 可见性操作

```python
# 隐藏选定
bpy.ops.paint.hide_show(action='HIDE', areas='SELECTED')

# 显示所有
bpy.ops.paint.hide_show(action='SHOW', areas='ALL')

# 反转可见性
bpy.ops.paint.hide_show(action='INVERT', areas='ALL')
```

## 实际应用示例

### 自动化顶点颜色绘制

```python
def apply_vertex_colors(obj, color_data, blend_mode='MIX'):
    """应用顶点颜色数据"""
    # 切换到顶点颜色绘制模式
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.paint.vertex_paint_toggle()
    
    # 获取顶点颜色层
    if not obj.data.vertex_colors:
        obj.data.vertex_colors.new(name="Col")
    
    color_layer = obj.data.vertex_colors.active
    
    # 应用颜色
    for poly in obj.data.polygons:
        for loop_index in poly.loop_indices:
            vertex_index = obj.data.loops[loop_index].vertex_index
            if vertex_index in color_data:
                color = color_data[vertex_index]
                color_layer.data[loop_index].color = (*color, 1.0)
    
    bpy.ops.object.mode_set(mode='OBJECT')
```

### 批量权重转移

```python
def transfer_weights(source_obj, target_obj, vert_indices=None):
    """将权重从源物体转移到目标物体"""
    # 确保两个物体都在权重绘制模式
    bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
    
    # 选择目标物体
    bpy.ops.object.select_all(action='DESELECT')
    target_obj.select_set(True)
    bpy.context.view_layer.objects.active = target_obj
    
    # 设置顶点索引
    if vert_indices is None:
        vert_indices = range(len(target_obj.data.vertices))
    
    # 创建笔触数据
    stroke = []
    for i in vert_indices:
        v = target_obj.data.vertices[i]
        stroke.append({
            "name": f"weight_{i}",
            "location": v.co,
            "mouse": (0, 0),
            "pressure": 1.0,
            "time": i * 0.01,
            "pen_flip": False,
            "active": True
        })
    
    # 执行权重转移
    bpy.ops.paint.weight_paint_stroke(
        stroke=stroke,
        mode='INVERT'
    )
```

### 顶点颜色渐变

```python
def create_vertex_color_gradient(obj, axis='Z', color_start=(1, 0, 0), color_end=(0, 0, 1)):
    """创建沿轴向的顶点颜色渐变"""
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.paint.vertex_paint_toggle()
    
    # 获取顶点颜色层
    if not obj.data.vertex_colors:
        obj.data.vertex_colors.new(name="Col")
    color_layer = obj.data.vertex_colors.active
    
    # 获取轴向范围
    coords = [v.co[{'X': 0, 'Y': 1, 'Z': 2}[axis]] for v in obj.data.vertices]
    min_coord = min(coords)
    max_coord = max(coords)
    range_size = max_coord - min_coord if max_coord != min_coord else 1.0
    
    # 应用渐变颜色
    for loop in obj.data.loops:
        v = obj.data.vertices[loop.vertex_index]
        coord = v.co[{'X': 0, 'Y': 1, 'Z': 2}[axis]]
        t = (coord - min_coord) / range_size
        
        r = color_start[0] + (color_end[0] - color_start[0]) * t
        g = color_start[1] + (color_end[1] - color_start[1]) * t
        b = color_start[2] + (color_end[2] - color_start[2]) * t
        
        color_layer.data[loop.index].color = (r, g, b, 1.0)
    
    bpy.ops.object.mode_set(mode='OBJECT')
```

### 权重清理

```python
def clean_weights(obj, threshold=0.01):
    """清理小于阈值的权重"""
    bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
    
    # 获取所有顶点组
    vgs = obj.vertex_groups
    
    for vg in vgs:
        for v in obj.data.vertices:
            try:
                weight = vg.weight(v.index)
                if weight < threshold:
                    vg.remove([v])
            except Exception:
                pass
    
    bpy.ops.object.mode_set(mode='OBJECT')
```

## 使用场景

- **顶点颜色绘制**：为网格添加顶点颜色数据
- **权重绘制**：编辑顶点权重用于蒙皮
- **纹理绘制**：在3D模型上绘制纹理
- **自动化着色**：批量应用颜色和权重数据
- **数据转移**：将颜色和权重数据转移到其他模型
- **权重清理**：清理无效的权重数据

## 注意事项

- 绘制操作需要先切换到相应的绘制模式
- 顶点颜色需要先创建颜色层
- 权重绘制需要顶点组存在
- 笔触数据需要精确的位置信息
- 批量操作可能影响性能
