# bpy.ops.compositor - 合成器操作模块

bpy.ops.compositor模块提供了合成器（ compositor）节点编辑器中的操作功能，用于管理和编辑合成节点。

## 概述

合成器是Blender中用于图像后期处理的重要工具。这个模块提供了在合成器环境中进行节点操作和渲染设置的操作。

## 核心功能

### 节点操作

```python
import bpy

def add_render_layer_node():
    """添加渲染层节点"""
    bpy.ops.compositor.add_node(
        type='CompositorNodeRLayers',
        use_transform=True
    )

def add_composite_node():
    """添加合成节点"""
    bpy.ops.compositor.add_node(
        type='CompositorNodeComposite',
        use_transform=True
    )

def add_viewer_node():
    """添加查看器节点"""
    bpy.ops.compositor.add_node(
        type='CompositorNodeViewer',
        use_transform=True
    )

def delete_selected_nodes():
    """删除选中节点"""
    bpy.ops.compositor.delete()

def duplicate_nodes():
    """复制节点"""
    bpy.ops.compositor.duplicate()
```

### 节点连接

```python
def link_nodes():
    """链接节点"""
    bpy.ops.compositor.link()

def unlink_nodes():
    """取消链接"""
    bpy.ops.compositor.unlink()

def reroute():
    """添加路由点"""
    bpy.ops.compositor.add_reroute()
```

### 选择操作

```python
def select_all():
    """全选"""
    bpy.ops.compositor.select_all(action='SELECT')

def deselect_all():
    """取消全选"""
    bpy.ops.compositor.select_all(action='DESELECT')

def select_hierarchy():
    """选择层级"""
    bpy.ops.compositor.select_hierarchy(direction='CHILD')

def select_border():
    """框选"""
    bpy.ops.compositor.select_border(extend=False)
```

## 实用函数

### 视口操作

```python
def view_all():
    """查看全部"""
    bpy.ops.compositor.view_all()

def view_selected():
    """查看选中"""
    bpy.ops.compositor.view_selected()

def zoom_in():
    """放大"""
    bpy.ops.compositor.zoom_in()

def zoom_out():
    """缩小"""
    bpy.ops.compositor.zoom_out()
```

### 混合操作

```python
def start_open_render():
    """开始开放渲染"""
    bpy.ops.render.opengl.render(
        animation=False,
        write_still=False
    )

def clear_render_result():
    """清除渲染结果"""
    bpy.ops.render.result_clear()
```

## 常见问题排查

### 节点连接问题

链接失败：
- 确认节点类型兼容
- 检查Socket类型匹配
- 验证输出输入存在

### 渲染问题

渲染失败：
- 检查节点设置正确
- 确认输入数据有效
- 验证输出节点存在
