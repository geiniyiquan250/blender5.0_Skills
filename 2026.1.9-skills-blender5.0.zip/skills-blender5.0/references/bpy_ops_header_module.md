# bpy.ops.header - 标题栏操作模块

Blender标题栏操作符，用于管理编辑器标题栏和菜单。

## 概述

`bpy.ops.header` 模块提供用于操作Blender各种编辑器标题栏的功能，包括菜单控制、工具栏切换和工作区管理。

## 核心功能

### 标题栏菜单

```python
import bpy

# 打开标题栏菜单
bpy.ops.header.menu(
    menu='HEADER_MT_context_menu'
)

# 打开文件菜单
bpy.ops.header.menu(
    menu='TOPBAR_MT_file'
)

# 打开编辑菜单
bpy.ops.header.menu(
    menu='TOPBAR_MT_edit'
)

# 打开渲染菜单
bpy.ops.header.menu(
    menu='TOPBAR_MT_render'
)

# 打开窗口菜单
bpy.ops.header.menu(
    menu='TOPBAR_MT_window'
)

# 打开帮助菜单
bpy.ops.header.menu(
    menu='TOPBAR_MT_help'
)
```

### 区域菜单

```python
# 打开区域菜单
bpy.ops.header.menu(
    menu='HEADER_MT_area'
)

# 打开视图菜单
bpy.ops.header.menu(
    menu='HEADER_MT_view'
)

# 打开选择菜单
bpy.ops.header.menu(
    menu='HEADER_MT_select'
)

# 打开编辑菜单
bpy.ops.header.menu(
    menu='HEADER_MT_edit'
)

# 打开对象菜单
bpy.ops.header.menu(
    menu='HEADER_MT_object'
)

# 打开标记菜单
bpy.ops.header.menu(
    menu='HEADER_MT_marker'
)
```

### 标题栏选择

```python
# 选择标题栏
bpy.ops.header.select(
    extend=False,
    deselect=False,
    toggle=False,
    deselect_all=True
)

# 全选标题栏
bpy.ops.header.select_all(
    action='SELECT'
)

# 取消全选标题栏
bpy.ops.header.select_all(
    action='DESELECT'
)

# 反选标题栏
bpy.ops.header.select_all(
    action='INVERT'
)
```

### 标题栏绘制

```python
# 刷新标题栏
bpy.ops.header.reports_banner_update()

# 更新标题栏
bpy.ops.header.header_update()

# 重绘标题栏
bpy.ops.header.draw(
    draw=COLLECTION_EDITOR_HT_header
)
```

### 工具栏操作

```python
# 切换工具栏
bpy.ops.screen.toolbar_prompt(
    tool_name='builtin.move'
)

# 展开工具栏
bpy.ops.screen.toolbar_prompt(
    tool_name='builtin.move',
    prompt='OPEN'
)

# 收起工具栏
bpy.ops.screen.toolbar_prompt(
    tool_name='builtin.move',
    prompt='CLOSE'
)
```

### 工作区操作

```python
# 添加工作区
bpy.ops.wm.workspace_add()

# 删除工作区
bpy.ops.wm.workspace_remove(
    workspace='默认'
)

# 切换到下一个工作区
bpy.ops.wm.workspace_cycle(
    direction='NEXT'
)

# 切换到上一个工作区
bpy.ops.wm.workspace_cycle(
    direction='PREV'
)

# 重命名工作区
bpy.ops.wm.workspace_duplicate()
```

### 区域操作

```python
# 最大化区域
bpy.ops.screen.screen_full_area(
    use_hide_panels=False
)

# 退出全屏
bpy.ops.screen.screen_full_area(
    use_hide_panels=True
)

# 翻转区域
bpy.ops.screen.region_flip()

# 区域查找
bpy.ops.screen.region_flip()
```

## 实用函数

```python
def show_workspace_menu():
    """显示工作区菜单"""
    bpy.ops.header.menu(menu='WORKSPACE_MT_selector')

def show_toolbar():
    """显示工具栏"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = True

def hide_toolbar():
    """隐藏工具栏"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.show_region_toolbar = False

def show_header():
    """显示标题栏"""
    for area in bpy.context.screen.areas:
        area.show_menus = True

def hide_header():
    """隐藏标题栏"""
    for area in bpy.context.screen.areas:
        area.show_menus = False

def toggle_fullscreen():
    """切换全屏"""
    bpy.ops.screen.screen_full_area()

def cycle_workspace_next():
    """切换到下一个工作区"""
    bpy.ops.wm.workspace_cycle(direction='NEXT')

def cycle_workspace_prev():
    """切换到上一个工作区"""
    bpy.ops.wm.workspace_cycle(direction='PREV')

def add_workspace(name='New Workspace'):
    """添加工作区"""
    bpy.ops.wm.workspace_add()
    ws = bpy.data.workspaces[-1]
    ws.name = name

def duplicate_workspace():
    """复制当前工作区"""
    bpy.ops.wm.workspace_duplicate()
```

## 常见问题排查

### 标题栏不显示
```python
# 检查区域类型
area = bpy.context.area
print(f"区域类型: {area.type}")
print(f"显示菜单: {area.show_menus}")

# 启用菜单
area.show_menus = True

# 刷新UI
bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
```

### 工作区丢失
```python
# 检查工作区
print(f"工作区数: {len(bpy.data.workspaces)}")
for ws in bpy.data.workspaces:
    print(f"工作区: {ws.name}")

# 切换工作区
for ws in bpy.data.workspaces:
    if ws.name == 'Layout':
        bpy.context.window.workspace = ws
        break

# 添加新工作区
bpy.ops.wm.workspace_add()
```

### 工具栏问题
```python
# 检查工具栏状态
space = bpy.context.area.spaces.active
print(f"工具栏: {space.show_region_toolbar}")
print(f"UI面板: {space.show_region_ui}")
print(f"工具设置: {space.show_region_toolbar}")

# 启用工具栏
space.show_region_toolbar = True

# 重置工具
bpy.ops.wm.tool_set_by_id(name='builtin.move')
```

### 全屏问题
```python
# 检查当前状态
print(f"全屏: {bpy.context.area.spaces.active.use_fullscreen}")

# 退出全屏
if bpy.context.area.spaces.active.use_fullscreen:
    bpy.ops.screen.screen_full_area()

# 检查多边形编辑器状态
print(f"多边形编辑器: {bpy.context.area.spaces.active.show_region_toolbar}")
```
