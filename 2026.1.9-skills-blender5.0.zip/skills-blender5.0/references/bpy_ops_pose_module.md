# bpy.ops.pose - Pose Operations Module

Blender 姿态操作符，用于在姿态模式下进行骨骼姿态的编辑、关键帧和动画控制。

## Overview

`bpy.ops.pose` 模块包含姿态编辑器中的所有操作命令，涵盖骨骼选择、姿态编辑、关键帧操作、约束管理和动画控制等功能。这个模块主要用于角色绑定和骨骼动画编辑。

## 核心功能

### 骨骼选择操作

```python
import bpy
import math

# 全选
bpy.ops.pose.select_all(action='SELECT')

# 全不选
bpy.ops.pose.select_all(action='DESELECT')

# 反选
bpy.ops.pose.select_all(action='INVERT')

# 选择层级
bpy.ops.pose.select_hierarchy(direction='PARENT', extend=False)
bpy.ops.pose.select_hierarchy(direction='CHILD', extend=False)
bpy.ops.pose.select_hierarchy(direction='PARENT', extend=True)
bpy.ops.pose.select_hierarchy(direction='CHILD', extend=True)

# 选择对称
bpy.ops.pose.select_mirror(only_active=False)

# 选择链接
bpy.ops.pose.select_linked(extend=False)

# 选择键选择
bpy.ops.pose.select_keyed()

# 选择保护
bpy.ops.pose.select_protected(extend=False)

# 选择约束
bpy.ops.pose.select_constrainted()

def select_all_bones():
    """选择所有骨骼"""
    bpy.ops.pose.select_all(action='SELECT')
    return [bone for bone in bpy.context.active_object.pose.bones if bone.bone.select]

def deselect_all_bones():
    """取消选择所有骨骼"""
    bpy.ops.pose.select_all(action='DESELECT')

def select_bone_chain(start_bone, direction='CHILD', extend=True):
    """选择骨骼链"""
    bpy.context.active_pose_bone = start_bone
    bpy.ops.pose.select_hierarchy(direction=direction, extend=extend)

def select_child_bones(bone, recursive=True):
    """选择子骨骼"""
    bpy.ops.pose.select_all(action='DESELECT')
    bone.bone.select = True
    bpy.context.active_pose_bone = bone
    
    if recursive:
        for child in bone.children:
            select_child_bones(child, True)

def select_parent_bones(bone, recursive=True):
    """选择父骨骼"""
    bpy.ops.pose.select_all(action='DESELECT')
    bone.bone.select = True
    bpy.context.active_pose_bone = bone
    
    if recursive and bone.parent:
        select_parent_bones(bone.parent, True)

def select_symmetric_bones():
    """选择对称骨骼"""
    bpy.ops.pose.select_mirror(only_active=False)
```

### 姿态变换操作

```python
# 清除变换
bpy.ops.pose.rot_clear(delta=False)
bpy.ops.pose.loc_clear(delta=False)
bpy.ops.pose.scale_clear(delta=False)
bpy.ops.pose.transform_clear(type='ALL')

# 应用姿态
bpy.ops.pose.armature_apply()
bpy.ops.pose.apply_pose_use_current()

# 复制姿态
bpy.ops.pose.copy()

# 粘贴姿态
bpy.ops.pose.paste(flip=False)

# 镜像姿态
bpy.ops.pose.flip(left_side=True, right_side=True)

# 复制定位
bpy.ops.pose.copy_location()

# 粘贴定位
bpy.ops.pose.paste_location(flip=False)

# 复制旋转
bpy.ops.pose.copy_rotation()

# 粘贴旋转
bpy.ops.pose.paste_rotation(flip=False)

# 复制缩放
bpy.ops.pose.copy_scale()

# 粘贴缩放
bpy.ops.pose.paste_scale(flip=False)

def clear_all_transforms():
    """清除所有变换"""
    bpy.ops.pose.rot_clear()
    bpy.ops.pose.loc_clear()
    bpy.ops.pose.scale_clear()

def reset_pose_to_rest():
    """重置姿态到休息姿态"""
    bpy.ops.pose.select_all(action='SELECT')
    bpy.ops.pose.transform_clear(type='ALL')

def copy_pose_to_clipboard():
    """复制姿态到剪贴板"""
    bpy.ops.pose.copy()

def paste_pose_from_clipboard(flip=False):
    """从剪贴板粘贴姿态"""
    bpy.ops.pose.paste(flip=flip)

def mirror_pose(left_side=True, right_side=True):
    """镜像姿态"""
    bpy.ops.pose.flip(left_side=left_side, right_side=right_side)

def copy_location_only():
    """仅复制位置"""
    bpy.ops.pose.copy_location()

def paste_location_only(flip=False):
    """仅粘贴位置"""
    bpy.ops.pose.paste_location(flip=flip)

def copy_rotation_only():
    """仅复制旋转"""
    bpy.ops.pose.copy_rotation()

def paste_rotation_only(flip=False):
    """仅粘贴旋转"""
    bpy.ops.pose.paste_rotation(flip=flip)

def copy_scale_only():
    """仅复制缩放"""
    bpy.ops.pose.copy_scale()

def paste_scale_only(flip=False):
    """仅粘贴缩放"""
    bpy.ops.pose.paste_scale(flip=flip)

def apply_current_pose():
    """应用当前姿态"""
    bpy.ops.pose.armature_apply()
```

### 关键帧操作

```python
# 插入关键帧
bpy.ops.pose.keyframe_insert()

# 删除关键帧
bpy.ops.pose.keyframe_delete()

# 清除关键帧
bpy.ops.pose.keyframe_clear()

# 插入所有关键帧
bpy.ops.pose.keyframe_insert(data_path='location')
bpy.ops.pose.keyframe_insert(data_path='rotation_euler')
bpy.ops.pose.keyframe_insert(data_path='rotation_quaternion')
bpy.ops.pose.keyframe_insert(data_path='scale')

def insert_keyframe_all():
    """为所有选中的骨骼插入关键帧"""
    bpy.ops.pose.select_all(action='SELECT')
    bpy.ops.pose.keyframe_insert()

def insert_keyframe_location():
    """为位置插入关键帧"""
    bpy.ops.pose.keyframe_insert(data_path='location')

def insert_keyframe_rotation():
    """为旋转插入关键帧"""
    bpy.ops.pose.keyframe_insert(data_path='rotation_euler')

def insert_keyframe_scale():
    """为缩放插入关键帧"""
    bpy.ops.pose.keyframe_insert(data_path='scale')

def delete_all_keyframes():
    """删除所有关键帧"""
    bpy.ops.pose.keyframe_delete()

def clear_all_keyframes():
    """清除所有关键帧"""
    bpy.ops.pose.keyframe_clear()

def keyframe_selected_bones():
    """为选中的骨骼插入关键帧"""
    bpy.ops.pose.keyframe_insert()

def keyframe_protected_bones():
    """为受保护的骨骼插入关键帧"""
    bpy.ops.pose.select_protected(extend=False)
    bpy.ops.pose.keyframe_insert()
```

### 约束操作

```python
# 添加约束
bpy.ops.pose.constraint_add(type='COPY_LOCATION')
bpy.ops.pose.constraint_add(type='COPY_ROTATION')
bpy.ops.pose.constraint_add(type='COPY_SCALE')
bpy.ops.pose.constraint_add(type='IK')
bpy.ops.pose.constraint_add(type='STRETCH_TO')
bpy.ops.pose.constraint_add(type='TRACK_TO')
bpy.ops.pose.constraint_add(type='LOOK_AT')
bpy.ops.pose.constraint_add(type='FOLLOW_PATH')
bpy.ops.pose.constraint_add(type='LIMIT_ROTATION')

# 约束添加（带目标）
bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')

# 复制约束
bpy.ops.pose.constraint_copy()

# 粘贴约束
bpy.ops.pose.constraint_paste()

# 删除约束
bpy.ops.pose.constraint_remove()

# 移动约束
bpy.ops.pose.constraint_move(type='COPY_LOCATION', direction='UP')
bpy.ops.pose.constraint_move(type='COPY_LOCATION', direction='DOWN')

def add_copy_location_constraint(target, bone, name="CopyLocation"):
    """添加位置复制约束"""
    constraint = bone.constraints.new(type='COPY_LOCATION')
    constraint.target = target
    constraint.subtarget = ""
    constraint.influence = 1.0
    return constraint

def add_copy_rotation_constraint(target, bone, name="CopyRotation"):
    """添加旋转复制约束"""
    constraint = bone.constraints.new(type='COPY_ROTATION')
    constraint.target = target
    constraint.subtarget = ""
    constraint.influence = 1.0
    return constraint

def add_ik_constraint(target, bone, chain_count=2):
    """添加反向动力学约束"""
    constraint = bone.constraints.new(type='IK')
    constraint.target = target
    constraint.chain_count = chain_count
    constraint.use_tail = False
    return constraint

def add_stretch_to_constraint(target, bone):
    """添加伸展约束"""
    constraint = bone.constraints.new(type='STRETCH_TO')
    constraint.target = target
    constraint.rest_length = bone.length
    constraint.gradient = 1.0
    return constraint

def add_track_to_constraint(target, bone):
    """添加朝向约束"""
    constraint = bone.constraints.new(type='TRACK_TO')
    constraint.target = target
    constraint.track_axis = 'TRACK_Z'
    constraint.up_axis = 'UP_Y'
    return constraint

def remove_all_constraints(bone):
    """移除所有约束"""
    for constraint in list(bone.constraints):
        bone.constraints.remove(constraint)

def copy_constraint(source_bone, dest_bone, constraint_name):
    """复制约束"""
    for constraint in source_bone.constraints:
        if constraint.name == constraint_name:
            new_constraint = constraint.copy()
            dest_bone.constraints.append(new_constraint)
            return new_constraint
    return None
```

### 骨骼变换操作

```python
# 变换
bpy.ops.transform.rotate(value=math.radians(45), orient_axis='Z')

# 平移
bpy.ops.transform.translate(value=(1, 0, 0))

# 缩放
bpy.ops.transform.resize(value=(1.5, 1.5, 1.5))

# 缩放骨骼
bpy.ops.transform.bbone_resize(value=(1, 1, 1))

# 变换到活动
bpy.ops.pose.transforms_to_deltas(mode='ALL')

# 增量为零
bpy.ops.pose.locrotmode_toggle()

# 自动 IK
bpy.ops.pose.auto_ik_clear()

def rotate_bone(bone, angle, axis='Z'):
    """旋转骨骼"""
    if axis == 'X':
        bone.rotation_euler.x = math.radians(angle)
    elif axis == 'Y':
        bone.rotation_euler.y = math.radians(angle)
    elif axis == 'Z':
        bone.rotation_euler.z = math.radians(angle)

def set_bone_location(bone, x, y, z):
    """设置骨骼位置"""
    bone.location = (x, y, z)

def set_bone_scale(bone, x, y, z):
    """设置骨骼缩放"""
    bone.scale = (x, y, z)

def reset_bone_transform(bone):
    """重置骨骼变换"""
    bone.location = (0, 0, 0)
    bone.rotation_euler = (0, 0, 0)
    bone.scale = (1, 1, 1)

def transform_to_deltas(mode='ALL'):
    """变换到增量"""
    bpy.ops.pose.transforms_to_deltas(mode=mode)
```

### 骨骼编辑操作

```python
# 骨骼显示
bpy.ops.pose.bone_layers(layers=[True, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False])

# 切换可见性
bpy.ops.pose.collada_export()

# 骨骼命名
bpy.ops.pose.autoside_names(axis='X')

# 对称命名
bpy.ops.pose.flip_names()

def set_bone_layer(bone, layer_index):
    """设置骨骼层"""
    for i in range(32):
        bone.bone.layers[i] = (i == layer_index)

def show_bone_layer(layer_index):
    """显示骨骼层"""
    bpy.ops.pose.bone_layers(layers=[i == layer_index for i in range(32)])

def hide_other_layers(current_layer):
    """隐藏其他层"""
    layers = [i == current_layer for i in range(32)]
    bpy.ops.pose.bone_layers(layers=layers)

def auto_rename_bones(axis='X'):
    """自动重命名骨骼"""
    bpy.ops.pose.autoside_names(axis=axis)

def flip_bone_names():
    """翻转骨骼名称"""
    bpy.ops.pose.flip_names()
```

## 实用姿态操作

### 姿态管理

```python
import bpy

class PoseManager:
    """姿态管理器"""
    
    @staticmethod
    def save_pose(name):
        """保存当前姿态"""
        pose = bpy.context.active_object.pose
        saved_pose = {}
        
        for bone in pose.bones:
            if bone.bone.select:
                saved_pose[bone.name] = {
                    'location': bone.location.copy(),
                    'rotation_euler': bone.rotation_euler.copy(),
                    'rotation_quaternion': bone.rotation_quaternion.copy(),
                    'scale': bone.scale.copy(),
                }
        
        return saved_pose
    
    @staticmethod
    def load_pose(pose_data, frame=None):
        """加载姿态"""
        pose = bpy.context.active_object.pose
        
        for bone_name, transform in pose_data.items():
            if bone_name in pose:
                bone = pose[bone_name]
                bone.location = transform['location']
                bone.rotation_euler = transform['rotation_euler']
                bone.rotation_quaternion = transform['rotation_quaternion']
                bone.scale = transform['scale']
                
                if frame is not None:
                    bone.keyframe_insert(data_path='location', frame=frame)
                    bone.keyframe_insert(data_path='rotation_euler', frame=frame)
                    bone.keyframe_insert(data_path='scale', frame=frame)
    
    @staticmethod
    def blend_poses(pose1, pose2, factor):
        """混合两个姿态"""
        blended = {}
        
        for bone_name in pose1:
            if bone_name in pose2:
                blended[bone_name] = {
                    'location': pose1[bone_name]['location'].lerp(pose2[bone_name]['location'], factor),
                    'rotation_euler': pose1[bone_name]['rotation_euler'].lerp(pose2[bone_name]['rotation_euler'], factor),
                    'scale': pose1[bone_name]['scale'].lerp(pose2[bone_name]['scale'], factor),
                }
        
        return blended
    
    @staticmethod
    def mirror_pose_data(pose_data):
        """镜像姿态数据"""
        mirrored = {}
        
        for bone_name, transform in pose_data.items():
            mirrored_name = bone_name.replace('.L', '.R').replace('.R', '.L')
            mirrored[mirrored_name] = {
                'location': (-transform['location'][0], transform['location'][1], transform['location'][2]),
                'rotation_euler': (-transform['rotation_euler'][0], -transform['rotation_euler'][1], transform['rotation_euler'][2]),
                'rotation_quaternion': transform['rotation_quaternion'].copy(),
                rotation_quaternion[0] *= -1
                rotation_quaternion[1] *= -1
                mirrored[mirrored_name] = {
                    'location': mirrored_location,
                    'rotation_euler': mirrored_rotation,
                    'scale': transform['scale'],
                }
        
        return mirrored

def save_current_pose(name):
    """保存当前姿态"""
    return PoseManager.save_pose(name)

def load_saved_pose(pose_data):
    """加载保存的姿态"""
    PoseManager.load_pose(pose_data)

def blend_poses_animated(pose1_data, pose2_data, start_frame, end_frame):
    """动画混合两个姿态"""
    frames = end_frame - start_frame
    for i in range(frames + 1):
        factor = i / frames
        blended = PoseManager.blend_poses(pose1_data, pose2_data, factor)
        PoseManager.load_pose(blended, frame=start_frame + i)
```

### IK 和 FK 控制

```python
import bpy
import math

class IKFKController:
    """IK/FK 控制器"""
    
    def __init__(self, armature):
        self.armature = armature
        self.pose = armature.pose
    
    def set_ik_fk_blend(self, ik_fk_value, bone_chain):
        """设置 IK/FK 混合值"""
        # ik_fk_value: 0 = FK, 1 = IK
        for bone in bone_chain:
            if "ik_fk" in bone:
                bone["ik_fk"] = ik_fk_value
    
    def switch_to_ik(self, end_bone, pole_target):
        """切换到 IK 模式"""
        # 添加 IK 约束
        ik_bone = end_bone
        constraint = ik_bone.constraints.new(type='IK')
        constraint.target = pole_target
        constraint.chain_length = 2
        
        # 隐藏 FK 控制
        for bone in self.pose.bones:
            if bone != end_bone and bone != pole_target:
                bone.bone.hide = True
    
    def switch_to_fk(self, bone_chain):
        """切换到 FK 模式"""
        # 移除 IK 约束
        for bone in bone_chain:
            for constraint in list(bone.constraints):
                if constraint.type == 'IK':
                    bone.constraints.remove(constraint)
    
    def create_pole_target(self, name, location):
        """创建极目标"""
        bpy.ops.object.empty_add(type='SPHERE', location=location)
        pole = bpy.context.active_object
        pole.name = name
        return pole

def setup_ik_chain(armature_obj, end_bone_name, pole_name="PoleTarget"):
    """设置 IK 链"""
    end_bone = armature_obj.pose.bones[end_bone_name]
    
    # 创建极目标
    pole_location = (end_bone.matrix @ bpy.types.PoseBone.location).to_3d()
    pole_location.y -= 1.0  # 放在后面
    
    pole = IKFKController(armature_obj).create_pole_target(pole_name, pole_location)
    
    # 添加 IK 约束
    constraint = end_bone.constraints.new(type='IK')
    constraint.target = armature_obj
    constraint.subtarget = pole.name
    constraint.chain_length = 2
    
    return pole

def toggle_ik_fk(armature, bone_name, value):
    """切换 IK/FK"""
    bone = armature.pose.bones[bone_name]
    if "ik_fk" not in bone:
        bone["ik_fk"] = 0.0
    
    bone["ik_fk"] = max(0, min(1, bone["ik_fk"] + value))
    return bone["ik_fk"]
```

### 动画姿态创建

```python
import bpy
import math

def create_walk_cycle(armature, frames_per_step=12):
    """创建行走循环动画"""
    # 设置帧率
    bpy.context.scene.render.fps = 30
    
    # 初始姿态
    set_neutral_pose(armature)
    
    # 关键帧
    for step in range(4):
        frame = step * frames_per_step
        
        if step % 2 == 0:
            set_walk_left_pose(armature, frame)
        else:
            set_walk_right_pose(armature, frame)
    
    # 循环
    armature.animation_data.action.use_cyclic = True

def set_neutral_pose(armature, frame=1):
    """设置中性姿态"""
    for bone in armature.pose.bones:
        bone.rotation_euler = (0, 0, 0)
        bone.location = (0, 0, 0)
        bone.scale = (1, 1, 1)
        bone.keyframe_insert(data_path='rotation_euler', frame=frame)
        bone.keyframe_insert(data_path='location', frame=frame)
        bone.keyframe_insert(data_path='scale', frame=frame)

def set_walk_left_pose(armature, frame):
    """设置左脚行走姿态"""
    # 左腿向前
    left_leg = armature.pose.bones.get("Thigh.L")
    if left_leg:
        left_leg.rotation_euler.x = math.radians(30)
        left_leg.keyframe_insert(data_path='rotation_euler', frame=frame)
    
    # 右腿向后
    right_leg = armature.pose.bones.get("Thigh.R")
    if right_leg:
        right_leg.rotation_euler.x = math.radians(-30)
        right_leg.keyframe_insert(data_path='rotation_euler', frame=frame)
    
    # 左臂向后
    left_arm = armature.pose.bones.get("UpperArm.L")
    if left_arm:
        left_arm.rotation_euler.x = math.radians(-30)
        left_arm.keyframe_insert(data_path='rotation_euler', frame=frame)
    
    # 右臂向前
    right_arm = armature.pose.bones.get("UpperArm.R")
    if right_arm:
        right_arm.rotation_euler.x = math.radians(30)
        right_arm.keyframe_insert(data_path='rotation_euler', frame=frame)

def set_walk_right_pose(armature, frame):
    """设置右脚行走姿态"""
    # 左腿向后
    left_leg = armature.pose.bones.get("Thigh.L")
    if left_leg:
        left_leg.rotation_euler.x = math.radians(-30)
        left_leg.keyframe_insert(data_path='rotation_euler', frame=frame)
    
    # 右腿向前
    right_leg = armature.pose.bones.get("Thigh.R")
    if right_leg:
        right_leg.rotation_euler.x = math.radians(30)
        right_leg.keyframe_insert(data_path='rotation_euler', frame=frame)
    
    # 左臂向前
    left_arm = armature.pose.bones.get("UpperArm.L")
    if left_arm:
        left_arm.rotation_euler.x = math.radians(30)
        left_arm.keyframe_insert(data_path='rotation_euler', frame=frame)
    
    # 右臂向后
    right_arm = armature.pose.bones.get("UpperArm.R")
    if right_arm:
        right_arm.rotation_euler.x = math.radians(-30)
        right_arm.keyframe_insert(data_path='rotation_euler', frame=frame)

def create_bounce_animation(armature, bounce_height=0.1, duration=30):
    """创建弹跳动画"""
    for frame in range(duration + 1):
        t = frame / duration
        
        # 正弦波
        y_offset = math.sin(t * 2 * math.pi) * bounce_height
        
        # 应用于根骨骼
        root = armature.pose.bones[0]
        root.location.y = y_offset
        root.keyframe_insert(data_path='location', frame=frame + 1)
```

## 姿态工程面板

```python
class PoseEngineeringPanel(bpy.types.Panel):
    """姿态工程面板"""
    bl_label = "姿态工具"
    bl_idname = "POSE_PT_pose_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '姿态'
    
    def draw(self, context):
        layout = self.layout
        obj = context.object
        
        if not obj or obj.type != 'ARMATURE':
            layout.label(text="请选择骨架对象")
            return
        
        layout.label(text="骨骼操作:")
        
        row = layout.row(align=True)
        row.operator("pose.select_all", text="全选").action='SELECT'
        row.operator("pose.select_all", text="反选").action='INVERT'
        
        row = layout.row()
        row.operator("pose.select_hierarchy", text="子骨骼").direction='CHILD'
        row.operator("pose.select_hierarchy", text="父骨骼").direction='PARENT'
        
        layout.separator()
        layout.label(text="姿态:")
        
        row = layout.row(align=True)
        row.operator("pose.copy", text="复制")
        row.operator("pose.paste", text="粘贴")
        
        row = layout.row()
        row.operator("pose.flip", text="镜像")
        row.operator("pose.apply_pose_use_current", text="应用")
        
        row = layout.row()
        row.operator("pose.rot_clear", text="清除旋转")
        row.operator("pose.loc_clear", text="清除位置")
        row.operator("pose.scale_clear", text="清除缩放")
        
        layout.separator()
        layout.label(text="关键帧:")
        
        row = layout.row(align=True)
        row.operator("pose.keyframe_insert", text="插入")
        row.operator("pose.keyframe_delete", text="删除")
        
        layout.separator()
        layout.label(text="约束:")
        
        row = layout.row()
        row.operator("pose.constraint_add", text="添加").type='COPY_LOCATION'
        row.operator("pose.constraint_remove", text="移除")
        
        row = layout.row()
        row.operator("pose.copy_constraint", text="复制")
        row.operator("pose.paste_constraint", text="粘贴")
```

## 最佳实践

### 1. 骨骼命名规范

```python
def apply_bone_naming(prefix, armature):
    """应用骨骼命名规范"""
    for i, bone in enumerate(armature.data.bones):
        bone.name = f"{prefix}_{i:02d}"

def create_bone_pairs(left_bone, right_bone):
    """创建骨骼对"""
    # 检查是否是左右对
    left_suffixes = ['.L', '_L', '_left', '.left']
    right_suffixes = ['.R', '_R', '_right', '.right']
    
    if any(left_bone.name.endswith(s) for s in left_suffixes):
        counterpart = left_bone.name
        for s in left_suffixes:
            counterpart = counterpart.replace(s, '')
        for s in right_suffixes:
            if left_bone.name.endswith(s.replace('_', '')):
                counterpart += s
            else:
                counterpart += s
        return counterpart
    return None
```

### 2. 姿态优化

```python
def optimize_keyframes(armature, threshold=0.001):
    """优化关键帧"""
    if not armature.animation_data or not armature.animation_data.action:
        return
    
    action = armature.animation_data.action
    
    for fcurve in action.fcurves:
        keyframe_points = list(fcurve.keyframe_points)
        
        for i in range(len(keyframe_points) - 1):
            curr = keyframe_points[i]
            next_kp = keyframe_points[i + 1]
            
            if abs(curr.co.y - next_kp.co.y) < threshold:
                fcurve.keyframe_points.remove(next_kp)
```

### 3. 姿态验证

```python
def validate_pose(armature):
    """验证姿态"""
    issues = []
    
    for bone in armature.pose.bones:
        # 检查旋转
        for i, angle in enumerate(bone.rotation_euler):
            if abs(angle) > math.pi * 2:
                issues.append(f"骨骼 {bone.name} 旋转超出范围")
        
        # 检查缩放
        for i, scale in enumerate(bone.scale):
            if scale < 0 or scale > 10:
                issues.append(f"骨骼 {bone.name} 缩放超出范围")
        
        # 检查约束
        for constraint in bone.constraints:
            if constraint.target is None:
                issues.append(f"骨骼 {bone.name} 的约束 {constraint.name} 没有目标")
    
    return issues
```

## 常见问题

### Q: 姿态不显示
A: 确保在姿态模式下，检查骨骼是否在正确层级。

### Q: 关键帧不工作
A: 检查是否在正确的场景中，确保动作已分配给骨架。

### Q: IK 不工作
A: 检查目标是否存在，确保链条长度正确设置。

### Q: 约束冲突
A: 检查约束顺序，确保没有冲突的约束。

## 相关模块

- [bpy.ops.armature](bpy_ops_armature_module.md) - 骨骼操作
- [bpy.ops.object](bpy_ops_object_module.md) - 对象操作
- [bpy.ops.animation](bpy_ops_animation_module.md) - 动画操作
- [bpy.types](bpy_types_detailed_module.md) - 数据类型
