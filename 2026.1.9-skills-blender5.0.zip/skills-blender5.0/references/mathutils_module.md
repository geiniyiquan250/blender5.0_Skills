# mathutils Module Reference

mathutils 模块提供数学运算工具，用于向量、矩阵、四元数、欧拉角和颜色运算。

## Vector (向量)

向量用于表示 3D 空间中的方向和位置。

### 创建向量

```python
import mathutils

# 创建 2D 向量
vec2 = mathutils.Vector((1.0, 2.0))

# 创建 3D 向量
vec3 = mathutils.Vector((1.0, 2.0, 3.0))

# 创建 4D 向量
vec4 = mathutils.Vector((1.0, 2.0, 3.0, 4.0))

# 从列表创建
vec = mathutils.Vector([1.0, 2.0, 3.0])

# 从元组创建
vec = mathutils.Vector((1.0, 2.0, 3.0))
```

### 向量属性

```python
vec = mathutils.Vector((1.0, 2.0, 3.0))

# 向量长度
length = vec.length

# 向量长度的平方
length_squared = vec.length_squared

# 向量维度
size = len(vec)

# 归一化向量
normalized = vec.normalized()

# 向量是否归一化
is_normalized = vec.is_normalized

# 向量是否为零
is_zero = vec.is_zero
```

### 向量运算

```python
vec1 = mathutils.Vector((1.0, 2.0, 3.0))
vec2 = mathutils.Vector((4.0, 5.0, 6.0))

# 加法
result = vec1 + vec2

# 减法
result = vec1 - vec2

# 乘法 (标量)
result = vec1 * 2.0

# 除法 (标量)
result = vec1 / 2.0

# 点积
dot = vec1.dot(vec2)

# 叉积
cross = vec1.cross(vec2)

# 反射
reflected = vec1.reflect(vec2)

# 投影
projected = vec1.project(vec2)

# 线性插值
result = vec1.lerp(vec2, 0.5)

# 球面线性插值
result = vec1.slerp(vec2, 0.5)

# 旋转
rotated = vec1.rotate(mathutils.Euler((0.0, 0.0, math.radians(45))))

# 复制
copied = vec1.copy()
```

### 向量方法

```python
vec = mathutils.Vector((1.0, 2.0, 3.0))

# 归一化
vec.normalize()

# 反转向量
vec.negate()

# 缩放到指定长度
vec.resize(5.0)

# 获取角度
angle = vec.angle(vec2)

# 获取距离
distance = vec.distance(vec2)

# 获取距离的平方
distance_squared = vec.distance_squared(vec2)

# 获取中点
midpoint = vec.midpoint(vec2)

# 正交化
vec.orthogonalize(vec2)

# 旋转
vec.rotate(euler)

# 获取 XYZ 分量
x = vec.x
y = vec.y
z = vec.z

# 设置 XYZ 分量
vec.x = 1.0
vec.y = 2.0
vec.z = 3.0

# 转换为元组
tuple_vec = tuple(vec)

# 转换为列表
list_vec = list(vec)
```

## Matrix (矩阵)

矩阵用于表示变换。

### 创建矩阵

```python
import mathutils

# 创建单位矩阵
matrix = mathutils.Matrix()

# 创建 3x3 矩阵
matrix_3x3 = mathutils.Matrix((
    (1.0, 0.0, 0.0),
    (0.0, 1.0, 0.0),
    (0.0, 0.0, 1.0)
))

# 创建 4x4 矩阵
matrix_4x4 = mathutils.Matrix((
    (1.0, 0.0, 0.0, 0.0),
    (0.0, 1.0, 0.0, 0.0),
    (0.0, 0.0, 1.0, 0.0),
    (0.0, 0.0, 0.0, 1.0)
))

# 从列表创建
matrix = mathutils.Matrix([
    [1.0, 0.0, 0.0, 0.0],
    [0.0, 1.0, 0.0, 0.0],
    [0.0, 0.0, 1.0, 0.0],
    [0.0, 0.0, 0.0, 1.0]
])
```

### 矩阵构造方法

```python
# 平移矩阵
matrix = mathutils.Matrix.Translation((1.0, 2.0, 3.0))

# 旋转矩阵
matrix = mathutils.Matrix.Rotation(math.radians(45), 4, 'Z')

# 缩放矩阵
matrix = mathutils.Matrix.Scale(2.0, 4)

# 正交矩阵
matrix = mathutils.Matrix.OrthoProjection('Z', 4, 4, 0, 10)

# 视图矩阵
matrix = mathutils.Matrix.LookAt(
    eye=(0.0, -10.0, 0.0),
    target=(0.0, 0.0, 0.0),
    up=(0.0, 0.0, 1.0)
)

# 透视投影矩阵
matrix = mathutils.Matrix.PerspectiveProjection(
    fov=math.radians(45),
    aspect=1.0,
    near=0.1,
    far=100.0
)

# 从四元数创建矩阵
quat = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
matrix = quat.to_matrix().to_4x4()

# 从欧拉角创建矩阵
euler = mathutils.Euler((math.radians(45), 0.0, 0.0))
matrix = euler.to_matrix().to_4x4()
```

### 矩阵属性

```python
matrix = mathutils.Matrix()

# 矩阵维度
rows = len(matrix)
cols = len(matrix[0])

# 矩阵是否可逆
is_invertible = matrix.is_invertible

# 矩阵是否正交
is_orthogonal = matrix.is_orthogonal

# 矩阵是否单位矩阵
is_identity = matrix.is_identity

# 矩阵行列式
determinant = matrix.determinant()

# 矩阵迹
trace = matrix.trace()

# 矩阵转置
transposed = matrix.transposed()

# 矩阵逆
inverse = matrix.inverted()

# 矩阵伴随
adjugate = matrix.adjugate()

# 矩阵缩放因子
scale = matrix.to_scale()

# 矩阵旋转部分
rotation = matrix.to_quaternion()

# 矩阵平移部分
translation = matrix.to_translation()

# 矩阵欧拉角
euler = matrix.to_euler()
```

### 矩阵运算

```python
mat1 = mathutils.Matrix()
mat2 = mathutils.Matrix()
vec = mathutils.Vector((1.0, 2.0, 3.0))

# 矩阵乘法
result = mat1 @ mat2

# 矩阵向量乘法
result = mat1 @ vec

# 矩阵加法
result = mat1 + mat2

# 矩阵减法
result = mat1 - mat2

# 矩阵标量乘法
result = mat1 * 2.0

# 矩阵标量除法
result = mat1 / 2.0

# 矩阵幂运算
result = mat1 ** 2

# 矩阵插值
result = mat1.lerp(mat2, 0.5)

# 矩阵分解
translation, rotation, scale = mat1.decompose()

# 矩阵重新组合
matrix = mathutils.Matrix.LocRotScale(translation, rotation, scale)
```

### 矩阵方法

```python
matrix = mathutils.Matrix()

# 重置为单位矩阵
matrix.identity()

# 转置矩阵
matrix.transpose()

# 求逆矩阵
if matrix.is_invertible:
    matrix.invert()

# 归一化矩阵
matrix.normalize()

# 缩放矩阵
matrix.scale(scale_vector)

# 旋转矩阵
matrix.rotate(rotation_matrix)

# 平移矩阵
matrix.translate(translation_vector)

# 复制矩阵
copied = matrix.copy()

# 转换为 3x3 矩阵
matrix_3x3 = matrix.to_3x3()

# 转换为 4x4 矩阵
matrix_4x4 = matrix.to_4x4()

# 转换为列表
list_matrix = list(matrix)

# 转换为元组
tuple_matrix = tuple(tuple(row) for row in matrix)
```

## Euler (欧拉角)

欧拉角用于表示旋转。

### 创建欧拉角

```python
import mathutils
import math

# 创建欧拉角
euler = mathutils.Euler((math.radians(45), math.radians(30), math.radians(60)))

# 指定旋转顺序
euler = mathutils.Euler((math.radians(45), math.radians(30), math.radians(60)), 'XYZ')

# 从四元数创建
quat = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
euler = quat.to_euler()

# 从矩阵创建
matrix = mathutils.Matrix.Rotation(math.radians(45), 4, 'Z')
euler = matrix.to_euler()
```

### 欧拉角属性

```python
euler = mathutils.Euler((math.radians(45), math.radians(30), math.radians(60)))

# 旋转角度
x_angle = euler.x
y_angle = euler.y
z_angle = euler.z

# 旋转顺序
order = euler.order

# 转换为度数
x_deg = math.degrees(euler.x)
y_deg = math.degrees(euler.y)
z_deg = math.degrees(euler.z)

# 转换为四元数
quat = euler.to_quaternion()

# 转换为矩阵
matrix = euler.to_matrix()

# 复制欧拉角
copied = euler.copy()
```

### 欧拉角运算

```python
euler1 = mathutils.Euler((math.radians(45), 0.0, 0.0))
euler2 = mathutils.Euler((0.0, math.radians(30), 0.0))

# 欧拉角加法
result = euler1 + euler2

# 欧拉角减法
result = euler1 - euler2

# 欧拉角乘法
result = euler1 * 2.0

# 欧拉角除法
result = euler1 / 2.0

# 欧拉角插值
result = euler1.lerp(euler2, 0.5)

# 欧拉角旋转
result = euler1.rotate(euler2)

# 欧拉角反转
result = -euler1

# 欧拉角归一化
result = euler1.normalized()
```

## Quaternion (四元数)

四元数用于表示旋转，避免万向节锁问题。

### 创建四元数

```python
import mathutils
import math

# 创建四元数 (w, x, y, z)
quat = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))

# 从轴角创建
quat = mathutils.Quaternion((0.0, 0.0, 1.0), math.radians(45))

# 从欧拉角创建
euler = mathutils.Euler((math.radians(45), 0.0, 0.0))
quat = euler.to_quaternion()

# 从矩阵创建
matrix = mathutils.Matrix.Rotation(math.radians(45), 4, 'Z')
quat = matrix.to_quaternion()

# 单位四元数
identity = mathutils.Quaternion()

# 旋转四元数
quat = mathutils.Quaternion.RotationDifference(vec1, vec2)
```

### 四元数属性

```python
quat = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))

# 四元数分量
w = quat.w
x = quat.x
y = quat.y
z = quat.z

# 四元数长度
length = quat.length

# 四元数是否归一化
is_normalized = quat.is_normalized

# 四元数共轭
conjugate = quat.conjugated()

# 四元数逆
inverse = quat.inverted()

# 四元数轴角
axis, angle = quat.to_axis_angle()

# 转换为欧拉角
euler = quat.to_euler()

# 转换为矩阵
matrix = quat.to_matrix()

# 复制四元数
copied = quat.copy()
```

### 四元数运算

```python
quat1 = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
quat2 = mathutils.Quaternion((0.0, 0.0, 0.0, 1.0))
vec = mathutils.Vector((1.0, 0.0, 0.0))

# 四元数乘法
result = quat1 @ quat2

# 四元数向量旋转
result = quat1 @ vec

# 四元数插值
result = quat1.lerp(quat2, 0.5)

# 球面线性插值
result = quat1.slerp(quat2, 0.5)

# 四元数归一化
quat1.normalize()

# 四元数旋转
quat1.rotate(quat2)

# 四元数反转
result = -quat1

# 四元数点积
dot = quat1.dot(quat2)

# 四元数指数
result = quat1.exp()

# 四元数对数
result = quat1.log()

# 四元数幂
result = quat1 ** 2
```

## Color (颜色)

颜色用于表示 RGB 和 HSV 颜色空间。

### 创建颜色

```python
import mathutils

# 创建 RGB 颜色
color = mathutils.Color((1.0, 0.5, 0.0))

# 创建 HSV 颜色
color = mathutils.Color()
color.hsv = (0.1, 0.8, 0.9)

# 从十六进制创建
color = mathutils.Color()
color.rgb = (0xFF / 255.0, 0x80 / 255.0, 0x00 / 255.0)

# 复制颜色
copied = color.copy()
```

### 颜色属性

```python
color = mathutils.Color((1.0, 0.5, 0.0))

# RGB 分量
r = color.r
g = color.g
b = color.b

# HSV 分量
h, s, v = color.hsv

# 亮度
brightness = color.v

# 饱和度
saturation = color.s

# 色相
hue = color.h

# 转换为元组
tuple_color = tuple(color)

# 转换为列表
list_color = list(color)

# 转换为十六进制
hex_color = f"#{int(color.r * 255):02x}{int(color.g * 255):02x}{int(color.b * 255):02x}"
```

### 颜色运算

```python
color1 = mathutils.Color((1.0, 0.0, 0.0))
color2 = mathutils.Color((0.0, 1.0, 0.0))

# 颜色加法
result = color1 + color2

# 颜色减法
result = color1 - color2

# 颜色乘法
result = color1 * 2.0

# 颜色除法
result = color1 / 2.0

# 颜色插值
result = color1.lerp(color2, 0.5)

# 颜色混合
result = color1.mix(color2, 0.5)

# 颜色反转
result = -color1

# 颜色亮度调整
color1.brightness = 0.8

# 颜色饱和度调整
color1.saturation = 0.6

# 颜色色相调整
color1.hue = 0.3
```

## 实用工具函数

### mathutils.geometry

几何运算工具函数。

```python
import mathutils.geometry

# 计算三角形面积
area = mathutils.geometry.area_tri(v1, v2, v3)

# 计算三角形法线
normal = mathutils.geometry.normal(v1, v2, v3)

# 计算点到线段的距离
distance = mathutils.geometry.distance_point_to_line(point, line_start, line_end)

# 计算点到平面的距离
distance = mathutils.geometry.distance_point_to_plane(point, plane_co, plane_no)

# 计算线段相交
intersect = mathutils.geometry.intersect_line_line(line1_start, line1_end, line2_start, line2_end)

# 计算线段平面相交
intersect = mathutils.geometry.intersect_line_plane(line_start, line_end, plane_co, plane_no)

# 计算三角形相交
intersect = mathutils.geometry.intersect_ray_tri(v1, v2, v3, ray_origin, ray_direction)

# 计算球体相交
intersect = mathutils.geometry.intersect_sphere_sphere(center1, radius1, center2, radius2)

# 计算包围盒
bbox = mathutils.geometry.box_fit_2d(points)
bbox = mathutils.geometry.box_fit_3d(points)
```

### mathutils.noise

噪声函数。

```python
import mathutils.noise

# 柏林噪声
value = mathutils.noise.noise(position)

# 湍流噪声
value = mathutils.noise.turbulence(position, octaves=6, hard=True)

# 分形布朗运动
value = mathutils.noise.fractal(position, H=1.0, lacunarity=2.0, octaves=6)

# 混合噪声
value = mathutils.noise.hybrid_multi_fractal(position, H=1.0, lacunarity=2.0, octaves=6)

# 多重分形
value = mathutils.noise.multi_fractal(position, H=1.0, lacunarity=2.0, octaves=6)

# 异向噪声
value = mathutils.noise.hetero_terrain(position, H=1.0, lacunarity=2.0, octaves=6)

# 山脊噪声
value = mathutils.noise.ridged_multi_fractal(position, H=1.0, lacunarity=2.0, octaves=6)

# 沃利噪声
value = mathutils.noise.voronoi(position)
```

## 完整示例：3D 变换系统

```python
import bpy
import mathutils
import math

# 创建变换系统
class TransformSystem:
    def __init__(self):
        self.position = mathutils.Vector((0.0, 0.0, 0.0))
        self.rotation = mathutils.Quaternion()
        self.scale = mathutils.Vector((1.0, 1.0, 1.0))
        
    def get_matrix(self):
        """获取变换矩阵"""
        translation_matrix = mathutils.Matrix.Translation(self.position)
        rotation_matrix = self.rotation.to_matrix().to_4x4()
        scale_matrix = mathutils.Matrix.Scale(self.scale.x, 4, (1.0, 0.0, 0.0))
        scale_matrix @= mathutils.Matrix.Scale(self.scale.y, 4, (0.0, 1.0, 0.0))
        scale_matrix @= mathutils.Matrix.Scale(self.scale.z, 4, (0.0, 0.0, 1.0))
        
        return translation_matrix @ rotation_matrix @ scale_matrix
    
    def set_matrix(self, matrix):
        """从矩阵设置变换"""
        self.position = matrix.to_translation()
        self.rotation = matrix.to_quaternion()
        self.scale = matrix.to_scale()
    
    def translate(self, translation):
        """平移"""
        self.position += translation
    
    def rotate(self, axis, angle):
        """绕轴旋转"""
        rotation_quat = mathutils.Quaternion(axis, angle)
        self.rotation = rotation_quat @ self.rotation
    
    def scale_by(self, scale_factor):
        """缩放"""
        self.scale *= scale_factor
    
    def look_at(self, target, up=(0.0, 0.0, 1.0)):
        """看向目标"""
        direction = (target - self.position).normalized()
        up_vector = mathutils.Vector(up).normalized()
        
        # 计算旋转矩阵
        z_axis = direction
        x_axis = up_vector.cross(z_axis).normalized()
        y_axis = z_axis.cross(x_axis)
        
        rotation_matrix = mathutils.Matrix((
            (x_axis.x, y_axis.x, z_axis.x),
            (x_axis.y, y_axis.y, z_axis.y),
            (x_axis.z, y_axis.z, z_axis.z)
        ))
        
        self.rotation = rotation_matrix.to_quaternion()
    
    def interpolate(self, other, factor):
        """插值到另一个变换"""
        self.position = self.position.lerp(other.position, factor)
        self.rotation = self.rotation.slerp(other.rotation, factor)
        self.scale = self.scale.lerp(other.scale, factor)

# 使用示例
transform = TransformSystem()

# 设置位置
transform.position = mathutils.Vector((2.0, 3.0, 1.0))

# 旋转
transform.rotate(mathutils.Vector((0.0, 0.0, 1.0)), math.radians(45))

# 缩放
transform.scale_by(2.0)

# 看向目标
transform.look_at(mathutils.Vector((0.0, 0.0, 0.0)))

# 获取变换矩阵
matrix = transform.get_matrix()

print(f"位置: {transform.position}")
print(f"旋转: {transform.rotation}")
print(f"缩放: {transform.scale}")
print(f"变换矩阵:\n{matrix}")
```

## 性能优化建议

1. **避免频繁创建对象**：重用向量、矩阵等对象，而不是频繁创建新对象
2. **使用原地操作**：对于需要修改的向量，使用 `vec.rotate()` 而不是 `vec = vec.rotated()`
3. **批量操作**：使用矩阵运算进行批量变换，而不是逐个变换
4. **使用适当的数学结构**：根据需求选择向量、四元数或欧拉角
5. **缓存计算结果**：对于重复使用的计算结果，进行缓存
6. **使用 numpy 集成**：对于大量数值计算，考虑使用 numpy 集成
    up=(0.0, 0.0, 1.0)
)
```

### 矩阵运算

```python
mat1 = mathutils.Matrix(((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)))
mat2 = mathutils.Matrix(((2.0, 0.0, 0.0), (0.0, 2.0, 0.0), (0.0, 0.0, 2.0)))

# 矩阵乘法
result = mat1 @ mat2

# 向量乘法
vec = mathutils.Vector((1.0, 2.0, 3.0))
result = mat1 @ vec

# 矩阵求逆
inverted = mat1.inverted()

# 矩阵转置
transposed = mat1.transposed()

# 矩阵行列式
determinant = mat1.determinant()

# 矩阵复制
copied = mat1.copy()
```

### 矩阵分解

```python
matrix = mathutils.Matrix((
    (1.0, 0.0, 0.0, 1.0),
    (0.0, 1.0, 0.0, 2.0),
    (0.0, 0.0, 1.0, 3.0),
    (0.0, 0.0, 0.0, 1.0)
))

# 分解为平移、旋转、缩放
loc, rot, scale = matrix.decompose()

# 获取平移
location = matrix.translation

# 获取旋转
rotation = matrix.to_quaternion()
rotation = matrix.to_euler()

# 获取缩放
scale = matrix.to_scale()
```

## Quaternion (四元数)

四元数用于表示旋转。

### 创建四元数

```python
import mathutils

# 创建单位四元数
quat = mathutils.Quaternion()

# 从轴和角度创建
quat = mathutils.Quaternion((0.0, 0.0, 1.0), math.radians(45))

# 从欧拉角创建
euler = mathutils.Euler((0.0, 0.0, math.radians(45)))
quat = euler.to_quaternion()

# 从矩阵创建
matrix = mathutils.Matrix.Rotation(math.radians(45), 4, 'Z')
quat = matrix.to_quaternion()

# 从分量创建
quat = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
```

### 四元数属性

```python
quat = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))

# 四元数分量
w = quat.w
x = quat.x
y = quat.y
z = quat.z

# 四元数角度
angle = quat.angle

# 四元数轴
axis = quat.axis

# 四元数是否归一化
is_normalized = quat.is_normalized

# 四元数是否为零
is_zero = quat.is_zero
```

### 四元数运算

```python
quat1 = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
quat2 = mathutils.Quaternion((0.0, 1.0, 0.0, 0.0))

# 四元数乘法
result = quat1 @ quat2

# 四元数共轭
conjugated = quat1.conjugated()

# 四元数求逆
inverted = quat1.inverted()

# 四元数归一化
normalized = quat1.normalized()

# 四元数点积
dot = quat1.dot(quat2)

# 四元数旋转
rotated = quat1.rotate(quat2)

# 四元数线性插值
result = quat1.slerp(quat2, 0.5)

# 四元数复制
copied = quat1.copy()
```

### 四元数方法

```python
quat = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))

# 归一化
quat.normalize()

# 反转
quat.invert()

# 共轭
quat.conjugate()

# 旋转向量
vec = mathutils.Vector((1.0, 0.0, 0.0))
rotated = quat @ vec

# 转换为欧拉角
euler = quat.to_euler()

# 转换为矩阵
matrix = quat.to_matrix()

# 转换为轴和角度
axis, angle = quat.to_axis_angle()
```

## Euler (欧拉角)

欧拉角用于表示旋转。

### 创建欧拉角

```python
import mathutils

# 创建欧拉角
euler = mathutils.Euler((0.0, 0.0, 0.0))

# 从四元数创建
quat = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
euler = quat.to_euler()

# 从矩阵创建
matrix = mathutils.Matrix.Rotation(math.radians(45), 4, 'Z')
euler = matrix.to_euler()

# 指定旋转顺序
euler = mathutils.Euler((0.0, 0.0, math.radians(45)), 'XYZ')
```

### 欧拉角属性

```python
euler = mathutils.Euler((0.0, 0.0, 0.0))

# 欧拉角分量
x = euler.x
y = euler.y
z = euler.z

# 旋转顺序
order = euler.order  # 'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'

# 是否包装
is_wrapped = euler.is_wrapped
```

### 欧拉角运算

```python
euler1 = mathutils.Euler((0.0, 0.0, 0.0))
euler2 = mathutils.Euler((0.0, 0.0, math.radians(45)))

# 欧拉角加法
result = euler1 + euler2

# 欧拉角减法
result = euler1 - euler2

# 欧拉角复制
copied = euler1.copy()
```

### 欧拉角方法

```python
euler = mathutils.Euler((0.0, 0.0, 0.0))

# 包装角度
euler.make_compatible(other_euler)

# 归一化
euler.normalize()

# 转换为四元数
quat = euler.to_quaternion()

# 转换为矩阵
matrix = euler.to_matrix()

# 旋转向量
vec = mathutils.Vector((1.0, 0.0, 0.0))
rotated = euler.to_quaternion() @ vec
```

## Color (颜色)

颜色用于表示 RGBA 颜色。

### 创建颜色

```python
import mathutils

# 创建颜色
color = mathutils.Color((1.0, 0.0, 0.0))

# 从十六进制创建
color = mathutils.Color((1.0, 0.0, 0.0))
color.from_hex('#FF0000')

# 从 HSV 创建
color = mathutils.Color()
color.from_hsv((0.0, 1.0, 1.0))
```

### 颜色属性

```python
color = mathutils.Color((1.0, 0.0, 0.0))

# 颜色分量
r = color.r
g = color.g
b = color.b

# 颜色复制
copied = color.copy()
```

### 颜色运算

```python
color1 = mathutils.Color((1.0, 0.0, 0.0))
color2 = mathutils.Color((0.0, 1.0, 0.0))

# 颜色加法
result = color1 + color2

# 颜色减法
result = color1 - color2

# 颜色乘法 (标量)
result = color1 * 2.0

# 颜色除法 (标量)
result = color1 / 2.0

# 颜色混合
result = color1.blend(color2, 0.5)
```

### 颜色方法

```python
color = mathutils.Color((1.0, 0.0, 0.0))

# 转换为 HSV
hsv = color.hsv

# 从 HSV 设置
color.hsv = (0.0, 1.0, 1.0)

# 转换为十六进制
hex_str = color.to_hex()

# 从十六进制设置
color.from_hex('#FF0000')

# 饱和度
color.saturate(0.5)

# 反转颜色
color.invert()

# 复制
copied = color.copy()
```

## 常用数学函数

```python
import mathutils

# 线性插值
result = mathutils.lerp(0.0, 10.0, 0.5)

# 球面线性插值
result = mathutils.slerp(0.0, 10.0, 0.5)

# 限制值
result = mathutils.clamp(5.0, 0.0, 10.0)

# 向下取整
result = mathutils.floor(5.7)

# 向上取整
result = mathutils.ceil(5.3)

# 四舍五入
result = mathutils.round(5.5)

# 模运算
result = mathutils.modulo(5.0, 2.0)

# 吸附
result = mathutils.snap(5.7, 1.0)
```

## 几何运算

```python
import mathutils

# 点到线的距离
point = mathutils.Vector((0.0, 0.0, 0.0))
line_p1 = mathutils.Vector((1.0, 0.0, 0.0))
line_p2 = mathutils.Vector((2.0, 0.0, 0.0))
distance = mathutils.geometry.point_line_distance(point, line_p1, line_p2)

# 点到面的距离
plane_co = mathutils.Vector((0.0, 0.0, 0.0))
plane_no = mathutils.Vector((0.0, 0.0, 1.0))
distance = mathutils.geometry.distance_point_to_plane(point, plane_co, plane_no)

# 线段相交
intersect = mathutils.geometry.intersect_line_line_2d(
    line_a_p1, line_a_p2,
    line_b_p1, line_b_p2
)

# 三角形重心
barycentric = mathutils.geometry.barycentric_transform(
    point,
    tri_a, tri_b, tri_c,
    tri_a_new, tri_b_new, tri_c_new
)

# 多边形面积
area = mathutils.geometry.area_tri(p1, p2, p3)
```

## 实用示例

### 计算两点距离

```python
import mathutils

point1 = mathutils.Vector((0.0, 0.0, 0.0))
point2 = mathutils.Vector((1.0, 1.0, 1.0))
distance = (point1 - point2).length
```

### 计算两个向量夹角

```python
import mathutils

vec1 = mathutils.Vector((1.0, 0.0, 0.0))
vec2 = mathutils.Vector((0.0, 1.0, 0.0))
angle = vec1.angle(vec2)
```

### 旋转向量

```python
import mathutils

vec = mathutils.Vector((1.0, 0.0, 0.0))
euler = mathutils.Euler((0.0, 0.0, math.radians(45)))
rotated = vec.rotate(euler)
```

### 创建变换矩阵

```python
import mathutils

# 平移
translation = mathutils.Matrix.Translation((1.0, 2.0, 3.0))

# 旋转
rotation = mathutils.Matrix.Rotation(math.radians(45), 4, 'Z')

# 缩放
scale = mathutils.Matrix.Scale(2.0, 4)

# 组合变换
transform = translation @ rotation @ scale
```

### 颜色混合

```python
import mathutils

color1 = mathutils.Color((1.0, 0.0, 0.0))
color2 = mathutils.Color((0.0, 1.0, 0.0))
blended = color1.blend(color2, 0.5)
```

### 欧拉角转四元数

```python
import mathutils

euler = mathutils.Euler((0.0, 0.0, math.radians(45)))
quat = euler.to_quaternion()
```

### 四元数转矩阵

```python
import mathutils

quat = mathutils.Quaternion((0.0, 0.0, 1.0), math.radians(45))
matrix = quat.to_matrix().to_4x4()
```
