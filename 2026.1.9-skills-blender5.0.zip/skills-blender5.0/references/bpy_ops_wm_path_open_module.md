# bpy.ops.wm - 路径打开操作模块

Blender窗口管理器路径操作符，用于打开文件路径和URL。

## 概述

`bpy.ops.wm.path_open` 模块提供用于在文件管理器中打开指定路径的功能，支持文件、目录和URL的打开。

## 核心功能

### 打开文件路径

```python
import bpy

# 打开文件
bpy.ops.wm.path_open(
    filepath='//file.txt'
)

# 打开目录
bpy.ops.wm.path_open(
    filepath='//'
)

# 打开绝对路径
bpy.ops.wm.path_open(
    filepath='C:/project/blend/file.blend'
)

# 打开相对路径
bpy.ops.wm.path_open(
    filepath='./textures/'
)
```

### 打开纹理目录

```python
# 打开纹理目录
bpy.ops.wm.path_open(
    filepath='//textures/'
)

# 打开图像目录
bpy.ops.wm.path_open(
    filepath='//images/'
)
```

### 打开导出目录

```python
# 打开导出目录
bpy.ops.wm.path_open(
    filepath='//exports/'
)

# 打开渲染目录
bpy.ops.wm.path_open(
    filepath='//renders/'
)
```

### 打开项目目录

```python
# 打开blend文件目录
bpy.ops.wm.path_open(
    filepath='//'
)

# 打开上一级目录
bpy.ops.wm.path_open(
    filepath='../'
)
```

### 打开绝对路径

```python
# 打开Windows路径
bpy.ops.wm.path_open(
    filepath='C:/Users/Name/Documents/blender/'
)

# 打开网络路径
bpy.ops.wm.path_open(
    filepath='//server/share/project/'
)
```

## 实用函数

```python
def open_blend_directory():
    """打开blend文件所在目录"""
    bpy.ops.wm.path_open(filepath='//')

def open_texture_folder():
    """打开纹理文件夹"""
    texture_dir = bpy.path.abspath('//textures/')
    if bpy.path.exists(texture_dir):
        bpy.ops.wm.path_open(filepath=texture_dir)
    else:
        print(f"纹理目录不存在: {texture_dir}")

def open_render_folder():
    """打开渲染输出文件夹"""
    render_path = bpy.context.scene.render.filepath
    render_dir = bpy.path.dirname(render_path)
    if bpy.path.exists(render_dir):
        bpy.ops.wm.path_open(filepath=render_dir)
    else:
        print(f"渲染目录不存在: {render_dir}")

def open_export_folder():
    """打开导出文件夹"""
    export_dir = bpy.path.abspath('//exports/')
    if bpy.path.exists(export_dir):
        bpy.ops.wm.path_open(filepath=export_dir)
    else:
        print(f"导出目录不存在: {export_dir}")

def open_addon_folder():
    """打开插件文件夹"""
    addon_dir = bpy.utils.user_resource('SCRIPTS', path='addons')
    if bpy.path.exists(addon_dir):
        bpy.ops.wm.path_open(filepath=addon_dir)
    else:
        print(f"插件目录不存在: {addon_dir}")

def open_config_folder():
    """打开配置文件夹"""
    config_dir = bpy.utils.user_resource('CONFIG')
    if bpy.path.exists(config_dir):
        bpy.ops.wm.path_open(filepath=config_dir)
    else:
        print(f"配置目录不存在: {config_dir}")

def open_temp_folder():
    """打开临时文件夹"""
    import tempfile
    temp_dir = tempfile.gettempdir()
    if bpy.path.exists(temp_dir):
        bpy.ops.wm.path_open(filepath=temp_dir)
    else:
        print(f"临时目录不存在: {temp_dir}")

def open_user_script_folder():
    """打开用户脚本文件夹"""
    script_dir = bpy.utils.user_resource('SCRIPTS', path='startup')
    if bpy.path.exists(script_dir):
        bpy.ops.wm.path_open(filepath=script_dir)
    else:
        print(f"脚本目录不存在: {script_dir}")
```

## 常见问题排查

### 路径不存在
```python
# 检查路径
filepath = '//textures/'
print(f"路径存在: {bpy.path.exists(filepath)}")

# 获取绝对路径
abs_path = bpy.path.abspath(filepath)
print(f"绝对路径: {abs_path}")
print(f"绝对路径存在: {bpy.path.exists(abs_path)}")

# 列出目录内容
if bpy.path.exists(abs_path):
    import os
    print(f"目录内容: {os.listdir(abs_path)}")
```

### 权限问题
```python
# 检查路径权限
import os
filepath = '//exports/'
abs_path = bpy.path.abspath(filepath)

if os.access(abs_path, os.W_OK):
    print("可写")
else:
    print("不可写")
    print("请检查目录权限")

# 尝试创建目录
if not os.path.exists(abs_path):
    os.makedirs(abs_path, exist_ok=True)
    print("已创建目录")
```

### 路径格式问题
```python
# 检查路径格式
filepath = '//textures/image.png'
print(f"文件存在: {bpy.path.exists(filepath)}")

# 使用正确的路径分隔符
filepath = '//textures/image.png'
print(f"路径: {filepath}")

# 规范化路径
import os
norm_path = os.path.normpath(filepath)
print(f"规范化路径: {norm_path}")
```

### 网络路径问题
```python
# 检查网络路径
filepath = '//server/project/'
abs_path = bpy.path.abspath(filepath)
print(f"网络路径: {abs_path}")

# 检查是否可访问
import os
if os.path.exists(abs_path):
    print("网络路径可访问")
    print(f"目录内容: {os.listdir(abs_path)}")
else:
    print("网络路径不可访问")
```
