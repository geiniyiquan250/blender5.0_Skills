# bpy.ops.scene 模块

场景操作模块，用于管理Blender场景和场景数据。

## 概述

bpy.ops.scene 模块包含用于创建、删除和管理Blender场景的运算符。这些运算符控制场景的渲染设置、物理模拟设置和场景级操作。

## 常用操作

### 场景管理

```python
import bpy

# 创建新场景
bpy.ops.scene.new(type='NEW')

# 复制当前场景
bpy.ops.scene.new(type='COPY')

# 将选中的物体复制到新场景
bpy.ops.scene.new(type='LINK_OBJECTS')

# 删除场景
bpy.ops.scene.delete()

# 重命名场景
bpy.context.scene.name = "NewSceneName"
```

### 帧设置

```python
# 设置当前帧
bpy.context.scene.frame_set(50)

# 设置起始帧
bpy.context.scene.frame_start = 1

# 设置结束帧
bpy.context.scene.frame_end = 250

# 设置预览范围
bpy.context.scene.frame_preview_start = 1
bpy.context.scene.frame_preview_end = 100

# 设置步长
bpy.context.scene.frame_step = 1
```

### 单位设置

```python
# 设置单位系统
bpy.context.scene.unit_settings.system = 'METRIC'
bpy.context.scene.unit_settings.system = 'IMPERIAL'
bpy.context.scene.unit_settings.system = 'NONE'

# 设置单位精度
bpy.context.scene.unit_settings.scale_length = 1.0

# 设置角度单位
bpy.context.scene.unit_settings.system_rotation = 'DEGREES'
bpy.context.scene.unit_settings.system_rotation = 'RADIANS'
```

### 场景视口显示

```python
# 设置显示模式
bpy.context.scene.display_settings.display_device = 'sRGB'

# 设置渲染引擎
bpy.context.scene.render.engine = 'CYCLES'
bpy.context.scene.render.engine = 'EEVEE'

# 设置显示更新
bpy.context.scene.display.render_aa = 'FXAA'
bpy.context.scene.display.shadow_cube_size = '2048'
```

### 场景特效

```python
# 场景色彩管理
bpy.context.scene.view_settings.view_transform = 'Filmic'
bpy.context.scene.view_settings.look = 'High Contrast'

# 伽马校正
bpy.context.scene.view_settings.gamma = 1.0
bpy.context.scene.view_settings.exposure = 0.0
```

## 实际应用示例

### 批量设置场景帧范围

```python
def setup_scene_frame_range(start, end, step=1):
    """设置场景帧范围"""
    scene = bpy.context.scene
    scene.frame_start = start
    scene.frame_end = end
    scene.frame_step = step
    
    # 同时设置预览范围
    scene.frame_preview_start = start
    scene.frame_preview_end = end

def copy_frame_range_to_all_scenes():
    """将当前场景的帧范围复制到所有场景"""
    current_frame_range = {
        'start': bpy.context.scene.frame_start,
        'end': bpy.context.scene.frame_end,
        'step': bpy.context.scene.frame_step
    }
    
    for scene in bpy.data.scenes:
        scene.frame_start = current_frame_range['start']
        scene.frame_end = current_frame_range['end']
        scene.frame_step = current_frame_range['step']
```

### 场景批量渲染配置

```python
def setup_batch_rendering(resolution_x=1920, resolution_y=1080, engine='CYCLES'):
    """配置批量渲染"""
    for scene in bpy.data.scenes:
        scene.render.resolution_x = resolution_x
        scene.render.resolution_y = resolution_y
        scene.render.engine = engine
        
        # 设置像素比
        scene.render.pixel_aspect_x = 1.0
        scene.render.pixel_aspect_y = 1.0
        
        # 设置输出格式
        scene.render.image_settings.file_format = 'PNG'
        scene.render.image_settings.color_mode = 'RGBA'

def setup_scene_colormanagement(scene_name, view_transform='Filmic'):
    """配置场景色彩管理"""
    scene = bpy.data.scenes.get(scene_name)
    if scene:
        scene.view_settings.view_transform = view_transform
        scene.view_settings.look = 'Medium Contrast'
        scene.view_settings.exposure = 0.0
        scene.view_settings.gamma = 1.0
```

### 场景单位配置

```python
def configure_scene_units(system='METRIC', scale=1.0):
    """配置场景单位系统"""
    scene = bpy.context.scene
    scene.unit_settings.system = system
    scene.unit_settings.scale_length = scale
    
    if system == 'METRIC':
        scene.unit_settings.length_unit = 'METERS'
    elif system == 'IMPERIAL':
        scene.unit_settings.length_unit = 'FEET'

def export_scene_info(scene_name):
    """导出场景信息"""
    scene = bpy.data.scenes.get(scene_name)
    if not scene:
        return None
    
    info = {
        'name': scene.name,
        'frame_range': (scene.frame_start, scene.frame_end, scene.frame_step),
        'unit_system': scene.unit_settings.system,
        'unit_scale': scene.unit_settings.scale_length,
        'render_engine': scene.render.engine,
        'resolution': (scene.render.resolution_x, scene.render.resolution_y),
        'objects_count': len(scene.objects),
        'collections_count': len(scene.collection.children),
    }
    
    return info
```

## 使用场景

- **多场景管理**：创建、删除、复制场景
- **渲染配置**：设置渲染引擎、分辨率、输出格式
- **帧范围控制**：管理动画的时间范围
- **单位系统**：配置测量单位和精度
- **色彩管理**：设置场景的色彩显示和输出
- **批量处理**：在多个场景中执行统一设置

## 注意事项

- 场景删除会移除所有关联的数据
- 单位设置影响测量和显示
- 帧范围更改影响所有关联的动画
