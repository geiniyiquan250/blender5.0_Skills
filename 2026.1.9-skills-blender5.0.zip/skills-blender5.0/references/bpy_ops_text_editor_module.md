# bpy.ops.text_editor - 文本编辑器操作模块

Blender文本编辑器操作符，用于在Blender内置文本编辑器中管理和编辑文本。

## 概述

`bpy.ops.text_editor` 模块提供用于操作Blender内置文本编辑器的功能，包括文本选择、编辑、搜索替换、格式化等操作。

## 核心功能

### 文本选择操作

```python
import bpy

# 全选文本
bpy.ops.text_editor.select_all(action='SELECT')

# 全不选
bpy.ops.text_editor.select_all(action='DESELECT')

# 反选
bpy.ops.text_editor.select_all(action='INVERT')

# 选择行
bpy.ops.text_editor.select_line()

# 选择单词
bpy.ops.text_editor.select_word()

# 选择括号内容
bpy.ops.text_editor.select_parentheses()

# 选择到行首
bpy.ops.text_editor.select_start_of_line()

# 选择到行尾
bpy.ops.text_editor.select_end_of_line()

# 选择到文件开头
bpy.ops.text_editor.select_start_of_file()

# 选择到文件结尾
bpy.ops.text_editor.select_end_of_file()

# 扩展选择到下一个单词
bpy.ops.text_editor.select_word_end(extend=True)

# 扩展选择到上一个单词
bpy.ops.text_editor.select_word_start(extend=True)

# 扩展选择到下一行
bpy.ops.text_editor.select_next_line(extend=True)

# 扩展选择到上一行
bpy.ops.text_editor.select_prev_line(extend=True)
```

### 文本编辑操作

```python
# 复制文本
bpy.ops.text_editor.copy()

# 剪切文本
bpy.ops.text_editor.cut()

# 粘贴文本
bpy.ops.text_editor.paste()

# 删除选中
bpy.ops.text_editor.delete()

# 删除行
bpy.ops.text_editor.delete_line()

# 删除到行尾
bpy.ops.text_editor.delete_to_end_of_line()

# 删除到行首
bpy.ops.text_editor.delete_to_start_of_line()

# 删除单词
bpy.ops.text_editor.delete_word()

# 删除前一个字符
bpy.ops.text_editor.delete_previous_character()

# 删除下一个字符
bpy.ops.text_editor.delete_next_character()

# 撤销
bpy.ops.text_editor.undo()

# 重做
bpy.ops.text_editor.redo()

# 重复行
bpy.ops.text_editor.duplicate_line()

# 合并行
bpy.ops.text_editor.merge_lines()
```

### 插入操作

```python
# 插入新行
bpy.ops.text_editor.insert_line()

# 在上方插入行
bpy.ops.text_editor.insert_line_above()

# 在下方插入行
bpy.ops.text_editor.insert_line_below()

# 插入制表符
bpy.ops.text_editor.insert_tab()

# 插入日期
bpy.ops.text_editor.insert_date()

# 插入时间
bpy.ops.text_editor.insert_time()

# 插入文件路径
bpy.ops.text_editor.insert_filepath()

# 插入对象名
bpy.ops.text_editor.insert_object_name()

# 插入当前属性
bpy.ops.text_editor.insert_property()
```

### 搜索和替换

```python
# 查找文本
bpy.ops.text_editor.find(text='search_text')

# 查找下一个
bpy.ops.text_editor.find_next()

# 查找上一个
bpy.ops.text_editor.find_previous()

# 替换文本
bpy.ops.text_editor.replace(text='search_text', replace='new_text')

# 替换所有
bpy.ops.text_editor.replace_all(text='search_text', replace='new_text')

# 使用正则表达式查找
bpy.ops.text_editor.find_regex(pattern='regex_pattern')

# 高亮全部
bpy.ops.text_editor.find_all(text='search_text')

# 清除高亮
bpy.ops.text_editor.find_clear()
```

### 文本格式化

```python

# 自动缩进
bpy.ops.text_editor.indent()

# 取消缩进
bpy.ops.text_editor.unindent()

# 注释代码
bpy.ops.text_editor.comment()

# 取消注释
bpy.ops.text_editor.uncomment()

# 区块注释
bpy.ops.text_editor.block_comment()

# 取消区块注释
bpy.ops.text_editor.unblock_comment()

# 格式化代码
bpy.ops.text_editor.format()

# 整理格式
bpy.ops.text_editor.reformat()

# 转换制表符为空格
bpy.ops.text_editorTabs_to_spaces()

# 转换空格为制表符
bpy.ops.text_editor.spaces_to_tabs()

# 大写转换
bpy.ops.text_editor.upper_case()

# 小写转换
bpy.ops.text_editor.lower_case()

# 首字母大写
bpy.ops.text_editor.capitalize()

# 交换大小写
bpy.ops.text_editor.swap_case()
```

### 文本移动

```python
# 移动到行首
bpy.ops.text_editor.move_to_start_of_line()

# 移动到行尾
bpy.ops.text_editor.move_to_end_of_line()

# 移动到文件开头
bpy.ops.text_editor.move_to_start_of_file()

# 移动到文件结尾
bpy.ops.text_editor.move_to_end_of_file()

# 移动到上一个单词
bpy.ops.text_editor.move_word_left()

# 移动到下一个单词
bpy.ops.text_editor.move_word_right()

# 移动到匹配括号
bpy.ops.text_editor.move_to_matching_bracket()

# 滚动到行
bpy.ops.text_editor.scroll_to_line(line_number=100)

# 滚动到选中
bpy.ops.text_editor.scroll_to_selection()
```

### 书签和跳转

```python
# 切换书签
bpy.ops.text_editor.toggle_bookmark()

# 添加书签
bpy.ops.text_editor.add_bookmark()

# 删除书签
bpy.ops.text_editor.clear_bookmark()

# 清除所有书签
bpy.ops.text_editor.clear_all_bookmarks()

# 跳转到下一个书签
bpy.ops.text_editor.next_bookmark()

# 跳转到上一个书签
bpy.ops.text_editor.prev_bookmark()

# 添加位置标记
bpy.ops.text_editor.add_position_marker()

# 跳转到位置标记
bpy.ops.text_editor.jump_to_marker(index=0)

# 清除位置标记
bpy.ops.text_editor.clear_position_markers()
```

### 文本转换

```python
# 转换为大写
bpy.ops.text_editor.upper_case()

# 转换为小写
bpy.ops.text_editor.lower_case()

# 转换为标题
bpy.ops.text_editor.title_case()

# 转换为换行
bpy.ops.text_editor.to_endoffile_as_newline()

# 转换换行符
bpy.ops.text_editor.convert_line_endings(type='UNIX')

# 排序行
bpy.ops.text_editor.sort_lines()

# 反向排序
bpy.ops.text_editor.sort_lines_reverse()

# 移除空行
bpy.ops.text_editor.remove_empty_lines()

# 移除重复行
bpy.ops.text_editor.remove_duplicate_lines()

# 合并行
bpy.ops.text_editor.join_lines()
```

### 文件操作

```python
# 新建文本
bpy.ops.text_editor.new()

# 打开文件
bpy.ops.text_editor.open(filepath='//script.py')

# 保存文件
bpy.ops.text_editor.save()

# 另存为
bpy.ops.text_editor.save_as(filepath='//new_script.py')

# 重新加载
bpy.ops.text_editor.reload()

# 导入文本
bpy.ops.text_editor.import_()

# 导出文本
bpy.ops.text_editor.export()
```

### 编码和语言

```python
# 设置编码
bpy.ops.text_editor.set_encoding(encoding='UTF-8')

# 检测编码
bpy.ops.text_editor.detect_encoding()

# 设置语言
bpy.ops.text_editor.set_language(language='Python')

# 设置语法高亮
bpy.ops.text_editor.set_syntax(syntax='Python')

# 设置换行方式
bpy.ops.text_editor.set_line_wrapping(wrap=True)

# 设置自动换行
bpy.ops.text_editor.set_auto_wrap()
```

## 实用函数

```python
def get_selected_text():
    """获取选中的文本"""
    text = bpy.context.space_data
    return text.selected_lines

def get_current_line_text():
    """获取当前行文本"""
    text = bpy.context.space_data
    return text.current_line.body

def get_line_number():
    """获取当前行号"""
    return bpy.context.space_data.current_line_index

def replace_in_file(old_text, new_text):
    """替换文件中的文本"""
    bpy.ops.text_editor.select_all(action='SELECT')
    bpy.ops.text_editor.replace(text=old_text, replace=new_text)

def insert_at_cursor(text):
    """在光标位置插入文本"""
    bpy.ops.text_editor.insert(text)

def get_text_stats():
    """获取文本统计信息"""
    text = bpy.context.space_data
    return {
        'lines': len(text.lines),
        'characters': sum(len(l.body) for l in text.lines),
        'words': sum(len(l.body.split()) for l in text.lines)
    }

def format_python_code():
    """格式化Python代码"""
    bpy.ops.text_editor.select_all(action='SELECT')
    bpy.ops.text_editor.format()

def toggle_bookmarks_all():
    """切换所有行的书签"""
    for i in range(len(bpy.context.space_data.lines)):
        bpy.ops.text_editor.move(line=i)
        bpy.ops.text_editor.toggle_bookmark()

def find_in_all_open():
    """在所有打开的文本中查找"""
    search_term = 'search_text'
    results = []
    for text in bpy.data.texts:
        if search_term in text.as_string():
            results.append(text.name)
    return results
```

## 常见问题排查

### 文本不显示
```python
# 检查当前文本
print(f"当前文本: {bpy.context.space_data.text}")

# 检查行数
print(f"行数: {len(bpy.context.space_data.lines)}")

# 重新加载
bpy.ops.text_editor.reload()

# 检查显示设置
text = bpy.context.space_data
print(f"显示行号: {text.show_line_numbers}")
print(f"显示空白: {text.show_whitespace}")
```

### 选择操作问题
```python
# 清除选择
bpy.ops.text_editor.select_all(action='DESELECT')

# 重置选择
bpy.ops.text_editor.move_to_start_of_file()
bpy.ops.text_editor.select_end_of_file()

# 检查选择模式
print(f"选择模式: {bpy.context.space_data.select_end}")
```

### 编码问题
```python
# 检查当前编码
print(f"当前编码: {bpy.context.space_data.encoding}")

# 尝试重新打开
bpy.ops.text_editor.reload()

# 设置正确编码
bpy.ops.text_editor.set_encoding(encoding='UTF-8')
```
